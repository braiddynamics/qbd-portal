# Replication Suite: Multiway Causal Invariance & Entropic Obstructions

This replication archive provides the complete formal verification proofs, high-performance simulation engine, Python reference auditor, and test suite for the paper:
**Pre-Geometric Dimensional Reduction and Multiway Causal Invariance: Thermodynamic and Combinatorial Obstructions to Continuum Spacetime**

---

## Structure
- `COMPUTATIONAL-SUPPLEMENT.md`: Comprehensive standalone computational guide and full code supplement.
- `causal_invariance_auditor.py`: Dual-mode Python reference auditor containing exact multiway graph canonicalization, Lovász homomorphism density evaluators, spectral moment computers, Fiedler algebraic connectivity analyzers, and explicit Wolfram hypergraph substitution rule auditors.
- `cpp/causal_invariance_engine.cpp`: High-performance C++20 multiway enumerator (exact 128-bit bitset arithmetic up to $N=8$, $8.95 \times 10^{23}$ paths) and parallel Monte Carlo percolation sampler ($N=9 \dots 16$ at $>3.1 \times 10^6$ traj/sec).
- `cpp/Makefile`: Makefile for building the C++20 engine with `-O3 -std=c++20 -pthread -march=native`.
- `cpp/dimensional_reduction_cpp_benchmark.csv`: Benchmark output data across scales $N=5 \dots 16$.
- `tests/test_causal_invariance_auditor.py`: 30 unit, integration, and C++ engine tests verifying graph canonicalization, analytical combinatorics, hypergraph replacement, gauge-invariant spectra, Lean kernel checks, and C++ engine numerical equivalence.
- `formal-proofs/CausalInvariance.lean`: Formal machine-checked proofs in Lean 4 (7 sections, 0 sorry, 0 custom axioms) verifying:
  1. ARS Core & Strong Normalization
  2. Formal Causal Posets & DAG Isomorphisms
  3. Counterexample $\mathcal{M}_1$ (Causal Invariance Without Confluence)
  4. Counterexample $\mathcal{M}_2$ (Confluence Without Causal Invariance)
  5. Trace Non-Injectivity & History-to-Macrostate Information Erasure
  6. Asynchronous Causal Cycles & Non-Acyclicity
  7. Adjoint Generator Kernel 1-Dimensionality (Chapman-Enskog Solvability Failure)
- `figures/`: High-resolution figures generated from numerical evaluations.

---

## Replication Instructions

### 1. Python Environment & Pytest Suite
Requirements: Python 3.8+ (`pytest`, `numpy`, `jaxtyping`, `matplotlib`)
```bash
python -m pytest tests/test_causal_invariance_auditor.py -v
```

### 2. C++20 High-Performance Engine
Requirements: C++20 compiler (`g++` 11+ or `clang++` 13+)
```bash
# Smoke test
g++ -O3 -std=c++20 -pthread -march=native cpp/causal_invariance_engine.cpp -o cpp/causal_invariance_engine
./cpp/causal_invariance_engine --smoke-test

# Full multi-scale benchmark
./cpp/causal_invariance_engine --benchmark
```

### 3. Formal Verification (Lean 4)
Requirements: Lean 4 toolchain (`leanprover/lean4:v4.33.1`)
```bash
lean formal-proofs/CausalInvariance.lean
```
