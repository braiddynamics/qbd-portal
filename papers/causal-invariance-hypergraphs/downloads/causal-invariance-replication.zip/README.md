﻿# Replication Suite: Information-Theoretic Constraints on Finite-Time Causal Invariance

This replication archive provides the complete formal verification proofs, simulation engine, and test suite for the paper:
**Information-Theoretic Constraints on Finite-Time Causal Invariance and Pre-Geometric Dimensional Reduction in Discrete Hypergraph Models**

---

## Structure
- simulation.py: Dual-mode Python simulation suite containing exact multiway graph canonicalization, Lovász homomorphism density evaluators, spectral moment computers, Fiedler algebraic connectivity analyzers, and explicit Wolfram hypergraph substitution rule auditors.
- 	ests/test_simulation.py: 28 unit and integration tests verifying graph canonicalization, analytical combinatorics, hypergraph replacement, gauge-invariant spectra, and formal verification kernel checks.
- CausalInvariance.lean: Formal machine-checked proofs in Lean 4 verifying the logical independence of ARS confluence and causal DAG poset isomorphism (0 sorry, 0 custom axioms).
- igures/: High-resolution figures generated from numerical evaluations.

---

## Replication Instructions

### 1. Python Environment & Tests
Requirements: Python 3.8+ (pytest, 
umpy, scipy)
`ash
python -m pytest tests/test_simulation.py -v
`

### 2. Formal Verification (Lean 4)
Requirements: Lean 4 toolchain (leanprover/lean4:v4.33.1)
`ash
lean CausalInvariance.lean
`
