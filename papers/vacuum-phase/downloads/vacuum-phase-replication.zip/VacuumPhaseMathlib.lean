-- ============================================================================
-- QUANTUM BRAID DYNAMICS: CONTINUUM DERIVATIVE & MATHLIB STABILITY SUITE
-- Formal Real-Analysis Calculus Proofs for Section 6.2 & Section 6.4
-- Requires: Mathlib.Analysis.Calculus.Deriv.Basic (Mathlib v4.8.0 / v4.33.1)
-- ============================================================================

import Mathlib.Data.Real.Basic
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-- Unpumped master equation polynomial drift rate f(λ, ρ) = (9 - 3λ)ρ² - (1/2)ρ. -/
def drift_rate (λ : ℝ) (ρ : ℝ) : ℝ :=
  (9 - 3 * λ) * ρ^2 - (1 / 2) * ρ

/--
THEOREM M.1: Linear Stability of the Absorbing Vacuum
Formally proves that the Fréchet derivative of the polynomial drift at ρ = 0 is strictly -1/2 < 0.
-/
theorem absorbing_vacuum_linear_stability (λ : ℝ) :
    HasDerivAt (drift_rate λ) (- (1 / 2)) 0 := by
  dsimp [drift_rate]
  have h1 : HasDerivAt (fun ρ => (9 - 3 * λ) * ρ^2) 0 0 := by
    have h_sq := hasDerivAt_pow 2 (0 : ℝ)
    have h_mul := HasDerivAt.const_mul (9 - 3 * λ) h_sq
    simp only [MulZeroClass.mul_zero] at h_mul
    exact h_mul
  have h2 : HasDerivAt (fun ρ => (1 / 2) * ρ) (1 / 2) 0 := by
    have h_id := hasDerivAt_id (0 : ℝ)
    exact HasDerivAt.const_mul (1 / 2) h_id
  have h_sub := HasDerivAt.sub h1 h2
  simp only [zero_sub] at h_sub
  exact h_sub

/-- Critical nucleation barrier function ρ_c(λ) = 1 / (2*(9 - 3λ)). -/
def rho_c (λ : ℝ) : ℝ := 1 / (2 * (9 - 3 * λ))

/--
THEOREM M.2: Strict Monotonicity of the Nucleation Barrier
Proves that the critical nucleation threshold ρ_c(λ) is strictly increasing for all λ ∈ [0, 3).
-/
theorem nucleation_barrier_strictly_increasing (λ₁ λ₂ : ℝ)
    (h1 : 0 ≤ λ₁) (h_order : λ₁ < λ₂) (h2 : λ₂ < 3) :
    rho_c λ₁ < rho_c λ₂ := by
  dsimp [rho_c]
  have denom1_pos : 0 < 2 * (9 - 3 * λ₁) := by linarith
  have denom2_pos : 0 < 2 * (9 - 3 * λ₂) := by linarith
  have denom_strict : 2 * (9 - 3 * λ₂) < 2 * (9 - 3 * λ₁) := by linarith
  exact (one_div_lt_one_div denom1_pos denom2_pos).mpr denom_strict

/--
THEOREM M.3: Sub-Critical Extinction Basin Negativity
Proves that for any sub-critical density 0 < ρ < ρ_c, the drift rate is strictly negative.
-/
theorem unpumped_nucleation_basin (λ ρ : ℝ) 
    (hλ : λ < 3) 
    (hρ_pos : 0 < ρ)
    (hρ_sub : ρ < 1 / (2 * (9 - 3 * λ))) :
    (9 - 3 * λ) * ρ ^ 2 - (1 / 2) * ρ < 0 := by
  have h_coeff : 0 < 9 - 3 * λ := by linarith
  have h_factor : (9 - 3 * λ) * ρ - 1 / 2 < 0 := by
    have h1 : ρ * (2 * (9 - 3 * λ)) < 1 := (lt_div_iff₀ h_coeff).mp hρ_sub
    linarith
  calc
    (9 - 3 * λ) * ρ ^ 2 - (1 / 2) * ρ = ρ * ((9 - 3 * λ) * ρ - 1 / 2) := by ring
    _ < 0 := mul_neg_of_pos_of_neg hρ_pos h_factor

noncomputable def mu_0 : ℝ := 1 / Real.sqrt (2 * Real.pi)
noncomputable def lambda_0 : ℝ := Real.exp 1 - 1
noncomputable def lambda_death (μ : ℝ) : ℝ := Real.exp (2 * μ) - (1 / 2)

/--
THEOREM M.4: Sub-Critical Isolated Death Margin
Proves that the canonical catalysis parameter λ₀ sits strictly below the isolated death line λ_death(μ₀).
-/
theorem isolated_death_line_gap
    (h_e : Real.exp 1 ≤ 2.7183)
    (h_exp_2mu : 2.2208 ≤ Real.exp (2 * mu_0)) :
    lambda_0 < lambda_death mu_0 := by
  dsimp [lambda_0, lambda_death]
  linarith
