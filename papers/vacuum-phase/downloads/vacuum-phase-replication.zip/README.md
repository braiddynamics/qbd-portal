# Quantum Braid Dynamics (QBD) — Vacuum Phase Replication Bundle

This package contains the complete, self-contained replication suite for the preprint:
**"A Constrained Stochastic Rewrite System on Timestamped DAGs: Microscopic Rules, Absorbing-State Dynamics, and Finite-N Quasi-Stationary Ensembles"** (Braid Dynamics Group, 2026).

Permanent Archive (Zenodo): https://zenodo.org/records/21423007
Online Portal & Interactive Reader: https://braiddynamics.com/papers/vacuum-phase

---

## 1. Quickstart & Verification Commands

### A. Lean 4 Formal Kernel Check (No Sorry or Custom Axiom Declarations)
Requires Lean 4 (`v4.33.1` or compatible):
```bash
lean VacuumPhase.lean
```

### B. Automated Pytest Test Suite (8 Test Modules, 126+ Checks)
Requires Python >= 3.8, `networkx`, `pytest`, `numpy`:
```bash
python -m pytest tests/
```

### C. Reference Simulation Engine CLI
```bash
# Display analytical reference priors (Table 1)
python vacuum_phase_engine.py --priors

# Run property-based move grammar invariant verification
python vacuum_phase_engine.py --test-invariants

# Run canonical design point ensemble (Table 3)
python vacuum_phase_engine.py --design-point --runs 100

# Run canonical slice sweep along lambda (Table 4)
python vacuum_phase_engine.py --canonical-slice --runs 100

# Run asymptotic scar & degree saturation diagnostics (Table 5)
python vacuum_phase_engine.py --scar-diagnostics --runs 100

# Run full 132-point parameter sweep (Table 2)
python vacuum_phase_engine.py --sweep --runs 20
```

---

## 2. Package Manifest

- `vacuum_phase_engine.py`: Single-file, standalone reference simulation engine.
- `VacuumPhase.lean`: Standalone Lean 4 Core kernel, including graph-changing diagnostic transport and immutable occurrence records. Legacy results retain their stated hypotheses; standard logical axioms are used where reported by `#print axioms`.
- `VacuumPhaseMathlib.lean`: Continuous real-analysis calculus companion (Fréchet derivatives).
- `lakefile.toml` & `lean-toolchain`: Lean 4 package build configuration.
- `p_surv_N100_design.csv`: Raw ensemble data for design point.
- `tests/`: 8 dedicated property-based and unit test suites.
- `calculations/`: Standalone agreed-repair calculations published in Supplement D.8, with their recorded outputs. These validate the analytic identities rather than replace their proofs.
