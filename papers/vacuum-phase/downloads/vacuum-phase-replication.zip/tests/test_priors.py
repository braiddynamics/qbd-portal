"""
Unit tests for Table 1 Analytical Reference Priors and Symmetries.
Preprint Paper: vacuum-phase.md (Sections 4 and 6.2, Propositions 4.1–4.5, Theorems 9.1–9.3).
"""

import math
import pytest
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import compute_analytical_priors


def test_table1_constitutive_priors_exact_values():
    """
    Verifies that compute_analytical_priors() produces exact mathematical values
    matching Table 1 in vacuum-phase.md.
    """
    priors = compute_analytical_priors()

    # Prop 4.1: Critical vacuum temperature T_c = ln 2 (one bit of Landauer entropy)
    assert math.isclose(priors["T_c"], math.log(2.0), rel_tol=1e-12)
    assert math.isclose(priors["T_c"], 0.6931471805599453, rel_tol=1e-9)

    # Prop 4.3: Dimensionless friction mu_0 = 1 / sqrt(2*pi) (1D integer lattice MaxEnt vacuum projector)
    assert math.isclose(priors["mu_0"], 1.0 / math.sqrt(2.0 * math.pi), rel_tol=1e-12)
    assert math.isclose(priors["mu_0"], 0.3989422804014327, rel_tol=1e-9)

    # Prop 4.2: Catalysis constant lambda_0 = e - 1 (1-nat Arrhenius defect release)
    assert math.isclose(priors["lambda_0"], math.e - 1.0, rel_tol=1e-12)
    assert math.isclose(priors["lambda_0"], 1.718281828459045, rel_tol=1e-9)

    # Prop 4.4: Geometric self-energy eps_geo = ln(2)/3 (k_deg=3 vertex channel equipartition)
    assert math.isclose(priors["eps_geo"], math.log(2.0) / 3.0, rel_tol=1e-12)
    assert math.isclose(priors["eps_geo"], 0.23104906018664842, rel_tol=1e-9)

    # Prop 4.5: Theoretical permittivity Lambda_theory = 2^-6 (6-port triad simplex routing)
    assert math.isclose(priors["Lambda_theory"], 1.0 / 64.0, rel_tol=1e-12)
    assert math.isclose(priors["Lambda_theory"], 0.015625, rel_tol=1e-9)

    # Section 6.2: Unpumped critical nucleation barrier rho_c = 1 / (24 - 6e)
    assert math.isclose(priors["rho_c"], 1.0 / (24.0 - 6.0 * math.e), rel_tol=1e-12)
    assert math.isclose(priors["rho_c"], 0.130033786184283, rel_tol=1e-6)

    # Section 6.2.1: Continuum saddle-node bifurcation boundary mu_crit = (9 - 3*lambda_0)^2 / 108
    expected_mu_crit = ((9.0 - 3.0 * (math.e - 1.0)) ** 2) / 108.0
    assert math.isclose(priors["mu_crit"], expected_mu_crit, rel_tol=1e-12)
    assert math.isclose(priors["mu_crit"], 0.13690012260485737, rel_tol=1e-6)


def test_isolated_death_line_and_gap():
    """
    Verifies the isolated death line formula lambda_death(mu) = e^(2*mu) - 0.5 (Definition 3.2),
    its value at mu_0, and the positive stability margin Delta_lambda > 0.
    """
    mu_0 = 1.0 / math.sqrt(2.0 * math.pi)
    lambda_0 = math.e - 1.0

    # Death line locus where uncapped Q_del(2) = 1.0
    lambda_death_mu0 = math.exp(2.0 * mu_0) - 0.5
    assert math.isclose(lambda_death_mu0, math.exp(2.0 / math.sqrt(2.0 * math.pi)) - 0.5, rel_tol=1e-12)
    assert math.isclose(lambda_death_mu0, 1.72084, rel_tol=1e-4)

    # Narrow gap Delta lambda = lambda_death - lambda_0 > 0
    delta_lambda = lambda_death_mu0 - lambda_0
    assert delta_lambda > 0.0
    assert math.isclose(delta_lambda, (math.exp(2.0 / math.sqrt(2.0 * math.pi)) - 0.5) - (math.e - 1.0), rel_tol=1e-12)
    assert math.isclose(delta_lambda, 0.00256, rel_tol=1e-2)

    # Single-cycle uncapped deletion probability Q_del(s=2)
    Q_del_2 = 0.5 * (1.0 + 2.0 * lambda_0) * math.exp(-2.0 * mu_0)
    expected_Q_del_2 = 0.5 * (2.0 * math.e - 1.0) * math.exp(-2.0 / math.sqrt(2.0 * math.pi))
    assert math.isclose(Q_del_2, expected_Q_del_2, rel_tol=1e-12)
    assert math.isclose(Q_del_2, 0.99885, rel_tol=1e-4)

    # Single-tick unassisted survival probability
    p_surv_1 = 1.0 - Q_del_2
    assert math.isclose(p_surv_1, 1.0 - expected_Q_del_2, rel_tol=1e-12)
    assert math.isclose(p_surv_1, 1.15e-3, rel_tol=1e-2)

    # Characteristic decay lifetime tau
    tau = 1.0 / math.log(1.0 / p_surv_1)
    assert math.isclose(tau, 0.14775, rel_tol=1e-3)


def test_nucleation_barrier_monotonicity():
    """
    Verifies Theorem 9.2: rho_c(lambda) = 1 / (2*(9 - 3*lambda)) is strictly
    increasing for all lambda in [0, 3).
    """
    def rho_c_func(lam: float) -> float:
        return 1.0 / (2.0 * (9.0 - 3.0 * lam))

    lambdas = [0.0, 0.5, 1.0, 1.5, math.e - 1.0, 2.0, 2.5, 2.8]
    barriers = [rho_c_func(l) for l in lambdas]

    # Verify strictly monotonic increase
    for i in range(len(barriers) - 1):
        assert barriers[i] < barriers[i + 1]

    # Check derivative analytically: d(rho_c)/d(lambda) = 3 / (2*(9-3*lambda)^2) > 0
    for l in lambdas:
        deriv = 3.0 / (2.0 * ((9.0 - 3.0 * l) ** 2))
        assert deriv > 0.0
