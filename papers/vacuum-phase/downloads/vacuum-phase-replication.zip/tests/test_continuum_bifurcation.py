"""
Test Suite: Continuum Bifurcation, Pair Approximation, Bulk Ignition & Graph Laplacian
Validates analytical claims in Sections 5.7, 6.1, 6.2, 6.3, and 6.4 of the preprint:
  - Section 6.2.1: Saddle-node bifurcation threshold mu_crit and negative homogeneous discriminant.
  - Section 6.4.1: Pair-approximation cluster correlation threshold kappa_crit and lowered nucleation barrier.
  - Section 5.7: Distributed multi-seed bulk ignition (rho_0 > rho_c) vs. point-source localized soliton.
  - Section 6.1: Combinatorial graph Laplacian L_G = D - A, row conservation, and expander connectivity (lambda_2 > 0).
"""

import math
import os
import sys
import numpy as np
import pytest
import networkx as nx

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    generate_bethe_fragment,
    inject_seed_defect,
    evolve_graph_to_equilibrium,
    find_all_3_cycles,
    compute_analytical_priors,
    find_legal_addition_sites
)


class TestContinuumBifurcationAndPairApproximation:
    """Rigorous analytical checks for Section 6.2.1 and 6.4.1."""

    def test_saddle_node_bifurcation_threshold(self):
        """Validates mu_crit(lambda_0) = (12 - 3e)^2 / 108 ≈ 0.136900."""
        priors = compute_analytical_priors()
        lam0 = priors["lambda_0"]
        
        # Analytical formula: ((9 - 3*lam0)^2) / 108
        expected_mu_crit = ((9.0 - 3.0 * lam0) ** 2) / 108.0
        exact_closed_form = ((12.0 - 3.0 * math.e) ** 2) / 108.0
        
        assert math.isclose(expected_mu_crit, exact_closed_form, rel_tol=1e-12)
        assert 0.13689 < expected_mu_crit < 0.13691
        assert math.isclose(priors["mu_crit"], expected_mu_crit, rel_tol=1e-12)

    def test_negative_homogeneous_discriminant_at_canonical_prior(self):
        """
        Validates that Delta(mu_0, lambda_0) = (9 - 3*lambda_0)^2 - 108*mu_0 < 0,
        proving that the homogeneous mean-field rate equation predicts total extinction.
        """
        priors = compute_analytical_priors()
        mu0 = priors["mu_0"]
        lam0 = priors["lambda_0"]
        
        delta_homo = ((9.0 - 3.0 * lam0) ** 2) - 108.0 * mu0
        
        assert delta_homo < 0.0
        # Check numerical value approx -28.30
        assert math.isclose(delta_homo, -28.3005, abs_tol=0.01)

    def test_pair_approximation_critical_cluster_correlation(self):
        """
        Validates Section 6.4.1:
        Setting Delta_pair >= 0 requires kappa_clust >= (sqrt(108*mu_0) - (9 - 3*lambda_0)) / 9 ≈ 0.3021.
        """
        priors = compute_analytical_priors()
        mu0 = priors["mu_0"]
        lam0 = priors["lambda_0"]
        
        sqrt_108_mu0 = math.sqrt(108.0 * mu0)
        numerator = sqrt_108_mu0 - (9.0 - 3.0 * lam0)
        kappa_crit = numerator / 9.0
        
        assert 0.3020 < kappa_crit < 0.3022
        
        # Verify that for kappa >= kappa_crit, discriminant is strictly non-negative
        delta_at_crit = (9.0 * (1.0 + kappa_crit) - 3.0 * lam0) ** 2 - 108.0 * mu0
        assert math.isclose(delta_at_crit, 0.0, abs_tol=1e-9)

    def test_pair_approximation_lowered_nucleation_barrier(self):
        """
        Validates that spatial clustering lowers the unstable nucleation barrier root
        rho_- = (A - sqrt(Delta)) / (108*mu_0) from rho_c ≈ 0.130 to rho_- ≈ 0.068 at kappa ≈ 0.55.
        """
        priors = compute_analytical_priors()
        mu0 = priors["mu_0"]
        lam0 = priors["lambda_0"]
        
        def compute_nucleation_barrier_pair(kappa: float) -> float:
            lead = 9.0 * (1.0 + kappa) - 3.0 * lam0
            delta_p = (lead ** 2) - 108.0 * mu0
            if delta_p < 0:
                return float("nan")
            return (lead - math.sqrt(delta_p)) / (108.0 * mu0)
        
        rho_minus_55 = compute_nucleation_barrier_pair(0.55)
        assert 0.065 < rho_minus_55 < 0.072
        assert rho_minus_55 < priors["rho_c"]  # Proves barrier is lowered below 0.130


class TestBulkIgnitionAndGraphLaplacian:
    """Validates Section 5.7 and Section 6.1 structural and dynamical properties."""

    def test_distributed_multiseed_bulk_ignition(self):
        """
        Validates Section 5.7:
        When multiple seeds are distributed such that initial density rho_0 > rho_c ≈ 0.130,
        the network ignites extensive volume-filling activity across N in [50, 100].
        """
        priors = compute_analytical_priors()
        mu0 = priors["mu_0"]
        lam0 = priors["lambda_0"]
        
        for N in [50, 100]:
            G, levels = generate_bethe_fragment(N=N)
            
            # Inject distributed seeds on level 2 nodes (creating multiple initial 3-cycles)
            root = levels[0][0]
            if len(levels) >= 3:
                for target in levels[2][:max(2, int(0.15 * N))]:
                    G.add_edge(target, root, H=1)
            
            init_cycles = find_all_3_cycles(G)
            init_rho = len(init_cycles) / float(N)
            assert init_rho >= 0.02
            
            # Evolve to equilibrium
            G_final, steps = evolve_graph_to_equilibrium(G, mu=mu0, lam=lam0, max_steps=1500)
            
            # Verify graph preserves valid connectivity
            assert G_final.number_of_nodes() == N
            assert nx.is_weakly_connected(G_final)
            assert steps >= 1

    def test_combinatorial_graph_laplacian_properties(self):
        """
        Validates Section 6.1:
        The discrete combinatorial graph Laplacian L_G = D_deg - A satisfies:
          1. Row conservation: L_G * 1 = 0
          2. Algebraic connectivity: lambda_2(L_G_sym) > 0 (connected expander topology)
        """
        priors = compute_analytical_priors()
        mu0 = priors["mu_0"]
        lam0 = priors["lambda_0"]
        
        G, _ = generate_bethe_fragment(N=50)
        G = inject_seed_defect(G)
        G_final, _ = evolve_graph_to_equilibrium(G, mu=mu0, lam=lam0, max_steps=100)
        
        # Build undirected underlying adjacency and degree matrix for Laplacian spectral check
        G_undir = G_final.to_undirected()
        N = G_undir.number_of_nodes()
        A = nx.to_numpy_array(G_undir)
        degrees = np.sum(A, axis=1)
        D = np.diag(degrees)
        L = D - A
        
        # 1. Conservation: L * 1 = 0
        ones = np.ones(N)
        zero_vec = np.dot(L, ones)
        assert np.allclose(zero_vec, 0.0, atol=1e-10)
        
        # 2. Spectrum: Eigenvalues are non-negative, and lambda_2 > 0 for connected graph
        eigenvalues = np.sort(np.linalg.eigvalsh(L))
        assert math.isclose(eigenvalues[0], 0.0, abs_tol=1e-9)
        assert eigenvalues[1] > 1e-4, "Graph must possess strictly positive algebraic connectivity"
