"""
Unit tests for First-Tick Burst & Single-Cycle Kinetics.
Preprint Paper: vacuum-phase.md (Section 3, Corollaries 3.3 & 3.4, Proposition 3.1).
"""

import math
import random
import pytest
import networkx as nx
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    compute_analytical_priors,
    generate_bethe_fragment,
    inject_seed_defect,
    find_all_3_cycles,
    find_legal_addition_sites,
    build_stress_map,
    execute_parallel_tick,
)


def test_proposition_3_1_isolated_cycle_deletion_rate_monte_carlo():
    """
    Proposition 3.1: An isolated 3-cycle has self-stress s_del = 2.
    At (mu_0, lambda_0), Q_del(2) = 0.5 * (1 + 2*lambda_0) * exp(-2*mu_0) ≈ 0.99885.
    We verify this rate across 10,000 independent Bernoulli trials.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]

    # Isolated 3-cycle graph
    G_isolated = nx.DiGraph([(0, 1, {'H': 1}), (1, 2, {'H': 2}), (2, 0, {'H': 3})])
    cycles = find_all_3_cycles(G_isolated)
    assert len(cycles) == 1

    stress_map = build_stress_map(cycles)
    cycle = cycles[0]
    cycle_nodes = {x for edge in cycle for x in edge}
    s_del = max(0, sum(stress_map.get(x, 0) for x in cycle_nodes) - 1)
    assert s_del == 2

    Q_del = min(1.0, 0.5 * (1.0 + lam * s_del) * math.exp(-mu * s_del))
    expected_Q_del = 0.5 * (2.0 * math.e - 1.0) * math.exp(-2.0 / math.sqrt(2.0 * math.pi))
    assert math.isclose(Q_del, expected_Q_del, rel_tol=1e-12)
    assert math.isclose(Q_del, 0.99885, rel_tol=1e-4)

    # Monte Carlo verification
    num_trials = 10000
    random.seed(42)
    deletions = sum(1 for _ in range(num_trials) if random.random() < Q_del)
    empirical_rate = deletions / num_trials

    # 3.5-sigma binomial confidence interval
    se = math.sqrt(Q_del * (1.0 - Q_del) / num_trials)
    assert abs(empirical_rate - Q_del) < 3.5 * se


@pytest.mark.parametrize("N", [50, 100, 200])
def test_corollary_3_4_first_tick_autocatalytic_burst(N):
    """
    Corollary 3.4: On tick 1 from seed defect:
    1. Every tree-supported 2-path has s_add = 0 and accepts with P_acc(0) = exp(-mu * 0) = 1.0.
    2. The resulting burst creates a dense 3-cycle cluster whose density rho(t=1) jumps
       well above the unpumped critical nucleation barrier rho_c ≈ 0.130.
    3. Burst density is scale-invariant across N.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]
    rho_c = priors["rho_c"]  # ≈ 0.13003

    random.seed(42)
    G, levels = generate_bethe_fragment(N)
    G = inject_seed_defect(G, levels)

    # Initial state: exactly 1 seed cycle
    assert len(find_all_3_cycles(G)) == 1

    # Check addition sites at t=0 before tick 1
    legal_additions = find_legal_addition_sites(G)
    cycles = find_all_3_cycles(G)
    stress_map = build_stress_map(cycles)

    # Verify that the overwhelming majority of candidate 2-paths have s_add = 0
    zero_stress_sites = 0
    for (u, v), H_new, (node_v, node_w, node_u) in legal_additions:
        s_add = stress_map.get(node_v, 0) + stress_map.get(node_w, 0) + stress_map.get(node_u, 0)
        if s_add == 0:
            zero_stress_sites += 1
            P_acc = math.exp(-mu * s_add)
            assert math.isclose(P_acc, 1.0)

    assert zero_stress_sites > 0

    # Execute tick 1
    G_tick1, active = execute_parallel_tick(G.copy(), mu, lam)
    assert active is True

    n3_tick1 = len(find_all_3_cycles(G_tick1))
    rho_tick1 = n3_tick1 / float(N)

    # Must exceed the unpumped nucleation barrier rho_c ≈ 0.130
    assert rho_tick1 > rho_c, f"Burst density {rho_tick1:.4f} failed to jump barrier {rho_c:.4f}"
    # Scale invariance: burst density is substantial for all N
    assert rho_tick1 >= 0.50
