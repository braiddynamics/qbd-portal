"""
Unit tests for Microscopic Move Grammar & Causal Integrity Filters.
Preprint Paper: vacuum-phase.md (Sections 2.5–2.7, Section 2.2.1 Bowtie Paradox, Axioms 1–3).
"""

import math
import pytest
import networkx as nx
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    is_permissible_puc,
    pre_check_aec,
    find_all_3_cycles,
    find_legal_addition_sites,
    build_stress_map,
)


def test_parent_uniqueness_condition_puc():
    """
    Section 2.5.2 (PUC): Candidate 2-path v -> w -> u is valid iff
    (v,u) not in E, and no alternative path v -> x -> u exists (x != w).
    """
    # Valid unique 2-path: 0 -> 1 -> 2
    G = nx.DiGraph([(0, 1, {'H': 0}), (1, 2, {'H': 0})])
    assert is_permissible_puc(G, u=2, v=0, w=1) is True

    # Violation 1: Direct bypass edge (0 -> 2) exists
    G_bypass = nx.DiGraph([(0, 1, {'H': 0}), (1, 2, {'H': 0}), (0, 2, {'H': 0})])
    assert is_permissible_puc(G_bypass, u=2, v=0, w=1) is False

    # Violation 2: Alternative 2-path 0 -> 3 -> 2 exists
    G_multi = nx.DiGraph([(0, 1, {'H': 0}), (1, 2, {'H': 0}),
                          (0, 3, {'H': 0}), (3, 2, {'H': 0})])
    assert is_permissible_puc(G_multi, u=2, v=0, w=1) is False

    # Violation 3: Reverse edge (2 -> 0) already exists
    G_rev = nx.DiGraph([(0, 1, {'H': 0}), (1, 2, {'H': 0}), (2, 0, {'H': 1})])
    assert is_permissible_puc(G_rev, u=2, v=0, w=1) is True


def test_aec_timestamp_monotonicity_pre_check():
    """
    Section 2.5.3 (AEC): A proposed return edge (u, v) with timestamp H_new
    is rejected if there is an existing strictly monotone path from v to u
    of length <= L_cut ending with H < H_new.
    """
    # Case 1: Monotone path 0 -> 1 -> 2 with H(0,1)=1 < H(1,2)=2.
    # Proposed return edge (2, 0) with H_new = 3 creates an acausal monotone loop 1 < 2 < 3.
    # AEC must REJECT.
    G_monotone = nx.DiGraph([(0, 1, {'H': 1}), (1, 2, {'H': 2})])
    assert pre_check_aec(G_monotone, u=2, v=0, H_new=3) is False

    # Case 2: Non-monotone path on tree with uniform height H=0:
    # 0 -> 1 -> 2 with H(0,1)=0 and H(1,2)=0 (0 not < 0).
    # AEC must ACCEPT (Proposition 3.4 first-tick ignition).
    G_tree = nx.DiGraph([(0, 1, {'H': 0}), (1, 2, {'H': 0})])
    assert pre_check_aec(G_tree, u=2, v=0, H_new=1) is True

    # Case 3: Decreasing timestamp path:
    # 0 -> 1 -> 2 with H(0,1)=2, H(1,2)=1 (2 not < 1).
    # AEC must ACCEPT because it does not form a strictly increasing causal loop.
    G_dec = nx.DiGraph([(0, 1, {'H': 2}), (1, 2, {'H': 1})])
    assert pre_check_aec(G_dec, u=2, v=0, H_new=3) is True


def test_bowtie_paradox_counter_model():
    """
    Section 2.2.1: Bowtie Paradox Counter-Model.
    Graph V={A,B,C,D} with edges A->B (H=1), B->C (H=2), C->D (H=3), D->A (H=4).
    Satisfies Axiom 1 (irreflexive, asymmetric) and Axiom 2 (no 2-path violations).
    AEC must detect that A <= C (1 < 2) and C <= A (3 < 4) would create an acausal cycle.
    """
    # Construct paths A -> B -> C and check proposed closure C -> D -> A
    G = nx.DiGraph([
        (0, 1, {'H': 1}),  # A -> B
        (1, 2, {'H': 2}),  # B -> C
        (2, 3, {'H': 3}),  # C -> D
    ])
    # Proposing return edge D -> A (3 -> 0) with H_new = 4
    # Existing monotone path 0 -> 1 -> 2 -> 3 has edge heights 1 < 2 < 3.
    # AEC must REJECT the closure because 3 < H_new=4.
    assert pre_check_aec(G, u=3, v=0, H_new=4) is False


def test_local_stress_functional_isolated_and_overlapping():
    """
    Section 2.6 & Theorem 8.1:
    - Isolated 3-cycle yields s_del = (1+1+1) - 1 = 2 exactly.
    - Two 3-cycles sharing 1 edge (4 nodes: 2 shared, 2 unshared):
      Shared nodes have stress=2, unshared have stress=1.
      s_del for each cycle = (2 + 2 + 1) - 1 = 4.
    """
    # Isolated 3-cycle
    G_isolated = nx.DiGraph([(0, 1, {'H': 1}), (1, 2, {'H': 2}), (2, 0, {'H': 3})])
    cycles_iso = find_all_3_cycles(G_isolated)
    assert len(cycles_iso) == 1

    stress_map_iso = build_stress_map(cycles_iso)
    assert stress_map_iso == {0: 1, 1: 1, 2: 1}

    # Isolated deletion self-stress
    cycle_nodes_iso = {x for edge in cycles_iso[0] for x in edge}
    s_del_iso = max(0, sum(stress_map_iso.get(x, 0) for x in cycle_nodes_iso) - 1)
    assert s_del_iso == 2  # Theorem 8.1 exact proof

    # Overlapping 3-cycles sharing edge (1, 2)
    # Cycle 1: 0 -> 1 -> 2 -> 0
    # Cycle 2: 3 -> 1 -> 2 -> 3
    G_overlap = nx.DiGraph([
        (0, 1, {'H': 1}), (1, 2, {'H': 2}), (2, 0, {'H': 3}),
        (3, 1, {'H': 1}), (2, 3, {'H': 3}),
    ])
    cycles_ov = find_all_3_cycles(G_overlap)
    assert len(cycles_ov) == 2

    stress_map_ov = build_stress_map(cycles_ov)
    assert stress_map_ov[1] == 2  # shared node 1
    assert stress_map_ov[2] == 2  # shared node 2
    assert stress_map_ov[0] == 1  # unshared node 0
    assert stress_map_ov[3] == 1  # unshared node 3

    for cycle in cycles_ov:
        nodes = {x for edge in cycle for x in edge}
        s_del = max(0, sum(stress_map_ov.get(x, 0) for x in nodes) - 1)
        assert s_del == (2 + 2 + 1) - 1 == 4
