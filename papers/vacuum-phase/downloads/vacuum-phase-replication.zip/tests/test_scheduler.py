"""
Unit tests for 4-Step Parallel Execution Scheduler & Lean 4 Mirrored Invariants.
Preprint Paper: vacuum-phase.md (Section 2.8, Lemma 2.1, Corollary 2.2, Lean 4 Theorems 4.1–6.1).
"""

import math
import random
import pytest
import networkx as nx
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    compute_analytical_priors,
    generate_bethe_fragment,
    inject_seed_defect,
    find_all_3_cycles,
    find_legal_addition_sites,
    build_stress_map,
    execute_parallel_tick,
    evolve_graph_to_equilibrium,
)


def test_lemma_2_1_deterministic_move_disjointness():
    """
    Lemma 2.1 & Lean Theorem 4.3: A_edges and D are strictly disjoint:
    A_edges ∩ D = ∅. No newly inserted edge is deleted within the same tick.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]

    G, levels = generate_bethe_fragment(100)
    G = inject_seed_defect(G, levels)

    # Run for 25 parallel ticks and verify disjointness at every single tick
    for _ in range(25):
        cycles = find_all_3_cycles(G)
        stress_map = build_stress_map(cycles)
        legal_additions = find_legal_addition_sites(G)

        A = set()
        for (u, v), H_new, (node_v, node_w, node_u) in legal_additions:
            s_add = stress_map.get(node_v, 0) + stress_map.get(node_w, 0) + stress_map.get(node_u, 0)
            if random.random() < math.exp(-mu * s_add):
                A.add(((u, v), H_new))

        D = set()
        for cycle in cycles:
            cycle_nodes = {x for edge in cycle for x in edge}
            s_del = max(0, sum(stress_map.get(x, 0) for x in cycle_nodes) - 1)
            Q_del = min(1.0, 0.5 * (1.0 + lam * s_del) * math.exp(-mu * s_del))
            if random.random() < Q_del:
                D.add(random.choice(cycle))

        A_edges = {e for e, _ in A}

        # Mathematical Invariants
        assert A_edges.isdisjoint(D), f"Violation of Lemma 2.1: A_edges and D overlap: {A_edges & D}"
        assert D.issubset(set(G.edges())), f"Violation: Deletion proposed for non-existent edge: {D - set(G.edges())}"
        assert A_edges.isdisjoint(set(G.edges())), f"Violation: Addition proposed for existing edge: {A_edges & set(G.edges())}"

        # Execute mutations
        A_filtered = {((u, v), H_new) for (u, v), H_new in A if (v, u) not in A_edges and u != v}
        for (u, v), H_new in A_filtered:
            G.add_edge(u, v, H=H_new)
        for u, v in D:
            if G.has_edge(u, v):
                G.remove_edge(u, v)


def test_corollary_2_2_reciprocal_proposal_elimination():
    """
    Corollary 2.2: The Step 3 merge filter strictly eliminates simultaneous
    reciprocal additions (u, v) and (v, u), preserving strict irreflexivity and asymmetry.
    """
    A = {
        ((1, 2), 2),
        ((2, 1), 2),  # Reciprocal pair with (1, 2)
        ((3, 4), 1),  # Valid addition
        ((5, 5), 1),  # Self-loop
    }
    A_edges = {e for e, _ in A}

    # Apply Step 3 Filter
    A_filtered = {((u, v), H_new) for (u, v), H_new in A if (v, u) not in A_edges and u != v}

    filtered_edges = {e for e, _ in A_filtered}
    assert filtered_edges == {(3, 4)}
    assert (1, 2) not in filtered_edges
    assert (2, 1) not in filtered_edges
    assert (5, 5) not in filtered_edges


def test_homeostatic_stall_idempotent_fixed_point():
    """
    Theorem 6.1 (absorbing_state_stationary):
    When a tick yields zero additions and zero deletions (A = ∅ ∧ D = ∅),
    the graph is in homeostatic equilibrium, and U(G) = G identically.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]

    G, levels = generate_bethe_fragment(50)
    G = inject_seed_defect(G, levels)

    G_final, steps = evolve_graph_to_equilibrium(G, mu, lam, max_steps=500)
    assert steps <= 500

    # Test that applying one more tick produces active=False and unchanged graph
    G_next, active = execute_parallel_tick(G_final.copy(), mu, lam)
    if not active:
        assert set(G_next.edges()) == set(G_final.edges())


def test_terminal_dag_acyclicity_on_extinction():
    """
    Verifies that on extinction (when 3-cycles vanish), the final scarred
    graph G_final is certified to be a Directed Acyclic Graph (DAG).
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], 4.0

    for seed in range(5):
        random.seed(seed * 100)
        G, levels = generate_bethe_fragment(50)
        G = inject_seed_defect(G, levels)
        G_final, _ = evolve_graph_to_equilibrium(G, mu, lam, max_steps=500)

        n3 = len(find_all_3_cycles(G_final))
        if n3 == 0:
            assert nx.is_directed_acyclic_graph(G_final), f"Extinct graph at seed {seed} is not a DAG!"
