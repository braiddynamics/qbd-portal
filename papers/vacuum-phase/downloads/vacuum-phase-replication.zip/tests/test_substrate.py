"""
Unit tests for Pre-Geometric Combinatorial Substrate and Boundary Physics.
Preprint Paper: vacuum-phase.md (Sections 2.1–2.4, Proposition 2.3.1, Axioms 1 & 2).
"""

import pytest
import networkx as nx
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    generate_bethe_fragment,
    inject_seed_defect,
    find_all_3_cycles,
)


@pytest.mark.parametrize("N", [3, 4, 10, 25, 50, 100, 250, 500])
def test_proposition_2_3_1_exact_leaf_boundary_theorem(N):
    """
    Proposition 2.3.1: On any binary Bethe fragment of size N >= 3,
    the number of leaf boundary vertices L satisfies L = (N + 2) // 2.
    """
    G, levels = generate_bethe_fragment(N)
    assert G.number_of_nodes() == N

    leaves = [v for v in G.nodes() if G.out_degree(v) == 0]
    expected_leaves = (N + 2) // 2
    assert len(leaves) == expected_leaves, f"Failed for N={N}: got {len(leaves)}, expected {expected_leaves}"

    # Verify boundary fraction approaches 50% as N grows (for N>=3, L/N in [0.50, 0.75])
    boundary_ratio = len(leaves) / float(N)
    assert 0.50 <= boundary_ratio <= 0.75
    if N >= 100:
        assert 0.50 <= boundary_ratio <= 0.55


@pytest.mark.parametrize("N", [10, 50, 100])
def test_bethe_fragment_coordination_degree_constraints(N):
    """
    Verifies the discrete coordination structure:
    - Root (node 0): in-degree 0, out-degree 3
    - Internal nodes: in-degree 1, out-degree 2 (total coordination k_deg = 3)
    - Leaf nodes: in-degree 1, out-degree 0
    - All edges initialized with timestamp H = 0
    """
    G, levels = generate_bethe_fragment(N)

    # Root checks
    root = 0
    assert G.in_degree(root) == 0
    assert G.out_degree(root) == 3

    # Internal and leaf checks
    for v in G.nodes():
        if v == root:
            continue
        assert G.in_degree(v) == 1, f"Node {v} has in-degree {G.in_degree(v)} != 1"
        out_d = G.out_degree(v)
        assert out_d in (0, 2), f"Node {v} has invalid out-degree {out_d}"
        if out_d == 2:
            assert (G.in_degree(v) + out_d) == 3  # Internal coordination degree = 3

    # Timestamps all H=0
    for u, v, d in G.edges(data=True):
        assert d.get("H", -1) == 0


def test_pristine_substrate_acyclicity_and_bipartiteness():
    """
    Verifies that the initial Bethe fragment G_0 contains zero 3-cycles,
    is depth-parity bipartite, and is a strict DAG.
    """
    G, _ = generate_bethe_fragment(100)

    # Zero 3-cycles
    cycles = find_all_3_cycles(G)
    assert len(cycles) == 0

    # Directed Acyclic Graph
    assert nx.is_directed_acyclic_graph(G)

    # Undirected representation is a tree (bipartite)
    G_undir = G.to_undirected()
    assert nx.is_tree(G_undir)
    assert nx.is_bipartite(G_undir)


def test_seed_defect_injection():
    """
    Verifies Section 2.4: Seed injection S_seed adds single return edge (u, v)
    with timestamp H=1, breaking bipartiteness and creating exactly one 3-cycle.
    """
    G, levels = generate_bethe_fragment(100)
    G = inject_seed_defect(G, levels)

    # Exactly 1 directed 3-cycle created
    cycles = find_all_3_cycles(G)
    assert len(cycles) == 1

    # Injected edge has H=1
    injected_cycle_edges = cycles[0]
    injected_edges_with_H1 = [e for e in injected_cycle_edges if G.edges[e].get("H") == 1]
    assert len(injected_edges_with_H1) == 1

    # Axiom 1: Strict Irreflexivity & Asymmetry
    for u, v in G.edges():
        assert u != v  # No self-loops
        assert not G.has_edge(v, u) or (u, v) in injected_cycle_edges  # Directed 3-cycle has no reciprocal pairs
