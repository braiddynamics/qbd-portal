"""
Unit tests for Homeostatic Stall Census, QSD Moments, and Reproducibility.
Preprint Paper: vacuum-phase.md (Section 5, Tables 2–4, p_surv_N100_design.csv).
"""

import math
import random
import pytest
import statistics
import pandas as pd
import sys
import os

# Add parent directory (papers-drafts/vacuum-phase) to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    compute_analytical_priors,
    generate_bethe_fragment,
    inject_seed_defect,
    find_all_3_cycles,
    evolve_graph_to_equilibrium,
    compute_qsd_moments,
    _worker_trajectory,
)


def test_statistical_moment_estimator_synthetic():
    """
    Verifies that compute_qsd_moments() correctly calculates unconditioned
    vs conditioned moments on known synthetic distributions.
    """
    # Create synthetic array with 70 zeros and 30 positive values
    n3_synthetic = [0] * 70 + [10] * 30
    N = 100

    moments = compute_qsd_moments(n3_synthetic, N)

    assert moments["n"] == 100.0
    assert moments["n_surv"] == 30.0
    assert math.isclose(moments["p_surv"], 0.30)
    assert math.isclose(moments["mean_n3_all"], 3.0)
    assert math.isclose(moments["mean_rho_all"], 0.03)
    assert math.isclose(moments["median_rho_all"], 0.0)  # Zero-inflated

    # Conditioned QSD moments (survivors only)
    assert math.isclose(moments["mean_n3_qsd"], 10.0)
    assert math.isclose(moments["mean_rho_qsd"], 0.10)
    assert math.isclose(moments["median_rho_qsd"], 0.10)


def test_p_surv_n100_design_csv_exact_numbers():
    """
    Verifies the exact metrics from the benchmark dataset p_surv_N100_design.csv:
    - Exactly 27 survivors out of 100 runs (p_surv = 0.270 ± 0.044)
    - Conditioned QSD mean cycle count <N3>_QSD = 9.19
    - Conditioned QSD mean density <rho>_QSD = 0.0919 ± 0.0119
    - Conditioned QSD median density = 0.080
    - Unconditioned median density = 0.000
    - Observed range: [2, 22]
    """
    csv_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'p_surv_N100_design.csv'))
    assert os.path.exists(csv_path), f"Benchmark file {csv_path} not found"

    df = pd.read_csv(csv_path, comment='#')
    assert len(df) == 100

    n3_vals = list(df['n3_final'])
    moments = compute_qsd_moments(n3_vals, N=100)

    assert int(moments["n_surv"]) == 27
    assert math.isclose(moments["p_surv"], 0.270, rel_tol=1e-3)
    assert math.isclose(moments["median_rho_all"], 0.000)
    assert math.isclose(moments["mean_n3_qsd"], 9.185185, rel_tol=1e-3)
    assert math.isclose(moments["mean_rho_qsd"], 0.09185, rel_tol=1e-3)
    assert math.isclose(moments["median_rho_qsd"], 0.080, rel_tol=1e-3)
    assert moments["n3_min_qsd"] == 2.0
    assert moments["n3_max_qsd"] == 22.0


def test_canonical_point_ensemble_fast_reproducibility():
    """
    Runs a fast 20-trajectory ensemble at (mu_0, lambda_0) with fixed seeds
    to verify that the active QSD attractor is populated consistently:
    - Survival fraction p_surv > 0
    - Zero-inflated median rho = 0.0
    - Active survivors populate QSD density rho ≈ 0.06 - 0.14
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]
    N = 100

    n3_finals = []
    for i in range(20):
        res = _worker_trajectory((i + 1, N, mu, lam, 42 * 10007 + i * 31))
        n3_finals.append(res["n3_final"])

    moments = compute_qsd_moments(n3_finals, N)

    assert moments["p_surv"] >= 0.10
    assert moments["median_rho_all"] == 0.0  # Zero inflation confirmed
    if moments["n_surv"] > 0:
        assert 0.05 <= moments["mean_rho_qsd"] <= 0.15


def test_deterministic_seed_trajectory_reproducibility():
    """
    Verifies that running with an identical random seed produces bit-for-bit
    identical graph mutations, stall step counts, and final cycle counts.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]
    seed = 123456

    # Run 1
    random.seed(seed)
    G1, levels1 = generate_bethe_fragment(50)
    G1 = inject_seed_defect(G1, levels1)
    G1_final, steps1 = evolve_graph_to_equilibrium(G1, mu, lam, max_steps=500)
    n3_1 = len(find_all_3_cycles(G1_final))

    # Run 2
    random.seed(seed)
    G2, levels2 = generate_bethe_fragment(50)
    G2 = inject_seed_defect(G2, levels2)
    G2_final, steps2 = evolve_graph_to_equilibrium(G2, mu, lam, max_steps=500)
    n3_2 = len(find_all_3_cycles(G2_final))

    assert steps1 == steps2
    assert n3_1 == n3_2
    assert set(G1_final.edges()) == set(G2_final.edges())
