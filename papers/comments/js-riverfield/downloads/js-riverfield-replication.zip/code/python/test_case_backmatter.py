#!/usr/bin/env python3
"""
Automated Verification Suite for Relativistic Quantum Mechanics Case Analysis

Test Inventory:
  1. test_wavepacket_asymptotic_convergence: Verifies that the second-order Klein-Gordon
     wavepacket envelope converges to the Schrödinger solution at O(c^-2) and backward
     antiparticle power decouples at O(c^-4).
  2. test_gauge_propagator_radiation: Verifies that the causal retarded Green's function
     yields non-zero radiation flux matching dipole theory, whereas a delta contact propagator
     yields identically zero flux outside the source.
  3. test_symbolic_poincare_algebra: Verifies the 10-generator Poincaré Lie algebra, static
     structure constants, and vanishing Jacobi identity across all 120 triples.
  4. test_symbolic_dirac_hypersurface_algebra: Verifies that ADM hypersurface deformation brackets
     depend dynamically on the phase-space 3-metric, certifying an open Lie algebroid.
  5. test_uv_scaling_divergence: Verifies that 3D equal-time foliation mode sums and 4D covariant
     functional determinants exhibit identical leading quartic ultraviolet divergence ~ Λ⁴.
  6. test_tachyonic_cauchy_continuum: Verifies unconditional discrete instability (λ₊ > 1) and
     O(Δt²) continuum convergence to the hyperbolic runaway cosh(μ t).
"""

import os
import sys
import pytest
import numpy as np


# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Ensure local directory is in sys.path regardless of execution CWD
current_dir = os.path.abspath(os.path.dirname(__file__))
if current_dir not in sys.path:
    sys.path.insert(0, current_dir)

import wavepacket_convergence
import gauge_propagator_simulation
import symbolic_constraint_algebra
import plot_uv_scaling
import tachyonic_cauchy_continuum

def test_wavepacket_asymptotic_convergence():
    slope_env, r2_env, slope_anti, r2_anti = wavepacket_convergence.run_simulation()
    # 1. Envelope converges to Schrödinger at O(c^-2)
    assert -2.15 <= slope_env <= -1.85, f"Envelope slope {slope_env:.4f} deviates from -2.0"
    assert r2_env >= 0.99, f"Envelope R^2 {r2_env:.4f} too low"
    # 2. Antiparticle branch power is suppressed at O(c^-4)
    assert -4.20 <= slope_anti <= -3.80, f"Antiparticle slope {slope_anti:.4f} deviates from -4.0"
    assert r2_anti >= 0.99, f"Antiparticle R^2 {r2_anti:.4f} too low"

def test_gauge_propagator_radiation():
    p_std, p_rf = gauge_propagator_simulation.run_simulation()
    # Standard QED must match theoretical dipole radiation: P_theory = ω² / (12π c) = 0.2387
    p_theory = (3.0**2) / (12.0 * np.pi * 1.0)
    assert np.isclose(p_std, p_theory, rtol=0.02), f"Expected standard radiation power near {p_theory:.4f}, got {p_std:.4f}"
    # Riverfield contact propagator must have strictly zero radiation
    assert np.abs(p_rf) < 1e-15, f"Expected Riverfield radiated power to be near machine zero (< 1e-15), got {p_rf}"

def test_symbolic_poincare_algebra():
    is_poincare_valid = symbolic_constraint_algebra.audit_poincare_algebra()
    assert is_poincare_valid is True

def test_symbolic_dirac_hypersurface_algebra():
    has_metric_dep = symbolic_constraint_algebra.audit_dirac_hypersurface_algebra()
    assert has_metric_dep is True

def test_uv_scaling_divergence():
    csv_path = plot_uv_scaling.get_default_csv_path()
    assert os.path.exists(csv_path), "C++ benchmark data missing! Compile and run lattice_uv_divergence first."
    slope_3D, slope_4D, r3, r4 = plot_uv_scaling.compute_scaling(csv_path)
    assert r3**2 >= 0.99, f"3D R^2 {r3**2} too low"
    assert r4**2 >= 0.99, f"4D R^2 {r4**2} too low"
    assert 3.85 <= slope_3D <= 4.15, f"3D slope {slope_3D} deviates from quartic"
    assert 3.85 <= slope_4D <= 4.15, f"4D slope {slope_4D} deviates from quartic"
    
    # Execute plot rendering to verify pipeline artifacts
    plot_uv_scaling.plot_uv_scaling(csv_path)
    out_dir = os.path.join(plot_uv_scaling.get_case_dir(), 'figures')
    pdf_file = os.path.join(out_dir, 'uv_scaling_comparison.pdf')
    png_file = os.path.join(out_dir, 'uv_scaling_comparison.png')
    assert os.path.exists(pdf_file) and os.path.getsize(pdf_file) > 1000, "Rendered PDF figure missing or corrupted"
    assert os.path.exists(png_file) and os.path.getsize(png_file) > 1000, "Rendered PNG figure missing or corrupted"

    # Test that missing CSV raises FileNotFoundError
    with pytest.raises(FileNotFoundError):
        plot_uv_scaling.compute_scaling(csv_path + ".nonexistent")

def test_tachyonic_cauchy_continuum():
    results = tachyonic_cauchy_continuum.run_simulation()
    assert len(results) > 0
    
    # 1. Multiplier must strictly exceed 1 for all dt (unconditional instability)
    for dt, res in results.items():
        assert res['lambda_plus'] > 1.0
    
    # 2. Tight tolerance on effective growth rate for fine resolution (error < 0.01%)
    assert np.isclose(results[0.001]['eff_rate'], 1.5, rtol=1e-4), f"Growth rate error: {results[0.001]['eff_rate']}"
    
    # 3. Verify true O(dt^2) error convergence rate: 10x smaller dt reduces error by ~100x
    err_dt_01 = results[0.1]['rel_err']
    err_dt_001 = results[0.01]['rel_err']
    convergence_ratio = err_dt_01 / err_dt_001
    assert 70.0 <= convergence_ratio <= 130.0, f"Expected O(dt^2) error reduction (~100x), got {convergence_ratio:.2f}x"

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

