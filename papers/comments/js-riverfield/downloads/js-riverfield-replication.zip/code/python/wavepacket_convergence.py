#!/usr/bin/env python3
"""
Wavepacket Asymptotic Convergence Suite (Klein-Gordon -> Schrödinger as c -> ∞)

Demonstrates the rigorous asymptotic reduction of the second-order hyperbolic
Klein-Gordon field equation to the first-order parabolic Schrödinger equation.
Evaluates the exact L² norm difference between the rest-mass phase-factored
Klein-Gordon wavepacket and the non-relativistic Schrödinger wavepacket.

Outputs:
  - figures/wavepacket_convergence.pdf
  - figures/wavepacket_convergence.png
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import linregress

# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def get_case_dir():
    curr = os.path.abspath(os.path.dirname(__file__))
    while curr and curr != os.path.dirname(curr):
        if os.path.exists(os.path.join(curr, 'figures')) and os.path.exists(os.path.join(curr, 'code')):
            return curr
        curr = os.path.dirname(curr)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))


def run_simulation(initial_data='foldy_wouthuysen'):
    """
    Simulates the true 2nd-order hyperbolic Klein-Gordon Cauchy initial value problem:
      ∂ₜ² ϕ_k + c²(k² + m²c²) ϕ_k = 0
    with physical Foldy-Wouthuysen positive-energy Cauchy data:
      ϕ_k(0) = ψ₀(k),  ∂ₜϕ_k(0) = -i m c² ψ₀(k)
      
    Decomposes into forward-propagating A(k) and backward-propagating antiparticle B(k) branches:
      A(k) = 1/2 (1 + mc²/Ω_k) ψ₀(k)
      B(k) = 1/2 (1 - mc²/Ω_k) ψ₀(k)
      
    Proves:
      1. Antiparticle branch power |B(k)|² is suppressed as O(c⁻⁴).
      2. Envelope ψ(x, t) = exp(i m c² t) ϕ(x, t) converges to Schrödinger at O(c⁻²).
    """
    # Simulation Parameters (natural units: ħ = 1, m = 1)
    m = 1.0
    x0 = 0.0
    k0 = 2.0
    sigma = 1.0
    t_final = 1.5

    # Spatial Grid
    N = 2048
    L = 60.0
    x = np.linspace(-L / 2, L / 2, N, endpoint=False)
    dx = x[1] - x[0]
    k = 2 * np.pi * np.fft.fftfreq(N, d=dx)

    # Initial Gaussian Wavepacket
    norm_const = (2 * np.pi * sigma**2)**(-0.25)
    psi0 = norm_const * np.exp(-(x - x0)**2 / (4 * sigma**2)) * np.exp(1j * k0 * x)
    psi0_k = np.fft.fft(psi0)

    # Schrödinger Evolution (Exact spectral propagator)
    omega_schrodinger = (k**2) / (2 * m)
    psi_schrodinger_k = psi0_k * np.exp(-1j * omega_schrodinger * t_final)
    psi_schrodinger = np.fft.ifft(psi_schrodinger_k)

    # Sweep speed of light c
    c_values = np.array([2.0, 3.0, 5.0, 8.0, 12.0, 20.0, 35.0, 60.0, 100.0, 200.0, 500.0])
    l2_errors = []
    anti_fractions = []
    sample_profiles = {}

    for c in c_values:
        # Relativistic Klein-Gordon dispersion: Ω_k = c √(k² + m² c²)
        omega_kg = c * np.sqrt(k**2 + (m * c)**2)
        
        if initial_data == 'foldy_wouthuysen':
            # Foldy-Wouthuysen Cauchy data: ϕ(0) = ψ₀, ∂ₜϕ(0) = -i m c² ψ₀
            A_k = 0.5 * (1.0 + (m * c**2) / omega_kg) * psi0_k
            B_k = 0.5 * (1.0 - (m * c**2) / omega_kg) * psi0_k
        elif initial_data == 'positive_projected':
            # Pure positive-frequency projection: B_k ≡ 0
            A_k = psi0_k
            B_k = np.zeros_like(psi0_k)
        elif initial_data == 'static_rest':
            # Unprojected rest data: ∂ₜϕ(0) = 0 => equal split A = B = 1/2
            A_k = 0.5 * psi0_k
            B_k = 0.5 * psi0_k
        else:
            raise ValueError(f"Unknown initial_data mode: {initial_data}")

        # Integrated backward antiparticle power fraction: ∫ |B(k)|² dk / ∫ |ψ₀(k)|² dk
        p_anti = np.sum(np.abs(B_k)**2) / np.sum(np.abs(psi0_k)**2)
        anti_fractions.append(p_anti)
        
        # Exact solution to 2nd-order wave equation:
        # Factoring out rest-mass phase exp(i m c² t):
        # ψ_envelope(x, t) = F⁻¹ [ A_k exp(-i(Ω - mc²)t) + B_k exp(+i(Ω + mc²)t) ]
        phi_envelope_k = (A_k * np.exp(-1j * (omega_kg - m * c**2) * t_final) +
                          B_k * np.exp(+1j * (omega_kg + m * c**2) * t_final))
        psi_kg = np.fft.ifft(phi_envelope_k)
        
        # Compute L² norm difference against Schrödinger: ||ψ_envelope - ψ_Schr||_L2
        error = np.sqrt(np.sum(np.abs(psi_kg - psi_schrodinger)**2) * dx)
        l2_errors.append(error)
        
        if c in [2.0, 5.0, 20.0, 100.0]:
            sample_profiles[c] = np.abs(psi_kg)**2

    l2_errors = np.array(l2_errors)
    anti_fractions = np.array(anti_fractions)

    # Linear regression in log-log space for L2 envelope error
    log_c = np.log10(c_values)
    log_err = np.log10(l2_errors)
    slope, intercept, r_value, p_value, std_err = linregress(log_c, log_err)

    # Linear regression for antiparticle power suppression
    if initial_data == 'foldy_wouthuysen':
        slope_anti, int_anti, r_anti, _, _ = linregress(log_c, np.log10(anti_fractions))
    else:
        slope_anti, r_anti = 0.0, 0.0

    print(f"[Wavepacket 2nd-Order Cauchy Convergence ({initial_data})]")
    print(f"  Envelope L² Error Slope: {slope:.4f} (Expected: -2.0000, R² = {r_value**2:.6f})")
    if initial_data == 'foldy_wouthuysen':
        print(f"  Antiparticle Power Slope: {slope_anti:.4f} (Expected: -4.0000, R² = {r_anti**2:.6f})")

    # Generate Publication Figure (Vertical Layout)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6.5, 8.0), dpi=300)

    # Panel 1: Wavepacket Profiles
    ax1.plot(x, np.abs(psi_schrodinger)**2, 'k-', lw=2.5, label='Schrödinger ($c \\to \\infty$)')
    colors = ['#d95f02', '#7570b3', '#1b9e77', '#e7298a']
    for idx, (c, profile) in enumerate(sample_profiles.items()):
        ax1.plot(x, profile, '--', color=colors[idx], lw=1.5, label=f'2nd-Order KG ($c={int(c)}$)')

    ax1.set_xlim(-15, 25)
    ax1.set_xlabel('Spatial Coordinate $x$', fontsize=11)
    ax1.set_ylabel('Probability Density $|\\psi(x, t_f)|^2$', fontsize=11)
    ax1.set_title(f'(a) 2nd-Order KG Wavepacket Evolution ($t_f = {t_final}$)', fontsize=12, fontweight='bold')
    ax1.legend(loc='upper right', frameon=True, framealpha=0.9, fontsize=9.5)
    ax1.grid(True, ls=':', alpha=0.6)

    # Panel 2: Log-Log Error Convergence & Antiparticle Suppression
    ax2.loglog(c_values, l2_errors, 'o-', color='#1f78b4', lw=2.0, ms=6,
               label=f'Envelope $L^2$ Error: $\\mathcal{{O}}(c^{{{slope:.2f}}})$ ($R^2={r_value**2:.4f}$)')
    
    if initial_data == 'foldy_wouthuysen':
        ax2.loglog(c_values, anti_fractions, 's--', color='#e31a1c', lw=1.8, ms=6,
                   label=f'Backward Antiparticle Power: $\\mathcal{{O}}(c^{{{slope_anti:.2f}}})$ ($R^2={r_anti**2:.4f}$)')

    # Reference slopes
    c_ref = np.linspace(c_values[0], c_values[-1], 100)
    ref_c2 = l2_errors[0] * (c_ref / c_values[0])**(-2)
    ax2.loglog(c_ref, ref_c2, 'k:', lw=1.2, alpha=0.7, label='Theoretical $\\mathcal{O}(c^{-2})$ Error Scaling')

    ax2.set_xlabel('Speed of Light $c$ (Relative Scale)', fontsize=11)
    ax2.set_ylabel('Metric Magnitude', fontsize=11)
    ax2.set_title('(b) Foldy--Wouthuysen Decoupling & Error Convergence', fontsize=12, fontweight='bold')
    ax2.legend(loc='lower left', frameon=True, framealpha=0.9, fontsize=9.5)
    ax2.grid(True, which='both', ls=':', alpha=0.6)

    plt.tight_layout()

    output_dir = os.path.join(get_case_dir(), 'figures')
    os.makedirs(output_dir, exist_ok=True)
    pdf_path = os.path.join(output_dir, 'wavepacket_convergence.pdf')
    png_path = os.path.join(output_dir, 'wavepacket_convergence.png')

    plt.savefig(pdf_path, bbox_inches='tight')
    plt.savefig(png_path, bbox_inches='tight')
    plt.close()

    print(f"  Saved figure: {pdf_path}")
    print(f"  Saved figure: {png_path}")

    return slope, r_value**2, slope_anti, r_anti**2

if __name__ == '__main__':
    run_simulation()
