#!/usr/bin/env python3
"""
Tachyonic Cauchy Problem: Continuum Limit & Discrete Convergence Suite

Analyzes the continuum limit of the discrete central-difference Cauchy recurrence
∂ₜ² x = μ² x as time-step Δt → 0 (with dimensionless parameter K = (μ Δt)² → 0),
demonstrating rigorous convergence to the continuous tachyonic runaway x(t) = cosh(μ t).

Analytical properties verified:
  1. Characteristic equation: λ² - (2+K)λ + 1 = 0
     Roots: λ₊ = 1 + K/2 + √(K + K²/4) > 1 for all K > 0.
  2. Asymptotic expansion: λ₊ = 1 + μ Δt + (μ Δt)²/2 + O(Δt³) = exp(μ Δt) + O(Δt³).
  3. Continuous limit: (λ₊)^(t/Δt) -> exp(μ t) as Δt -> 0.
  4. Global instability: Even from rest (x(0) = 1, v(0) = 0), the mode explodes
     exponentially as x(t) ~ (1/2) exp(μ t) for any μ > 0.

Outputs:
  - figures/tachyonic_cauchy_runaway.pdf
  - figures/tachyonic_cauchy_runaway.png
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def get_case_dir():
    curr = os.path.abspath(os.path.dirname(__file__))
    while curr and curr != os.path.dirname(curr):
        if os.path.exists(os.path.join(curr, 'figures')) and os.path.exists(os.path.join(curr, 'code')):
            return curr
        curr = os.path.dirname(curr)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

def run_simulation():
    # Parameters
    mu = 1.5          # Tachyonic growth rate (mass scale)
    t_max = 5.0       # Final time
    
    # Time steps to test across multiple orders of magnitude
    dt_values = [0.2, 0.1, 0.05, 0.01, 0.001]
    
    # Continuous reference solution
    t_fine = np.linspace(0, t_max, 1000)
    x_exact = np.cosh(mu * t_fine)
    v_exact = mu * np.sinh(mu * t_fine)
    
    # Storage for discrete runs
    results = {}
    
    for dt in dt_values:
        K = (mu * dt)**2
        # Exact discrete multiplier
        lambda_plus = 1.0 + K / 2.0 + np.sqrt(K + (K**2) / 4.0)
        
        N_steps = int(np.round(t_max / dt))
        t_arr = np.linspace(0, N_steps * dt, N_steps + 1)
        
        x_discrete = np.zeros(N_steps + 1)
        x_discrete[0] = 1.0
        # Second-order initial step from rest: x_1 = x_0 + 1/2 (mu dt)^2 x_0 = 1 + K/2
        x_discrete[1] = 1.0 + 0.5 * K
        
        for n in range(1, N_steps):
            x_discrete[n + 1] = (2.0 + K) * x_discrete[n] - x_discrete[n - 1]
            
        # Error at t_max
        exact_at_t = np.cosh(mu * t_arr[-1])
        abs_err = np.abs(x_discrete[-1] - exact_at_t)
        rel_err = abs_err / exact_at_t
        
        # Discrete growth rate: (1/dt) * ln(lambda_plus)
        eff_growth_rate = np.log(lambda_plus) / dt
        
        results[dt] = {
            't': t_arr,
            'x': x_discrete,
            'K': K,
            'lambda_plus': lambda_plus,
            'eff_rate': eff_growth_rate,
            'abs_err': abs_err,
            'rel_err': rel_err
        }

    # Verify key mathematical properties:
    # 1. λ₊ > 1 strictly for all K > 0 (unconditional discrete runaway)
    for dt, res in results.items():
        assert res['lambda_plus'] > 1.0, f"Expected λ₊ > 1, got {res['lambda_plus']} for dt={dt}"
    
    # 2. Strict rate matching for fine resolution (error < 0.01% at dt=0.001)
    assert np.isclose(results[0.001]['eff_rate'], mu, rtol=1e-4), f"Effective rate {results[0.001]['eff_rate']} deviates from mu={mu}"
    
    # 3. True second-order O(dt^2) error scaling: 10x smaller dt yields ~100x error reduction
    err_dt_01 = results[0.1]['rel_err']
    err_dt_001 = results[0.01]['rel_err']
    convergence_ratio = err_dt_01 / err_dt_001
    assert 70.0 <= convergence_ratio <= 130.0, f"Expected O(dt^2) error reduction (~100x), got {convergence_ratio:.2f}x"

    # Generate Figure (Vertical Layout)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(6.5, 8.0))
    
    # Panel A: Trajectory comparison
    ax1.plot(t_fine, x_exact, 'k-', linewidth=2.2, label=r'Continuous Exact: $\cosh(\mu t)$', zorder=5)
    
    colors = ['#d95f02', '#7570b3', '#1b9e77', '#e7298a']
    for dt, col in zip([0.2, 0.1, 0.05, 0.01], colors):
        res = results[dt]
        # Plot every few points for readability
        step = max(1, len(res['t']) // 40)
        ax1.plot(res['t'][::step], res['x'][::step], 'o', color=col, markersize=4,
                 label=rf'Discrete $\Delta t = {dt}$ ($K = {res["K"]:.4f}$)')
        
    ax1.set_yscale('log')
    ax1.set_xlabel(r'Time $t$ [$\mu^{-1}$]', fontsize=11)
    ax1.set_ylabel(r'Amplitude $x(t)$ (Log Scale)', fontsize=11)
    ax1.set_title(r'(a) Tachyonic Mode Explosion from Rest ($x(0)=1, \dot{x}(0)=0$)', fontsize=12, fontweight='bold')
    ax1.grid(True, which='both', linestyle='--', alpha=0.5)
    ax1.legend(loc='upper left', frameon=True, fontsize=9.5)
    
    # Panel B: Multiplier convergence and truncation error
    dt_fine = np.logspace(-4, -0.5, 200)
    K_fine = (mu * dt_fine)**2
    lam_fine = 1.0 + K_fine / 2.0 + np.sqrt(K_fine + (K_fine**2) / 4.0)
    rate_fine = np.log(lam_fine) / dt_fine
    
    ax2.plot(dt_fine, rate_fine, 'b-', linewidth=2, label=r'Discrete Multiplier $\frac{1}{\Delta t} \ln \lambda_+(\Delta t)$')
    ax2.axhline(mu, color='red', linestyle='--', linewidth=1.5, label=rf'Continuous Rate $\mu = {mu}$')
    
    # Overlay tested points
    for dt in dt_values:
        res = results[dt]
        ax2.plot(dt, res['eff_rate'], 'ro', markersize=6)
        
    ax2.set_xscale('log')
    ax2.set_xlabel(r'Discretization Time Step $\Delta t$', fontsize=11)
    ax2.set_ylabel(r'Effective Growth Multiplier $[\mu]$', fontsize=11)
    ax2.set_title(r'(b) Continuum Limit: $\lim_{\Delta t \to 0} \, \frac{1}{\Delta t} \ln \lambda_+ = \mu$', fontsize=12, fontweight='bold', pad=10)
    ax2.grid(True, which='both', linestyle='--', alpha=0.5)
    ax2.legend(loc='lower left', frameon=True, fontsize=9.5)
    
    plt.tight_layout()
    
    # Save figure
    out_dir = os.path.join(get_case_dir(), 'figures')
    os.makedirs(out_dir, exist_ok=True)
    pdf_path = os.path.join(out_dir, 'tachyonic_cauchy_runaway.pdf')
    png_path = os.path.join(out_dir, 'tachyonic_cauchy_runaway.png')
    
    plt.savefig(pdf_path, dpi=300)
    plt.savefig(png_path, dpi=300)
    plt.close()
    
    print(f"[+] Saved continuum runaway figures to {pdf_path} and {png_path}")
    return results

if __name__ == '__main__':
    run_simulation()
