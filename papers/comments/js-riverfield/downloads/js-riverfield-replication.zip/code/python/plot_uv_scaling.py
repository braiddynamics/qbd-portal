#!/usr/bin/env python3
"""
Plot UV Scaling Comparison: 3D Mode Sum vs 4D Covariant Functional Determinant

Reads benchmark data from code/cpp/uv_scaling_results.csv and produces
a high-resolution log-log scaling plot demonstrating identical leading
quartic ultraviolet divergence (~ Λ⁴).

Outputs:
  - figures/uv_scaling_comparison.pdf
  - figures/uv_scaling_comparison.png
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import linregress


# Ensure UTF-8 output on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

def get_case_dir():
    curr = os.path.abspath(os.path.dirname(__file__))
    while curr and curr != os.path.dirname(curr):
        if os.path.exists(os.path.join(curr, 'figures')) and os.path.exists(os.path.join(curr, 'code')):
            return curr
        curr = os.path.dirname(curr)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))

def get_default_csv_path():
    case_dir = get_case_dir()
    candidate = os.path.join(case_dir, 'code', 'cpp', 'uv_scaling_results.csv')
    if os.path.exists(candidate):
        return candidate
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'cpp', 'uv_scaling_results.csv'))

def compute_scaling(csv_path=None):
    """
    Loads lattice benchmark CSV data and computes log-log power-law regression slopes.
    
    Returns:
      slope_3D: Fitted exponent for 3D equal-time mode sum ~ Λ⁴.
      slope_4D: Fitted pure power-law exponent for 4D covariant determinant ~ Λ⁴
                (factoring out the ln(Λ) functional determinant enhancement).
      r_3D:     Pearson correlation coefficient for 3D regression.
      r_4D:     Pearson correlation coefficient for 4D regression.
      
    Raises:
      FileNotFoundError: If the benchmark CSV file has not been generated.
    """
    if csv_path is None:
        csv_path = get_default_csv_path()
        
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"C++ benchmark data missing: {csv_path}. Compile and run lattice_uv_divergence first."
        )

    data = np.genfromtxt(csv_path, delimiter=',', skip_header=1)
    Lambda = data[:, 1]
    E_3D = data[:, 2]
    E_4D = data[:, 3]

    log_lam = np.log10(Lambda)
    slope_3D, int_3D, r_3D, _, _ = linregress(log_lam, np.log10(E_3D))
    
    # 4D Functional Determinant in continuum scales as ~ 1/2 Λ⁴ ln(Λ).
    # Factoring out ln(Λ) isolates the pure power-law scale ~ Λ⁴:
    slope_4D_factored, int_4D, r_4D_factored, _, _ = linregress(log_lam, np.log10(E_4D / np.log(Lambda)))
    
    return slope_3D, slope_4D_factored, r_3D, r_4D_factored

def plot_uv_scaling(csv_path=None):
    if csv_path is None:
        csv_path = get_default_csv_path()
        
    if not os.path.exists(csv_path):
        raise FileNotFoundError(
            f"C++ benchmark data missing: {csv_path}. Compile and run lattice_uv_divergence first."
        )

    data = np.genfromtxt(csv_path, delimiter=',', skip_header=1)
    Lambda = data[:, 1]
    E_3D = data[:, 2]
    E_4D = data[:, 3]

    log_lam = np.log10(Lambda)
    slope_3D, slope_4D_factored, r_3D, r_4D_factored = compute_scaling(csv_path)
    slope_4D_raw, int_4D_raw, r_4D_raw, _, _ = linregress(log_lam, np.log10(E_4D))

    plt.figure(figsize=(7.5, 5.5), dpi=300)
    plt.loglog(Lambda, E_3D, 's-', color='#2b83ba', lw=2.0, ms=7,
               label=f'3D Equal-Time Slicing Mode Sum (Slope = {slope_3D:.2f})')
    plt.loglog(Lambda, E_4D, 'o-', color='#d7191c', lw=2.0, ms=7,
               label=f'4D Covariant Functional Det $\\ln\\det(-\\partial^2+m^2)$ (Slope = {slope_4D_raw:.2f})')

    # Theoretical quartic reference line ~ Λ^4
    lam_ref = np.linspace(Lambda[0], Lambda[-1], 100)
    ref_curve = E_3D[0] * (lam_ref / Lambda[0])**4
    plt.loglog(lam_ref, ref_curve, 'k--', lw=1.5, alpha=0.7, label='Theoretical Quartic Scaling $\\sim \\Lambda^4$')

    plt.xlabel('Ultraviolet Cutoff Scale $\\Lambda = \\pi / a$', fontsize=11)
    plt.ylabel('Vacuum Energy Density $\\mathcal{E}(\\Lambda)$', fontsize=11)
    plt.title('Ultraviolet Divergence Invariance: 3D Foliation vs. 4D Covariant', fontsize=12, fontweight='bold')
    plt.legend(loc='upper left', frameon=True, framealpha=0.9)
    plt.grid(True, which='both', ls=':', alpha=0.6)

    plt.text(0.48, 0.15,
             "Conclusion:\n"
             f"• 3D Mode Sum Scaling: $\\Lambda^{{{slope_3D:.2f}}}$ ($R^2={r_3D**2:.5f}$)\n"
             f"• 4D Factored Power-Law: $\\Lambda^{{{slope_4D_factored:.2f}}}$ ($R^2={r_4D_factored**2:.5f}$)\n"
             "• Equal-time foliation does NOT cause the divergence.\n"
             "• Leading $\\sim \\Lambda^4$ infinity is an invariant continuum property.",
             transform=plt.gca().transAxes, fontsize=9.0,
             bbox=dict(boxstyle='round,pad=0.5', facecolor='#e0f3f8', edgecolor='#2b83ba', alpha=0.9))

    plt.tight_layout()

    output_dir = os.path.join(get_case_dir(), 'figures')
    os.makedirs(output_dir, exist_ok=True)
    pdf_path = os.path.join(output_dir, 'uv_scaling_comparison.pdf')
    png_path = os.path.join(output_dir, 'uv_scaling_comparison.png')

    plt.savefig(pdf_path, bbox_inches='tight')
    plt.savefig(png_path, bbox_inches='tight')
    plt.close()

    print(f"[UV Scaling Plot]")
    print(f"  3D Fitted Exponent:          {slope_3D:.4f} (R² = {r_3D**2:.5f})")
    print(f"  4D Raw Exponent (with ln Λ): {slope_4D_raw:.4f} (R² = {r_4D_raw**2:.5f})")
    print(f"  4D Factored Pure Power-Law:  {slope_4D_factored:.4f} (R² = {r_4D_factored**2:.5f})")
    print(f"  Saved figure: {pdf_path}")
    print(f"  Saved figure: {png_path}")

if __name__ == '__main__':
    plot_uv_scaling()
