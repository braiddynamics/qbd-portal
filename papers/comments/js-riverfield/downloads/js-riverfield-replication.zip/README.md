# Replication Bundle: Formal Verification & Computational Audit of Canonical Field Quantization

Accompanying Case Study: Comment on Riverfield (2026) Theoretical Claims
Authors: R. Fisher, Braid Dynamics Research Group
Archive DOI: 10.5281/zenodo.XXXXXXX

## Contents:
1. code/lean/RiverfieldRefutation.lean: Self-contained Lean 4 formal proof kernel (21 theorems, 0 axioms, 0 sorry).
2. code/python/: Python simulation scripts, symbolic constraint algebra audit, and pytest test suite.
3. code/cpp/: C++20 hardware-accelerated lattice UV divergence scaling engine and Makefile.

## Verification Commands:
- Lean 4: lake env lean code/lean/RiverfieldRefutation.lean
- Python tests: python -m pytest code/python/test_suite.py
- C++ Engine: cd code/cpp && make && ./lattice_uv_divergence.exe
