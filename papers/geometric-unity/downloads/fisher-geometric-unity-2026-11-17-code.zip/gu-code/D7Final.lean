import D7Unrestricted

/-!
# The complex symbol channels and their dimensions

Lower the output indices with the determinant metrics and combine the vector
and two-form slots into a symbol. Equivariant restriction to the alternating,
trace, and joint-kernel summands then gives the channel decomposition.
-/

namespace GeometricUnity.D7Final

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7ComplementaryGrades
open D7Unrestricted (Intertwiners intertwinerEquiv summedVectorTarget unrestricted_hom_dimension)
open D7TripleInvariants (ExteriorIntertwiners metricEquiv metricEquiv_toLinearMap)
open D7TripleMultiplicity (sourceGrade targetGrade summedSource summedTarget bundledHomEquiv
  vector_and_bianchi_hom_dimensions vector_and_alternating_totals)
open scoped BigOperators TensorProduct

set_option backward.isDefEq.respectTransparency false

noncomputable section

private abbrev Group14 := ↥splitSpecialOrthogonal

abbrev SymbolForm (S : Type) [AddCommMonoid S] [Module ℂ S] (k l : ℕ) :=
  S →ₗ[ℂ] Ext k →ₗ[ℂ] Ext l →ₗ[ℂ] ℂ

def invariantSymbols {S : Type} [AddCommMonoid S] [Module ℂ S]
    (ρ : Representation ℂ Group14 S) (k l : ℕ) : Submodule ℂ (SymbolForm S k l) where
  carrier := {F | ∀ (g : Group14) s x y,
    F (ρ g s) (exteriorRepresentation k g x) (exteriorRepresentation l g y) = F s x y}
  add_mem' hF hG g s x y := by simp only [LinearMap.add_apply, hF g s x y, hG g s x y]
  zero_mem' := by
    change ∀ (g : Group14) (s : S) (x : Ext k) (y : Ext l), _ = _
    intros; rfl
  smul_mem' c F hF g s x y := by simp only [LinearMap.smul_apply, hF g s x y]

abbrev Symbols {S : Type} [AddCommMonoid S] [Module ℂ S]
    (ρ : Representation ℂ Group14 S) (k l : ℕ) := ↥(invariantSymbols ρ k l)

private abbrev Imm (k l : ℕ) := ↥(D7QuadInvariants.invariantForms k l)

private def evaluate {k l : ℕ} (x : Ext k) (y : Ext l) :
    (Ext k →ₗ[ℂ] Ext l →ₗ[ℂ] ℂ) →ₗ[ℂ] ℂ where
  toFun f := f x y
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

private theorem uncurry_invariant {k l : ℕ} (F : Imm k l) :
    TensorProduct.lift F.val ∈ invariantSymbols tensorAction k l := by
  intro g s x y
  let f := TensorProduct.lift F.val
  have h : ((evaluate (exteriorRepresentation k g x) (exteriorRepresentation l g y)).comp f).comp
      (tensorAction g) = (evaluate x y).comp f := by
    apply TensorProduct.ext'
    intro a u
    change f ((action 2) g (a ⊗ₜ[ℂ] u)) (exteriorRepresentation k g x) (exteriorRepresentation l g y) =
      f (a ⊗ₜ[ℂ] u) x y
    rw [action_tmul]
    exact F.prop g a u x y
  exact DFunLike.congr_fun h s

private theorem curry_invariant {k l : ℕ} (F : Symbols tensorAction k l) :
    TensorProduct.curry F.val ∈ D7QuadInvariants.invariantForms k l := by
  intro g a u x y
  have h := F.prop g (a ⊗ₜ[ℂ] u) x y
  change F.val ((action 2) g (a ⊗ₜ[ℂ] u)) _ _ = _ at h
  rw [action_tmul] at h
  exact h

/-- Lowering the output vector index turns the two exterior input slots
and the output vector slot into the divergence symbol. -/
def uncurrySymbol (k l : ℕ) : Imm k l ≃ₗ[ℂ] Symbols tensorAction k l where
  toFun F := ⟨TensorProduct.lift F.val, uncurry_invariant F⟩
  invFun F := ⟨TensorProduct.curry F.val, curry_invariant F⟩
  left_inv F := by
    apply Subtype.ext
    apply LinearMap.ext
    intro a
    apply LinearMap.ext
    intro u
    rfl
  right_inv F := by
    apply Subtype.ext
    apply TensorProduct.ext'
    intro a u
    rfl
  map_add' F G := by
    apply Subtype.ext
    apply TensorProduct.ext'
    intro a u
    rfl
  map_smul' c F := by
    apply Subtype.ext
    apply TensorProduct.ext'
    intro a u
    rfl

section Restriction

variable {S T : Type} [AddCommMonoid S] [Module ℂ S] [AddCommMonoid T] [Module ℂ T]
variable {ρ : Representation ℂ Group14 S} {σ : Representation ℂ Group14 T} {k l : ℕ}

def restrictSymbol (f : σ.IntertwiningMap ρ) : Symbols ρ k l →ₗ[ℂ] Symbols σ k l where
  toFun F := ⟨F.val.comp f.toLinearMap, by
    intro g s x y
    change F.val (f (σ g s)) _ _ = F.val (f s) x y
    rw [Representation.IntertwiningMap.isIntertwining σ ρ f]
    exact F.prop g (f s) x y⟩
  map_add' F G := by
    apply Subtype.ext
    apply LinearMap.ext
    intro x
    rfl
  map_smul' c F := by
    apply Subtype.ext
    apply LinearMap.ext
    intro x
    rfl

@[simp] theorem restrictSymbol_apply (f : σ.IntertwiningMap ρ) (F : Symbols ρ k l)
    (s : T) (x : Ext k) (y : Ext l) :
    (restrictSymbol f F).val s x y = F.val (f s) x y := rfl

def restrictEquiv (e : σ.Equiv ρ) : Symbols ρ k l ≃ₗ[ℂ] Symbols σ k l :=
  LinearEquiv.ofLinearMap (restrictSymbol e.toIntertwiningMap) (restrictSymbol e.symm.toIntertwiningMap)
    (by
      apply LinearMap.ext
      intro F
      apply Subtype.ext
      apply LinearMap.ext
      intro s
      change F.val (e.symm (e s)) = F.val s
      rw [Representation.Equiv.symm_apply_apply])
    (by
      apply LinearMap.ext
      intro F
      apply Subtype.ext
      apply LinearMap.ext
      intro s
      change F.val (e (e.symm s)) = F.val s
      rw [Representation.Equiv.apply_symm_apply])

private def symbolInl (ρ : Representation ℂ Group14 S) (σ : Representation ℂ Group14 T) :
    ρ.IntertwiningMap (ρ.prod σ) := Representation.IntertwiningMap.inl ℂ ρ σ
private def symbolInr (ρ : Representation ℂ Group14 S) (σ : Representation ℂ Group14 T) :
    σ.IntertwiningMap (ρ.prod σ) := Representation.IntertwiningMap.inr ℂ ρ σ

def productSymbols (ρ : Representation ℂ Group14 S) (σ : Representation ℂ Group14 T) (k l : ℕ) :
    Symbols (ρ.prod σ) k l ≃ₗ[ℂ] Symbols ρ k l × Symbols σ k l where
  toFun F := (restrictSymbol (symbolInl ρ σ) F, restrictSymbol (symbolInr ρ σ) F)
  invFun p := restrictSymbol (Representation.IntertwiningMap.fst ℂ ρ σ) p.1 +
    restrictSymbol (Representation.IntertwiningMap.snd ℂ ρ σ) p.2
  left_inv F := by
    apply Subtype.ext
    apply LinearMap.ext
    intro s
    change F.val (s.1, 0) + F.val (0, s.2) = F.val s
    rw [← map_add]
    congr 1
    exact Prod.ext (add_zero _) (zero_add _)
  right_inv p := by
    apply Prod.ext
    · apply Subtype.ext
      apply LinearMap.ext
      intro s
      change p.1.val s + p.2.val 0 = p.1.val s
      rw [map_zero, add_zero]
    · apply Subtype.ext
      apply LinearMap.ext
      intro t
      change p.1.val 0 + p.2.val t = p.2.val t
      rw [map_zero, zero_add]
  map_add' F G := Prod.ext (map_add _ _ _) (map_add _ _ _)
  map_smul' c F := Prod.ext (map_smul _ _ _) (map_smul _ _ _)

end Restriction

section Lowering

variable {S : Type} [AddCommMonoid S] [Module ℂ S]

abbrev SymbolIntertwiners (ρ : Representation ℂ Group14 S) (k l : ℕ) :=
  (ρ.tprod (exteriorRepresentation k)).IntertwiningMap (exteriorRepresentation l)

private def lowerSymbol {ρ : Representation ℂ Group14 S} {k l : ℕ} (T : SymbolIntertwiners ρ k l) :
    SymbolForm S k l :=
  TensorProduct.curry ((metricEquiv l).toLinearMap.comp T.toLinearMap)

private theorem lowerSymbol_apply {ρ : Representation ℂ Group14 S} {k l : ℕ} (T : SymbolIntertwiners ρ k l)
    (s : S) (x : Ext k) (y : Ext l) :
    lowerSymbol T s x y = exteriorMetric l (T (s ⊗ₜ[ℂ] x)) y := by
  change (metricEquiv l).toLinearMap (T (s ⊗ₜ[ℂ] x)) y = _
  rw [metricEquiv_toLinearMap]

private theorem lowerSymbol_invariant {ρ : Representation ℂ Group14 S} {k l : ℕ}
    (T : SymbolIntertwiners ρ k l) : lowerSymbol T ∈ invariantSymbols ρ k l := by
  intro g s x y
  rw [lowerSymbol_apply, lowerSymbol_apply]
  have he := Representation.IntertwiningMap.isIntertwining
    (ρ.tprod (exteriorRepresentation k)) (exteriorRepresentation l) T g (s ⊗ₜ[ℂ] x)
  simp only [Representation.tprod_apply, TensorProduct.map_tmul] at he
  rw [he, metric_invariant]

private def lower (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    SymbolIntertwiners ρ k l →ₗ[ℂ] Symbols ρ k l where
  toFun T := ⟨lowerSymbol T, lowerSymbol_invariant T⟩
  map_add' T U := by
    apply Subtype.ext
    apply LinearMap.ext
    intro s
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    change lowerSymbol (T + U) s x y = lowerSymbol T s x y + lowerSymbol U s x y
    simp only [lowerSymbol_apply, Representation.IntertwiningMap.coe_add,
      Pi.add_apply, map_add, LinearMap.add_apply]
  map_smul' c T := by
    apply Subtype.ext
    apply LinearMap.ext
    intro s
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    change lowerSymbol (c • T) s x y = c • lowerSymbol T s x y
    simp only [lowerSymbol_apply, Representation.IntertwiningMap.coe_smul,
      Pi.smul_apply, map_smul, LinearMap.smul_apply]

private theorem lower_injective (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    Function.Injective (lower ρ k l) := by
  intro T U h
  apply Representation.IntertwiningMap.ext
  apply TensorProduct.ext'
  intro s x
  apply (metricEquiv l).injective
  exact congrArg (fun F : Symbols ρ k l => F.val s x) h

private theorem lower_surjective (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    Function.Surjective (lower ρ k l) := by
  intro F
  let f := (metricEquiv l).symm.toLinearMap.comp (TensorProduct.lift F.val)
  have hv (s : S) (x : Ext k) : exteriorMetric l (f (s ⊗ₜ[ℂ] x)) = F.val s x := by
    rw [← metricEquiv_toLinearMap]
    change metricEquiv l ((metricEquiv l).symm (TensorProduct.lift F.val (s ⊗ₜ[ℂ] x))) = _
    rw [LinearEquiv.apply_symm_apply, TensorProduct.lift.tmul]
  let T : SymbolIntertwiners ρ k l :=
    { toLinearMap := f
      isIntertwining' g := by
        apply TensorProduct.ext'
        intro s x
        simp only [LinearMap.comp_apply, Representation.tprod_apply, TensorProduct.map_tmul]
        apply exteriorMetric_injective l
        apply LinearMap.ext
        intro y
        obtain ⟨z, rfl⟩ := exterior_surjective l g y
        rw [metric_invariant, hv, hv]
        exact F.prop g s x z }
  refine ⟨T, Subtype.ext ?_⟩
  apply LinearMap.ext
  intro s
  apply LinearMap.ext
  intro x
  apply LinearMap.ext
  intro y
  change lowerSymbol T s x y = _
  rw [lowerSymbol_apply]
  exact DFunLike.congr_fun (hv s x) y

/-- Raising the last exterior index recovers the intertwiners of the
symbol representation tensored with the input grade. -/
def symbolIntertwinerEquiv (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    SymbolIntertwiners ρ k l ≃ₗ[ℂ] Symbols ρ k l :=
  LinearEquiv.ofBijective (lower ρ k l) ⟨lower_injective ρ k l, lower_surjective ρ k l⟩

private theorem freeSymbolIntertwiners (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    Module.Free ℂ (SymbolIntertwiners ρ k l) :=
  @Module.Free.of_divisionRing ℂ (SymbolIntertwiners ρ k l) _
    (Representation.IntertwiningMap.instAddCommGroup
      (ρ.tprod (exteriorRepresentation k)) (exteriorRepresentation l)) _

end Lowering

private theorem finiteSymbolIntertwiners {S : Type} [AddCommGroup S] [Module ℂ S]
    [Module.Finite ℂ S]
    (ρ : Representation ℂ Group14 S) (k l : ℕ) :
    Module.Finite ℂ (SymbolIntertwiners ρ k l) :=
  Module.Finite.of_injective
    (Representation.IntertwiningMap.toLinearMapl
      (ρ := ρ.tprod (exteriorRepresentation k)) (σ := exteriorRepresentation l))
    (Representation.IntertwiningMap.toLinearMap_injective _ _)

private def oneExterior : (exteriorRepresentation 1).Equiv vectorAction :=
  Representation.Equiv.mk (exteriorPower.oneEquiv ℂ Space) (fun g =>
    exteriorPower.oneEquiv_naturality g.val)

local instance hookTensorAddCommGroup (k : ℕ) : AddCommGroup (↥hook ⊗[ℂ] Ext k) :=
  @TensorProduct.addCommGroup ℂ _ ↥hook (Ext k) hook.addCommGroup _ _ _

abbrev HookIntertwiners (k l : ℕ) := SymbolIntertwiners hookAction k l

/-- Lower both output indices and combine the vector and two-form slots. -/
def divergenceSymbol (k l : ℕ) : Intertwiners k l ≃ₗ[ℂ] Symbols tensorAction k l :=
  (intertwinerEquiv k l).trans (uncurrySymbol k l)

theorem divergenceSymbol_tmul {k l : ℕ} (T : Intertwiners k l)
    (a : Space) (u : Ext 2) (x : Ext k) (y : Ext l) :
    (divergenceSymbol k l T).val (a ⊗ₜ[ℂ] u) x y =
      D7Unrestricted.tensorMetric l (T (u ⊗ₜ[ℂ] x)) (a ⊗ₜ[ℂ] y) :=
  D7Unrestricted.intertwinerEquiv_apply T a u x y

/-- Restrict the divergence symbol to the alternating, vector, and
traceless hook summands and raise the exterior output index in each. -/
def gradeChannelSplit (k l : ℕ) :
    Intertwiners k l ≃ₗ[ℂ]
      ExteriorIntertwiners 3 k l × ExteriorIntertwiners 1 k l × HookIntertwiners k l := by
  let A := exteriorRepresentation 3
  let B := vectorAction
  let H := hookAction
  let split := restrictEquiv (k := k) (l := l) D7VectorTensor.splitRepresentation.symm
  let splitFirst := productSymbols A (B.prod H) k l
  let splitRest := productSymbols B H k l
  let alternating := (symbolIntertwinerEquiv A k l).symm
  let vector := (restrictEquiv (k := k) (l := l) oneExterior).trans
    (symbolIntertwinerEquiv (exteriorRepresentation 1) k l).symm
  let residual := (symbolIntertwinerEquiv H k l).symm
  exact (divergenceSymbol k l).trans (split.trans (splitFirst.trans
    (alternating.prodCongr (splitRest.trans (vector.prodCongr residual)))))

theorem grade_dimension_sum (k l : ℕ) :
    Module.finrank ℂ (Intertwiners k l) =
      Module.finrank ℂ (ExteriorIntertwiners 3 k l) +
      Module.finrank ℂ (ExteriorIntertwiners 1 k l) +
      Module.finrank ℂ (HookIntertwiners k l) := by
  have hA : Module.Finite ℂ (ExteriorIntertwiners 3 k l) :=
    finiteSymbolIntertwiners (exteriorRepresentation 3) k l
  have hV : Module.Finite ℂ (ExteriorIntertwiners 1 k l) :=
    finiteSymbolIntertwiners (exteriorRepresentation 1) k l
  have hH : Module.Finite ℂ (HookIntertwiners k l) :=
    @finiteSymbolIntertwiners ↥hook hook.addCommGroup hook.module
      (FiniteDimensional.finiteDimensional_submodule hook) hookAction k l
  have fA : Module.Free ℂ (ExteriorIntertwiners 3 k l) :=
    freeSymbolIntertwiners (exteriorRepresentation 3) k l
  have fV : Module.Free ℂ (ExteriorIntertwiners 1 k l) :=
    freeSymbolIntertwiners (exteriorRepresentation 1) k l
  have fH : Module.Free ℂ (HookIntertwiners k l) :=
    freeSymbolIntertwiners (S := ↥hook) hookAction k l
  rw [(gradeChannelSplit k l).finrank_eq,
    Module.finrank_prod (M := ExteriorIntertwiners 3 k l)
      (M' := ExteriorIntertwiners 1 k l × HookIntertwiners k l),
    Module.finrank_prod (M := ExteriorIntertwiners 1 k l) (M' := HookIntertwiners k l)]
  omega

def altMap : tensorAction.IntertwiningMap (exteriorRepresentation 3) :=
  ⟨alternation, alternation_equivariant⟩

private def threeMap : (exteriorRepresentation 3).IntertwiningMap tensorAction :=
  ⟨includeThree, includeThree_equivariant⟩

/-- Bianchi-compatible symbols annihilate the kernel of alternation. -/
def bianchiSymbols (k l : ℕ) : Submodule ℂ (Symbols tensorAction k l) where
  carrier := {F | ∀ s, alternation s = 0 → F.val s = 0}
  zero_mem' := fun _ _ => rfl
  add_mem' {F G} hF hG s hs := by
    change F.val s + G.val s = 0
    rw [hF s hs, hG s hs, add_zero]
  smul_mem' c F hF s hs := by
    change c • F.val s = 0
    rw [hF s hs, smul_zero]

private theorem pullback_alt_mem {k l : ℕ} (A : Symbols (exteriorRepresentation 3) k l) :
    restrictSymbol altMap A ∈ bianchiSymbols k l := by
  intro s hs
  change A.val (alternation s) = 0
  rw [hs, map_zero]

private theorem recover_from_three {k l : ℕ} {F : Symbols tensorAction k l}
    (h : F ∈ bianchiSymbols k l) :
    restrictSymbol altMap (restrictSymbol threeMap F) = F := by
  apply Subtype.ext
  apply LinearMap.ext
  intro s
  change F.val (includeThree (alternation s)) = F.val s
  have hker : alternation (s - includeThree (alternation s)) = 0 := by
    rw [map_sub, alternation_three, sub_self]
  have hzero := h _ hker
  rw [map_sub, sub_eq_zero] at hzero
  exact hzero.symm

private theorem recover_from_alt {k l : ℕ} (A : Symbols (exteriorRepresentation 3) k l) :
    restrictSymbol threeMap (restrictSymbol altMap A) = A := by
  apply Subtype.ext
  apply LinearMap.ext
  intro u
  change A.val (alternation (includeThree u)) = A.val u
  rw [alternation_three]

/-- The Bianchi condition is equivalent to unique equivariant factorization
through alternation in the symbol argument. -/
theorem bianchi_iff_factor {k l : ℕ} (F : Symbols tensorAction k l) :
    F ∈ bianchiSymbols k l ↔
      ∃! A : Symbols (exteriorRepresentation 3) k l, restrictSymbol altMap A = F := by
  constructor
  · intro h
    refine ⟨restrictSymbol threeMap F, recover_from_three h, ?_⟩
    intro A hA
    rw [← hA, recover_from_alt]
  · rintro ⟨A, rfl, _⟩
    exact pullback_alt_mem A

/-- Restriction to the alternating summand and pullback along alternation
are inverse on the Bianchi-compatible subspace. -/
def bianchiEquiv (k l : ℕ) :
    ↥(bianchiSymbols k l) ≃ₗ[ℂ] ExteriorIntertwiners 3 k l := by
  let f := (restrictSymbol (k := k) (l := l) threeMap).comp (bianchiSymbols k l).subtype
  let g := (restrictSymbol (k := k) (l := l) altMap).codRestrict (bianchiSymbols k l) pullback_alt_mem
  let e : ↥(bianchiSymbols k l) ≃ₗ[ℂ] Symbols (exteriorRepresentation 3) k l :=
    LinearEquiv.ofLinearMap f g
    (LinearMap.ext recover_from_alt)
    (LinearMap.ext fun F => Subtype.ext (recover_from_three F.prop))
  exact e.trans (symbolIntertwinerEquiv (exteriorRepresentation 3) k l).symm

/-- The subspace of the original two-form-to-vector intertwiners selected
by the Bianchi condition on their divergence symbols. -/
def bianchiIntertwiners (k l : ℕ) : Submodule ℂ (Intertwiners k l) :=
  (bianchiSymbols k l).comap (divergenceSymbol k l).toLinearMap

def bianchiIntertwinerEquiv (k l : ℕ) :
    ↥(bianchiIntertwiners k l) ≃ₗ[ℂ] ExteriorIntertwiners 3 k l :=
  ((divergenceSymbol k l).ofSubmodules (bianchiIntertwiners k l) (bianchiSymbols k l)
    ((bianchiSymbols k l).map_comap_eq_of_surjective (divergenceSymbol k l).surjective)).trans
    (bianchiEquiv k l)

theorem bianchi_grade_total :
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ ↥(bianchiIntertwiners k.val l.val)) = 96 := by
  calc
    _ = ∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val) :=
      Finset.sum_congr rfl fun k _ =>
        Finset.sum_congr rfl fun l _ => (bianchiIntertwinerEquiv k.val l.val).finrank_eq
    _ = 96 := vector_and_alternating_totals.2

private theorem hook_grade_difference (k : Fin 15) :
    (∑ l : Fin 15, Module.finrank ℂ (HookIntertwiners k.val l.val)) =
      (∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val)) -
        (∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val)) -
        (∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) := by
  have h (l : Fin 15) := grade_dimension_sum k.val l.val
  conv_rhs =>
    rw [show (∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val)) = _ from
      Finset.sum_congr rfl (fun l _ => h l)]
  simp only [Finset.sum_add_distrib]
  omega

private def rowDifference (unrestricted alternating vector : List ℕ) : List ℕ :=
  List.zipWith (· - ·) (List.zipWith (· - ·) unrestricted alternating) vector

/-- The fifteen input-grade rows for the actual complex hook intertwiners. -/
theorem hook_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (HookIntertwiners k.val l.val)) =
      D7Counts.expectedRows.map (fun row => row.hook.toNat) := by
  rw [show (List.ofFn fun k : Fin 15 => ∑ l : Fin 15,
      Module.finrank ℂ (HookIntertwiners k.val l.val)) =
    rowDifference
      (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val))
      (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val))
      (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) by
        apply List.ext_getElem
        · simp [rowDifference]
        · intro i hi _
          simp only [rowDifference, List.getElem_zipWith, List.getElem_ofFn]
          exact hook_grade_difference ⟨i, by simpa using hi⟩]
  rw [D7Unrestricted.unrestricted_by_grade, D7TripleMultiplicity.alternating_multiplicities_by_grade,
    D7TripleMultiplicity.vector_multiplicities_by_grade]
  decide +kernel

theorem hook_grade_total :
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (HookIntertwiners k.val l.val)) = 48 := by
  have h : (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val)) =
      (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val)) +
      (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) +
      (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (HookIntertwiners k.val l.val)) := by
    simp_rw [grade_dimension_sum]
    simp only [Finset.sum_add_distrib]
  rw [D7Unrestricted.unrestricted_total, vector_and_alternating_totals.1,
    vector_and_alternating_totals.2] at h
  omega

section Bundled

open CategoryTheory CategoryTheory.Limits

local instance : HasFiniteBiproducts (FDRep ℂ splitSpecialOrthogonal) :=
  HasFiniteBiproducts.of_hasFiniteProducts

/-- The grade blocks of the full two-form-to-vector Hom space. -/
def unrestrictedBlocks :
    (summedSource 2 ⟶ summedVectorTarget) ≃ₗ[ℂ]
      (∀ k l : Fin 15, Intertwiners k.val l.val) :=
  (D7Classification.blockHomEquiv ℂ (sourceGrade 2) D7Unrestricted.vectorTargetGrade).trans
    (LinearEquiv.piCongrRight fun k =>
      LinearEquiv.piCongrRight fun l => D7Unrestricted.gradeHomEquiv k l)

/-- A full equivariant operator is Bianchi-compatible when its divergence
symbol in every input and output grade annihilates the kernel of alternation. -/
def bianchiHom : Submodule ℂ (summedSource 2 ⟶ summedVectorTarget) :=
  (Submodule.pi Set.univ fun k : Fin 15 =>
    Submodule.pi Set.univ fun l : Fin 15 => bianchiIntertwiners k.val l.val).comap
    unrestrictedBlocks.toLinearMap

theorem mem_bianchiHom (T : summedSource 2 ⟶ summedVectorTarget) :
    T ∈ bianchiHom ↔ ∀ k l : Fin 15,
      unrestrictedBlocks T k l ∈ bianchiIntertwiners k.val l.val := by
  simp [bianchiHom, Submodule.mem_pi]

private def bianchiHomBlocks :
    ↥bianchiHom ≃ₗ[ℂ] (∀ k l : Fin 15, ↥(bianchiIntertwiners k.val l.val)) where
  toFun T k l := ⟨unrestrictedBlocks T.val k l, (mem_bianchiHom T.val).mp T.prop k l⟩
  invFun B := ⟨unrestrictedBlocks.symm (fun k l => (B k l).val), by
    apply (mem_bianchiHom _).mpr
    rw [LinearEquiv.apply_symm_apply]
    exact fun k l => (B k l).prop⟩
  left_inv T := Subtype.ext (unrestrictedBlocks.symm_apply_apply T.val)
  right_inv B := by
    funext k l
    apply Subtype.ext
    exact congrFun (congrFun (unrestrictedBlocks.apply_symm_apply (fun k l => (B k l).val)) k) l
  map_add' T S := by
    funext k l
    apply Subtype.ext
    exact congrFun (congrFun (map_add unrestrictedBlocks T.val S.val) k) l
  map_smul' c T := by
    funext k l
    apply Subtype.ext
    exact congrFun (congrFun (map_smul unrestrictedBlocks c T.val) k) l

set_option maxHeartbeats 1200000 in
/-- Assemble the unique alternating factor of each block into a map
from the full alternating source. -/
def bianchiHomEquiv : ↥bianchiHom ≃ₗ[ℂ] (summedSource 3 ⟶ summedTarget) := by
  let grade (k l : Fin 15) :
      (sourceGrade 3 k ⟶ targetGrade l) ≃ₗ[ℂ] ExteriorIntertwiners 3 k.val l.val :=
    bundledHomEquiv (U := Ext 3 ⊗[ℂ] Ext k.val) (W := Ext l.val)
      ((exteriorRepresentation 3).tprod (exteriorRepresentation k.val))
      (exteriorRepresentation l.val)
  let blocks : (∀ k l : Fin 15, ↥(bianchiIntertwiners k.val l.val)) ≃ₗ[ℂ]
      (∀ k l : Fin 15, sourceGrade 3 k ⟶ targetGrade l) :=
    LinearEquiv.piCongrRight fun k => LinearEquiv.piCongrRight fun l =>
      (bianchiIntertwinerEquiv k.val l.val).trans (grade k l).symm
  change ↥bianchiHom ≃ₗ[ℂ] (⨁ sourceGrade 3 ⟶ ⨁ targetGrade)
  exact bianchiHomBlocks.trans (blocks.trans
    (D7Classification.blockHomEquiv ℂ (sourceGrade 3) targetGrade).symm)

/-- The Bianchi-compatible subspace of the full unrestricted complex Hom
space has dimension 96. -/
theorem bianchi_hom_dimension : Module.finrank ℂ ↥bianchiHom = 96 :=
  bianchiHomEquiv.finrank_eq.trans vector_and_bianchi_hom_dimensions.2

def hookGrade (k : Fin 15) : FDRep ℂ splitSpecialOrthogonal :=
  FDRep.of (V := ↥hook ⊗[ℂ] Ext k.val) (hookAction.tprod (exteriorRepresentation k.val))

def summedHook : FDRep ℂ splitSpecialOrthogonal := ⨁ hookGrade

private def hookGradeHomEquiv (k l : Fin 15) :
    (hookGrade k ⟶ targetGrade l) ≃ₗ[ℂ] HookIntertwiners k.val l.val :=
  bundledHomEquiv (U := ↥hook ⊗[ℂ] Ext k.val) (W := Ext l.val)
    (hookAction.tprod (exteriorRepresentation k.val)) (exteriorRepresentation l.val)

theorem hook_hom_dimension : Module.finrank ℂ (summedHook ⟶ summedTarget) = 48 := by
  change Module.finrank ℂ (⨁ hookGrade ⟶ ⨁ targetGrade) = _
  rw [(D7Classification.blockHomEquiv ℂ hookGrade targetGrade).finrank_eq,
    Module.finrank_pi_fintype, ← hook_grade_total]
  apply Finset.sum_congr rfl
  intro k _
  rw [Module.finrank_pi_fintype]
  exact Finset.sum_congr rfl fun l _ => (hookGradeHomEquiv k l).finrank_eq

/-- The unrestricted, alternating, vector, and hook Hom space dimensions. -/
theorem complex_channel_dimensions :
    (Module.finrank ℂ (summedSource 2 ⟶ summedVectorTarget),
     Module.finrank ℂ (summedSource 3 ⟶ summedTarget),
     Module.finrank ℂ (summedSource 1 ⟶ summedTarget),
     Module.finrank ℂ (summedHook ⟶ summedTarget)) = (200, 96, 56, 48) := by
  rw [unrestricted_hom_dimension, vector_and_bianchi_hom_dimensions.2,
    vector_and_bianchi_hom_dimensions.1, hook_hom_dimension]

end Bundled

/-- Transport the dimension once the complexified real action has been
compared with the complex intertwiner space. -/
theorem real_dimension_of_comparison {G m n : Type} [Fintype m] [Fintype n]
    (ρ : G → Matrix m m ℝ) (τ : G → Matrix n n ℝ)
    {E : Type} [AddCommGroup E] [Module ℂ E]
    (e : D7Classification.ComplexIntertwiners ρ τ ≃ₗ[ℂ] E) :
    Module.finrank ℝ (D7Classification.RealIntertwiners ρ τ) = Module.finrank ℂ E :=
  (D7Classification.finrank_real_complex_intertwiners ρ τ).trans e.finrank_eq

section RealAction

variable {G H m n U W : Type} [Monoid G] [Monoid H]
variable [AddCommGroup U] [AddCommGroup W] [Module ℂ U] [Module ℂ W]

private def intertwiningDefect (T : U →ₗ[ℂ] W) :
    (Module.End ℂ U × Module.End ℂ W) →ₗ[ℂ] (U →ₗ[ℂ] W) where
  toFun p := T.comp p.1 - p.2.comp T
  map_add' p q := by
    change T.comp (p.1 + q.1) - (p.2 + q.2).comp T =
      (T.comp p.1 - p.2.comp T) + (T.comp q.1 - q.2.comp T)
    rw [LinearMap.comp_add, LinearMap.add_comp]
    abel
  map_smul' c p := by
    change T.comp (c • p.1) - (c • p.2).comp T = c • (T.comp p.1 - p.2.comp T)
    rw [LinearMap.comp_smul, LinearMap.smul_comp, smul_sub]

/-- It suffices for the restricted actions to span the pairs of ambient
actions on source and target. The intertwining equation is linear in
that pair for each candidate intertwiner. -/
def restrictGroupEquiv (φ : H →* G) (ρ : Representation ℂ G U) (τ : Representation ℂ G W)
    (hspan : ∀ g, (ρ g, τ g) ∈ Submodule.span ℂ (Set.range fun h => (ρ (φ h), τ (φ h)))) :
    ρ.IntertwiningMap τ ≃ₗ[ℂ] Representation.IntertwiningMap (ρ.comp φ) (τ.comp φ) where
  toFun T := ⟨T.toLinearMap, fun h => T.isIntertwining' (φ h)⟩
  invFun T := ⟨T.toLinearMap, by
    let d := intertwiningDefect T.toLinearMap
    have hker : Submodule.span ℂ (Set.range fun h => (ρ (φ h), τ (φ h))) ≤ d.ker := by
      apply Submodule.span_le.mpr
      rintro _ ⟨h, rfl⟩
      exact sub_eq_zero.mpr (T.isIntertwining' h)
    intro g
    exact sub_eq_zero.mp (hker (hspan g))⟩
  left_inv _ := Representation.IntertwiningMap.ext rfl
  right_inv _ := Representation.IntertwiningMap.ext rfl
  map_add' _ _ := Representation.IntertwiningMap.ext rfl
  map_smul' _ _ := Representation.IntertwiningMap.ext rfl

variable [Fintype m] [Fintype n] [DecidableEq m] [DecidableEq n]

/-- Coordinates identify equivariant linear maps with the matrix intertwiner equations. -/
def intertwinerMatrices {K X Y : Type*} [Field K] [AddCommGroup X] [AddCommGroup Y]
    [Module K X] [Module K Y] (b : Module.Basis m K X) (c : Module.Basis n K Y)
    (ρ : Representation K H X) (τ : Representation K H Y) :
    ρ.IntertwiningMap τ ≃ₗ[K] ↥(D7Classification.matrixIntertwiners
      (fun h => LinearMap.toMatrix b b (ρ h)) (fun h => LinearMap.toMatrix c c (τ h))) where
  toFun T := ⟨LinearMap.toMatrix b c T.toLinearMap, by
    intro h
    change LinearMap.toMatrix b c T.toLinearMap * LinearMap.toMatrix b b (ρ h) =
      LinearMap.toMatrix c c (τ h) * LinearMap.toMatrix b c T.toLinearMap
    rw [← LinearMap.toMatrix_comp b b c, ← LinearMap.toMatrix_comp b c c, T.isIntertwining']⟩
  invFun X := ⟨(LinearMap.toMatrix b c).symm X.val, by
    intro h
    apply (LinearMap.toMatrix b c).injective
    rw [LinearMap.toMatrix_comp b b c, LinearMap.toMatrix_comp b c c, LinearEquiv.apply_symm_apply]
    exact X.prop h⟩
  left_inv T := Representation.IntertwiningMap.ext ((LinearMap.toMatrix b c).symm_apply_apply _)
  right_inv X := Subtype.ext ((LinearMap.toMatrix b c).apply_symm_apply _)
  map_add' T S := Subtype.ext (map_add (LinearMap.toMatrix b c) T.toLinearMap S.toLinearMap)
  map_smul' a T := Subtype.ext (map_smul (LinearMap.toMatrix b c) a T.toLinearMap)

/-- Real descent with explicit comparison conditions. In the chosen complex
bases, the real matrices must complexify to the restricted actions, and
those actions must span the ambient pairs. -/
theorem real_dimension_of_action_span
    (φ : H →* G) (ρ : Representation ℂ G U) (τ : Representation ℂ G W)
    (a : H → Matrix m m ℝ) (b : H → Matrix n n ℝ)
    (u : Module.Basis m ℂ U) (w : Module.Basis n ℂ W)
    (ha : ∀ h, D7Classification.complexMatrices (a h) = LinearMap.toMatrix u u (ρ (φ h)))
    (hb : ∀ h, D7Classification.complexMatrices (b h) = LinearMap.toMatrix w w (τ (φ h)))
    (hspan : ∀ g, (ρ g, τ g) ∈ Submodule.span ℂ (Set.range fun h => (ρ (φ h), τ (φ h)))) :
    Module.finrank ℝ (D7Classification.RealIntertwiners a b) =
      Module.finrank ℂ (ρ.IntertwiningMap τ) := by
  apply real_dimension_of_comparison a b
  have e := (restrictGroupEquiv φ ρ τ hspan).trans (intertwinerMatrices u w (ρ.comp φ) (τ.comp φ))
  have ha' : D7Classification.complexMatrices ∘ a = fun h => LinearMap.toMatrix u u ((ρ.comp φ) h) :=
    funext ha
  have hb' : D7Classification.complexMatrices ∘ b = fun h => LinearMap.toMatrix w w ((τ.comp φ) h) :=
    funext hb
  change ↥(D7Classification.matrixIntertwiners (D7Classification.complexMatrices ∘ a)
    (D7Classification.complexMatrices ∘ b)) ≃ₗ[ℂ] ρ.IntertwiningMap τ
  rw [ha', hb']
  exact e.symm

end RealAction

end
end GeometricUnity.D7Final
