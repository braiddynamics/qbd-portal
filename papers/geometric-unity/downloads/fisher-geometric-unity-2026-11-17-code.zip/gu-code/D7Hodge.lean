import D7Exterior
import Mathlib.Tactic.Module

/-!
# The middle exterior power of the split special orthogonal representation

An orthonormal basis for the complex bilinear form gives the Hodge operator
on the seventh exterior power. The determinant pairing proves equivariance
for the same action used in `D7Exterior`.
-/

namespace GeometricUnity.D7Hodge

open D7Exterior
open scoped BigOperators

noncomputable section

private theorem plus_index (i : Pair) : pairIndex (plusAxis i) = i := by
  apply Fin.ext
  change (2 * i.val) / 2 = i.val
  omega

private theorem minus_index (i : Pair) : pairIndex (minusAxis i) = i := by
  apply Fin.ext
  change (2 * i.val + 1) / 2 = i.val
  omega

private theorem axis_cases (j : Axis) : j = plusAxis (pairIndex j) ∨ j = minusAxis (pairIndex j) := by
  by_cases hj : j.val % 2 = 0
  · exact Or.inl (Fin.ext (by change j.val = 2 * (j.val / 2); omega))
  · exact Or.inr (Fin.ext (by change j.val = 2 * (j.val / 2) + 1; omega))

private def mix : Space →ₗ[ℂ] Space where
  toFun x j := if j.val % 2 = 0 then x j + Complex.I * x (minusAxis (pairIndex j))
    else (x (plusAxis (pairIndex j)) - Complex.I * x j) / 2
  map_add' x y := by
    funext j
    simp only [Pi.add_apply]
    split <;> ring
  map_smul' c x := by
    funext j
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply]
    split <;> ring

private theorem mix_plus (x : Space) (i : Pair) :
    mix x (plusAxis i) = x (plusAxis i) + Complex.I * x (minusAxis i) := by
  have h : (plusAxis i).val % 2 = 0 := by change (2 * i.val) % 2 = 0; omega
  change (if _ then _ else _) = _
  simp [h, plus_index]

private theorem mix_minus (x : Space) (i : Pair) :
    mix x (minusAxis i) = (x (plusAxis i) - Complex.I * x (minusAxis i)) / 2 := by
  have h : (minusAxis i).val % 2 ≠ 0 := by change (2 * i.val + 1) % 2 ≠ 0; omega
  change (if _ then _ else _) = _
  simp [h, minus_index]

private theorem mix_injective : Function.Injective mix := by
  intro x y h
  have hp (i : Pair) := congrFun h (plusAxis i)
  have hm (i : Pair) := congrFun h (minusAxis i)
  simp only [mix_plus] at hp
  simp only [mix_minus] at hm
  funext j
  rcases axis_cases j with hj | hj
  · rw [hj]
    linear_combination (1 / 2 : ℂ) * hp (pairIndex j) + hm (pairIndex j)
  · rw [hj]
    linear_combination (-Complex.I / 2) * hp (pairIndex j) + Complex.I * hm (pairIndex j) +
      (x (minusAxis (pairIndex j)) - y (minusAxis (pairIndex j))) * Complex.I_mul_I

private def mixEquiv : Space ≃ₗ[ℂ] Space :=
  LinearEquiv.ofBijective mix ⟨mix_injective,
    LinearMap.injective_iff_surjective.mp mix_injective⟩

/-- Complex orthonormal coordinates for the bilinear form in the null basis. -/
def orthBasis : Module.Basis Axis ℂ Space := axisBasis.map mixEquiv

private def axesEquiv : Pair × Fin 2 ≃ Axis where
  toFun p := if p.2 = 0 then plusAxis p.1 else minusAxis p.1
  invFun j := (pairIndex j, ⟨j.val % 2, Nat.mod_lt _ (by decide)⟩)
  left_inv := by
    rintro ⟨i, a⟩
    fin_cases a
    · exact Prod.ext (plus_index i) (Fin.ext (by change (2 * i.val) % 2 = 0; omega))
    · exact Prod.ext (minus_index i) (Fin.ext (by change (2 * i.val + 1) % 2 = 1; omega))
  right_inv j := by
    change (if (⟨j.val % 2, _⟩ : Fin 2) = 0 then _ else _) = _
    by_cases h : j.val % 2 = 0
    · rw [if_pos (Fin.ext h)]
      apply Fin.ext; change 2 * (j.val / 2) = j.val; omega
    · rw [if_neg (fun e => h (congrArg Fin.val e))]
      apply Fin.ext; change 2 * (j.val / 2) + 1 = j.val; omega

private theorem sum_axes (f : Axis → ℂ) :
    ∑ j, f j = ∑ i : Pair, (f (plusAxis i) + f (minusAxis i)) := by
  rw [← axesEquiv.sum_comp f, Fintype.sum_prod_type]
  simp [Fin.sum_univ_two, axesEquiv]

private theorem splitForm_mix (x y : Space) : splitForm (mix x) (mix y) = ∑ j, x j * y j := by
  rw [sum_axes]
  apply Finset.sum_congr rfl
  intro i _
  change mix x (plusAxis i) * mix y (minusAxis i) +
    mix x (minusAxis i) * mix y (plusAxis i) = _
  rw [mix_plus, mix_minus, mix_plus, mix_minus]
  linear_combination -(x (minusAxis i) * y (minusAxis i)) * Complex.I_mul_I

abbrev Mid := ⋀[ℂ]^7 Space
abbrev MiddleIndex := Index 7

def middleBasis : Module.Basis MiddleIndex ℂ Mid := orthBasis.exteriorPower 7

def complement (s : MiddleIndex) : MiddleIndex :=
  ⟨s.valᶜ, by change (s.valᶜ).card = 7; simp [Finset.card_compl]⟩

theorem complement_complement (s : MiddleIndex) : complement (complement s) = s := by
  apply Subtype.ext
  exact compl_compl s.val

private theorem disjoint_complement (s : MiddleIndex) : Disjoint s.val (complement s).val :=
  disjoint_compl_right

private theorem disjoint_iff (s t : MiddleIndex) : Disjoint s.val t.val ↔ t = complement s := by
  constructor
  · intro h
    apply Subtype.ext
    apply Finset.eq_of_subset_of_card_le
    · intro i hi
      exact Finset.mem_compl.mpr (Finset.disjoint_left.mp h.symm hi)
    · exact Nat.le_of_eq ((complement s).prop.trans t.prop.symm)
  · rintro rfl
    exact disjoint_complement s

def volume : (⋀[ℂ]^14 Space) →ₗ[ℂ] ℂ :=
  exteriorPower.alternatingMapLinearEquiv orthBasis.det

private def wedge (x y : Mid) : ⋀[ℂ]^14 Space :=
  ⟨x.val * y.val, by
    change x.val * y.val ∈ (LinearMap.range (ExteriorAlgebra.ι ℂ : Space →ₗ[ℂ] _)) ^ (7 + 7)
    rw [pow_add]
    exact Submodule.mul_mem_mul x.prop y.prop⟩

private theorem wedge_pure (v w : Fin 7 → Space) :
    wedge (exteriorPower.ιMulti ℂ 7 v) (exteriorPower.ιMulti ℂ 7 w) =
      exteriorPower.ιMulti ℂ 14 (Fin.append v w) := by
  apply Subtype.ext
  exact ExteriorAlgebra.ιMulti_mul_ιMulti v w

/-- The coefficient of the positively oriented top wedge in a product of middle wedges. -/
def volumePair : Mid →ₗ[ℂ] Mid →ₗ[ℂ] ℂ :=
  LinearMap.mk₂ ℂ (fun x y => volume (wedge x y))
    (fun x₁ x₂ y => by rw [← map_add]; congr 1; apply Subtype.ext; exact add_mul _ _ _)
    (fun r x y => by rw [← map_smul]; congr 1; apply Subtype.ext; exact smul_mul_assoc _ _ _)
    (fun x y₁ y₂ => by rw [← map_add]; congr 1; apply Subtype.ext; exact mul_add _ _ _)
    (fun r x y => by rw [← map_smul]; congr 1; apply Subtype.ext; exact mul_smul_comm _ _ _)

theorem volumePair_pure (v w : Fin 7 → Space) :
    volumePair (exteriorPower.ιMulti ℂ 7 v) (exteriorPower.ιMulti ℂ 7 w) =
      orthBasis.det (Fin.append v w) := by
  change volume (wedge (exteriorPower.ιMulti ℂ 7 v) (exteriorPower.ιMulti ℂ 7 w)) = _
  rw [wedge_pure, volume, exteriorPower.alternatingMapLinearEquiv_apply_ιMulti]

private def blockSwap : Equiv.Perm Axis := finAddFlip (m := 7) (n := 7)

private theorem blockSwap_sign : blockSwap.sign = -1 := by
  decide +kernel

private theorem append_swap (v w : Fin 7 → Space) : Fin.append w v = Fin.append v w ∘ blockSwap := by
  funext j
  refine Fin.addCases ?_ ?_ j
  · intro i
    rw [Function.comp_apply, blockSwap, finAddFlip_apply_castAdd, Fin.append_left, Fin.append_right]
  · intro i
    rw [Function.comp_apply, blockSwap, finAddFlip_apply_natAdd, Fin.append_right, Fin.append_left]

private theorem ext_mid {W : Type*} [AddCommGroup W] [Module ℂ W] {f g : Mid →ₗ[ℂ] W}
    (h : ∀ v : Fin 7 → Space, f (exteriorPower.ιMulti ℂ 7 v) = g (exteriorPower.ιMulti ℂ 7 v)) :
    f = g := by
  apply exteriorPower.linearMap_ext
  ext v
  exact h v

private theorem ext_mid₂ {f g : Mid →ₗ[ℂ] Mid →ₗ[ℂ] ℂ}
    (h : ∀ v w : Fin 7 → Space,
      f (exteriorPower.ιMulti ℂ 7 v) (exteriorPower.ιMulti ℂ 7 w) =
      g (exteriorPower.ιMulti ℂ 7 v) (exteriorPower.ιMulti ℂ 7 w)) : f = g := by
  apply ext_mid
  intro v
  exact ext_mid (h v)

theorem volumePair_skew (x y : Mid) : volumePair y x = -volumePair x y := by
  have h : volumePair.flip = -volumePair := by
    apply ext_mid₂
    intro v w
    simp only [LinearMap.flip_apply, LinearMap.neg_apply, volumePair_pure]
    rw [append_swap, AlternatingMap.map_perm, blockSwap_sign]
    simp
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

private theorem append_map (f : Space →ₗ[ℂ] Space) (v w : Fin 7 → Space) :
    Fin.append (f ∘ v) (f ∘ w) = f ∘ Fin.append v w := by
  funext j
  refine Fin.addCases ?_ ?_ j
  · intro i; rw [Function.comp_apply, Fin.append_left, Fin.append_left]; rfl
  · intro i; rw [Function.comp_apply, Fin.append_right, Fin.append_right]; rfl

theorem volumePair_invariant (g : splitSpecialOrthogonal) (x y : Mid) :
    volumePair (exteriorRepresentation 7 g x) (exteriorRepresentation 7 g y) = volumePair x y := by
  let A := exteriorRepresentation 7 g
  have h : ((volumePair.comp A).flip.comp A).flip = volumePair := by
    apply ext_mid₂
    intro v w
    change volumePair (exteriorPower.map 7 g.val (exteriorPower.ιMulti ℂ 7 v))
      (exteriorPower.map 7 g.val (exteriorPower.ιMulti ℂ 7 w)) = _
    rw [exteriorPower.map_apply_ιMulti, exteriorPower.map_apply_ιMulti, volumePair_pure,
      volumePair_pure, append_map, Module.Basis.det_comp, g.prop.1, one_mul]
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

private def dotMetric : Space →ₗ[ℂ] Space →ₗ[ℂ] ℂ :=
  LinearMap.mk₂ ℂ (fun x y => ∑ j, x j * y j)
    (fun x₁ x₂ y => by simp [add_mul, Finset.sum_add_distrib])
    (fun r x y => by simp [smul_eq_mul, mul_assoc, Finset.mul_sum])
    (fun x y₁ y₂ => by simp [mul_add, Finset.sum_add_distrib])
    (fun r x y => by simp [smul_eq_mul, mul_left_comm, Finset.mul_sum])

def splitMetric : Space →ₗ[ℂ] Space →ₗ[ℂ] ℂ :=
  let f := mixEquiv.symm.toLinearMap
  ((dotMetric.comp f).flip.comp f).flip

theorem splitMetric_apply (x y : Space) : splitMetric x y = splitForm x y := by
  change (∑ j, (mixEquiv.symm x) j * (mixEquiv.symm y) j) = _
  rw [← splitForm_mix]
  change splitForm (mixEquiv (mixEquiv.symm x)) (mixEquiv (mixEquiv.symm y)) = _
  simp

theorem orthBasis_pair (i j : Axis) : splitForm (orthBasis i) (orthBasis j) = if i = j then 1 else 0 := by
  change splitForm (mix (axisBasis i)) (mix (axisBasis j)) = _
  rw [splitForm_mix, Finset.sum_eq_single i]
  · simp [axisBasis, Pi.basisFun_apply, Pi.single_apply]
  · intro l _ hl
    simp [axisBasis, Pi.basisFun_apply, hl]
  · simp

theorem preserves_splitForm_of_basis (f : Space →ₗ[ℂ] Space)
    (hb : ∀ i j, splitForm (f (orthBasis i)) (f (orthBasis j)) = splitForm (orthBasis i) (orthBasis j))
    (x y : Space) : splitForm (f x) (f y) = splitForm x y := by
  have h : ((splitMetric.comp f).flip.comp f).flip = splitMetric := by
    apply orthBasis.ext
    intro i
    apply orthBasis.ext
    intro j
    simp only [LinearMap.flip_apply, LinearMap.comp_apply, splitMetric_apply]
    exact hb i j
  simpa only [LinearMap.flip_apply, LinearMap.comp_apply, splitMetric_apply] using
    DFunLike.congr_fun (DFunLike.congr_fun h x) y

private theorem splitMetric_axis (i : Axis) : splitMetric (orthBasis i) = orthBasis.coord i := by
  apply orthBasis.ext
  intro j
  rw [splitMetric_apply, orthBasis_pair, Module.Basis.coord_apply, Module.Basis.repr_self,
    Finsupp.single_apply]
  simp [eq_comm]

/-- The determinant pairing induced by the split metric on exterior powers. -/
def exteriorMetric (n : ℕ) : (⋀[ℂ]^n Space) →ₗ[ℂ] (⋀[ℂ]^n Space) →ₗ[ℂ] ℂ :=
  (exteriorPower.pairingDual ℂ Space n).comp (exteriorPower.map n splitMetric)

abbrev metricPair : Mid →ₗ[ℂ] Mid →ₗ[ℂ] ℂ := exteriorMetric 7

theorem exteriorMetric_pure (n : ℕ) (u v : Fin n → Space) : exteriorMetric n
    (exteriorPower.ιMulti ℂ n u) (exteriorPower.ιMulti ℂ n v) =
      (Matrix.of fun i j => splitForm (u j) (v i)).det := by
  simp only [exteriorMetric, LinearMap.comp_apply, exteriorPower.map_apply_ιMulti,
    exteriorPower.pairingDual_ιMulti_ιMulti, Function.comp_apply, splitMetric_apply]

set_option maxRecDepth 4096 in
theorem exteriorMetric_axis (n : ℕ) (s : Index n) :
    exteriorMetric n (orthBasis.exteriorPower n s) = (orthBasis.exteriorPower n).coord s := by
  have h : splitMetric ∘ orthBasis = orthBasis.coord := funext splitMetric_axis
  calc
    exteriorMetric n (orthBasis.exteriorPower n s) = exteriorPower.ιMultiDual ℂ n orthBasis s := by
      simp only [exteriorMetric, LinearMap.comp_apply, exteriorPower.basis_apply,
        exteriorPower.map_apply_ιMulti_family, h, exteriorPower.ιMultiDual]
    _ = (orthBasis.exteriorPower n).coord s := (exteriorPower.basis_coord ℂ n orthBasis s).symm

private theorem metricPair_axis (s : MiddleIndex) : metricPair (middleBasis s) = middleBasis.coord s :=
  exteriorMetric_axis 7 s

theorem exteriorMetric_injective (n : ℕ) : Function.Injective (exteriorMetric n) := by
  let b := orthBasis.exteriorPower n
  have h (s : Index n) : (exteriorMetric n).flip (b s) = b.coord s := by
    apply b.ext
    intro t
    simp only [LinearMap.flip_apply, b, exteriorMetric_axis, Module.Basis.coord_apply,
      Module.Basis.repr_self, Finsupp.single_apply]
    simp [eq_comm]
  intro x y hxy
  apply b.repr.injective
  ext s
  change b.coord s x = b.coord s y
  rw [← h s]
  exact DFunLike.congr_fun hxy (b s)

private theorem metricPair_injective : Function.Injective metricPair := exteriorMetric_injective 7

theorem metricPair_invariant (g : splitSpecialOrthogonal) (x y : Mid) :
    metricPair (exteriorRepresentation 7 g x) (exteriorRepresentation 7 g y) = metricPair x y := by
  let A := exteriorRepresentation 7 g
  have h : ((metricPair.comp A).flip.comp A).flip = metricPair := by
    apply ext_mid₂
    intro v w
    change metricPair (exteriorPower.map 7 g.val (exteriorPower.ιMulti ℂ 7 v))
      (exteriorPower.map 7 g.val (exteriorPower.ιMulti ℂ 7 w)) = _
    simp only [metricPair, exteriorMetric, LinearMap.comp_apply, exteriorPower.map_apply_ιMulti,
      exteriorPower.pairingDual_ιMulti_ιMulti, Function.comp_apply, splitMetric_apply, g.prop.2]
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

private def shuffleSign (s : MiddleIndex) : ℤˣ :=
  (Set.powersetCard.permOfDisjoint (disjoint_complement s)).sign

theorem volume_top (s : Index 14) : volume (exteriorPower.ιMulti_family ℂ 14 orthBasis s) = 1 := by
  have hs : s.val = Finset.univ := s.val.card_eq_iff_eq_univ.mp (by simp)
  have he : (Set.powersetCard.ofFinEmbEquiv.symm s : Axis ↪o Axis) = RelEmbedding.refl _ := by
    symm
    apply Finset.orderEmbOfFin_unique' s.prop
    rw [hs]
    intro i
    exact Finset.mem_univ _
  simp [volume, exteriorPower.ιMulti_family, he, Module.Basis.det_self]

private theorem wedge_complement (s : MiddleIndex) :
    wedge (middleBasis s) (middleBasis (complement s)) = shuffleSign s •
      exteriorPower.ιMulti_family ℂ 14 orthBasis (Set.powersetCard.disjUnion (disjoint_complement s)) := by
  apply Subtype.ext
  simpa only [wedge, middleBasis, exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe,
    Submodule.coe_smul_of_tower, shuffleSign]
    using ExteriorAlgebra.ιMulti_family_mul_of_disjoint ℂ orthBasis s (complement s) (disjoint_complement s)

private theorem volumePair_zero (s t : MiddleIndex) (h : t ≠ complement s) :
    volumePair (middleBasis s) (middleBasis t) = 0 := by
  have hz : wedge (middleBasis s) (middleBasis t) = 0 := by
    apply Subtype.ext
    simpa only [wedge, middleBasis, exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe,
      Submodule.coe_zero]
      using ExteriorAlgebra.ιMulti_family_mul_of_not_disjoint ℂ orthBasis s t (mt (disjoint_iff s t).mp h)
  change volume (wedge (middleBasis s) (middleBasis t)) = 0
  rw [hz, map_zero]

private def coefficient (s : MiddleIndex) : ℂ := volumePair (middleBasis s) (middleBasis (complement s))

private theorem coefficient_sq (s : MiddleIndex) : coefficient s * coefficient s = 1 := by
  change volume (wedge (middleBasis s) (middleBasis (complement s))) *
    volume (wedge (middleBasis s) (middleBasis (complement s))) = 1
  rw [wedge_complement]
  rcases Int.units_eq_one_or (shuffleSign s) with h | h
  · simp [h, volume_top]
  · simp [h, volume_top]

private theorem coefficient_complement (s : MiddleIndex) : coefficient (complement s) = -coefficient s := by
  simp only [coefficient, complement_complement, volumePair_skew (middleBasis s) (middleBasis (complement s))]

/-- Hodge star, with the chosen orthonormal volume. It squares to minus the identity. -/
def star : Mid →ₗ[ℂ] Mid :=
  middleBasis.constr ℂ fun s => coefficient s • middleBasis (complement s)

private theorem star_basis (s : MiddleIndex) : star (middleBasis s) = coefficient s • middleBasis (complement s) :=
  middleBasis.constr_basis _ _ _

theorem metric_star (x y : Mid) : metricPair (star x) y = volumePair x y := by
  have h : metricPair.comp star = volumePair := by
    apply middleBasis.ext
    intro s
    apply middleBasis.ext
    intro t
    simp only [LinearMap.comp_apply, star_basis, map_smul, LinearMap.smul_apply, metricPair_axis,
      Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
    by_cases he : t = complement s
    · subst t; simp [coefficient]
    · simp [he, volumePair_zero s t he]
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

theorem star_square (x : Mid) : star (star x) = -x := by
  have h : star.comp star = -LinearMap.id := by
    apply middleBasis.ext
    intro s
    simp only [LinearMap.comp_apply, star_basis, map_smul, coefficient_complement,
      complement_complement, smul_smul, mul_neg, coefficient_sq, neg_one_smul, LinearMap.neg_apply,
      LinearMap.id_apply]
  exact DFunLike.congr_fun h x

theorem star_equivariant (g : splitSpecialOrthogonal) (x : Mid) :
    star (exteriorRepresentation 7 g x) = exteriorRepresentation 7 g (star x) := by
  apply metricPair_injective
  apply LinearMap.ext
  intro y
  let e := LinearMap.equivOfIsUnitDet (g.prop.1 ▸ isUnit_one : IsUnit g.val.det)
  have he : e.toLinearMap = g.val := LinearMap.coe_equivOfIsUnitDet _
  have hs : Function.Surjective (exteriorRepresentation 7 g) := by
    intro w
    refine ⟨exteriorPower.map 7 e.symm.toLinearMap w, ?_⟩
    change (exteriorPower.map 7 g.val).comp (exteriorPower.map 7 e.symm.toLinearMap) w = w
    rw [← exteriorPower.map_comp, ← he, LinearEquiv.comp_coe, LinearEquiv.symm_trans_self,
      LinearEquiv.refl_toLinearMap, exteriorPower.map_id, LinearMap.id_apply]
  obtain ⟨w, rfl⟩ := hs y
  rw [metric_star, volumePair_invariant, metricPair_invariant, metric_star]

def orthDiagonal (c : Axis → ℂ) : Space →ₗ[ℂ] Space :=
  orthBasis.constr ℂ fun j => c j • orthBasis j

theorem orthDiagonal_basis (c : Axis → ℂ) (j : Axis) :
    orthDiagonal c (orthBasis j) = c j • orthBasis j :=
  orthBasis.constr_basis _ _ _

theorem orthDiagonal_exterior (c : Axis → ℂ) (k : ℕ) (s : Index k) :
    exteriorPower.map k (orthDiagonal c) (orthBasis.exteriorPower k s) =
      (∏ j ∈ s.val, c j) • orthBasis.exteriorPower k s := by
  rw [exteriorPower.basis_apply, exteriorPower.map_apply_ιMulti_family]
  let e := s.val.orderIsoOfFin s.prop
  change exteriorPower.ιMulti ℂ k (fun j => orthDiagonal c (orthBasis (e j).val)) =
    (∏ j ∈ s.val, c j) • exteriorPower.ιMulti ℂ k (fun j => orthBasis (e j).val)
  simp only [orthDiagonal_basis, AlternatingMap.map_smul_univ]
  congr 1
  calc
    _ = ∏ j : s.val, c j.val := Fintype.prod_equiv e.toEquiv _ (fun j => c j.val) fun _ => rfl
    _ = _ := Finset.prod_coe_sort s.val c

/-- Reflection in the first orthonormal axis. -/
def vectorReflection : Space →ₗ[ℂ] Space := orthDiagonal fun j => if j = 0 then -1 else 1

theorem vectorReflection_square (x : Space) : vectorReflection (vectorReflection x) = x := by
  have h : vectorReflection.comp vectorReflection = LinearMap.id := by
    apply orthBasis.ext
    intro i
    simp only [LinearMap.comp_apply, vectorReflection, orthDiagonal_basis, map_smul, LinearMap.id_apply]
    by_cases hi : i = 0 <;> simp [hi]
  exact DFunLike.congr_fun h x

theorem vectorReflection_isometry (x y : Space) :
    splitForm (vectorReflection x) (vectorReflection y) = splitForm x y := by
  apply preserves_splitForm_of_basis
  intro i j
  simp only [vectorReflection, orthDiagonal_basis, ← splitMetric_apply,
    map_smul, LinearMap.smul_apply, smul_eq_mul]
  rw [splitMetric_apply, orthBasis_pair]
  by_cases h : i = j
  · subst j; by_cases hi : i = 0 <;> simp [hi]
  · simp [h]

def reflection : Mid →ₗ[ℂ] Mid := exteriorPower.map 7 vectorReflection

private theorem reflection_basis (s : MiddleIndex) : reflection (middleBasis s) =
    (if 0 ∈ s.val then (-1 : ℂ) else 1) • middleBasis s := by
  change exteriorPower.map 7 (orthDiagonal _) (orthBasis.exteriorPower 7 s) = _
  rw [orthDiagonal_exterior]
  congr 1
  by_cases h : (0 : Axis) ∈ s.val
  · rw [if_pos h, Finset.prod_eq_single 0]
    · simp
    · intro j _ hj; simp [hj]
    · exact fun h' => (h' h).elim
  · rw [if_neg h]
    apply Finset.prod_eq_one
    intro j hj
    have h' : j ≠ 0 := fun e => h (e ▸ hj)
    simp [h']

theorem reflection_square (x : Mid) : reflection (reflection x) = x := by
  have h : reflection.comp reflection = LinearMap.id := by
    apply middleBasis.ext
    intro s
    simp only [LinearMap.comp_apply, reflection_basis, map_smul, LinearMap.id_apply]
    by_cases hs : (0 : Axis) ∈ s.val <;> simp [hs, smul_smul]
  exact DFunLike.congr_fun h x

theorem star_reflection (x : Mid) : star (reflection x) = -reflection (star x) := by
  have h : star.comp reflection = -(reflection.comp star) := by
    apply middleBasis.ext
    intro s
    simp only [LinearMap.comp_apply, LinearMap.neg_apply, reflection_basis, map_smul, star_basis]
    by_cases h : (0 : Axis) ∈ s.val <;> simp [complement, h] <;> module
  exact DFunLike.congr_fun h x

/-- Normalizing the Hodge star makes its two eigenvalues `1` and `-1`. -/
def involution : Mid →ₗ[ℂ] Mid := Complex.I • star

theorem involution_square (x : Mid) : involution (involution x) = x := by
  simp [involution, LinearMap.smul_apply, smul_smul, Complex.I_mul_I, star_square]

theorem involution_equivariant (g : splitSpecialOrthogonal) (x : Mid) :
    involution (exteriorRepresentation 7 g x) = exteriorRepresentation 7 g (involution x) := by
  simp [involution, star_equivariant]

theorem involution_basis (s : MiddleIndex) :
    ∃ c : ℂ, c ≠ 0 ∧ involution (middleBasis s) = c • middleBasis (complement s) := by
  refine ⟨Complex.I * coefficient s, mul_ne_zero Complex.I_ne_zero ?_, ?_⟩
  · intro hc
    have h := coefficient_sq s
    rw [hc, zero_mul] at h
    exact zero_ne_one h
  · simp [involution, star_basis, smul_smul]

def involutionEigenspace {E : Type*} [AddCommGroup E] [Module ℂ E]
    (J : E →ₗ[ℂ] E) (a : ℂ) : Submodule ℂ E := LinearMap.ker (J - a • LinearMap.id)

theorem mem_involutionEigenspace {E : Type*} [AddCommGroup E] [Module ℂ E]
    (J : E →ₗ[ℂ] E) (a : ℂ) (x : E) : x ∈ involutionEigenspace J a ↔ J x = a • x := by
  simp [involutionEigenspace, LinearMap.mem_ker, sub_eq_zero]

abbrev sector (a : ℂ) : Submodule ℂ Mid := involutionEigenspace involution a

theorem mem_sector (a : ℂ) (x : Mid) : x ∈ sector a ↔ involution x = a • x := by
  exact mem_involutionEigenspace involution a x

theorem sector_invariant (a : ℂ) (g : splitSpecialOrthogonal) (x : Mid) (h : x ∈ sector a) :
    exteriorRepresentation 7 g x ∈ sector a := by
  rw [mem_sector] at h ⊢
  rw [involution_equivariant, h, map_smul]

theorem involution_eigenspaces_isCompl {E : Type*} [AddCommGroup E] [Module ℂ E]
    (J : E →ₗ[ℂ] E) (hJ : ∀ x, J (J x) = x) :
    IsCompl (involutionEigenspace J 1) (involutionEigenspace J (-1)) := by
  constructor
  · rw [Submodule.disjoint_def]
    intro x hx hy
    have hx' : J x = x := by simpa using (mem_involutionEigenspace J 1 x).mp hx
    have hy' : J x = -x := ((mem_involutionEigenspace J (-1) x).mp hy).trans (by module)
    have hv : (2 : ℂ) • x = 0 := by
      rw [two_smul]
      nth_rw 1 [hx'.symm.trans hy']
      exact neg_add_cancel x
    exact (smul_eq_zero.mp hv).resolve_left (by norm_num)
  · apply codisjoint_iff_le_sup.mpr
    intro x _
    rw [Submodule.mem_sup]
    refine ⟨(1 / 2 : ℂ) • (x + J x), ?_, (1 / 2 : ℂ) • (x - J x), ?_, ?_⟩
    · simp only [mem_involutionEigenspace, map_smul, map_add, hJ, one_smul]
      rw [add_comm (J x) x]
    · simp only [mem_involutionEigenspace, map_smul, map_sub, hJ]
      module
    · module

theorem middle_sectors_isCompl : IsCompl (sector 1) (sector (-1)) :=
  involution_eigenspaces_isCompl involution involution_square

private theorem reflection_sector (a : ℂ) (x : Mid) (h : x ∈ sector a) : reflection x ∈ sector (-a) := by
  rw [mem_sector] at h ⊢
  have he : involution (reflection x) = -reflection (involution x) := by
    simp [involution, star_reflection]
  rw [he, h, map_smul]
  module

private def sectorEquiv : sector 1 ≃ₗ[ℂ] sector (-1) where
  toFun x := ⟨reflection x.val, reflection_sector 1 x.val x.prop⟩
  invFun y := ⟨reflection y.val, by simpa using reflection_sector (-1) y.val y.prop⟩
  left_inv x := Subtype.ext (reflection_square x.val)
  right_inv y := Subtype.ext (reflection_square y.val)
  map_add' x y := Subtype.ext (reflection.map_add x.val y.val)
  map_smul' c x := Subtype.ext (reflection.map_smul c x.val)

/-- The degree-seven exterior representation is the direct sum of two invariant
subspaces of dimension 1716. -/
theorem middle_sector_dimensions :
    Module.finrank ℂ (sector 1) = 1716 ∧ Module.finrank ℂ (sector (-1)) = 1716 := by
  have h := Submodule.finrank_add_eq_of_isCompl middle_sectors_isCompl
  rw [exteriorPower.finrank_eq, Module.finrank_pi, Fintype.card_fin] at h
  have he := sectorEquiv.finrank_eq
  have hc : Nat.choose 14 7 = 3432 := by decide
  rw [hc] at h
  omega

private theorem axisBasis_coord (x : Space) (i : Axis) : axisBasis.coord i x = x i := by
  simp [axisBasis, Module.Basis.coord_apply, Pi.basisFun_repr]

private theorem axisBasis_value (j i : Axis) : axisBasis j i = if i = j then 1 else 0 := by
  simp [axisBasis, Pi.basisFun_apply, Pi.single_apply]

private theorem same_plus (i j : Pair) : plusAxis i = plusAxis j ↔ i = j :=
  ⟨fun h => by simpa only [plus_index] using congrArg pairIndex h, congrArg plusAxis⟩

private theorem same_minus (i j : Pair) : minusAxis i = minusAxis j ↔ i = j :=
  ⟨fun h => by simpa only [minus_index] using congrArg pairIndex h, congrArg minusAxis⟩

private theorem plus_diff_minus (i j : Pair) : plusAxis i ≠ minusAxis j := by
  intro h
  have e := congrArg Fin.val h
  change 2 * i.val = 2 * j.val + 1 at e
  omega

private theorem minus_diff_plus (i j : Pair) : minusAxis i ≠ plusAxis j :=
  Ne.symm (plus_diff_minus j i)

private theorem mix_det : mix.det = Complex.I := by
  let b := axisBasis.reindex (axesEquiv.symm.trans (Equiv.prodComm _ _))
  let A : Matrix (Fin 2) (Fin 2) ℂ := !![1, Complex.I; 1 / 2, -Complex.I / 2]
  have hA : LinearMap.toMatrix b b mix = Matrix.blockDiagonal (fun _ : Pair => A) := by
    ext ⟨a, i⟩ ⟨d, j⟩
    rw [LinearMap.toMatrix_apply, Matrix.blockDiagonal_apply]
    simp only [b, Module.Basis.reindex_apply, Module.Basis.repr_reindex_apply,
      Equiv.symm_trans_apply, Equiv.symm_symm, Equiv.prodComm_symm, Equiv.prodComm_apply]
    change axisBasis.coord (axesEquiv (i, a)) (mix (axisBasis (axesEquiv (j, d)))) = _
    rw [axisBasis_coord]
    fin_cases a <;> fin_cases d <;>
      simp [axesEquiv, mix_plus, mix_minus, axisBasis_value, same_plus, same_minus,
        plus_diff_minus, minus_diff_plus, A] <;>
      split <;> simp_all
  rw [← LinearMap.det_toMatrix b, hA, Matrix.det_blockDiagonal]
  have hc : A.det = -Complex.I := by
    rw [Matrix.det_fin_two]
    change 1 * (-Complex.I / 2) - Complex.I * (1 / 2) = -Complex.I
    ring
  rw [Finset.prod_const, Finset.card_univ, Fintype.card_fin, hc]
  calc
    (-Complex.I) ^ 7 = Complex.I * (Complex.I * Complex.I) ^ 3 * (-1) := by ring
    _ = Complex.I := by rw [Complex.I_mul_I]; ring

private theorem null_volume : orthBasis.det axisBasis = -Complex.I := by
  have hu : orthBasis.det (mix ∘ axisBasis) = 1 := Module.Basis.det_self orthBasis
  rw [Module.Basis.det_comp, mix_det] at hu
  linear_combination (-Complex.I) * hu + (orthBasis.det axisBasis) * Complex.I_mul_I

theorem splitMetric_null_plus (i : Pair) : splitMetric (axisBasis (plusAxis i)) = axisBasis.coord (minusAxis i) := by
  apply LinearMap.ext
  intro y
  rw [splitMetric_apply, axisBasis_coord]
  change (∑ j : Pair, (axisBasis (plusAxis i) (plusAxis j) * y (minusAxis j) +
    axisBasis (plusAxis i) (minusAxis j) * y (plusAxis j))) = _
  simp [axisBasis_value, same_plus, minus_diff_plus]

private theorem metric_minus (i : Pair) : splitMetric (axisBasis (minusAxis i)) = axisBasis.coord (plusAxis i) := by
  apply LinearMap.ext
  intro y
  rw [splitMetric_apply, axisBasis_coord]
  change (∑ j : Pair, (axisBasis (minusAxis i) (plusAxis j) * y (minusAxis j) +
    axisBasis (minusAxis i) (minusAxis j) * y (plusAxis j))) = _
  simp [axisBasis_value, same_minus, plus_diff_minus]

private def selected (minusLast : Bool) : MiddleIndex :=
  if minusLast then lastMinus else highestPlus (7 : Fin 15)

private def preferred (minusLast : Bool) (i : Pair) : Axis :=
  if minusLast && i == 6 then minusAxis i else plusAxis i

private theorem selected_order (minusLast : Bool) (i : Pair) :
    Set.powersetCard.ofFinEmbEquiv.symm (selected minusLast) i = preferred minusLast i := by
  have hmono : ∀ b : Bool, ∀ a d : Pair, a < d → preferred b a < preferred b d := by decide +kernel
  have hm : ∀ b : Bool, ∀ j : Pair, preferred b j ∈ (selected b).val := by decide +kernel
  let f := OrderEmbedding.ofStrictMono (preferred minusLast) (hmono minusLast)
  exact (congrArg (fun e : Pair ↪o Axis => e i)
    (Finset.orderEmbOfFin_unique' (selected minusLast).prop (f := f) (hm minusLast))).symm

private def opposite (minusLast : Bool) (i : Pair) : Axis :=
  if minusLast && i == 6 then plusAxis i else minusAxis i

private theorem opposite_order (minusLast : Bool) (i : Pair) :
    Set.powersetCard.ofFinEmbEquiv.symm (complement (selected minusLast)) i = opposite minusLast i := by
  have hmono : ∀ b : Bool, ∀ a d : Pair, a < d → opposite b a < opposite b d := by decide +kernel
  have hm : ∀ b : Bool, ∀ j : Pair, opposite b j ∈ (complement (selected b)).val := by decide +kernel
  let f := OrderEmbedding.ofStrictMono (opposite minusLast) (hmono minusLast)
  exact (congrArg (fun e : Pair ↪o Axis => e i)
    (Finset.orderEmbOfFin_unique' (complement (selected minusLast)).prop (f := f) (hm minusLast))).symm

private def nullShuffle (minusLast : Bool) : Equiv.Perm Axis :=
  Equiv.ofBijective (Fin.append (preferred minusLast) (opposite minusLast)) (by
    cases minusLast <;> constructor <;> intro j
    · revert j; decide +kernel
    · revert j; decide +kernel
    · revert j; decide +kernel
    · revert j; decide +kernel)

private theorem nullShuffle_sign (minusLast : Bool) :
    (nullShuffle minusLast).sign = if minusLast then 1 else -1 := by
  cases minusLast <;> decide +kernel

private abbrev nullBasis := axisBasis.exteriorPower 7

set_option maxRecDepth 4096 in
private theorem metric_selected (b : Bool) : metricPair (nullBasis (selected b)) =
    nullBasis.coord (complement (selected b)) := by
  calc
    _ = exteriorPower.ιMultiDual ℂ 7 axisBasis (complement (selected b)) := by
      simp only [metricPair, exteriorMetric, LinearMap.comp_apply, exteriorPower.basis_apply, exteriorPower.ιMultiDual,
        exteriorPower.ιMulti_family, exteriorPower.map_apply_ιMulti]
      congr 1
      congr 1
      funext j
      simp only [Function.comp_apply, selected_order, opposite_order, preferred, opposite]
      split <;> simp [splitMetric_null_plus, metric_minus]
    _ = _ := (exteriorPower.basis_coord ℂ 7 axisBasis _).symm

private theorem volume_selected_complement (b : Bool) :
    volumePair (nullBasis (selected b)) (nullBasis (complement (selected b))) =
      if b then -Complex.I else Complex.I := by
  simp only [exteriorPower.basis_apply, exteriorPower.ιMulti_family, volumePair_pure]
  have h : Fin.append (axisBasis ∘ Set.powersetCard.ofFinEmbEquiv.symm (selected b))
      (axisBasis ∘ Set.powersetCard.ofFinEmbEquiv.symm (complement (selected b))) =
      axisBasis ∘ nullShuffle b := by
    funext j
    refine Fin.addCases ?_ ?_ j
    · intro i
      rw [Fin.append_left, Function.comp_apply, selected_order]
      change _ = axisBasis (Fin.append (preferred b) (opposite b) (Fin.castAdd 7 i))
      rw [Fin.append_left]
    · intro i
      rw [Fin.append_right, Function.comp_apply, opposite_order]
      change _ = axisBasis (Fin.append (preferred b) (opposite b) (Fin.natAdd 7 i))
      rw [Fin.append_right]
  rw [h, AlternatingMap.map_perm, nullShuffle_sign, null_volume]
  cases b <;> simp

private theorem volume_selected (b : Bool) : volumePair (nullBasis (selected b)) =
    (if b then -Complex.I else Complex.I) • nullBasis.coord (complement (selected b)) := by
  apply nullBasis.ext
  intro t
  rw [LinearMap.smul_apply, smul_eq_mul, Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
  by_cases ht : t = complement (selected b)
  · subst t
    rw [if_pos rfl, mul_one, volume_selected_complement]
  · have hz : wedge (nullBasis (selected b)) (nullBasis t) = 0 := by
      apply Subtype.ext
      simpa only [wedge, exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe, Submodule.coe_zero]
        using ExteriorAlgebra.ιMulti_family_mul_of_not_disjoint ℂ axisBasis (selected b) t
          (mt (disjoint_iff (selected b) t).mp ht)
    change volume (wedge (nullBasis (selected b)) (nullBasis t)) = _
    rw [hz, map_zero, if_neg ht, mul_zero]

private theorem selected_star (b : Bool) : star (nullBasis (selected b)) =
    (if b then -Complex.I else Complex.I) • nullBasis (selected b) := by
  apply metricPair_injective
  apply LinearMap.ext
  intro y
  rw [metric_star, volume_selected, map_smul, metric_selected]

/-- The all-positive highest-weight wedge belongs to the negative Hodge sector
for the orientation and the involution `I • star` used here. -/
theorem highestPlus_mem_sector : nullBasis (highestPlus (7 : Fin 15)) ∈ sector (-1) := by
  rw [mem_sector]
  have h := selected_star false
  change star (nullBasis (highestPlus (7 : Fin 15))) =
    Complex.I • nullBasis (highestPlus (7 : Fin 15)) at h
  simp only [involution, LinearMap.smul_apply, h, smul_smul, Complex.I_mul_I]

/-- The sign-reversed highest-weight wedge belongs to the positive Hodge sector. -/
theorem lastMinus_mem_sector : nullBasis lastMinus ∈ sector 1 := by
  rw [mem_sector]
  have h := selected_star true
  change star (nullBasis lastMinus) = -Complex.I • nullBasis lastMinus at h
  simp only [involution, LinearMap.smul_apply, h, smul_smul, mul_neg, Complex.I_mul_I, neg_neg]

end
end GeometricUnity.D7Hodge
