import D7RealComparison
import BianchiSymbol
import Mathlib.LinearAlgebra.Alternating.Uncurry.Fin

/-! # Real first jets, exterior alternation, and the split metric -/

namespace GeometricUnity.D7RealJets

open D7Exterior (Axis)
open D7RealComparison (Covector)
open scoped TensorProduct BigOperators

noncomputable section

set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1000000

abbrev Forms (k : ℕ) := ⋀[ℝ]^k Covector
abbrev FormJets := Covector ⊗[ℝ] Forms 2

def formBasis : Module.Basis Axis ℝ Covector := (Pi.basisFun ℝ Axis).dualBasis

def wedgeTwo (x y : Covector) : Forms 2 := exteriorPower.ιMulti ℝ 2 ![x, y]
def wedgeThree (x y z : Covector) : Forms 3 := exteriorPower.ιMulti ℝ 3 ![x, y, z]

theorem two_ext {W : Type*} [AddCommGroup W] [Module ℝ W] {f g : Forms 2 →ₗ[ℝ] W}
    (h : ∀ y z, f (wedgeTwo y z) = g (wedgeTwo y z)) : f = g := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  have hv : (![v 0, v 1] : Fin 2 → Covector) = v := by funext i; fin_cases i <;> rfl
  simpa only [LinearMap.compAlternatingMap_apply, wedgeTwo, hv] using h (v 0) (v 1)

theorem tensor_ext {W : Type*} [AddCommGroup W] [Module ℝ W] {f g : FormJets →ₗ[ℝ] W}
    (h : ∀ x y z, f (x ⊗ₜ[ℝ] wedgeTwo y z) = g (x ⊗ₜ[ℝ] wedgeTwo y z)) : f = g := by
  apply TensorProduct.ext'
  intro x u
  have he : f.comp (TensorProduct.mk ℝ Covector (Forms 2) x) =
      g.comp (TensorProduct.mk ℝ Covector (Forms 2) x) := two_ext (h x)
  exact DFunLike.congr_fun he u

private theorem three_ext {W : Type*} [AddCommGroup W] [Module ℝ W] {f g : Forms 3 →ₗ[ℝ] W}
    (h : ∀ x y z, f (wedgeThree x y z) = g (wedgeThree x y z)) : f = g := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  have hv : (![v 0, v 1, v 2] : Fin 3 → Covector) = v := by funext i; fin_cases i <;> rfl
  simpa only [LinearMap.compAlternatingMap_apply, wedgeThree, hv] using h (v 0) (v 1) (v 2)

private theorem coe_wedgeTwo (y z : Covector) :
    (wedgeTwo y z : ExteriorAlgebra ℝ Covector) = ExteriorAlgebra.ι ℝ y * ExteriorAlgebra.ι ℝ z := by
  simp [wedgeTwo, ExteriorAlgebra.ιMulti_apply]

private theorem coe_wedgeThree (x y z : Covector) :
    (wedgeThree x y z : ExteriorAlgebra ℝ Covector) =
      ExteriorAlgebra.ι ℝ x * (ExteriorAlgebra.ι ℝ y * ExteriorAlgebra.ι ℝ z) := by
  simp [wedgeThree, ExteriorAlgebra.ιMulti_apply]

theorem wedgeTwo_swap (x y : Covector) : wedgeTwo x y = -wedgeTwo y x := by
  apply Subtype.ext
  simp only [Submodule.coe_neg, coe_wedgeTwo]
  exact eq_neg_of_add_eq_zero_left (ExteriorAlgebra.ι_add_mul_swap (R := ℝ) x y)

private def wedgeLeft (x : Covector) (u : Forms 2) : Forms 3 :=
  ⟨ExteriorAlgebra.ι ℝ x * u.val, by
    change _ ∈ (LinearMap.range (ExteriorAlgebra.ι ℝ : Covector →ₗ[ℝ] _)) ^ (2 + 1)
    rw [Nat.add_comm 2 1, pow_add, pow_one]
    exact Submodule.mul_mem_mul (LinearMap.mem_range_self _ x) u.prop⟩

private def wedgeLeftLinear : Covector →ₗ[ℝ] Forms 2 →ₗ[ℝ] Forms 3 :=
  LinearMap.mk₂ ℝ wedgeLeft
    (fun x y u => by
      apply Subtype.ext
      change ExteriorAlgebra.ι ℝ (x + y) * u.val = _
      rw [map_add]
      exact add_mul _ _ _)
    (fun r x u => by
      apply Subtype.ext
      change ExteriorAlgebra.ι ℝ (r • x) * u.val = _
      rw [map_smul]
      exact smul_mul_assoc _ _ _)
    (fun x u v => by apply Subtype.ext; exact mul_add _ _ _)
    (fun r x u => by apply Subtype.ext; exact mul_smul_comm _ _ _)

/-- Wedge the derivative covector with the two form covectors. -/
def wedgeJet : FormJets →ₗ[ℝ] Forms 3 := TensorProduct.lift wedgeLeftLinear

@[simp] theorem wedgeJet_pure (x y z : Covector) :
    wedgeJet (x ⊗ₜ[ℝ] wedgeTwo y z) = wedgeThree x y z := by
  rw [wedgeJet, TensorProduct.lift.tmul]
  apply Subtype.ext
  change ExteriorAlgebra.ι ℝ x * (wedgeTwo y z).val = _
  rw [coe_wedgeTwo, coe_wedgeThree]

theorem map_wedgeTwo (f : Covector →ₗ[ℝ] Covector) (x y : Covector) :
    exteriorPower.map 2 f (wedgeTwo x y) = wedgeTwo (f x) (f y) := by
  rw [wedgeTwo, wedgeTwo, exteriorPower.map_apply_ιMulti]
  congr 1
  funext i
  fin_cases i <;> rfl

private theorem map_wedgeThree (f : Covector →ₗ[ℝ] Covector) (x y z : Covector) :
    exteriorPower.map 3 f (wedgeThree x y z) = wedgeThree (f x) (f y) (f z) := by
  rw [wedgeThree, wedgeThree, exteriorPower.map_apply_ιMulti]
  congr 1
  funext i
  fin_cases i <;> rfl

theorem wedgeJet_natural (f : Covector →ₗ[ℝ] Covector) :
    wedgeJet.comp (TensorProduct.map f (exteriorPower.map 2 f)) =
      (exteriorPower.map 3 f).comp wedgeJet := by
  apply tensor_ext
  intro x y z
  simp only [LinearMap.comp_apply, TensorProduct.map_tmul, map_wedgeTwo, wedgeJet_pure,
    map_wedgeThree]

private def insertionAlternating : Covector →ₗ[ℝ] (Covector [⋀^Fin 2]→ₗ[ℝ] FormJets) where
  toFun x := (TensorProduct.mk ℝ Covector (Forms 2) x).compAlternatingMap (exteriorPower.ιMulti ℝ 2)
  map_add' x y := by ext v; exact TensorProduct.add_tmul _ _ _
  map_smul' c x := by ext v; exact (TensorProduct.smul_tmul' c x _).symm

def includeThree : Forms 3 →ₗ[ℝ] FormJets :=
  (1 / 3 : ℝ) • exteriorPower.alternatingMapLinearEquiv (R := ℝ) (M := Covector) (N := FormJets) (n := 3)
    (AlternatingMap.alternatizeUncurryFin (R := ℝ) (M := Covector) (N := FormJets) insertionAlternating)

@[simp] theorem includeThree_pure (x y z : Covector) :
    includeThree (wedgeThree x y z) = (1 / 3 : ℝ) •
      (x ⊗ₜ[ℝ] wedgeTwo y z + y ⊗ₜ[ℝ] wedgeTwo z x + z ⊗ₜ[ℝ] wedgeTwo x y) := by
  simp only [includeThree, LinearMap.smul_apply, wedgeThree,
    exteriorPower.alternatingMapLinearEquiv_apply_ιMulti,
    AlternatingMap.alternatizeUncurryFin_apply, insertionAlternating,
    LinearMap.coe_mk, AddHom.coe_mk, LinearMap.compAlternatingMap_apply, TensorProduct.mk_apply]
  let F (i : Fin 3) := (-1 : ℤ) ^ i.val •
    (![x, y, z] i ⊗ₜ[ℝ] exteriorPower.ιMulti ℝ 2 (i.removeNth ![x, y, z]))
  change (1 / 3 : ℝ) • ∑ i : Fin 3, F i = _
  rw [Fin.sum_univ_three]
  have h₀ : F 0 = x ⊗ₜ[ℝ] wedgeTwo y z := by
    change (1 : ℤ) • (x ⊗ₜ[ℝ] wedgeTwo y z) = _
    exact one_zsmul _
  have h : (1 : Fin 3).removeNth ![x, y, z] = ![x, z] := by
    funext i
    fin_cases i <;> rfl
  have h₁ : F 1 = y ⊗ₜ[ℝ] wedgeTwo z x := by
    change (-1 : ℤ) • (y ⊗ₜ[ℝ] exteriorPower.ιMulti ℝ 2 ((1 : Fin 3).removeNth ![x, y, z])) = _
    rw [h]
    change (-1 : ℤ) • (y ⊗ₜ[ℝ] wedgeTwo x z) = _
    have hm : y ⊗ₜ[ℝ] wedgeTwo x z = -(y ⊗ₜ[ℝ] wedgeTwo z x) :=
      (congrArg (fun u : Forms 2 => y ⊗ₜ[ℝ] u) (wedgeTwo_swap x z)).trans
        (TensorProduct.tmul_neg y (wedgeTwo z x))
    rw [hm, neg_one_zsmul]
    exact neg_neg (y ⊗ₜ[ℝ] wedgeTwo z x : FormJets)
  have h₂ : F 2 = z ⊗ₜ[ℝ] wedgeTwo x y := by
    change (-1 : ℤ) ^ 2 • (z ⊗ₜ[ℝ] wedgeTwo x y) = _
    norm_num
  rw [h₀, h₁, h₂]

private theorem wedgeThree_rotate (x y z : Covector) : wedgeThree y z x = wedgeThree x y z := by
  let p : Equiv.Perm (Fin 3) := Equiv.swap 0 2 * Equiv.swap 0 1
  have hp : p.sign = 1 := by decide +kernel
  have he : (![y, z, x] : Fin 3 → Covector) = ![x, y, z] ∘ p := by
    funext i
    fin_cases i <;> rfl
  rw [wedgeThree, wedgeThree, he, AlternatingMap.map_perm, hp, one_smul]

theorem wedge_includeThree : wedgeJet.comp includeThree = LinearMap.id := by
  apply three_ext
  intro x y z
  simp only [LinearMap.comp_apply, includeThree_pure, map_smul, map_add, wedgeJet_pure,
    wedgeThree_rotate y z x, wedgeThree_rotate x y z, LinearMap.id_apply]
  module

theorem includeThree_natural (f : Covector →ₗ[ℝ] Covector) :
    includeThree.comp (exteriorPower.map 3 f) =
      (TensorProduct.map f (exteriorPower.map 2 f)).comp includeThree := by
  apply three_ext (W := FormJets)
  intro x y z
  simp only [LinearMap.comp_apply, map_wedgeThree, includeThree_pure, map_smul, map_add,
    TensorProduct.map_tmul, map_wedgeTwo]

private def pairCoordinate (b c : Axis) : (Forms 2) →ₗ[ℝ] ℝ :=
  exteriorPower.pairingDual ℝ Covector 2
    (exteriorPower.ιMulti ℝ 2 ![formBasis.coord b, formBasis.coord c])

private theorem pairCoordinate_wedge (b c : Axis) (y z : Covector) :
    pairCoordinate b c (wedgeTwo y z) =
      formBasis.coord b y * formBasis.coord c z - formBasis.coord c y * formBasis.coord b z := by
  simp [pairCoordinate, wedgeTwo, exteriorPower.pairingDual_ιMulti_ιMulti, Matrix.det_fin_two]

private theorem pairCoordinate_swap (b c : Axis) :
    pairCoordinate c b = -pairCoordinate b c := by
  apply two_ext
  intro x y
  simp only [LinearMap.neg_apply, pairCoordinate_wedge]
  ring

private def tripleCoordinate (a b c : Axis) : FormJets →ₗ[ℝ] ℝ :=
  TensorProduct.lift ((formBasis.coord a).smulRight (pairCoordinate b c))

@[simp] private theorem tripleCoordinate_tmul (a b c : Axis) (x : Covector) (u : Forms 2) :
    tripleCoordinate a b c (x ⊗ₜ[ℝ] u) = formBasis.coord a x * pairCoordinate b c u := rfl

private theorem tripleCoordinate_swap (a b c : Axis) :
    tripleCoordinate a c b = -tripleCoordinate a b c := by
  apply TensorProduct.ext'
  intro x u
  rw [tripleCoordinate_tmul, LinearMap.neg_apply, tripleCoordinate_tmul,
    pairCoordinate_swap b c, LinearMap.neg_apply, mul_neg]

private theorem tripleCoordinate_average (a b c : Axis) (s : FormJets) :
    tripleCoordinate a b c (includeThree (wedgeJet s)) =
      (1 / 3 : ℝ) * (tripleCoordinate a b c s + tripleCoordinate b c a s +
        tripleCoordinate c a b s) := by
  let f := (tripleCoordinate a b c).comp (includeThree.comp wedgeJet)
  let g := (1 / 3 : ℝ) • (tripleCoordinate a b c + tripleCoordinate b c a +
    tripleCoordinate c a b)
  have h : f = g := by
    apply TensorProduct.ext'
    intro x u
    let m := TensorProduct.mk ℝ Covector (Forms 2) x
    have hm : f.comp m = g.comp m := by
      apply two_ext
      intro y z
      simp only [f, g, m, LinearMap.comp_apply, TensorProduct.mk_apply, wedgeJet_pure,
        includeThree_pure, map_smul, map_add, LinearMap.smul_apply,
        LinearMap.add_apply, tripleCoordinate_tmul, pairCoordinate_wedge, smul_eq_mul]
      ring
    exact DFunLike.congr_fun hm u
  exact DFunLike.congr_fun h s

section Coefficients

variable {E : Type} [AddCommGroup E] [Module ℝ E]

private def coordinateEntry (a b c : Axis) : (FormJets ⊗[ℝ] E) →ₗ[ℝ] E :=
  (TensorProduct.lid ℝ E).toLinearMap.comp ((tripleCoordinate a b c).rTensor E)

@[simp] private theorem coordinateEntry_tmul (a b c : Axis) (s : FormJets) (x : E) :
    coordinateEntry a b c (s ⊗ₜ[ℝ] x) = tripleCoordinate a b c s • x := by
  simp [coordinateEntry]

private theorem coordinateEntry_swap (a b c : Axis) :
    (coordinateEntry a c b : (FormJets ⊗[ℝ] E) →ₗ[ℝ] E) = -coordinateEntry a b c := by
  apply TensorProduct.ext'
  intro s x
  rw [coordinateEntry_tmul, LinearMap.neg_apply, coordinateEntry_tmul,
    tripleCoordinate_swap a b c, LinearMap.neg_apply, neg_smul]

/-- The coordinates of a tensor with the derivative slot first and the
skew two-form slots second and third. -/
def tensorJet : (FormJets ⊗[ℝ] E) →ₗ[ℝ] BianchiSymbol.Jet Axis E where
  toFun s := ⟨fun a b c => coordinateEntry a b c s, by
    intro a b c
    change coordinateEntry a c b s = -coordinateEntry a b c s
    rw [coordinateEntry_swap, LinearMap.neg_apply]⟩
  map_add' s t := by
    apply Subtype.ext
    funext a b c
    exact map_add (coordinateEntry a b c) s t
  map_smul' r s := by
    apply Subtype.ext
    funext a b c
    exact (coordinateEntry a b c).map_smul r s

/-- Assemble the skew pair using all ordered coordinate pairs. -/
def assembleJet (J : BianchiSymbol.Jet Axis E) : FormJets ⊗[ℝ] E :=
  (2 : ℝ)⁻¹ • ∑ a : Axis, ∑ b : Axis, ∑ c : Axis,
    (formBasis a ⊗ₜ[ℝ] wedgeTwo (formBasis b) (formBasis c)) ⊗ₜ[ℝ] J.val a b c

private theorem axisCoordinate_basis (i j : Axis) :
    formBasis.coord i (formBasis j) = if i = j then 1 else 0 := by
  simp [Module.Basis.coord_apply, Finsupp.single_apply, eq_comm]

private theorem tensorJet_assemble (J : BianchiSymbol.Jet Axis E) :
    tensorJet (assembleJet J) = J := by
  apply Subtype.ext
  funext i j k
  change coordinateEntry i j k (assembleJet J) = J.val i j k
  simp only [assembleJet, map_smul, map_sum, coordinateEntry_tmul, tripleCoordinate_tmul,
    pairCoordinate_wedge, axisCoordinate_basis]
  have h (a b c : Axis) :
      ((if i = a then (1 : ℝ) else 0) *
        ((if j = b then 1 else 0) * (if k = c then 1 else 0) -
          (if k = b then 1 else 0) * (if j = c then 1 else 0))) • J.val a b c =
      (if k = c then if j = b then if i = a then J.val a b c else 0 else 0 else 0) -
      (if j = c then if k = b then if i = a then J.val a b c else 0 else 0 else 0) := by
    split_ifs <;> simp
  simp_rw [h, Finset.sum_sub_distrib]
  simp only [Finset.sum_ite_eq, Finset.mem_univ, if_true]
  rw [J.prop i j k]
  module

private def tensorBasis : Module.Basis (Axis × D7Exterior.Index 2) ℝ FormJets :=
  formBasis.tensorProduct (formBasis.exteriorPower 2)

private theorem pairCoordinate_basis (s : D7Exterior.Index 2) :
    let e := s.val.orderIsoOfFin s.prop
    pairCoordinate (e 0).val (e 1).val = (formBasis.exteriorPower 2).coord s := by
  let e := s.val.orderIsoOfFin s.prop
  have he : (![formBasis.coord (e 0).val, formBasis.coord (e 1).val] : Fin 2 → _) =
      fun j => formBasis.coord (e j).val := by
    funext j
    fin_cases j <;> rfl
  change pairCoordinate (e 0).val (e 1).val = _
  rw [pairCoordinate, he]
  exact (exteriorPower.basis_coord ℝ 2 formBasis s).symm

private theorem tripleCoordinate_basis (a : Axis) (s : D7Exterior.Index 2) :
    let e := s.val.orderIsoOfFin s.prop
    tripleCoordinate a (e 0).val (e 1).val = tensorBasis.coord (a, s) := by
  apply TensorProduct.ext'
  intro x u
  rw [tripleCoordinate_tmul, pairCoordinate_basis]
  simp only [Module.Basis.coord_apply, tensorBasis, Module.Basis.tensorProduct_repr_tmul_apply,
    smul_eq_mul]
  exact mul_comm _ _

private theorem tensorJet_injective :
    Function.Injective (tensorJet : (FormJets ⊗[ℝ] E) →ₗ[ℝ] BianchiSymbol.Jet Axis E) := by
  intro s t h
  apply (TensorProduct.equivFinsuppOfBasisLeft tensorBasis).injective
  ext ⟨a, ij⟩
  let e := ij.val.orderIsoOfFin ij.prop
  have hentry : coordinateEntry a (e 0).val (e 1).val s =
      coordinateEntry a (e 0).val (e 1).val t :=
    congrArg (fun J : BianchiSymbol.Jet Axis E => J.val a (e 0).val (e 1).val) h
  have hcoord : tripleCoordinate a (e 0).val (e 1).val = tensorBasis.coord (a, ij) :=
    tripleCoordinate_basis a ij
  simpa only [TensorProduct.equivFinsuppOfBasisLeft_apply, coordinateEntry, LinearMap.comp_apply,
    LinearEquiv.coe_coe, hcoord] using hentry

/-- Tensor and skew-array descriptions of a first jet. -/
def jetEquiv : (FormJets ⊗[ℝ] E) ≃ₗ[ℝ] BianchiSymbol.Jet Axis E where
  __ := tensorJet
  invFun := assembleJet
  left_inv s := tensorJet_injective (tensorJet_assemble (tensorJet s))
  right_inv := tensorJet_assemble

private theorem coordinateEntry_average (a b c : Axis) (s : FormJets ⊗[ℝ] E) :
    coordinateEntry a b c (includeThree.rTensor E (wedgeJet.rTensor E s)) =
      (1 / 3 : ℝ) • BianchiSymbol.cyclicSum (tensorJet s).val a b c := by
  let p := (includeThree.rTensor E).comp (wedgeJet.rTensor E)
  have h : (coordinateEntry a b c).comp p =
      (1 / 3 : ℝ) • ((coordinateEntry a b c) + coordinateEntry b c a + coordinateEntry c a b) := by
    apply TensorProduct.ext'
    intro t x
    simp only [p, LinearMap.comp_apply, LinearMap.rTensor_tmul, coordinateEntry_tmul,
      LinearMap.smul_apply, LinearMap.add_apply, tripleCoordinate_average, mul_smul, add_smul]
  exact DFunLike.congr_fun h s

/-- The cyclic mean in the coordinate model is the projection obtained
by exterior alternation followed by the normalized three-form inclusion. -/
theorem cyclic_average_eq_projection (s : FormJets ⊗[ℝ] E) (a b c : Axis) :
    (BianchiSymbol.alternation (tensorJet s)).val.val a b c =
      (tensorJet (includeThree.rTensor E (wedgeJet.rTensor E s))).val a b c := by
  rw [BianchiSymbol.alternation_apply]
  change _ = coordinateEntry a b c (includeThree.rTensor E (wedgeJet.rTensor E s))
  rw [coordinateEntry_average]

/-- The coordinate closed-jet condition is exactly the kernel of wedge
alternation on the derivative and form slots. -/
theorem closed_tensorJet_iff (s : FormJets ⊗[ℝ] E) :
    BianchiSymbol.ClosedJet (tensorJet s) ↔ wedgeJet.rTensor E s = 0 := by
  have hsection : (wedgeJet.rTensor E).comp (includeThree.rTensor E) =
      LinearMap.id := by
    apply TensorProduct.ext'
    intro u x
    have h := DFunLike.congr_fun wedge_includeThree u
    simp only [LinearMap.comp_apply, LinearMap.rTensor_tmul, LinearMap.id_apply]
    exact congrArg (fun v => v ⊗ₜ[ℝ] x) h
  rw [BianchiSymbol.closed_iff_alternation_eq_zero]
  constructor
  · intro h
    have hj : tensorJet (includeThree.rTensor E (wedgeJet.rTensor E s)) = 0 := by
      apply Subtype.ext
      funext a b c
      rw [← cyclic_average_eq_projection, h]
      rfl
    have hz := tensorJet_injective (hj.trans (map_zero tensorJet).symm)
    have hp := DFunLike.congr_fun hsection (wedgeJet.rTensor E s)
    change wedgeJet.rTensor E
        (includeThree.rTensor E (wedgeJet.rTensor E s)) = _ at hp
    rw [hz, map_zero] at hp
    exact hp.symm
  · intro h
    apply Subtype.ext
    apply Subtype.ext
    funext a b c
    rw [cyclic_average_eq_projection, h, map_zero, map_zero]
    rfl

end Coefficients

section Trace

open D7SpinAction D7RealComparison

private abbrev sharp := metricDualEquiv.symm.toLinearEquiv

private def metricIso : Covector ≃ₗ[ℝ] Module.Dual ℝ Covector :=
  sharp.trans (Module.evalEquiv ℝ Vector)

private def metric (a b : Covector) : ℝ := metricIso a b

private theorem metric_symm (a b : Covector) : metric a b = metric b a := by
  obtain ⟨x, rfl⟩ := metricDualEquiv.toLinearEquiv.surjective a
  obtain ⟨y, rfl⟩ := metricDualEquiv.toLinearEquiv.surjective b
  simp only [metric, metricIso, LinearEquiv.trans_apply,
    Module.evalEquiv_apply, Module.Dual.eval_apply]
  have hs (v : Vector) : sharp (metricDualEquiv.toLinearEquiv v) = v :=
    metricDualEquiv.symm_apply_apply v
  rw [hs, hs]
  change WitnessW1.splitForm.associated y x = WitnessW1.splitForm.associated x y
  rw [QuadraticMap.associated_apply, QuadraticMap.associated_apply, add_comm y x]
  congr 1
  ring

private theorem metric_invariant (g : Spin) (a b : Covector) :
    metric (vectorRepresentation.dual g a) (vectorRepresentation.dual g b) = metric a b := by
  have h := DFunLike.congr_fun (metricDualEquiv.symm.isIntertwining' g) a
  change sharp (vectorRepresentation.dual g a) = vectorRepresentation g (sharp a) at h
  have hx : vectorRepresentation g⁻¹ (vectorRepresentation g (sharp a)) = sharp a := by
    change (vectorRepresentation g⁻¹ * vectorRepresentation g) (sharp a) = sharp a
    rw [← map_mul, inv_mul_cancel, map_one]
    rfl
  change b (vectorRepresentation g⁻¹ (sharp (vectorRepresentation.dual g a))) = b (sharp a)
  rw [h, hx]

private def traceTerm (y z : Covector) : Covector →ₗ[ℝ] Covector :=
  (metricIso.toLinearMap.flip y).smulRight z - (metricIso.toLinearMap.flip z).smulRight y

private def traceAlt : Covector [⋀^Fin 2]→ₗ[ℝ] (Covector →ₗ[ℝ] Covector) where
  toFun w := traceTerm (w 0) (w 1)
  map_update_add' w i a b := by
    apply LinearMap.ext
    intro x
    fin_cases i <;> simp [traceTerm, Function.update, smul_add, add_smul] <;> module
  map_update_smul' w i c a := by
    apply LinearMap.ext
    intro x
    fin_cases i <;> simp [traceTerm, Function.update, smul_smul, smul_sub] <;> module
  map_eq_zero_of_eq' w i j h hij := by
    fin_cases i <;> fin_cases j <;> try exact (hij rfl).elim
    all_goals
      apply LinearMap.ext
      intro x
      have he : w 0 = w 1 := by first | exact h | exact h.symm
      simp [traceTerm, he]

/-- Contract the derivative slot against the form slots with the inverse split metric. -/
def traceJet : FormJets →ₗ[ℝ] Covector :=
  TensorProduct.lift (exteriorPower.alternatingMapLinearEquiv
    (R := ℝ) (M := Covector) (N := Covector →ₗ[ℝ] Covector) (n := 2) traceAlt).flip

@[simp] theorem traceJet_pure (x y z : Covector) :
    traceJet (x ⊗ₜ[ℝ] wedgeTwo y z) = metric x y • z - metric x z • y := by
  simp [traceJet, wedgeTwo, traceAlt, traceTerm, metric]

theorem traceJet_equivariant (g : Spin) :
    traceJet.comp (TensorProduct.map (vectorRepresentation.dual g)
      (exteriorPower.map 2 (vectorRepresentation.dual g))) =
      (vectorRepresentation.dual g).comp traceJet := by
  apply tensor_ext (W := Covector)
  intro x y z
  simp only [LinearMap.comp_apply, TensorProduct.map_tmul, map_wedgeTwo, traceJet_pure,
    metric_invariant, map_sub, map_smul]

theorem trace_includeThree : traceJet.comp includeThree = 0 := by
  apply three_ext (W := Covector)
  intro x y z
  simp only [LinearMap.comp_apply, includeThree_pure, map_smul, map_add, traceJet_pure,
    metric_symm y x, metric_symm z x, metric_symm z y, LinearMap.zero_apply]
  module

private def tensorEval : (Covector ⊗[ℝ] Covector) ≃ₗ[ℝ] (Covector →ₗ[ℝ] Covector) :=
  (TensorProduct.congr metricIso (LinearEquiv.refl ℝ Covector)).trans
    (dualTensorHomEquiv ℝ Covector Covector)

private theorem tensorEval_tmul (x y z : Covector) :
    tensorEval (x ⊗ₜ[ℝ] y) z = metric x z • y := by
  change dualTensorHom ℝ Covector Covector (metricIso x ⊗ₜ[ℝ] y) z = _
  rw [dualTensorHom_apply]
  rfl

private def metricBasis (i : Axis) : Covector := metricIso.symm (formBasis.coord i)

private theorem metricBasis_apply (i : Axis) (x : Covector) :
    metric (metricBasis i) x = formBasis.repr x i := by
  rw [metric, metricBasis, metricIso.apply_symm_apply, Module.Basis.coord_apply]

private theorem metricBasis_sum (x : Covector) :
    (∑ i : Axis, metric (metricBasis i) x • formBasis i) = x := by
  simpa only [metricBasis_apply] using formBasis.sum_repr x

private def metricTensor : Covector ⊗[ℝ] Covector :=
  ∑ i : Axis, metricBasis i ⊗ₜ[ℝ] formBasis i

private theorem metricTensor_invariant (g : Spin) :
    TensorProduct.map (vectorRepresentation.dual g) (vectorRepresentation.dual g) metricTensor =
      metricTensor := by
  apply tensorEval.injective
  apply LinearMap.ext
  intro v
  have hv : vectorRepresentation.dual g (vectorRepresentation.dual g⁻¹ v) = v := by
    change (vectorRepresentation.dual g * vectorRepresentation.dual g⁻¹) v = v
    rw [← map_mul, mul_inv_cancel, map_one]
    rfl
  obtain ⟨x, rfl⟩ : ∃ x, vectorRepresentation.dual g x = v := ⟨_, hv⟩
  simp only [metricTensor, map_sum, TensorProduct.map_tmul, LinearMap.sum_apply,
    tensorEval_tmul, metric_invariant, metricBasis_sum]
  simp_rw [← map_smul (vectorRepresentation.dual g)]
  rw [← map_sum, metricBasis_sum]

private theorem wedgeTwo_add_left (x y z : Covector) :
    wedgeTwo (x + y) z = wedgeTwo x z + wedgeTwo y z := by
  apply Subtype.ext
  simp [coe_wedgeTwo, add_mul]

private theorem wedgeTwo_add_right (x y z : Covector) :
    wedgeTwo x (y + z) = wedgeTwo x y + wedgeTwo x z := by
  apply Subtype.ext
  simp [coe_wedgeTwo, mul_add]

private theorem wedgeTwo_smul_left (c : ℝ) (x y : Covector) :
    wedgeTwo (c • x) y = c • wedgeTwo x y := by
  apply Subtype.ext
  simp [coe_wedgeTwo]

private theorem wedgeTwo_smul_right (c : ℝ) (x y : Covector) :
    wedgeTwo x (c • y) = c • wedgeTwo x y := by
  apply Subtype.ext
  simp [coe_wedgeTwo]

private def rawTraceSection : Covector →ₗ[ℝ] FormJets where
  toFun x := ∑ i : Axis, metricBasis i ⊗ₜ[ℝ] wedgeTwo (formBasis i) x
  map_add' x y := by simp [wedgeTwo_add_right, TensorProduct.tmul_add, Finset.sum_add_distrib]
  map_smul' c x := by simp [wedgeTwo_smul_right, TensorProduct.tmul_smul, Finset.smul_sum]

private theorem trace_rawSection (x : Covector) : traceJet (rawTraceSection x) = (13 : ℝ) • x := by
  change traceJet (∑ i : Axis, metricBasis i ⊗ₜ[ℝ] wedgeTwo (formBasis i) x) = _
  simp only [map_sum, traceJet_pure, metricBasis_apply, Module.Basis.repr_self, Finsupp.single_eq_same,
    one_smul, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
    formBasis.sum_repr]
  module

private def insertVector (x : Covector) : (Covector ⊗[ℝ] Covector) →ₗ[ℝ] FormJets :=
  TensorProduct.map LinearMap.id
    { toFun := fun y => wedgeTwo y x
      map_add' := fun y z => wedgeTwo_add_left y z x
      map_smul' := fun c y => wedgeTwo_smul_left c y x }

private theorem insertVector_metricTensor (x : Covector) :
    insertVector x metricTensor = rawTraceSection x := by
  simp only [insertVector, metricTensor, map_sum, TensorProduct.map_tmul, LinearMap.id_apply]
  rfl

private theorem rawTraceSection_equivariant (g : Spin) :
    rawTraceSection.comp (vectorRepresentation.dual g) =
      (TensorProduct.map (vectorRepresentation.dual g)
        (exteriorPower.map 2 (vectorRepresentation.dual g))).comp rawTraceSection := by
  let f := vectorRepresentation.dual g
  apply LinearMap.ext
  intro x
  have h : (TensorProduct.map f (exteriorPower.map 2 f)).comp (insertVector x) =
      (insertVector (f x)).comp (TensorProduct.map f f) := by
    apply TensorProduct.ext'
    intro y z
    change TensorProduct.map f (exteriorPower.map 2 f) (y ⊗ₜ[ℝ] wedgeTwo z x) =
      (insertVector (f x)) (TensorProduct.map f f (y ⊗ₜ[ℝ] z))
    simp only [TensorProduct.map_tmul, map_wedgeTwo]
    rfl
  have ht := DFunLike.congr_fun h metricTensor
  change TensorProduct.map f (exteriorPower.map 2 f) (insertVector x metricTensor) =
    insertVector (f x) (TensorProduct.map f f metricTensor) at ht
  rw [show TensorProduct.map f f metricTensor = metricTensor from metricTensor_invariant g,
    insertVector_metricTensor, insertVector_metricTensor] at ht
  exact ht.symm

private def alternatingResidual : FormJets →ₗ[ℝ] FormJets where
  toFun x := x - includeThree (wedgeJet x)
  map_add' x y := by simp only [map_add]; abel
  map_smul' c x := by simp only [map_smul, smul_sub, RingHom.id_apply]

/-- A trace section with its alternating projection removed. -/
def includeVector : Covector →ₗ[ℝ] FormJets :=
  (1 / 13 : ℝ) • alternatingResidual.comp rawTraceSection

theorem wedge_includeVector : wedgeJet.comp includeVector = 0 := by
  apply LinearMap.ext
  intro x
  change wedgeJet ((1 / 13 : ℝ) • (rawTraceSection x - includeThree (wedgeJet (rawTraceSection x)))) = 0
  have h : wedgeJet (includeThree (wedgeJet (rawTraceSection x))) = wedgeJet (rawTraceSection x) :=
    DFunLike.congr_fun wedge_includeThree _
  rw [map_smul, map_sub, h, sub_self, smul_zero]

theorem trace_includeVector : traceJet.comp includeVector = LinearMap.id := by
  apply LinearMap.ext
  intro x
  change traceJet ((1 / 13 : ℝ) • (rawTraceSection x - includeThree (wedgeJet (rawTraceSection x)))) = x
  have h : traceJet (includeThree (wedgeJet (rawTraceSection x))) = 0 :=
    DFunLike.congr_fun trace_includeThree _
  rw [map_smul, map_sub, h, sub_zero, trace_rawSection, smul_smul]
  norm_num

theorem includeVector_equivariant (g : Spin) :
    includeVector.comp (vectorRepresentation.dual g) =
      (TensorProduct.map (vectorRepresentation.dual g)
        (exteriorPower.map 2 (vectorRepresentation.dual g))).comp includeVector := by
  let f := vectorRepresentation.dual g
  let F := TensorProduct.map f (exteriorPower.map 2 f)
  have hw : wedgeJet.comp F = (exteriorPower.map 3 f).comp wedgeJet := wedgeJet_natural f
  have hi : includeThree.comp (exteriorPower.map 3 f) = F.comp includeThree := includeThree_natural f
  have hr : rawTraceSection.comp f = F.comp rawTraceSection := rawTraceSection_equivariant g
  apply LinearMap.ext
  intro x
  have hr' : rawTraceSection (f x) = F (rawTraceSection x) := DFunLike.congr_fun hr x
  have hw' : wedgeJet (F (rawTraceSection x)) =
      exteriorPower.map 3 f (wedgeJet (rawTraceSection x)) := DFunLike.congr_fun hw (rawTraceSection x)
  have hi' : includeThree (exteriorPower.map 3 f (wedgeJet (rawTraceSection x))) =
      F (includeThree (wedgeJet (rawTraceSection x))) :=
    DFunLike.congr_fun hi (wedgeJet (rawTraceSection x))
  change (1 / 13 : ℝ) • (rawTraceSection (f x) - includeThree (wedgeJet (rawTraceSection (f x)))) =
    F ((1 / 13 : ℝ) • (rawTraceSection x - includeThree (wedgeJet (rawTraceSection x))))
  rw [hr', hw', hi', map_smul, map_sub]

end Trace

end
end GeometricUnity.D7RealJets
