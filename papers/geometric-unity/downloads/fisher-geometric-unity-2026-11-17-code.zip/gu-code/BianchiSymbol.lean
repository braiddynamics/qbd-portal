import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Module
import Mathlib.Tactic.NormNum

/-!
# Geometric Unity: the Bianchi symbol criterion

In coordinates, a first jet of a two-form is an array `J a b c`
skew in its last two indices. The exterior derivative of the two-form
has components given by the cyclic sum. Every jet in the kernel of
that sum is realized by a closed linear two-form. A linear symbol
vanishes on all such jets precisely when it factors uniquely through
the projection onto alternating tensors.
-/

namespace GeometricUnity.BianchiSymbol

noncomputable section

open scoped BigOperators

variable {ι E W : Type*}
variable [AddCommGroup E] [Module ℝ E] [AddCommGroup W] [Module ℝ W]

abbrev Coefficients (ι E : Type*) := ι → ι → ι → E

def skewJets (ι E : Type*) [AddCommGroup E] [Module ℝ E] :
    Submodule ℝ (Coefficients ι E) where
  carrier := {J | ∀ a b c, J a c b = -J a b c}
  zero_mem' := by intro a b c; simp
  add_mem' := by
    intro J K hJ hK a b c
    change J a c b + K a c b = -(J a b c + K a b c)
    rw [hJ a b c, hK a b c, neg_add]
  smul_mem' := by
    intro r J hJ a b c
    change r • J a c b = -(r • J a b c)
    rw [hJ a b c, smul_neg]

abbrev Jet (ι E : Type*) [AddCommGroup E] [Module ℝ E] := ↥(skewJets ι E)

/-- For a jet already skew in its last two indices, cyclic invariance
is equivalent to total alternation. -/
def alternatingJets (ι E : Type*) [AddCommGroup E] [Module ℝ E] :
    Submodule ℝ (Jet ι E) where
  carrier := {J | ∀ a b c, J.val c a b = J.val a b c}
  zero_mem' := by intro a b c; rfl
  add_mem' := by
    intro J K hJ hK a b c
    change J.val c a b + K.val c a b = J.val a b c + K.val a b c
    rw [hJ a b c, hK a b c]
  smul_mem' := by
    intro r J hJ a b c
    change r • J.val c a b = r • J.val a b c
    rw [hJ a b c]

abbrev ThreeForm (ι E : Type*) [AddCommGroup E] [Module ℝ E] :=
  ↥(alternatingJets ι E)

theorem ThreeForm.swapFirst (J : ThreeForm ι E) (a b c : ι) :
    J.val.val b a c = -J.val.val a b c := by
  rw [J.property a c b, J.val.property a b c]

def cyclicSum (J : Coefficients ι E) (a b c : ι) : E :=
  J a b c + J b c a + J c a b

def ClosedJet (J : Jet ι E) : Prop := ∀ a b c, cyclicSum J.val a b c = 0

private def cyclicAverage : Jet ι E →ₗ[ℝ] Jet ι E where
  toFun J := ⟨fun a b c => (1 / 3 : ℝ) • cyclicSum J.val a b c, by
    intro a b c
    change (1 / 3 : ℝ) • cyclicSum J.val a c b = -((1 / 3 : ℝ) • cyclicSum J.val a b c)
    unfold cyclicSum
    rw [J.property a b c, J.property c a b, J.property b c a, ← smul_neg]
    congr 1
    abel⟩
  map_add' J K := by
    apply Subtype.ext
    funext a b c
    change (1 / 3 : ℝ) • cyclicSum (J.val + K.val) a b c =
      (1 / 3 : ℝ) • cyclicSum J.val a b c + (1 / 3 : ℝ) • cyclicSum K.val a b c
    rw [← smul_add]
    congr 1
    simp only [cyclicSum, Pi.add_apply]
    abel
  map_smul' r J := by
    apply Subtype.ext
    funext a b c
    change (1 / 3 : ℝ) • cyclicSum (r • J.val) a b c =
      r • ((1 / 3 : ℝ) • cyclicSum J.val a b c)
    simp only [cyclicSum, Pi.smul_apply, ← smul_add]
    rw [smul_comm]

/-- Alternation is the mean of the three cyclic permutations on the
space of jets skew in their last two slots. -/
def alternation : Jet ι E →ₗ[ℝ] ThreeForm ι E :=
  cyclicAverage.codRestrict (alternatingJets ι E) (by
    intro J a b c
    change (1 / 3 : ℝ) • cyclicSum J.val c a b = (1 / 3 : ℝ) • cyclicSum J.val a b c
    congr 1
    unfold cyclicSum
    abel)

theorem alternation_apply (J : Jet ι E) (a b c : ι) :
    (alternation J).val.val a b c = (1 / 3 : ℝ) • cyclicSum J.val a b c := rfl

theorem alternation_retract (F : ThreeForm ι E) : alternation F.val = F := by
  apply Subtype.ext
  apply Subtype.ext
  funext a b c
  have second : F.val.val b c a = F.val.val a b c :=
    (F.property c a b).trans (F.property a b c)
  change (1 / 3 : ℝ) • cyclicSum F.val.val a b c = F.val.val a b c
  rw [cyclicSum, second, F.property a b c]
  module

theorem closed_iff_alternation_eq_zero (J : Jet ι E) : ClosedJet J ↔ alternation J = 0 := by
  constructor
  · intro h
    apply Subtype.ext
    apply Subtype.ext
    funext a b c
    change (1 / 3 : ℝ) • cyclicSum J.val a b c = 0
    rw [h a b c, smul_zero]
  · intro h a b c
    have hh : (1 / 3 : ℝ) • cyclicSum J.val a b c = 0 :=
      congrArg (fun T : ThreeForm ι E => T.val.val a b c) h
    exact (smul_eq_zero.mp hh).resolve_left (by norm_num)

def Compatible (M : Jet ι E →ₗ[ℝ] W) : Prop := ∀ J, ClosedJet J → M J = 0

def alternatingRestriction (M : Jet ι E →ₗ[ℝ] W) : ThreeForm ι E →ₗ[ℝ] W :=
  M.comp (alternatingJets ι E).subtype

theorem value_on_alternation (M : Jet ι E →ₗ[ℝ] W) (hM : Compatible M) (J : Jet ι E) :
    M J = M (alternation J).val := by
  have hker : alternation (J - (alternation J).val) = 0 := by
    rw [map_sub, alternation_retract, sub_self]
  have hz := hM _ ((closed_iff_alternation_eq_zero _).mpr hker)
  rw [map_sub] at hz
  exact sub_eq_zero.mp hz

/-- The Bianchi-compatible symbols are exactly the maps that factor
uniquely through alternation. The factor is restriction to three-forms. -/
theorem compatible_iff_unique_factor (M : Jet ι E →ₗ[ℝ] W) :
    Compatible M ↔ ∃! L : ThreeForm ι E →ₗ[ℝ] W, M = L.comp alternation := by
  constructor
  · intro hM
    refine ⟨alternatingRestriction M, LinearMap.ext (value_on_alternation M hM), ?_⟩
    intro L hL
    apply LinearMap.ext
    intro F
    have heq := LinearMap.congr_fun hL F.val
    rw [LinearMap.comp_apply, alternation_retract] at heq
    exact heq.symm
  · rintro ⟨L, hL, _⟩ J hJ
    rw [hL, LinearMap.comp_apply, (closed_iff_alternation_eq_zero J).mp hJ, map_zero]

/-- Restriction retains the intertwining identity for any action whose
action on three-forms is the restriction of its action on jets. -/
theorem alternatingRestriction_intertwines
    (M : Jet ι E →ₗ[ℝ] W) (S : Jet ι E →ₗ[ℝ] Jet ι E)
    (S₃ : ThreeForm ι E →ₗ[ℝ] ThreeForm ι E) (T : W →ₗ[ℝ] W)
    (hS : ∀ F, S F.val = (S₃ F).val) (hM : ∀ J, M (S J) = T (M J)) :
    ∀ F, alternatingRestriction M (S₃ F) = T (alternatingRestriction M F) := by
  intro F
  change M (S₃ F).val = T (M F.val)
  rw [← hS F, hM]

section Realization

variable [Fintype ι] [DecidableEq ι]

/-- A linear two-form with coefficients given by the prescribed first jet. -/
def linearField (J : Jet ι E) (x : ι → ℝ) (b c : ι) : E :=
  ∑ a, x a • J.val a b c

omit [DecidableEq ι] in
theorem linearField_skew (J : Jet ι E) (x : ι → ℝ) (b c : ι) :
    linearField J x c b = -linearField J x b c := by
  unfold linearField
  simp only [fun a => J.property a b c, smul_neg, Finset.sum_neg_distrib]

theorem linearField_line (J : Jet ι E) (x : ι → ℝ) (a b c : ι) (t : ℝ) :
    linearField J (x + t • Pi.single a 1) b c = linearField J x b c + t • J.val a b c := by
  simp [linearField, Pi.add_apply, Pi.smul_apply, Pi.single_apply, add_smul,
    mul_ite, ite_smul, Finset.sum_add_distrib]

end Realization

section CoordinateDerivative

variable {A : Type*} [NormedAddCommGroup A] [NormedSpace ℝ A]
variable [Fintype ι] [DecidableEq ι]

def coordinateDerivative (F : (ι → ℝ) → ι → ι → A) (x : ι → ℝ) (a b c : ι) : A :=
  deriv (fun t : ℝ => F (x + t • Pi.single a 1) b c) 0

def ClosedField (F : (ι → ℝ) → ι → ι → A) : Prop :=
  ∀ x a b c, cyclicSum (coordinateDerivative F x) a b c = 0

theorem hasPartial_linearField (J : Jet ι A) (x : ι → ℝ) (a b c : ι) :
    HasDerivAt (fun t : ℝ => linearField J (x + t • Pi.single a 1) b c) (J.val a b c) 0 := by
  simp_rw [linearField_line]
  apply (hasDerivAt_const_add_iff (linearField J x b c)).2
  simpa only [one_smul] using
    HasDerivAt.smul_const (hasDerivAt_id' (x := (0 : ℝ))) (J.val a b c)

theorem partial_linearField (J : Jet ι A) (x : ι → ℝ) (a b c : ι) :
    coordinateDerivative (linearField J) x a b c = J.val a b c :=
  (hasPartial_linearField J x a b c).deriv

/-- The realized form is closed at every coordinate point precisely
when the prescribed jet has vanishing cyclic sum. -/
theorem linearField_closed_iff (J : Jet ι A) : ClosedField (linearField J) ↔ ClosedJet J := by
  constructor
  · intro h a b c
    simpa only [cyclicSum, partial_linearField] using h 0 a b c
  · intro h x a b c
    simpa only [cyclicSum, partial_linearField] using h a b c

theorem closed_linear_realization (J : Jet ι A) (hJ : ClosedJet J) :
    ∃ F : (ι → ℝ) → ι → ι → A,
      (∀ x b c, F x c b = -F x b c) ∧ ClosedField F ∧
        ∀ x a b c, coordinateDerivative F x a b c = J.val a b c :=
  ⟨linearField J, linearField_skew J, (linearField_closed_iff J).mpr hJ, partial_linearField J⟩

/-- Taking coordinate derivatives preserves the skew symmetry of a two-form. -/
def firstJet (F : (ι → ℝ) → ι → ι → A)
    (hF : ∀ x b c, F x c b = -F x b c) (x : ι → ℝ) : Jet ι A :=
  ⟨coordinateDerivative F x, by
    intro a b c
    unfold coordinateDerivative
    have h : (fun t : ℝ => F (x + t • Pi.single a 1) c b) =
        fun t : ℝ => -F (x + t • Pi.single a 1) b c :=
      funext fun t => hF (x + t • Pi.single a 1) b c
    rw [h]
    exact deriv.neg (f := fun t : ℝ => F (x + t • Pi.single a 1) b c)⟩

/-- Testing on coordinatewise differentiable closed fields is equivalent
to testing on the closed jets. Linear fields suffice for the reverse direction. -/
theorem compatible_iff_closed_fields (M : Jet ι A →ₗ[ℝ] W) :
    Compatible M ↔
      ∀ (F : (ι → ℝ) → ι → ι → A) (hF : ∀ x b c, F x c b = -F x b c),
        (∀ x a b c,
          DifferentiableAt ℝ (fun t : ℝ => F (x + t • Pi.single a 1) b c) 0) →
          ClosedField F → ∀ x, M (firstJet F hF x) = 0 := by
  constructor
  · intro hM F hF _ hclosed x
    exact hM _ (hclosed x)
  · intro h J hJ
    have hz := h (linearField J) (linearField_skew J)
      (fun x a b c => (hasPartial_linearField J x a b c).differentiableAt)
      ((linearField_closed_iff J).mpr hJ) 0
    have heq : firstJet (linearField J) (linearField_skew J) 0 = J := by
      apply Subtype.ext
      funext a b c
      exact partial_linearField J 0 a b c
    rwa [heq] at hz

end CoordinateDerivative

end

end GeometricUnity.BianchiSymbol
