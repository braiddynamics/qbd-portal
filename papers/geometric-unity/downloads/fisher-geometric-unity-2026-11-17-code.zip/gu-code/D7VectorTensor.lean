import D7Hodge
import Mathlib.LinearAlgebra.Contraction
import Mathlib.RepresentationTheory.Intertwining

/-!
# Alternation and trace on the vector times two-form representation

The joint kernel is the traceless hook. The two projections and their
sections are formed using the exterior algebra and the same split form as
the exterior-power representation.
-/

namespace GeometricUnity.D7VectorTensor

open D7Exterior D7Hodge TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

abbrev Two := ⋀[ℂ]^2 Space
abbrev Three := ⋀[ℂ]^3 Space
abbrev VTwo := Space ⊗[ℂ] Two

def vectorAction : Representation ℂ splitSpecialOrthogonal Space where
  toFun g := g.val
  map_one' := rfl
  map_mul' _ _ := rfl

def tensorAction : Representation ℂ splitSpecialOrthogonal VTwo :=
  vectorAction.tprod (exteriorRepresentation 2)

def wedgeTwo (x y : Space) : Two := exteriorPower.ιMulti ℂ 2 ![x, y]

def wedgeThree (x y z : Space) : Three := exteriorPower.ιMulti ℂ 3 ![x, y, z]

private theorem coe_wedgeTwo (x y : Space) : (wedgeTwo x y : ExteriorAlgebra ℂ Space) =
    ExteriorAlgebra.ι ℂ x * ExteriorAlgebra.ι ℂ y := by
  simp [wedgeTwo, ExteriorAlgebra.ιMulti_apply]

private theorem coe_wedgeThree (x y z : Space) : (wedgeThree x y z : ExteriorAlgebra ℂ Space) =
    ExteriorAlgebra.ι ℂ x * (ExteriorAlgebra.ι ℂ y * ExteriorAlgebra.ι ℂ z) := by
  simp [wedgeThree, ExteriorAlgebra.ιMulti_apply]

theorem wedgeTwo_self (x : Space) : wedgeTwo x x = 0 := by
  apply Subtype.ext
  rw [coe_wedgeTwo, Submodule.coe_zero, ExteriorAlgebra.ι_sq_zero]

theorem wedgeTwo_swap (x y : Space) : wedgeTwo y x = -wedgeTwo x y := by
  apply Subtype.ext
  simp only [Submodule.coe_neg, coe_wedgeTwo]
  exact eq_neg_of_add_eq_zero_left (ExteriorAlgebra.ι_add_mul_swap (R := ℂ) y x)

private def wedgeLeft (n : ℕ) (x : Space) (u : ⋀[ℂ]^n Space) : ⋀[ℂ]^(n + 1) Space :=
  ⟨ExteriorAlgebra.ι ℂ x * u.val, by
    change _ ∈ (LinearMap.range (ExteriorAlgebra.ι ℂ : Space →ₗ[ℂ] _)) ^ (n + 1)
    rw [Nat.add_comm n 1, pow_add, pow_one]
    exact Submodule.mul_mem_mul (LinearMap.mem_range_self _ x) u.prop⟩

def wedgeLeftLinear (n : ℕ) : Space →ₗ[ℂ] (⋀[ℂ]^n Space) →ₗ[ℂ] (⋀[ℂ]^(n + 1) Space) :=
  LinearMap.mk₂ ℂ (wedgeLeft n)
    (fun x y u => by apply Subtype.ext; change ExteriorAlgebra.ι ℂ (x + y) * u.val = _; rw [map_add]; exact add_mul _ _ _)
    (fun r x u => by apply Subtype.ext; change ExteriorAlgebra.ι ℂ (r • x) * u.val = _; rw [map_smul]; exact smul_mul_assoc _ _ _)
    (fun x u v => by apply Subtype.ext; exact mul_add _ _ _)
    (fun r x u => by apply Subtype.ext; exact mul_smul_comm _ _ _)

def alternation : VTwo →ₗ[ℂ] Three := TensorProduct.lift (wedgeLeftLinear 2)

@[simp] theorem alternation_pure (x y z : Space) :
    alternation (x ⊗ₜ[ℂ] wedgeTwo y z) = wedgeThree x y z := by
  rw [alternation, TensorProduct.lift.tmul]
  apply Subtype.ext
  change ExteriorAlgebra.ι ℂ x * (wedgeTwo y z).val = _
  rw [coe_wedgeTwo, coe_wedgeThree]

theorem wedgeTwo_add_left (x y z : Space) : wedgeTwo (x + y) z = wedgeTwo x z + wedgeTwo y z := by
  apply Subtype.ext
  simp [coe_wedgeTwo, add_mul]

private theorem wedgeTwo_add_right (x y z : Space) : wedgeTwo x (y + z) = wedgeTwo x y + wedgeTwo x z := by
  apply Subtype.ext
  simp [coe_wedgeTwo, mul_add]

theorem wedgeTwo_smul_left (c : ℂ) (x y : Space) : wedgeTwo (c • x) y = c • wedgeTwo x y := by
  apply Subtype.ext
  simp [coe_wedgeTwo]

theorem wedgeTwo_smul_right (c : ℂ) (x y : Space) : wedgeTwo x (c • y) = c • wedgeTwo x y := by
  apply Subtype.ext
  simp [coe_wedgeTwo]

private def traceTerm (y z : Space) : Space →ₗ[ℂ] Space :=
  (splitMetric.flip y).smulRight z - (splitMetric.flip z).smulRight y

private def traceAlt : Space [⋀^Fin 2]→ₗ[ℂ] (Space →ₗ[ℂ] Space) where
  toFun w := traceTerm (w 0) (w 1)
  map_update_add' w i a b := by
    apply LinearMap.ext
    intro x
    fin_cases i <;> simp [traceTerm, Function.update, smul_add, add_smul] <;> module
  map_update_smul' w i c a := by
    apply LinearMap.ext
    intro x
    fin_cases i <;> simp [traceTerm, Function.update, smul_smul, smul_sub] <;> module
  map_eq_zero_of_eq' w i j h hij := by
    fin_cases i <;> fin_cases j <;> simp_all [traceTerm]

def trace : VTwo →ₗ[ℂ] Space :=
  TensorProduct.lift (exteriorPower.alternatingMapLinearEquiv traceAlt).flip

@[simp] theorem trace_pure (x y z : Space) :
    trace (x ⊗ₜ[ℂ] wedgeTwo y z) = splitForm x y • z - splitForm x z • y := by
  simp [trace, wedgeTwo, traceAlt, traceTerm, splitMetric_apply]

private theorem map_wedgeTwo (f : Space →ₗ[ℂ] Space) (x y : Space) :
    exteriorPower.map 2 f (wedgeTwo x y) = wedgeTwo (f x) (f y) := by
  rw [wedgeTwo, wedgeTwo, exteriorPower.map_apply_ιMulti]
  congr 1
  funext i
  fin_cases i <;> rfl

private theorem map_wedgeThree (f : Space →ₗ[ℂ] Space) (x y z : Space) :
    exteriorPower.map 3 f (wedgeThree x y z) = wedgeThree (f x) (f y) (f z) := by
  rw [wedgeThree, wedgeThree, exteriorPower.map_apply_ιMulti]
  congr 1
  funext i
  fin_cases i <;> rfl

private theorem two_ext {W : Type*} [AddCommGroup W] [Module ℂ W] {f g : Two →ₗ[ℂ] W}
    (h : ∀ y z, f (wedgeTwo y z) = g (wedgeTwo y z)) : f = g := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  have hv : (![v 0, v 1] : Fin 2 → Space) = v := by funext i; fin_cases i <;> rfl
  simpa only [LinearMap.compAlternatingMap_apply, wedgeTwo, hv] using h (v 0) (v 1)

private theorem three_ext {W : Type*} [AddCommGroup W] [Module ℂ W] {f g : Three →ₗ[ℂ] W}
    (h : ∀ x y z, f (wedgeThree x y z) = g (wedgeThree x y z)) : f = g := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  have hv : (![v 0, v 1, v 2] : Fin 3 → Space) = v := by funext i; fin_cases i <;> rfl
  simpa only [LinearMap.compAlternatingMap_apply, wedgeThree, hv] using h (v 0) (v 1) (v 2)

private theorem tensor_ext {W : Type*} [AddCommGroup W] [Module ℂ W] {f g : VTwo →ₗ[ℂ] W}
    (h : ∀ x y z, f (x ⊗ₜ[ℂ] wedgeTwo y z) = g (x ⊗ₜ[ℂ] wedgeTwo y z)) : f = g := by
  apply TensorProduct.ext'
  intro x u
  have he : f.comp (TensorProduct.mk ℂ Space Two x) = g.comp (TensorProduct.mk ℂ Space Two x) :=
    two_ext (h x)
  exact DFunLike.congr_fun he u

theorem action_pure (g : splitSpecialOrthogonal) (x y z : Space) :
    tensorAction g (x ⊗ₜ[ℂ] wedgeTwo y z) = g.val x ⊗ₜ[ℂ] wedgeTwo (g.val y) (g.val z) := by
  change TensorProduct.map g.val (exteriorPower.map 2 g.val) _ = _
  rw [TensorProduct.map_tmul, map_wedgeTwo]

theorem alternation_equivariant (g : splitSpecialOrthogonal) :
    alternation.comp (tensorAction g) = (exteriorRepresentation 3 g).comp alternation := by
  apply tensor_ext
  intro x y z
  simp only [LinearMap.comp_apply, action_pure, alternation_pure]
  exact (map_wedgeThree g.val x y z).symm

theorem trace_equivariant (g : splitSpecialOrthogonal) :
    trace.comp (tensorAction g) = (vectorAction g).comp trace := by
  apply tensor_ext
  intro x y z
  simp only [LinearMap.comp_apply, action_pure, trace_pure, g.prop.2, map_sub, map_smul]
  rfl

def cyclicTensor (x y z : Space) : VTwo :=
  x ⊗ₜ[ℂ] wedgeTwo y z + y ⊗ₜ[ℂ] wedgeTwo z x + z ⊗ₜ[ℂ] wedgeTwo x y

private theorem cyclic_repeat (x z : Space) : cyclicTensor x x z = 0 := by
  unfold cyclicTensor
  rw [wedgeTwo_self, tmul_zero, add_zero, wedgeTwo_swap x z, tmul_neg, add_neg_cancel]

private theorem cyclic_rotate (x y z : Space) : cyclicTensor y z x = cyclicTensor x y z := by
  unfold cyclicTensor
  abel

private def cyclicFamily (w : Fin 3 → Space) : VTwo := cyclicTensor (w 0) (w 1) (w 2)

private theorem fin3_distinct (i j : Fin 3) (h : i.val ≠ j.val) : i ≠ j :=
  fun e => h (congrArg Fin.val e)

private theorem fin3_cases : ∀ i : Fin 3, i = 0 ∨ i = 1 ∨ i = 2 := by decide +kernel

private theorem cyclic_update_zero [DecidableEq (Fin 3)] (w : Fin 3 → Space) (x : Space) :
    cyclicFamily (Function.update w 0 x) = cyclicTensor x (w 1) (w 2) := by
  unfold cyclicFamily
  rw [Function.update_self, Function.update_of_ne (fin3_distinct 1 0 (by decide)),
    Function.update_of_ne (fin3_distinct 2 0 (by decide))]

private theorem cyclic_update_one [DecidableEq (Fin 3)] (w : Fin 3 → Space) (x : Space) :
    cyclicFamily (Function.update w 1 x) = cyclicTensor (w 0) x (w 2) := by
  unfold cyclicFamily
  rw [Function.update_self, Function.update_of_ne (fin3_distinct 0 1 (by decide)),
    Function.update_of_ne (fin3_distinct 2 1 (by decide))]

private theorem cyclic_update_two [DecidableEq (Fin 3)] (w : Fin 3 → Space) (x : Space) :
    cyclicFamily (Function.update w 2 x) = cyclicTensor (w 0) (w 1) x := by
  unfold cyclicFamily
  rw [Function.update_self, Function.update_of_ne (fin3_distinct 0 2 (by decide)),
    Function.update_of_ne (fin3_distinct 1 2 (by decide))]

private def cyclicAlternating : Space [⋀^Fin 3]→ₗ[ℂ] VTwo where
  toFun := cyclicFamily
  map_update_add' w i a b := by
    rcases fin3_cases i with rfl | rfl | rfl
    · simp only [cyclic_update_zero, cyclicTensor, wedgeTwo_add_left, wedgeTwo_add_right, add_tmul, tmul_add]; abel
    · simp only [cyclic_update_one, cyclicTensor, wedgeTwo_add_left, wedgeTwo_add_right, add_tmul, tmul_add]; abel
    · simp only [cyclic_update_two, cyclicTensor, wedgeTwo_add_left, wedgeTwo_add_right, add_tmul, tmul_add]; abel
  map_update_smul' w i c a := by
    rcases fin3_cases i with rfl | rfl | rfl
    · simp only [cyclic_update_zero, cyclicTensor, wedgeTwo_smul_left, wedgeTwo_smul_right, ← smul_tmul', tmul_smul]; module
    · simp only [cyclic_update_one, cyclicTensor, wedgeTwo_smul_left, wedgeTwo_smul_right, ← smul_tmul', tmul_smul]; module
    · simp only [cyclic_update_two, cyclicTensor, wedgeTwo_smul_left, wedgeTwo_smul_right, ← smul_tmul', tmul_smul]; module
  map_eq_zero_of_eq' w i j h hij := by
    have h₁ (x y : Space) : cyclicTensor x y x = 0 := by rw [cyclic_rotate x x y, cyclic_repeat]
    have h₂ (x y : Space) : cyclicTensor x y y = 0 := by rw [← cyclic_rotate x y y, cyclic_repeat]
    change cyclicTensor (w 0) (w 1) (w 2) = 0
    fin_cases i <;> fin_cases j
    · exact (hij rfl).elim
    · rw [← (show w 0 = w 1 from h), cyclic_repeat]
    · rw [← (show w 0 = w 2 from h), h₁]
    · rw [(show w 1 = w 0 from h), cyclic_repeat]
    · exact (hij rfl).elim
    · rw [← (show w 1 = w 2 from h), h₂]
    · rw [(show w 2 = w 0 from h), h₁]
    · rw [(show w 2 = w 1 from h), h₂]
    · exact (hij rfl).elim

def includeThree : Three →ₗ[ℂ] VTwo := (3 : ℂ)⁻¹ • exteriorPower.alternatingMapLinearEquiv cyclicAlternating

@[simp] theorem includeThree_pure (x y z : Space) : includeThree (wedgeThree x y z) =
    (3 : ℂ)⁻¹ • cyclicTensor x y z := by
  simp [includeThree, wedgeThree, cyclicAlternating, cyclicFamily]

theorem wedgeThree_rotate (x y z : Space) : wedgeThree y z x = wedgeThree x y z := by
  let p : Equiv.Perm (Fin 3) := Equiv.swap 0 2 * Equiv.swap 0 1
  have hp : p.sign = 1 := by decide +kernel
  have he : (![y, z, x] : Fin 3 → Space) = ![x, y, z] ∘ p := by
    funext i
    fin_cases i <;> rfl
  rw [wedgeThree, wedgeThree, he, AlternatingMap.map_perm, hp, one_smul]

theorem splitForm_symm (x y : Space) : splitForm x y = splitForm y x := by
  apply Finset.sum_congr rfl
  intro i _
  change x (plusAxis i) * y (minusAxis i) + x (minusAxis i) * y (plusAxis i) =
    y (plusAxis i) * x (minusAxis i) + y (minusAxis i) * x (plusAxis i)
  ring

theorem alternation_includeThree : alternation.comp includeThree = LinearMap.id := by
  apply three_ext
  intro x y z
  simp only [LinearMap.comp_apply, includeThree_pure, map_smul, cyclicTensor, map_add, alternation_pure,
    LinearMap.id_apply]
  rw [wedgeThree_rotate y z x, wedgeThree_rotate x y z]
  module

theorem trace_includeThree : trace.comp includeThree = 0 := by
  apply three_ext
  intro x y z
  simp only [LinearMap.comp_apply, includeThree_pure, map_smul, cyclicTensor, map_add, trace_pure,
    LinearMap.zero_apply]
  rw [splitForm_symm y x, splitForm_symm z x, splitForm_symm z y]
  module

theorem includeThree_equivariant (g : splitSpecialOrthogonal) :
    includeThree.comp (exteriorRepresentation 3 g) = (tensorAction g).comp includeThree := by
  apply three_ext
  intro x y z
  change includeThree (exteriorPower.map 3 g.val (wedgeThree x y z)) = tensorAction g (includeThree (wedgeThree x y z))
  simp only [map_wedgeThree, includeThree_pure, map_smul, cyclicTensor, map_add, action_pure]

private theorem metric_orthBasis (i : Axis) : splitMetric (orthBasis i) = orthBasis.coord i := by
  apply orthBasis.ext
  intro j
  rw [splitMetric_apply, orthBasis_pair, Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
  simp [eq_comm]

theorem orth_sum (x : Space) : ∑ i, splitForm (orthBasis i) x • orthBasis i = x := by
  have h (i : Axis) : splitForm (orthBasis i) x = orthBasis.repr x i := by
    rw [← splitMetric_apply, metric_orthBasis, Module.Basis.coord_apply]
  simp only [h, orthBasis.sum_repr]

private def metricIso : Space ≃ₗ[ℂ] Module.Dual ℂ Space :=
  orthBasis.equiv orthBasis.dualBasis (Equiv.refl Axis)

private theorem metricIso_eq : metricIso.toLinearMap = splitMetric := by
  apply orthBasis.ext
  intro i
  rw [metric_orthBasis]
  change orthBasis.equiv orthBasis.dualBasis (Equiv.refl Axis) (orthBasis i) = _
  simp

private def tensorEval : (Space ⊗[ℂ] Space) ≃ₗ[ℂ] (Space →ₗ[ℂ] Space) :=
  (TensorProduct.congr metricIso (LinearEquiv.refl ℂ Space)).trans (dualTensorHomEquiv ℂ Space Space)

private theorem tensorEval_tmul (x y z : Space) : tensorEval (x ⊗ₜ[ℂ] y) z = splitForm x z • y := by
  change dualTensorHom ℂ Space Space ((metricIso x) ⊗ₜ[ℂ] y) z = _
  rw [dualTensorHom_apply, ← LinearEquiv.coe_coe, metricIso_eq, splitMetric_apply]

def metricTensor : Space ⊗[ℂ] Space := ∑ i, orthBasis i ⊗ₜ[ℂ] orthBasis i

theorem metricTensor_invariant (g : splitSpecialOrthogonal) :
    TensorProduct.map g.val g.val metricTensor = metricTensor := by
  apply tensorEval.injective
  apply LinearMap.ext
  intro v
  let e := LinearMap.equivOfIsUnitDet (g.prop.1 ▸ isUnit_one : IsUnit g.val.det)
  obtain ⟨x, hx⟩ := e.surjective v
  have he : e.toLinearMap = g.val := LinearMap.coe_equivOfIsUnitDet _
  change e.toLinearMap x = v at hx
  rw [he] at hx
  rw [← hx]
  simp only [metricTensor, map_sum, map_tmul, LinearMap.sum_apply, tensorEval_tmul, g.prop.2, orth_sum]
  simp_rw [← map_smul g.val]
  rw [← map_sum, orth_sum]

private def rawVector : Space →ₗ[ℂ] VTwo where
  toFun x := ∑ i, orthBasis i ⊗ₜ[ℂ] wedgeTwo (orthBasis i) x
  map_add' x y := by simp [wedgeTwo_add_right, tmul_add, Finset.sum_add_distrib]
  map_smul' c x := by simp [wedgeTwo_smul_right, tmul_smul, Finset.smul_sum]

def includeVector : Space →ₗ[ℂ] VTwo := (13 : ℂ)⁻¹ • rawVector

theorem includeVector_apply (x : Space) : includeVector x =
    (13 : ℂ)⁻¹ • ∑ i, orthBasis i ⊗ₜ[ℂ] wedgeTwo (orthBasis i) x := rfl

private theorem trace_rawVector (x : Space) : trace (rawVector x) = (13 : ℂ) • x := by
  change trace (∑ i, orthBasis i ⊗ₜ[ℂ] wedgeTwo (orthBasis i) x) = _
  simp only [map_sum, trace_pure, orthBasis_pair, if_true, Finset.sum_sub_distrib,
    Finset.sum_const, Finset.card_univ, Fintype.card_fin, orth_sum]
  rw [← Nat.cast_smul_eq_nsmul ℂ]
  module

theorem wedgeThree_repeat (x y : Space) : wedgeThree x x y = 0 := by
  apply Subtype.ext
  rw [coe_wedgeThree, Submodule.coe_zero, ← mul_assoc, ExteriorAlgebra.ι_sq_zero, zero_mul]

theorem trace_includeVector : trace.comp includeVector = LinearMap.id := by
  apply LinearMap.ext
  intro x
  simp only [LinearMap.comp_apply, includeVector, LinearMap.smul_apply, map_smul, trace_rawVector,
    LinearMap.id_apply, smul_smul]
  norm_num

set_option maxHeartbeats 1000000 in
theorem alternation_includeVector : alternation.comp includeVector = 0 := by
  apply LinearMap.ext
  intro x
  change alternation ((13 : ℂ)⁻¹ • ∑ i, orthBasis i ⊗ₜ[ℂ] wedgeTwo (orthBasis i) x) = 0
  rw [map_smul, map_sum, Finset.sum_eq_zero fun i _ => by rw [alternation_pure, wedgeThree_repeat], smul_zero]

private def wedgeRight (x : Space) : Space →ₗ[ℂ] Two where
  toFun y := wedgeTwo y x
  map_add' y z := wedgeTwo_add_left y z x
  map_smul' c y := wedgeTwo_smul_left c y x

private def insertVector (x : Space) : (Space ⊗[ℂ] Space) →ₗ[ℂ] VTwo :=
  TensorProduct.map LinearMap.id (wedgeRight x)

private theorem insertVector_metricTensor (x : Space) : insertVector x metricTensor = rawVector x := by
  change TensorProduct.map LinearMap.id (wedgeRight x) metricTensor = _
  simp only [metricTensor, map_sum, map_tmul, LinearMap.id_apply]
  rfl

set_option maxHeartbeats 1000000 in
theorem includeVector_equivariant (g : splitSpecialOrthogonal) :
    includeVector.comp (vectorAction g) = (tensorAction g).comp includeVector := by
  have h (x : Space) : (tensorAction g).comp (insertVector x) =
      (insertVector (g.val x)).comp (TensorProduct.map g.val g.val) := by
    apply TensorProduct.ext'
    intro y z
    change tensorAction g (TensorProduct.map LinearMap.id (wedgeRight x) (y ⊗ₜ[ℂ] z)) =
      TensorProduct.map LinearMap.id (wedgeRight (g.val x)) (TensorProduct.map g.val g.val (y ⊗ₜ[ℂ] z))
    simp only [map_tmul, LinearMap.id_apply]
    exact action_pure g y z x
  apply LinearMap.ext
  intro x
  have he := DFunLike.congr_fun (h x) metricTensor
  change tensorAction g (insertVector x metricTensor) =
    insertVector (g.val x) (TensorProduct.map g.val g.val metricTensor) at he
  rw [metricTensor_invariant, insertVector_metricTensor, insertVector_metricTensor] at he
  change (13 : ℂ)⁻¹ • rawVector (g.val x) = tensorAction g ((13 : ℂ)⁻¹ • rawVector x)
  rw [map_smul, he]

/-- The joint kernel of alternation and trace. -/
def hook : Submodule ℂ VTwo := alternation.ker ⊓ trace.ker

theorem mem_hook (x : VTwo) : x ∈ hook ↔ alternation x = 0 ∧ trace x = 0 := by
  simp [hook, LinearMap.mem_ker]

theorem hook_invariant (g : splitSpecialOrthogonal) (x : VTwo) (hx : x ∈ hook) : tensorAction g x ∈ hook := by
  rw [mem_hook] at hx ⊢
  have ha := DFunLike.congr_fun (alternation_equivariant g) x
  have ht := DFunLike.congr_fun (trace_equivariant g) x
  simp only [LinearMap.comp_apply, hx.1, hx.2, map_zero] at ha ht
  exact ⟨ha, ht⟩

def hookAction : Representation ℂ splitSpecialOrthogonal hook :=
  tensorAction.subrepresentation hook (fun g x hx => hook_invariant g x hx)

@[simp] theorem alternation_three (u : Three) : alternation (includeThree u) = u :=
  DFunLike.congr_fun alternation_includeThree u

@[simp] theorem trace_three (u : Three) : trace (includeThree u) = 0 :=
  DFunLike.congr_fun trace_includeThree u

set_option maxHeartbeats 1000000 in
@[simp] theorem alternation_vector (v : Space) : alternation (includeVector v) = 0 := by
  have h : (alternation.comp includeVector) v = (0 : Space →ₗ[ℂ] Three) v :=
    LinearMap.congr_fun alternation_includeVector v
  simpa only [LinearMap.comp_apply, LinearMap.zero_apply] using h

set_option maxHeartbeats 1000000 in
@[simp] theorem trace_vector (v : Space) : trace (includeVector v) = v := by
  have h : (trace.comp includeVector) v = (LinearMap.id : Space →ₗ[ℂ] Space) v :=
    LinearMap.congr_fun trace_includeVector v
  simpa only [LinearMap.comp_apply, LinearMap.id_apply] using h

def residual : VTwo →ₗ[ℂ] VTwo := LinearMap.id - includeThree.comp alternation - includeVector.comp trace

theorem residual_mem (x : VTwo) : residual x ∈ hook := by
  simp [mem_hook, residual]

def splitLinear : VTwo ≃ₗ[ℂ] Three × Space × hook where
  toFun x := (alternation x, trace x, ⟨residual x, residual_mem x⟩)
  invFun p := includeThree p.1 + includeVector p.2.1 + p.2.2.val
  left_inv x := by
    change includeThree (alternation x) + includeVector (trace x) + residual x = x
    simp only [residual, LinearMap.sub_apply, LinearMap.id_apply, LinearMap.comp_apply]
    abel
  right_inv p := by
    rcases p with ⟨u, v, w⟩
    have hw := (mem_hook w.val).mp w.prop
    refine Prod.ext ?_ (Prod.ext ?_ (Subtype.ext ?_))
    · change alternation (includeThree u + includeVector v + w.val) = u
      simp [hw.1]
    · change trace (includeThree u + includeVector v + w.val) = v
      simp [hw.2]
    · change residual (includeThree u + includeVector v + w.val) = w.val
      simp [residual, hw.1, hw.2]
      abel
  map_add' x y := Prod.ext (alternation.map_add x y)
    (Prod.ext (trace.map_add x y) (Subtype.ext (residual.map_add x y)))
  map_smul' c x := Prod.ext (alternation.map_smul c x)
    (Prod.ext (trace.map_smul c x) (Subtype.ext (residual.map_smul c x)))

/-- The splitting intertwines the actual orthogonal actions. -/
theorem split_equivariant (g : splitSpecialOrthogonal) (x : VTwo) :
    splitLinear (tensorAction g x) =
      ((exteriorRepresentation 3).prod (vectorAction.prod hookAction)) g (splitLinear x) := by
  have ha := DFunLike.congr_fun (alternation_equivariant g) x
  have ht := DFunLike.congr_fun (trace_equivariant g) x
  simp only [LinearMap.comp_apply] at ha ht
  refine Prod.ext ha (Prod.ext ht (Subtype.ext ?_))
  change residual (tensorAction g x) = tensorAction g (residual x)
  simp only [residual, LinearMap.sub_apply, LinearMap.comp_apply, LinearMap.id_apply, ha, ht, map_sub]
  have h₁ := DFunLike.congr_fun (includeThree_equivariant g) (alternation x)
  have h₂ := DFunLike.congr_fun (includeVector_equivariant g) (trace x)
  simp only [LinearMap.comp_apply] at h₁ h₂
  rw [h₁, h₂]

def splitRepresentation : tensorAction.Equiv ((exteriorRepresentation 3).prod (vectorAction.prod hookAction)) :=
  Representation.Equiv.mk splitLinear (fun g => LinearMap.ext (split_equivariant g))

set_option backward.isDefEq.respectTransparency false in
/-- The trace-free, alternation-free part has dimension 896. -/
theorem hook_dimension : Module.finrank ℂ hook = 896 := by
  let : Module.Free ℂ (↥hook) := Module.Free.of_divisionRing ℂ (↥hook)
  have h := splitLinear.finrank_eq
  rw [Module.finrank_tensorProduct, Module.finrank_prod, Module.finrank_prod,
    exteriorPower.finrank_eq, exteriorPower.finrank_eq, Module.finrank_pi, Fintype.card_fin] at h
  have h₂ : Nat.choose 14 2 = 91 := by decide
  have h₃ : Nat.choose 14 3 = 364 := by decide
  rw [h₂, h₃] at h
  omega

private abbrev u (i : Pair) : Space := axisBasis (plusAxis i)

private theorem wedge_first_two : wedgeTwo (u 0) (u 1) =
    axisBasis.exteriorPower 2 (highestPlus (2 : Fin 15)) := by
  let axes : Fin 2 → Axis := ![plusAxis 0, plusAxis 1]
  have hstrict : ∀ i j, i < j → axes i < axes j := by decide +kernel
  have hmem : ∀ i, axes i ∈ (highestPlus (2 : Fin 15)).val := by decide +kernel
  let e := OrderEmbedding.ofStrictMono axes hstrict
  have he := Finset.orderEmbOfFin_unique' (highestPlus (2 : Fin 15)).prop (f := e) hmem
  rw [exteriorPower.basis_apply, exteriorPower.ιMulti_family,
    Set.powersetCard.ofFinEmbEquiv_symm_apply, ← he]
  rfl

/-- The null-basis hook candidate with weight two on the first pair and one on the second. -/
def hookHighest : VTwo := u 0 ⊗ₜ[ℂ] wedgeTwo (u 0) (u 1)

theorem hookHighest_ne_zero : hookHighest ≠ 0 := by
  rw [hookHighest, wedge_first_two]
  simpa only [Module.Basis.tensorProduct_apply'] using
    (axisBasis.tensorProduct (axisBasis.exteriorPower 2)).ne_zero (plusAxis 0, highestPlus (2 : Fin 15))

theorem hookHighest_mem : hookHighest ∈ hook := by
  have hz (j : Pair) : splitForm (u 0) (u j) = 0 := by
    rw [← splitMetric_apply, splitMetric_null_plus, Module.Basis.coord_apply,
      Module.Basis.repr_self, Finsupp.single_apply]
    have he : ∀ j : Pair, plusAxis j ≠ minusAxis 0 := by decide +kernel
    rw [if_neg (he j)]
  simp [mem_hook, hookHighest, wedgeThree_repeat, hz]

theorem hookHighest_torus (t : Pair → ℂˣ) :
    tensorAction (torusElement t) hookHighest = ((t 0 ^ 2 * t 1 : ℂˣ) : ℂ) • hookHighest := by
  have h0 : scale t (plusAxis 0) = t 0 := by change t 0 ^ (1 : ℤ) = _; rw [zpow_one]
  have h1 : scale t (plusAxis 1) = t 1 := by change t 1 ^ (1 : ℤ) = _; rw [zpow_one]
  have h (j : Pair) : torus t (u j) = (scale t (plusAxis j) : ℂ) • u j := torus_axis t _
  change tensorAction (torusElement t) (u 0 ⊗ₜ[ℂ] wedgeTwo (u 0) (u 1)) = _
  rw [action_pure]
  change torus t (u 0) ⊗ₜ[ℂ] wedgeTwo (torus t (u 0)) (torus t (u 1)) = _
  rw [h 0, h 1, h0, h1, wedgeTwo_smul_left, wedgeTwo_smul_right, smul_smul, smul_tmul_smul]
  change _ • hookHighest = _
  congr 1
  push_cast
  ring

theorem hookHighest_root_fixed (c : ℂ) (i j : Pair) (h : i < j) :
    tensorAction (rootMinusElement c i j h) hookHighest = hookHighest ∧
      tensorAction (rootPlusElement c i j h) hookHighest = hookHighest := by
  have hV := firstAxis_root_fixed c i j h
  have hW := highestPlus_root_fixed (2 : Fin 15) c i j h
  let v := axisBasis.exteriorPower 2 (highestPlus (2 : Fin 15))
  change exteriorRepresentation 2 (rootMinusElement c i j h) v = v ∧
    exteriorRepresentation 2 (rootPlusElement c i j h) v = v at hW
  rw [hookHighest, wedge_first_two]
  constructor
  · change TensorProduct.map (rootMinusElement c i j h).val (exteriorRepresentation 2 (rootMinusElement c i j h)) _ = _
    rw [map_tmul, hV.1, hW.1]
  · change TensorProduct.map (rootPlusElement c i j h).val (exteriorRepresentation 2 (rootPlusElement c i j h)) _ = _
    rw [map_tmul, hV.2, hW.2]

/-- The unfiltered signed table for this tensor product. -/
theorem vector_tensor_grade_two : D7Counts.gradeMultiplicities 1 2 =
    D7Counts.tally [(D7Counts.mu 1, 1), (D7Counts.mu 3, 1), (D7Counts.nu 2, 1)] := by
  decide +kernel

end
end GeometricUnity.D7VectorTensor
