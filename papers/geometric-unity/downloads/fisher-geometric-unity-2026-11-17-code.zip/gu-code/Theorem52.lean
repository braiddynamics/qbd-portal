import Mathlib.Analysis.Calculus.Deriv.Add
import Mathlib.Analysis.Calculus.Deriv.Mul
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.LinearAlgebra.BilinearMap
import Mathlib.Tactic.Abel
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NoncommRing
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Ring

/-!
# Geometric Unity: Theorem 5.2

The first variation of the action at fixed background, metric and dressing
(Eqs. (46)–(47) of the technical note).
Indexed coefficients take values in a real associative algebra. The
linear functional `trace` represents the integrated cyclic trace. The
Leibniz and parallelism hypotheses express the covariant product rule in
components. `BoundaryZero` is the integrated divergence identity for the
mixed terms involving the test field, supplied by Stokes' theorem in the
geometric setting.

The output uses raised components, so the sign of an orthonormal metric
enters the mass term through `g`. The fixed factor `i` of the commutator
channel is absorbed into its insertion `Q`. No topology or continuity
assumptions on the coefficient algebra are needed for the real derivative
along a line.

Checked with Lean 4.33.1 and Mathlib v4.33.1.
-/

namespace GeometricUnity.Theorem52

noncomputable section

open scoped BigOperators

variable {A : Type*} [Ring A] [Algebra ℝ A]
variable {ι : Type*} [Fintype ι]

abbrev OneForm (ι A : Type*) := ι → A
abbrev TwoForm (ι A : Type*) := ι → ι → A
abbrev Insertion (ι A : Type*) := ι → ι → ι → A
abbrev Bracket (A : Type*) [Ring A] [Algebra ℝ A] := A →ₗ[ℝ] A →ₗ[ℝ] A

def anti : Bracket A :=
  LinearMap.mk₂ ℝ (fun x y => x * y + y * x)
    (by intros; simp only [add_mul, mul_add]; abel)
    (by intros; simp [smul_add])
    (by intros; simp only [add_mul, mul_add]; abel)
    (by intros; simp [smul_add])

def comm : Bracket A :=
  LinearMap.mk₂ ℝ (fun x y => x * y - y * x)
    (by intros; simp only [add_mul, mul_add]; abel)
    (by intros; simp [smul_sub])
    (by intros; simp only [add_mul, mul_add]; abel)
    (by intros; simp [smul_sub])

theorem anti_apply (x y : A) : anti x y = x * y + y * x := rfl
theorem comm_apply (x y : A) : comm x y = x * y - y * x := rfl

structure Alternating (P : Insertion ι A) : Prop where
  swapBC (a b c : ι) : P a c b = -P a b c
  swapAC (a b c : ι) : P c b a = -P a b c

omit [Algebra ℝ A] [Fintype ι] in
private theorem Alternating.cycle {P : Insertion ι A} (h : Alternating P) (a b c : ι) :
    P c a b = P a b c := by
  rw [h.swapBC c b a, h.swapAC a b c, neg_neg]

omit [Algebra ℝ A] [Fintype ι] in
private theorem Alternating.cycle' {P : Insertion ι A} (h : Alternating P) (a b c : ι) :
    P b c a = P a b c :=
  (h.cycle c a b).trans (h.cycle a b c)

variable (trace : A →ₗ[ℝ] ℝ)

def Cyclic : Prop := ∀ x y : A, trace (x * y) = trace (y * x)

def sum3 {B : Type*} [AddCommMonoid B] (f : ι → ι → ι → B) : B :=
  ∑ a, ∑ b, ∑ c, f a b c

private theorem sum3_swapBC {B : Type*} [AddCommMonoid B] (f : ι → ι → ι → B) :
    sum3 (fun a b c => f a c b) = sum3 f := by
  unfold sum3
  exact Finset.sum_congr rfl (fun a _ => Finset.sum_comm)

private theorem sum3_cycle {B : Type*} [AddCommMonoid B] (f : ι → ι → ι → B) :
    sum3 (fun a b c => f c a b) = sum3 f := by
  unfold sum3
  calc
    (∑ a, ∑ b, ∑ c, f c a b) = ∑ a, ∑ c, ∑ b, f c a b :=
      Finset.sum_congr rfl (fun _ _ => Finset.sum_comm)
    _ = ∑ c, ∑ a, ∑ b, f c a b := Finset.sum_comm

private theorem sum3_cycle' {B : Type*} [AddCommMonoid B] (f : ι → ι → ι → B) :
    sum3 (fun a b c => f b c a) = sum3 f :=
  (sum3_cycle (fun a b c => f c a b)).trans (sum3_cycle f)

private theorem sum3_swapAC {B : Type*} [AddCommMonoid B] (f : ι → ι → ι → B) :
    sum3 (fun a b c => f c b a) = sum3 f :=
  (sum3_cycle (fun a b c => f a c b)).trans (sum3_swapBC f)

private theorem sum3_add (f h : ι → ι → ι → ℝ) :
    sum3 (fun a b c => f a b c + h a b c) = sum3 f + sum3 h := by
  simp [sum3, Finset.sum_add_distrib]

private theorem sum3_sub (f h : ι → ι → ι → ℝ) :
    sum3 (fun a b c => f a b c - h a b c) = sum3 f - sum3 h := by
  simp [sum3, Finset.sum_sub_distrib]

private theorem sum3_neg (f : ι → ι → ι → ℝ) :
    sum3 (fun a b c => -f a b c) = -sum3 f := by
  simp [sum3, Finset.sum_neg_distrib]

private theorem sum3_congr {f h : ι → ι → ι → ℝ}
    (heq : ∀ a b c, f a b c = h a b c) : sum3 f = sum3 h :=
  congrArg sum3 (funext fun a => funext fun b => funext fun c => heq a b c)

private theorem rotate (h : Cyclic trace) (x y z : A) :
    trace (x * (y * z)) = trace (y * (z * x)) := by
  rw [h x (y * z), mul_assoc]

private theorem trace_anti_swap (h : Cyclic trace) (x p y : A) :
    trace (x * anti p y) = trace (y * anti p x) := by
  simp only [anti_apply, mul_add, map_add]
  rw [rotate trace h x p y, rotate trace h p y x, rotate trace h x y p]
  abel

private theorem trace_comm_swap (h : Cyclic trace) (x p y : A) :
    trace (x * comm p y) = -trace (y * comm p x) := by
  simp only [comm_apply, mul_sub, map_sub]
  rw [rotate trace h x p y, rotate trace h p y x, rotate trace h x y p]
  abel

private theorem trace_comm_shift (h : Cyclic trace) (x p y : A) :
    trace (x * comm p y) = -trace (p * comm x y) := by
  simp only [comm_apply, mul_sub, map_sub]
  rw [rotate trace h x p y, rotate trace h x y p, rotate trace h y p x]
  abel

variable (D : ι → A →ₗ[ℝ] A)

def Leibniz : Prop := ∀ b x y, D b (x * y) = D b x * y + x * D b y
def Parallel (P : Insertion ι A) : Prop := ∀ a b c, D b (P a b c) = 0

/-- The integrated trace of the divergence of the indicated mixed product. -/
def BoundaryZero (B : Bracket A) (P : Insertion ι A) (X Y : OneForm ι A) : Prop :=
  sum3 (fun a b c => trace (D b (X a * B (P a b c) (Y c)))) = 0

def dB (T : OneForm ι A) : TwoForm ι A := fun b c => D b (T c) - D c (T b)

def wedgeSquare (T : OneForm ι A) : TwoForm ι A := fun b c => comm (T b) (T c)

/-- Bare contraction with the explicit factor of one half. -/
def theta (B : Bracket A) (P : Insertion ι A) (F : TwoForm ι A) : OneForm ι A :=
  fun a => (1 / 2 : ℝ) • ∑ b, ∑ c, B (P a b c) (F b c)

def pair (X Y : OneForm ι A) : ℝ := ∑ a, trace (X a * Y a)

def raise (g : ι → ℝ) (T : OneForm ι A) : OneForm ι A := fun a => g a • T a

def action (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (lam m : ℝ) (T : OneForm ι A) : ℝ :=
  let H := F + (1 / 2 : ℝ) • dB D T + lam • wedgeSquare T
  pair trace T (theta anti P H + theta comm Q H) + m * pair trace T (raise g T)

def correction (P : Insertion ι A) (lam : ℝ) (T : OneForm ι A) : OneForm ι A :=
  fun a => (-lam) • ∑ b, ∑ c, anti (T b) (comm (T c) (P a b c))

def euler (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (lam m : ℝ) (T : OneForm ι A) : OneForm ι A :=
  theta anti P (F + dB D T + (3 * lam) • wedgeSquare T) +
    theta comm Q F + (2 * m) • raise g T + correction P lam T

private def contraction (B : Bracket A) (P : Insertion ι A) (F : TwoForm ι A)
    (X : OneForm ι A) : ℝ :=
  sum3 fun a b c => trace (X a * B (P a b c) (F b c))

private def kinetic (B : Bracket A) (P : Insertion ι A) (X Y : OneForm ι A) : ℝ :=
  sum3 fun a b c => trace (X a * B (P a b c) (D b (Y c)))

private def cubic (B : Bracket A) (P : Insertion ι A) (X Y Z : OneForm ι A) : ℝ :=
  sum3 fun a b c => trace (X a * B (P a b c) (comm (Y b) (Z c)))

private def correctionTerm (P : Insertion ι A) (X T : OneForm ι A) : ℝ :=
  sum3 fun a b c => trace (X a * anti (T b) (comm (T c) (P a b c)))

private theorem pair_add_right (X Y Z : OneForm ι A) :
    pair trace X (Y + Z) = pair trace X Y + pair trace X Z := by
  simp [pair, Pi.add_apply, mul_add, Finset.sum_add_distrib]

private theorem pair_smul_right (r : ℝ) (X Y : OneForm ι A) :
    pair trace X (r • Y) = r * pair trace X Y := by
  simp [pair, Pi.smul_apply, Finset.mul_sum, smul_eq_mul]

private theorem pair_theta (B : Bracket A) (P : Insertion ι A) (F : TwoForm ι A)
    (X : OneForm ι A) : pair trace X (theta B P F) = (1 / 2) * contraction trace B P F X := by
  simp [pair, theta, contraction, sum3, Finset.mul_sum, map_sum, smul_eq_mul]

private theorem contraction_add (B : Bracket A) (P : Insertion ι A) (F H : TwoForm ι A)
    (X : OneForm ι A) :
    contraction trace B P (F + H) X = contraction trace B P F X + contraction trace B P H X := by
  simp [contraction, Pi.add_apply, mul_add, sum3_add]

private theorem contraction_smul (B : Bracket A) (P : Insertion ι A) (F : TwoForm ι A)
    (r : ℝ) (X : OneForm ι A) :
    contraction trace B P (r • F) X = r * contraction trace B P F X := by
  simp [contraction, sum3, Pi.smul_apply, Finset.mul_sum, smul_eq_mul]

private theorem contraction_dB (B : Bracket A) (P : Insertion ι A) (h : Alternating P)
    (X Y : OneForm ι A) : contraction trace B P (dB D Y) X = 2 * kinetic trace D B P X Y := by
  have swap : sum3 (fun a b c => trace (X a * B (P a b c) (D c (Y b)))) =
      -kinetic trace D B P X Y := by
    rw [← sum3_swapBC (fun a b c => trace (X a * B (P a b c) (D c (Y b))))]
    unfold kinetic
    rw [← sum3_neg]
    apply sum3_congr
    intro a b c
    rw [h.swapBC a b c, map_neg, LinearMap.neg_apply, mul_neg, map_neg]
  simp only [contraction, dB, map_sub, mul_sub, sum3_sub, swap]
  change kinetic trace D B P X Y - -kinetic trace D B P X Y = _
  ring

private theorem pair_correction (P : Insertion ι A) (lam : ℝ) (X T : OneForm ι A) :
    pair trace X (correction P lam T) = -lam * correctionTerm trace P X T := by
  simp [pair, correction, correctionTerm, sum3, Finset.mul_sum, map_sum,
    smul_eq_mul]

private theorem kinetic_swap (B : Bracket A) (P : Insertion ι A) (hp : Alternating P)
    (hD : Leibniz D) (hP : Parallel D P)
    (hbracket : ∀ b x y, D b (B x y) = B (D b x) y + B x (D b y))
    (s : ℝ) (hs : ∀ x p y, trace (x * B p y) = s * trace (y * B p x))
    (X Y : OneForm ι A) (hzero : BoundaryZero trace D B P X Y) :
    kinetic trace D B P X Y = s * kinetic trace D B P Y X := by
  let f := fun a b c => trace (D b (X a) * B (P a b c) (Y c))
  let k := fun a b c => trace (X a * B (P a b c) (D b (Y c)))
  have hprod (a b c : ι) :
      trace (D b (X a * B (P a b c) (Y c))) = f a b c + k a b c := by
    dsimp [f, k]
    rw [hD b, hbracket b, hP a b c, map_zero, LinearMap.zero_apply, zero_add, map_add]
  have hz : sum3 f + sum3 k = 0 := by
    rw [← sum3_add, ← sum3_congr hprod]
    exact hzero
  have ibp : sum3 k = -sum3 f := by
    linarith
  calc
    kinetic trace D B P X Y = -sum3 f := ibp
    _ = sum3 (fun a b c => s * trace (Y c * B (P c b a) (D b (X a)))) := by
      rw [← sum3_neg]
      apply sum3_congr
      intro a b c
      dsimp [f]
      rw [hs, hp.swapAC a b c, map_neg, LinearMap.neg_apply, mul_neg, map_neg, mul_neg]
    _ = _ := by rw [sum3_swapAC]; simp [kinetic, sum3, Finset.mul_sum]

private theorem kinetic_plus_symm (P : Insertion ι A) (hp : Alternating P)
    (hcyc : Cyclic trace) (hD : Leibniz D) (hP : Parallel D P)
    (X Y : OneForm ι A) (hzero : BoundaryZero trace D anti P X Y) :
    kinetic trace D anti P X Y = kinetic trace D anti P Y X := by
  have h := kinetic_swap trace D anti P hp hD hP
    (by intro b x y; simp only [anti_apply, map_add, hD b]; abel)
    1 (by intro x p y; rw [one_mul]; exact trace_anti_swap trace hcyc x p y) X Y hzero
  simpa using h

private theorem kinetic_minus_skew (Q : Insertion ι A) (hq : Alternating Q)
    (hcyc : Cyclic trace) (hD : Leibniz D) (hQ : Parallel D Q)
    (X Y : OneForm ι A) (hzero : BoundaryZero trace D comm Q X Y) :
    kinetic trace D comm Q X Y = -kinetic trace D comm Q Y X := by
  have h := kinetic_swap trace D comm Q hq hD hQ
    (by intro b x y; simp only [comm_apply, map_sub, hD b]; abel)
    (-1) (by intro x p y; rw [neg_one_mul]; exact trace_comm_swap trace hcyc x p y) X Y hzero
  simpa using h

private theorem cubic_minus_zero (Q : Insertion ι A) (hq : Alternating Q)
    (hcyc : Cyclic trace) (T : OneForm ι A) :
    cubic trace comm Q T T T = 0 := by
  let f := fun a b c => trace (Q a b c * comm (T a) (comm (T b) (T c)))
  have h1 : sum3 (fun a b c => trace (Q a b c * comm (T c) (comm (T a) (T b)))) =
      sum3 f := by
    calc
      _ = sum3 (fun a b c => f c a b) := by
        apply sum3_congr
        intro a b c
        dsimp [f]
        rw [hq.cycle a b c]
      _ = _ := sum3_cycle f
  have h2 : sum3 (fun a b c => trace (Q a b c * comm (T b) (comm (T c) (T a)))) =
      sum3 f := by
    calc
      _ = sum3 (fun a b c => f b c a) := by
        apply sum3_congr
        intro a b c
        dsimp [f]
        rw [hq.cycle' a b c]
      _ = _ := sum3_cycle' f
  have jacobi (x y z : A) : comm x (comm y z) + comm y (comm z x) + comm z (comm x y) = 0 := by
    simp only [comm_apply]
    noncomm_ring
  have hs : sum3 f + sum3 f + sum3 f = 0 := by
    -- Combine exactly one copy from each cyclic placement.
    calc
      _ = sum3 (fun a b c =>
        trace (Q a b c * (comm (T a) (comm (T b) (T c)) +
          comm (T b) (comm (T c) (T a)) + comm (T c) (comm (T a) (T b))))) := by
        simp only [mul_add, map_add, sum3_add]
        rw [h1, h2]
      _ = 0 := by simp [jacobi, sum3]
  calc
    cubic trace comm Q T T T = sum3 (fun a b c => -f a b c) := by
      apply sum3_congr
      intro a b c
      exact trace_comm_shift trace hcyc _ _ _
    _ = 0 := by rw [sum3_neg]; linarith

private theorem cubic_move (P : Insertion ι A) (hp : Alternating P)
    (hcyc : Cyclic trace) (T X : OneForm ι A) :
    cubic trace anti P T X T =
      sum3 (fun a b c => trace (X a * comm (T b) (anti (P a b c) (T c)))) := by
  calc
    _ = sum3 (fun a b c => trace (X b * comm (T c) (anti (P a b c) (T a)))) := by
      apply sum3_congr
      intro a b c
      rw [trace_anti_swap trace hcyc]
      simp only [comm_apply, sub_mul, map_sub, mul_assoc, mul_sub]
      rw [rotate trace hcyc (T c) (X b) (anti (P a b c) (T a))]
    _ = _ := by
      let f := fun a b c => trace (X a * comm (T b) (anti (P a b c) (T c)))
      calc
        _ = sum3 (fun a b c => f b c a) := by
          apply sum3_congr
          intro a b c
          dsimp [f]
          rw [hp.cycle' a b c]
        _ = _ := sum3_cycle' f

private theorem cubic_exchange (P : Insertion ι A) (hp : Alternating P) (X Y Z : OneForm ι A) :
    cubic trace anti P X Y Z = cubic trace anti P X Z Y := by
  unfold cubic
  rw [← sum3_swapBC (fun a b c => trace (X a * anti (P a b c) (comm (Z b) (Y c))))]
  apply sum3_congr
  intro a b c
  have flip : comm (Z c) (Y b) = -comm (Y b) (Z c) := by
    simp only [comm_apply]
    abel
  simp only [hp.swapBC a b c, flip, map_neg, LinearMap.neg_apply, neg_neg]

private theorem cubic_move_value (P : Insertion ι A) (hp : Alternating P)
    (hcyc : Cyclic trace) (T X : OneForm ι A) :
    cubic trace anti P T X T = cubic trace anti P X T T - correctionTerm trace P X T := by
  let r := fun a b c => trace (X a * comm (anti (T b) (T c)) (P a b c))
  have hr := sum3_swapBC r
  have hf : ∀ a b c, r a c b = -r a b c := by
    intro a b c
    change trace (X a * comm (anti (T c) (T b)) (P a c b)) = _
    rw [hp.swapBC a b c, map_neg, mul_neg, map_neg]
    simp only [r, anti_apply, add_comm (T c * T b) (T b * T c)]
  have hz : sum3 r = 0 := by
    have hneg : sum3 (fun a b c => r a c b) = -sum3 r :=
      (sum3_congr hf).trans (sum3_neg r)
    linarith
  have rearrange (b c p : A) :
      comm b (anti p c) = anti p (comm b c) - anti b (comm c p) + comm (anti b c) p := by
    simp only [comm_apply, anti_apply]
    noncomm_ring
  rw [cubic_move trace P hp hcyc T X]
  simp only [rearrange, mul_add, mul_sub, map_add, map_sub, sum3_add, sum3_sub]
  change cubic trace anti P X T T - correctionTerm trace P X T + sum3 r = _
  rw [hz, add_zero]

/-! The action on an affine line is a real scalar polynomial of degree at most
three. The following lemmas differentiate it without a topology on `A`. -/

private theorem polynomial_deriv (c₀ c₁ c₂ c₃ : ℝ) :
    HasDerivAt (fun t : ℝ => c₀ + t * c₁ + t ^ 2 * c₂ + t ^ 3 * c₃) c₁ 0 := by
  have h := (((hasDerivAt_const (0 : ℝ) c₀).fun_add
      ((hasDerivAt_id' (x := (0 : ℝ))).mul_const c₁)).fun_add
      ((hasDerivAt_pow 2 (0 : ℝ)).mul_const c₂)).fun_add
      ((hasDerivAt_pow 3 (0 : ℝ)).mul_const c₃)
  simpa using h

private theorem trace_line2 (x dx y dy : A) :
    HasDerivAt (fun t : ℝ => trace ((x + t • dx) * (y + t • dy)))
      (trace (dx * y) + trace (x * dy)) 0 := by
  have heq : (fun t : ℝ => trace ((x + t • dx) * (y + t • dy))) =
      fun t => trace (x * y) + t * (trace (dx * y) + trace (x * dy)) +
        t ^ 2 * trace (dx * dy) + t ^ 3 * 0 := by
    funext t
    simp only [add_mul, mul_add, smul_mul_assoc, mul_smul_comm,
      map_add, map_smul, smul_eq_mul]
    ring
  rw [heq]
  exact polynomial_deriv _ _ _ _

private theorem trace_line3 (B : Bracket A) (L : A →ₗ[ℝ] A) (x dx y dy z dz : A) :
    HasDerivAt (fun t : ℝ => trace ((x + t • dx) * L (B (y + t • dy) (z + t • dz))))
      (trace (dx * L (B y z)) + trace (x * L (B dy z)) + trace (x * L (B y dz))) 0 := by
  let f := fun x y z => trace (x * L (B y z))
  have heq : (fun t : ℝ => f (x + t • dx) (y + t • dy) (z + t • dz)) =
      fun t => f x y z + t * (f dx y z + f x dy z + f x y dz) +
        t ^ 2 * (f dx dy z + f dx y dz + f x dy dz) + t ^ 3 * f dx dy dz := by
    funext t
    simp only [f, map_add, map_smul, LinearMap.add_apply, LinearMap.smul_apply,
      smul_mul_assoc, mul_smul_comm, add_mul, mul_add, smul_eq_mul]
    ring
  change HasDerivAt (fun t : ℝ => f (x + t • dx) (y + t • dy) (z + t • dz)) _ _
  rw [heq]
  exact polynomial_deriv _ _ _ _

private theorem sum3_deriv {f : ι → ι → ι → ℝ → ℝ} {f' : ι → ι → ι → ℝ}
    (h : ∀ a b c, HasDerivAt (f a b c) (f' a b c) 0) :
    HasDerivAt (fun t => sum3 (fun a b c => f a b c t)) (sum3 f') 0 :=
  HasDerivAt.fun_sum fun a _ =>
    HasDerivAt.fun_sum fun b _ =>
      HasDerivAt.fun_sum fun c _ => h a b c

private theorem contraction_deriv (B : Bracket A) (P : Insertion ι A) (F : TwoForm ι A)
    (T X : OneForm ι A) :
    HasDerivAt (fun t : ℝ => contraction trace B P F (T + t • X))
      (contraction trace B P F X) 0 := by
  unfold contraction
  apply sum3_deriv
  intro a b c
  simpa only [Pi.add_apply, Pi.smul_apply, smul_zero, add_zero, mul_zero, map_zero] using
    trace_line2 trace (T a) (X a) (B (P a b c) (F b c)) 0

private theorem kinetic_deriv (B : Bracket A) (P : Insertion ι A) (T X : OneForm ι A) :
    HasDerivAt (fun t : ℝ => kinetic trace D B P (T + t • X) (T + t • X))
      (kinetic trace D B P X T + kinetic trace D B P T X) 0 := by
  unfold kinetic
  rw [← sum3_add]
  apply sum3_deriv
  intro a b c
  simpa only [Pi.add_apply, Pi.smul_apply, map_add, map_smul] using
    trace_line2 trace (T a) (X a) (B (P a b c) (D b (T c))) (B (P a b c) (D b (X c)))

private theorem cubic_deriv (B : Bracket A) (P : Insertion ι A) (T X : OneForm ι A) :
    HasDerivAt (fun t : ℝ => cubic trace B P (T + t • X) (T + t • X) (T + t • X))
      (cubic trace B P X T T + cubic trace B P T X T + cubic trace B P T T X) 0 := by
  unfold cubic
  rw [← sum3_add, ← sum3_add]
  apply sum3_deriv
  intro a b c
  exact trace_line3 trace comm (B (P a b c)) (T a) (X a) (T b) (X b) (T c) (X c)

private theorem mass_deriv (g : ι → ℝ) (hcyc : Cyclic trace) (T X : OneForm ι A) :
    HasDerivAt (fun t : ℝ => pair trace (T + t • X) (raise g (T + t • X)))
      (2 * pair trace X (raise g T)) 0 := by
  have h (a : ι) : HasDerivAt
      (fun t : ℝ => trace ((T + t • X) a * raise g (T + t • X) a))
      (2 * trace (X a * raise g T a)) 0 := by
    have hc : trace (T a * (g a • X a)) = trace (X a * (g a • T a)) := by
      simp only [mul_smul_comm, map_smul, hcyc (T a) (X a)]
    have hd := trace_line2 trace (T a) (X a) (g a • T a) (g a • X a)
    simpa only [raise, Pi.add_apply, Pi.smul_apply, smul_add, smul_comm (g a), hc, two_mul] using hd
  simpa only [pair, Finset.mul_sum] using HasDerivAt.fun_sum (fun a _ => h a)

private theorem action_reduced (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (hp : Alternating P) (hq : Alternating Q) (hcyc : Cyclic trace)
    (lam m : ℝ) (T : OneForm ι A) :
    action trace D g P Q F lam m T =
      (1 / 2) * (contraction trace anti P F T + contraction trace comm Q F T +
        kinetic trace D anti P T T + kinetic trace D comm Q T T) +
      (lam / 2) * cubic trace anti P T T T + m * pair trace T (raise g T) := by
  simp only [action, pair_add_right, pair_theta, contraction_add, contraction_smul,
    contraction_dB trace D anti P hp, contraction_dB trace D comm Q hq]
  change (1 / 2 : ℝ) *
      (contraction trace anti P F T + (1 / 2) * (2 * kinetic trace D anti P T T) +
        lam * cubic trace anti P T T T) +
    (1 / 2) * (contraction trace comm Q F T + (1 / 2) * (2 * kinetic trace D comm Q T T) +
        lam * cubic trace comm Q T T T) + m * pair trace T (raise g T) = _
  rw [cubic_minus_zero trace Q hq hcyc T]
  ring

/-- The real derivative in direction `α` is the trace pairing with the full
Euler expression, including the quadratic correction. -/
theorem theorem_5_2 (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (hp : Alternating P) (hq : Alternating Q) (hcyc : Cyclic trace) (hD : Leibniz D)
    (hP : Parallel D P) (hQ : Parallel D Q) (lam m : ℝ) (T α : OneForm ι A)
    (hbP : BoundaryZero trace D anti P T α) (hbQ : BoundaryZero trace D comm Q T α) :
    HasDerivAt (fun t : ℝ => action trace D g P Q F lam m (T + t • α))
      (pair trace α (euler D g P Q F lam m T)) 0 := by
  simp_rw [action_reduced trace D g P Q F hp hq hcyc lam m]
  have h :=
    ((((contraction_deriv trace anti P F T α).add
      (contraction_deriv trace comm Q F T α)).add
      (kinetic_deriv trace D anti P T α)).add
      (kinetic_deriv trace D comm Q T α)).const_mul (1 / 2)
  have hv := (h.add ((cubic_deriv trace anti P T α).const_mul (lam / 2))).add
    ((mass_deriv trace g hcyc T α).const_mul m)
  apply hv.congr_deriv
  rw [kinetic_plus_symm trace D P hp hcyc hD hP T α hbP,
    kinetic_minus_skew trace D Q hq hcyc hD hQ T α hbQ,
    cubic_exchange trace P hp T T α, cubic_move_value trace P hp hcyc T α]
  simp only [euler, pair_add_right, pair_theta, contraction_add, contraction_smul,
    contraction_dB trace D anti P hp, pair_smul_right, pair_correction]
  change _ = (1 / 2 : ℝ) *
    (contraction trace anti P F α + 2 * kinetic trace D anti P α T +
      (3 * lam) * cubic trace anti P α T T) +
    (1 / 2) * contraction trace comm Q F α + (2 * m) * pair trace α (raise g T) +
    (-lam) * correctionTerm trace P α T
  ring

/-- Stationarity is equivalent to vanishing of the Euler expression
if the trace pairing separates the coefficients against the test fields. -/
theorem stationary_iff (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (hp : Alternating P) (hq : Alternating Q) (hcyc : Cyclic trace) (hD : Leibniz D)
    (hP : Parallel D P) (hQ : Parallel D Q) (lam m : ℝ) (T : OneForm ι A)
    (admissible : OneForm ι A → Prop)
    (hbP : ∀ α, admissible α → BoundaryZero trace D anti P T α)
    (hbQ : ∀ α, admissible α → BoundaryZero trace D comm Q T α)
    (separates : ∀ E : OneForm ι A, (∀ α, admissible α → pair trace α E = 0) → E = 0) :
    (∀ α, admissible α → deriv (fun t : ℝ => action trace D g P Q F lam m (T + t • α)) 0 = 0) ↔
    euler D g P Q F lam m T = 0 := by
  have h (α) (hα : admissible α) :=
    (theorem_5_2 trace D g P Q F hp hq hcyc hD hP hQ lam m T α (hbP α hα) (hbQ α hα)).deriv
  constructor
  · intro hs
    apply separates
    intro α hα
    rw [← h α hα]
    exact hs α hα
  · intro heq α hα
    rw [h α hα]
    simp [heq, pair]

omit [Fintype ι] in
private theorem adjoint_comm (sharp : A →ₗ[ℝ] A)
    (hrev : ∀ x y, sharp (x * y) = sharp y * sharp x)
    (x p : A) (hx : sharp x = -x) (hp : sharp p = p) :
    sharp (comm x p) = comm x p := by
  simp only [comm_apply, map_sub, hrev, hx, hp, mul_neg, neg_mul]
  abel

/-- A skew-adjoint torsion and self-adjoint insertion give a skew-adjoint
correction. Here `sharp` is the coefficient adjoint on the real algebra. -/
theorem correction_skew (sharp : A →ₗ[ℝ] A)
    (hrev : ∀ x y, sharp (x * y) = sharp y * sharp x)
    (T : OneForm ι A) (P : Insertion ι A) (lam : ℝ)
    (hT : ∀ a, sharp (T a) = -T a) (hP : ∀ a b c, sharp (P a b c) = P a b c)
    (a : ι) : sharp (correction P lam T a) = -correction P lam T a := by
  have h (b c : ι) : sharp (anti (T b) (comm (T c) (P a b c))) =
      -anti (T b) (comm (T c) (P a b c)) := by
    have hc := adjoint_comm sharp hrev (T c) (P a b c) (hT c) (hP a b c)
    simp only [anti_apply, map_add, hrev, hT b, hc, mul_neg, neg_mul]
    abel
  simp only [correction, map_smul, map_sum, h, Finset.sum_neg_distrib, smul_neg]

/-- Local component formula for the background covariant derivative. -/
def covariant (d : ι → A →ₗ[ℝ] A) (B : OneForm ι A) : ι → A →ₗ[ℝ] A :=
  fun b => d b + comm (B b)

def curvature (d : ι → A →ₗ[ℝ] A) (B : OneForm ι A) : TwoForm ι A :=
  dB d B + wedgeSquare B

omit [Fintype ι] in
theorem curvature_shift (d : ι → A →ₗ[ℝ] A) (B T : OneForm ι A) :
    curvature d (B + T) = curvature d B + dB (covariant d B) T + wedgeSquare T := by
  funext a b
  simp only [curvature, dB, covariant, wedgeSquare, Pi.add_apply, LinearMap.add_apply,
    map_add, comm_apply]
  noncomm_ring

/-- At the Einstein couplings the first term is the contraction of the full
curvature, and the mass coefficient is `κ`. The correction persists. -/
theorem einstein_euler (d : ι → A →ₗ[ℝ] A) (g : ι → ℝ) (P : Insertion ι A)
    (B T : OneForm ι A) (κ : ℝ) :
    euler (covariant d B) g P 0 (curvature d B) (1 / 3) (κ / 2) T =
      theta anti P (curvature d (B + T)) + κ • raise g T + correction P (1 / 3) T := by
  rw [euler, curvature_shift]
  have h₁ : (3 * (1 / 3) : ℝ) = 1 := by norm_num
  have h₂ : 2 * (κ / 2) = κ := by ring
  simp only [h₁, h₂, one_smul]
  have hQ : theta comm (0 : Insertion ι A) (curvature d B) = 0 := by
    funext a
    simp [theta]
  rw [hQ, add_zero]

end

end GeometricUnity.Theorem52
