import Mathlib.Data.Int.Basic

/-!
# Geometric Unity: the finite D₇ calculation in Theorem 3.4

The program computes the signed multiplicity tables and their pairings
over the integers. The exterior-grade highest-weight lists are inputs
to the calculation. Identifying these pairings with dimensions of
equivariant Hom spaces uses the representation-theoretic argument in
the note.
-/

namespace GeometricUnity.D7Counts

abbrev Weight := List ℤ
abbrev Multiplicities := List (Weight × ℤ)

def zeroWeight : Weight := List.replicate 7 0
def addWeight (w v : Weight) : Weight := List.zipWith (· + ·) w v
def subWeight (w v : Weight) : Weight := List.zipWith (· - ·) w v

def unitWeight (i : ℕ) (sign : ℤ) : Weight :=
  (List.range 7).map fun j => if i = j then sign else 0

def vectorWeights : List Weight :=
  (List.range 7).flatMap fun i => [unitWeight i 1, unitWeight i (-1)]

/-- Choose positions in a list, preserving repeated values in the output. -/
def choosePositions {α : Type} : ℕ → List α → List (List α)
  | 0, _ => [[]]
  | _ + 1, [] => []
  | n + 1, a :: rest =>
      (choosePositions n rest).map (a :: ·) ++ choosePositions (n + 1) rest

def exteriorWeights (r : ℕ) : List Weight :=
  (choosePositions r vectorWeights).map fun selected =>
    selected.foldl addWeight zeroWeight

def rho : Weight := [6, 5, 4, 3, 2, 1, 0]

/-- Insert by decreasing absolute value. Passing an entry reverses the
permutation sign. A repeated absolute value makes the weight singular. -/
def insertAbs (x : ℤ) : Weight → Option (Weight × ℤ)
  | [] => some ([x], 1)
  | y :: ys =>
      if x.natAbs = y.natAbs then none
      else if y.natAbs < x.natAbs then some (x :: y :: ys, 1)
      else (insertAbs x ys).map fun (zs, sign) => (y :: zs, -sign)

def sortAbs : Weight → Option (Weight × ℤ)
  | [] => some ([], 1)
  | x :: xs => do
      let (ys, sign₁) ← sortAbs xs
      let (zs, sign₂) ← insertAbs x ys
      pure (zs, sign₁ * sign₂)

/-- Make the first six coordinates positive and put the compensating
sign, when needed, on the seventh coordinate. The sign component is
the determinant because the number of coordinate sign flips is even. -/
def reflect (w : Weight) : Option (Weight × ℤ) := do
  let (sorted, sign) ← sortAbs w
  match sorted with
  | [a, b, c, d, e, f, g] =>
      let first := [a, b, c, d, e, f]
      let flips := (first.filter (· < 0)).length
      pure (first.map (fun x => (x.natAbs : ℤ)) ++ [if flips % 2 = 1 then -g else g], sign)
  | _ => none

def addMultiplicity (w : Weight) (m : ℤ) : Multiplicities → Multiplicities
  | [] => [(w, m)]
  | (v, n) :: tail =>
      match compare w v with
      | .lt => (w, m) :: (v, n) :: tail
      | .eq => (v, n + m) :: tail
      | .gt => (v, n) :: addMultiplicity w m tail

def tally (terms : Multiplicities) : Multiplicities :=
  let summed := terms.foldl (fun table (w, m) => addMultiplicity w m table) []
  summed.filter fun (_, m) => m != 0

def coefficient (terms : Multiplicities) (w : Weight) : ℤ :=
  (terms.lookup w).getD 0

def mu (k : ℕ) : Weight :=
  (List.range 7).map fun i => if i < k then 1 else 0

def muMinus : Weight := [1, 1, 1, 1, 1, 1, -1]

def nu (k : ℕ) : Weight := 2 :: (mu k).drop 1
def nuMinus : Weight := 2 :: muMinus.drop 1

/-- The supplied highest-weight labels for each exterior grade. -/
def gradeWeights (k : ℕ) : List Weight :=
  if k > 14 then []
  else
    let j := min k (14 - k)
    if j = 7 then [mu 7, muMinus] else [mu j]

def signedTerms (weights highestWeights : List Weight) : Multiplicities :=
  highestWeights.flatMap fun highest =>
    let shifted := addWeight highest rho
    weights.filterMap fun w =>
      (reflect (addWeight shifted w)).map fun (dom, sign) =>
        (subWeight dom rho, sign)

def cliffordMultiplicities : Multiplicities :=
  tally <| (List.range 15).flatMap fun k => (gradeWeights k).map (·, 1)

def vectorTarget : Multiplicities :=
  tally <| signedTerms (exteriorWeights 1) ((List.range 15).flatMap gradeWeights)

def gradeMultiplicities (r k : ℕ) : Multiplicities :=
  tally <| signedTerms (exteriorWeights r) (gradeWeights k)

def retain (target source : Multiplicities) : Multiplicities :=
  source.filter fun (w, _) => coefficient target w != 0

def pairing (source target : Multiplicities) : ℤ :=
  (source.map fun (w, n) => n * coefficient target w).sum

structure Row where
  unrestricted : ℤ
  alternating : ℤ
  vector : ℤ
  hook : ℤ
  deriving DecidableEq, Repr

def gradeRow (k : ℕ) : Row :=
  let u := pairing (gradeMultiplicities 2 k) vectorTarget
  let b := pairing (gradeMultiplicities 3 k) cliffordMultiplicities
  let v := pairing (gradeMultiplicities 1 k) cliffordMultiplicities
  ⟨u, b, v, u - b - v⟩

def rows : List Row := (List.range 15).map gradeRow

def addRows (x y : Row) : Row :=
  ⟨x.unrestricted + y.unrestricted, x.alternating + y.alternating,
    x.vector + y.vector, x.hook + y.hook⟩

def total : Row := rows.foldl addRows ⟨0, 0, 0, 0⟩

set_option maxRecDepth 4096 in
/-- The cardinalities count retained subsets, including those with the same
weight sum. -/
theorem exterior_weight_counts :
    ((exteriorWeights 1).length, (exteriorWeights 2).length, (exteriorWeights 3).length) =
      (14, 91, 364) := by decide

theorem chamber_examples :
    reflect [6, 5, 4, 3, 2, 1, -1] = none ∧
    reflect [5, -6, 4, 3, 2, 1, 0] = some ([6, 5, 4, 3, 2, 1, 0], -1) ∧
    reflect [-7, 6, 5, 4, 3, 2, 1] = some ([7, 6, 5, 4, 3, 2, -1], 1) := by decide

private def unitTable (weights : List Weight) : Multiplicities :=
  tally (weights.map (·, 1))

set_option maxRecDepth 4096 in
theorem targets :
    cliffordMultiplicities = tally (((List.range 7).map fun k => (mu k, 2)) ++
      [(mu 7, 1), (muMinus, 1)]) ∧
    vectorTarget = tally ([(mu 0, 2)] ++
      ((List.range 6).map fun k => (mu (k + 1), 4)) ++
      [(mu 7, 2), (muMinus, 2)] ++
      ((List.range 6).map fun k => (nu (k + 1), 2)) ++ [(nu 7, 1), (nuMinus, 1)]) := by
  decide +kernel

/-- The r = 2 entries contributing to the unrestricted pairing, in grades 0–7. -/
def expectedSecond : List (List Weight) :=
  [[mu 2],
   [mu 1, nu 2, mu 3],
   [mu 2, nu 1, nu 3, mu 0, mu 4],
   [mu 3, nu 2, nu 4, mu 1, mu 5],
   [mu 4, nu 3, nu 5, mu 2, mu 6],
   [mu 5, nu 4, nu 6, mu 3, mu 7, muMinus],
   [mu 6, mu 6, nu 5, nu 7, nuMinus, mu 4],
   [mu 7, muMinus, nu 6, nu 6, mu 5, mu 5]]

/-- The r = 3 entries contributing to the alternating pairing, in grades 0–7. -/
def expectedThird : List (List Weight) :=
  [[mu 3],
   [mu 2, mu 4],
   [mu 1, mu 3, mu 5],
   [mu 2, mu 4, mu 0, mu 6],
   [mu 3, mu 5, mu 1, mu 7, muMinus],
   [mu 4, mu 6, mu 6, mu 2],
   [mu 5, mu 5, mu 7, muMinus, mu 3],
   [mu 6, mu 6, mu 4, mu 4]]

/-- The r = 1 entries contributing to the vector pairing, in grades 0–7. -/
def expectedFirst : List (List Weight) :=
  [[mu 1], [mu 0, mu 2], [mu 1, mu 3], [mu 2, mu 4], [mu 3, mu 5],
   [mu 4, mu 6], [mu 5, mu 7, muMinus], [mu 6, mu 6]]

def retainedTable (r : ℕ) (target : Multiplicities) : List Multiplicities :=
  (List.range 8).map fun k => retain target (gradeMultiplicities r k)

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem first_table : retainedTable 1 cliffordMultiplicities = expectedFirst.map unitTable := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem second_table : retainedTable 2 vectorTarget = expectedSecond.map unitTable := by
  decide +kernel

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem third_table : retainedTable 3 cliffordMultiplicities = expectedThird.map unitTable := by
  decide +kernel

def expectedRows : List Row :=
  [⟨4, 2, 2, 0⟩, ⟨10, 4, 4, 2⟩, ⟨14, 6, 4, 4⟩,
   ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩,
   ⟨16, 8, 4, 4⟩,
   ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩, ⟨16, 8, 4, 4⟩,
   ⟨14, 6, 4, 4⟩, ⟨10, 4, 4, 2⟩, ⟨4, 2, 2, 0⟩]

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
theorem grade_rows : rows = expectedRows := by decide +kernel

theorem totals : total = ⟨200, 96, 56, 48⟩ := by
  rw [total, grade_rows]
  decide

end GeometricUnity.D7Counts
