import D7RealRanks
import D7RealJets
import Mathlib.Analysis.Matrix.Normed

/-! # The real Spin(7,7)-equivariant contraction spaces -/

namespace GeometricUnity.D7RealTheorem

open D7Exterior (Axis)
open D7SpinAction D7RealComparison
open scoped TensorProduct

noncomputable section

set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

private theorem representation_inv_cancel {W : Type*} [AddCommMonoid W] [Module ℝ W]
    (τ : Representation ℝ Spin W) (g : Spin) (y : W) : τ g (τ g⁻¹ y) = y := by
  change (τ g * τ g⁻¹) y = y
  rw [← map_mul, mul_inv_cancel, map_one]
  rfl

private def currySymbols {U W E : Type*} [AddCommGroup U] [Module ℝ U]
    [AddCommGroup W] [Module ℝ W] [AddCommGroup E] [Module ℝ E]
    (ρ : Representation ℝ Spin U) (τ : Representation ℝ Spin W) (σ : Representation ℝ Spin E) :
    (ρ.tprod τ).IntertwiningMap σ ≃ₗ[ℝ] ρ.IntertwiningMap (Representation.linHom τ σ) where
  toFun T := ⟨TensorProduct.curry T.toLinearMap, by
    intro g
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    have h := DFunLike.congr_fun (T.isIntertwining' g) (x ⊗ₜ[ℝ] τ g⁻¹ y)
    simp only [LinearMap.comp_apply, Representation.tprod_apply, TensorProduct.map_tmul,
      representation_inv_cancel] at h
    exact h⟩
  invFun S := ⟨TensorProduct.lift S.toLinearMap, by
    intro g
    apply TensorProduct.ext'
    intro x y
    have h := DFunLike.congr_fun (DFunLike.congr_fun (S.isIntertwining' g) x) (τ g y)
    have hy : τ g⁻¹ (τ g y) = y := by simpa only [inv_inv] using representation_inv_cancel τ g⁻¹ y
    simp only [LinearMap.comp_apply, Representation.linHom_apply, hy] at h
    exact h⟩
  left_inv T := by apply Representation.IntertwiningMap.ext; apply TensorProduct.ext'; intros; rfl
  right_inv S := by apply Representation.IntertwiningMap.ext; apply LinearMap.ext; intro x; ext y; rfl
  map_add' T S := by apply Representation.IntertwiningMap.ext; rfl
  map_smul' a T := by apply Representation.IntertwiningMap.ext; rfl

open D7RealJets (FormJets)

abbrev JetTensors := FormJets ⊗[ℝ] Coefficients

local instance : AddCommGroup FormJets :=
  TensorProduct.addCommGroup (R := ℝ) (M := Covector) (N := D7RealJets.Forms 2)

local instance : AddCommGroup JetTensors :=
  TensorProduct.addCommGroup (R := ℝ) (M := FormJets) (N := Coefficients)

private abbrev formJetAction := vectorRepresentation.dual.tprod (formAction 2)

def jetAction : Representation ℝ Spin JetTensors :=
  formJetAction.tprod coefficientAction

abbrev DivergenceSymbols := jetAction.IntertwiningMap coefficientAction

private def toJetRepresentation :
    ((formCoefficientsAction 2).tprod vectorRepresentation).Equiv jetAction :=
  (Representation.TensorProduct.comm (formCoefficientsAction 2) vectorRepresentation).trans
    ((liftTensorEquiv metricDualEquiv (formCoefficientsAction 2)).trans
      (Representation.TensorProduct.assoc vectorRepresentation.dual (formAction 2) coefficientAction).symm)

/-- Metric contraction of the one-form output gives the divergence symbol. -/
def divergenceSymbol : Operators ≃ₗ[ℝ] DivergenceSymbols := by
  let a := transportHom (Representation.Equiv.refl (formCoefficientsAction 2))
    (Representation.Equiv.dualTensorHom (V := Vector) (W := Coefficients)
      vectorRepresentation coefficientAction)
  let b := currySymbols (U := FormCoefficients 2) (W := Vector) (E := Coefficients)
    (formCoefficientsAction 2) vectorRepresentation coefficientAction
  let c := transportHom (M := FormCoefficients 2 ⊗[ℝ] Vector) (U := JetTensors)
    toJetRepresentation (Representation.Equiv.refl coefficientAction)
  exact a.trans (b.symm.trans c)

private def wedgeSymbol : jetAction.IntertwiningMap (formCoefficientsAction 3) :=
  (⟨D7RealJets.wedgeJet, fun g => D7RealJets.wedgeJet_natural (vectorRepresentation.dual g)⟩ :
    formJetAction.IntertwiningMap (formAction 3)).rTensor coefficientAction

private def alternatingSection : (formCoefficientsAction 3).IntertwiningMap jetAction :=
  (⟨D7RealJets.includeThree, fun g => D7RealJets.includeThree_natural (vectorRepresentation.dual g)⟩ :
    (formAction 3).IntertwiningMap formJetAction).rTensor coefficientAction

@[simp] private theorem wedge_section (x : FormCoefficients 3) :
    wedgeSymbol (alternatingSection x) = x := by
  suffices h : (wedgeSymbol.toLinearMap).comp alternatingSection.toLinearMap = LinearMap.id from
    DFunLike.congr_fun h x
  apply TensorProduct.ext'
  intro u a
  change D7RealJets.wedgeJet (D7RealJets.includeThree u) ⊗ₜ[ℝ] a = u ⊗ₜ[ℝ] a
  exact congrArg (fun v => v ⊗ₜ[ℝ] a) (DFunLike.congr_fun D7RealJets.wedge_includeThree u)

/-- The real operator subspace whose divergence vanishes on the kernel of alternation. -/
def bianchiOperators : Submodule ℝ Operators where
  carrier := {T | ∀ s, wedgeSymbol s = 0 → divergenceSymbol T s = 0}
  zero_mem' := by intro s _; simp
  add_mem' := by intro T U hT hU s hs; simp [hT s hs, hU s hs]
  smul_mem' := by intro c T hT s hs; simp [hT s hs]

theorem mem_bianchi_iff (T : Operators) :
    T ∈ bianchiOperators ↔ ∀ s, wedgeSymbol s = 0 → divergenceSymbol T s = 0 := Iff.rfl

/-- Evaluate the divergence symbol on a skew first jet in real coordinates. -/
def coordinateDivergence (T : Operators) : BianchiSymbol.Jet Axis Coefficients →ₗ[ℝ] Coefficients :=
  (divergenceSymbol T).toLinearMap.comp (D7RealJets.jetEquiv (E := Coefficients)).symm.toLinearMap

set_option maxRecDepth 8192 in
private theorem mem_bianchi_iff_compatible (T : Operators) :
    T ∈ bianchiOperators ↔ BianchiSymbol.Compatible (coordinateDivergence T) := by
  rw [mem_bianchi_iff]
  have hw (s : JetTensors) :
      BianchiSymbol.ClosedJet (D7RealJets.jetEquiv s) ↔ wedgeSymbol s = 0 :=
    D7RealJets.closed_tensorJet_iff s
  have hcoord (J : BianchiSymbol.Jet Axis Coefficients) :
      coordinateDivergence T J =
        divergenceSymbol T ((D7RealJets.jetEquiv (E := Coefficients)).symm J) := by
    simp only [coordinateDivergence, LinearMap.comp_apply, LinearEquiv.coe_coe,
      Representation.IntertwiningMap.toLinearMap_apply]
  unfold BianchiSymbol.Compatible
  constructor
  · intro h J hJ
    have hs := (hw ((D7RealJets.jetEquiv (E := Coefficients)).symm J)).mp
      (by rwa [LinearEquiv.apply_symm_apply])
    rw [hcoord]
    exact h (D7RealJets.jetEquiv.symm J) hs
  · intro h s hs
    have he := h (D7RealJets.jetEquiv s) ((hw s).mpr hs)
    rwa [hcoord, LinearEquiv.symm_apply_apply] at he

section ClosedFields

open scoped Matrix.Norms.Elementwise

/-- Vanishing on all real closed fields with coefficient matrices in the unitary real form. -/
def VanishesOnClosedFields (T : Operators) : Prop :=
  ∀ (F : (Axis → ℝ) → Axis → Axis → Coefficients)
    (hF : ∀ x b c, F x c b = -F x b c),
    (∀ x a b c, DifferentiableAt ℝ (fun t : ℝ => F (x + t • Pi.single a 1) b c) 0) →
    BianchiSymbol.ClosedField F →
    ∀ x, coordinateDivergence T (BianchiSymbol.firstJet F hF x) = 0

theorem mem_bianchi_iff_closed_fields (T : Operators) :
    T ∈ bianchiOperators ↔ VanishesOnClosedFields T :=
  (mem_bianchi_iff_compatible T).trans (BianchiSymbol.compatible_iff_closed_fields (coordinateDivergence T))

end ClosedFields

private theorem bianchi_factor (T : ↥bianchiOperators) (s : JetTensors) :
    divergenceSymbol T.val (alternatingSection (wedgeSymbol s)) = divergenceSymbol T.val s := by
  have hz : wedgeSymbol (s - alternatingSection (wedgeSymbol s)) = 0 := by
    rw [map_sub, wedge_section, sub_self]
  have h := (mem_bianchi_iff T.val).mp T.prop _ hz
  rwa [map_sub, sub_eq_zero, eq_comm] at h

/-- The Bianchi-compatible operators are exactly the alternating symbol channel. -/
def bianchiEquiv : ↥bianchiOperators ≃ₗ[ℝ] ExteriorSymbols 3 where
  toFun T := (divergenceSymbol T.val).comp alternatingSection
  invFun A := ⟨divergenceSymbol.symm (A.comp wedgeSymbol), by
    apply (mem_bianchi_iff _).mpr
    intro s hs
    rw [LinearEquiv.apply_symm_apply]
    change A (wedgeSymbol s) = 0
    rw [hs, map_zero]⟩
  left_inv T := by
    apply Subtype.ext
    apply divergenceSymbol.injective
    rw [LinearEquiv.apply_symm_apply]
    apply Representation.IntertwiningMap.ext
    exact LinearMap.ext (bianchi_factor T)
  right_inv A := by
    simp only [LinearEquiv.apply_symm_apply]
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    exact congrArg A (wedge_section x)
  map_add' T U := by
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    exact DFunLike.congr_fun (congrArg Representation.IntertwiningMap.toLinearMap
      (map_add divergenceSymbol T.val U.val)) (alternatingSection x)
  map_smul' c T := by
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    exact DFunLike.congr_fun (congrArg Representation.IntertwiningMap.toLinearMap
      (map_smul divergenceSymbol c T.val)) (alternatingSection x)

theorem bianchi_dimension : Module.finrank ℝ ↥bianchiOperators = 96 :=
  bianchiEquiv.finrank_eq.trans exterior_symbol_dimensions.2

abbrev VectorSymbols := oneFormCoefficientsAction.IntertwiningMap coefficientAction

private def realExteriorOne : (formAction 1).Equiv vectorRepresentation.dual :=
  Representation.Equiv.mk (exteriorPower.oneEquiv ℝ Covector) fun g =>
    exteriorPower.oneEquiv_naturality (vectorRepresentation.dual g)

theorem vector_symbol_dimension : Module.finrank ℝ VectorSymbols = 56 :=
  (transportHom (liftTensorEquiv realExteriorOne coefficientAction).symm
    (Representation.Equiv.refl coefficientAction)).finrank_eq.trans exterior_symbol_dimensions.1

private def traceSymbol : jetAction.IntertwiningMap oneFormCoefficientsAction :=
  (⟨D7RealJets.traceJet, D7RealJets.traceJet_equivariant⟩ :
    formJetAction.IntertwiningMap vectorRepresentation.dual).rTensor coefficientAction

private def vectorSection : oneFormCoefficientsAction.IntertwiningMap jetAction :=
  (⟨D7RealJets.includeVector, D7RealJets.includeVector_equivariant⟩ :
    vectorRepresentation.dual.IntertwiningMap formJetAction).rTensor coefficientAction

@[simp] private theorem trace_section (x : OneFormCoefficients) :
    traceSymbol (vectorSection x) = x := by
  suffices h : traceSymbol.toLinearMap.comp vectorSection.toLinearMap = LinearMap.id from
    DFunLike.congr_fun h x
  apply TensorProduct.ext'
  intro u a
  change D7RealJets.traceJet (D7RealJets.includeVector u) ⊗ₜ[ℝ] a = u ⊗ₜ[ℝ] a
  exact congrArg (fun v => v ⊗ₜ[ℝ] a) (DFunLike.congr_fun D7RealJets.trace_includeVector u)

@[simp] private theorem trace_alternating (x : FormCoefficients 3) :
    traceSymbol (alternatingSection x) = 0 := by
  suffices h : traceSymbol.toLinearMap.comp alternatingSection.toLinearMap = 0 from
    DFunLike.congr_fun h x
  apply TensorProduct.ext'
  intro u a
  have h := DFunLike.congr_fun D7RealJets.trace_includeThree u
  change D7RealJets.traceJet (D7RealJets.includeThree u) = 0 at h
  change D7RealJets.traceJet (D7RealJets.includeThree u) ⊗ₜ[ℝ] a = 0
  rw [h, TensorProduct.zero_tmul]

@[simp] private theorem wedge_vector (x : OneFormCoefficients) :
    wedgeSymbol (vectorSection x) = 0 := by
  suffices h : wedgeSymbol.toLinearMap.comp vectorSection.toLinearMap = 0 from
    DFunLike.congr_fun h x
  apply TensorProduct.ext'
  intro u a
  have h := DFunLike.congr_fun D7RealJets.wedge_includeVector u
  change D7RealJets.wedgeJet (D7RealJets.includeVector u) = 0 at h
  change D7RealJets.wedgeJet (D7RealJets.includeVector u) ⊗ₜ[ℝ] a = 0
  rw [h, TensorProduct.zero_tmul]

private def channelRestrictions : DivergenceSymbols →ₗ[ℝ] ExteriorSymbols 3 × VectorSymbols where
  toFun S := (S.comp alternatingSection, S.comp vectorSection)
  map_add' S T := by
    apply Prod.ext <;> apply Representation.IntertwiningMap.ext <;> apply LinearMap.ext <;>
      intro x <;> rfl
  map_smul' c S := by
    apply Prod.ext <;> apply Representation.IntertwiningMap.ext <;> apply LinearMap.ext <;>
      intro x <;> rfl

private theorem channelRestrictions_surjective : Function.Surjective channelRestrictions := by
  rintro ⟨A, V⟩
  refine ⟨A.comp wedgeSymbol + V.comp traceSymbol, ?_⟩
  apply Prod.ext <;> apply Representation.IntertwiningMap.ext <;> apply LinearMap.ext <;> intro x
  · change A (wedgeSymbol (alternatingSection x)) + V (traceSymbol (alternatingSection x)) = A x
    simp
  · change A (wedgeSymbol (vectorSection x)) + V (traceSymbol (vectorSection x)) = V x
    simp

/-- Symbols supported on the traceless hook, equivalently the symbols vanishing on the
alternating and vector inclusions. -/
def hookSymbols : Submodule ℝ DivergenceSymbols := channelRestrictions.ker

/-- Project first jets to the joint kernel of alternation and trace. -/
def hookProjection : jetAction.IntertwiningMap jetAction :=
  Representation.IntertwiningMap.id jetAction -
    alternatingSection.comp wedgeSymbol - vectorSection.comp traceSymbol

theorem hookProjection_mem (x : JetTensors) :
    wedgeSymbol (hookProjection x) = 0 ∧ traceSymbol (hookProjection x) = 0 := by
  change wedgeSymbol (x - alternatingSection (wedgeSymbol x) - vectorSection (traceSymbol x)) = 0 ∧
    traceSymbol (x - alternatingSection (wedgeSymbol x) - vectorSection (traceSymbol x)) = 0
  simp

theorem mem_hook_iff_project (S : DivergenceSymbols) :
    S ∈ hookSymbols ↔ S.comp hookProjection = S := by
  change channelRestrictions S = 0 ↔ _
  constructor
  · intro h
    have hA := congrArg Prod.fst h
    have hV := congrArg Prod.snd h
    change S.comp alternatingSection = 0 at hA
    change S.comp vectorSection = 0 at hV
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    have ha : S (alternatingSection (wedgeSymbol x)) = 0 :=
      DFunLike.congr_fun hA (wedgeSymbol x)
    have hv : S (vectorSection (traceSymbol x)) = 0 :=
      DFunLike.congr_fun hV (traceSymbol x)
    change S (x - alternatingSection (wedgeSymbol x) - vectorSection (traceSymbol x)) = S x
    simp [ha, hv]
  · intro h
    apply Prod.ext <;> apply Representation.IntertwiningMap.ext <;> apply LinearMap.ext <;> intro x
    · have ha := DFunLike.congr_fun h (alternatingSection x)
      change S (alternatingSection x - alternatingSection (wedgeSymbol (alternatingSection x)) -
        vectorSection (traceSymbol (alternatingSection x))) = S (alternatingSection x) at ha
      exact (by simpa using ha.symm : S (alternatingSection x) = 0)
    · have hv := DFunLike.congr_fun h (vectorSection x)
      change S (vectorSection x - alternatingSection (wedgeSymbol (vectorSection x)) -
        vectorSection (traceSymbol (vectorSection x))) = S (vectorSection x) at hv
      exact (by simpa using hv.symm : S (vectorSection x) = 0)

theorem hook_symbol_dimension : Module.finrank ℝ ↥hookSymbols = 48 := by
  let : AddCommGroup (ExteriorSymbols 3) :=
    Representation.IntertwiningMap.instAddCommGroup (formCoefficientsAction 3) coefficientAction
  let : AddCommGroup VectorSymbols :=
    Representation.IntertwiningMap.instAddCommGroup oneFormCoefficientsAction coefficientAction
  have : Module.Finite ℝ (ExteriorSymbols 3) :=
    Module.finite_of_finrank_eq_succ exterior_symbol_dimensions.2
  have : Module.Finite ℝ VectorSymbols :=
    Module.finite_of_finrank_eq_succ vector_symbol_dimension
  have h := LinearMap.finrank_range_add_finrank_ker (K := ℝ) (V := DivergenceSymbols)
    (V₂ := ExteriorSymbols 3 × VectorSymbols) channelRestrictions
  have he := LinearMap.range_eq_top.mpr channelRestrictions_surjective
  have hd := divergenceSymbol.finrank_eq.symm.trans unrestricted_dimension
  rw [he, finrank_top, Module.finrank_prod, exterior_symbol_dimensions.2,
    vector_symbol_dimension, hd] at h
  change Module.finrank ℝ ↥channelRestrictions.ker = 48
  omega

/-- Theorem 3.4 on the actual real Spin representation and the real closed-field test. -/
theorem theorem_3_4 :
    Module.finrank ℝ Operators = 200 ∧
    Module.finrank ℝ (ExteriorSymbols 3) = 96 ∧
    Module.finrank ℝ VectorSymbols = 56 ∧
    Module.finrank ℝ ↥hookSymbols = 48 ∧
    Module.finrank ℝ ↥bianchiOperators = 96 ∧
    (∀ T : Operators, T ∈ bianchiOperators ↔ VanishesOnClosedFields T) :=
  ⟨unrestricted_dimension, exterior_symbol_dimensions.2, vector_symbol_dimension,
    hook_symbol_dimension, bianchi_dimension, mem_bianchi_iff_closed_fields⟩

end
end GeometricUnity.D7RealTheorem
