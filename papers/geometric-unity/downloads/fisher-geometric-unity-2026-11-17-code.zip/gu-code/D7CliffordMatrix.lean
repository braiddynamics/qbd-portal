import D7SpinAction
import Mathlib.Algebra.Ring.Action.ConjAct
import Mathlib.LinearAlgebra.Complex.Module
import Mathlib.LinearAlgebra.ExteriorAlgebra.Basis
import Mathlib.LinearAlgebra.Matrix.ToLin
import Mathlib.LinearAlgebra.Matrix.Trace
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.LinearAlgebra.TensorProduct.Basis
import Mathlib.RingTheory.TensorProduct.Maps

/-!
# The split Clifford algebra on seven exterior generators

The spinor module is the real exterior algebra of a seven-dimensional
space. A split vector with positive and negative coordinates `p` and
`n` acts by creation with `p + n` and contraction by `p - n`.
-/

namespace GeometricUnity.D7CliffordMatrix

open WitnessW1 (Index Cl splitForm metricSign gamma)
open scoped BigOperators Matrix TensorProduct

noncomputable section

abbrev Half := Fin 7 → ℝ
abbrev Spinor := ExteriorAlgebra ℝ Half
abbrev SpinorIndex := Finset (Fin 7)
abbrev Mat := Matrix SpinorIndex SpinorIndex ℝ

def spinorBasis : Module.Basis SpinorIndex ℝ Spinor :=
  (Pi.basisFun ℝ (Fin 7)).ExteriorAlgebra

theorem spinor_finrank : Module.finrank ℝ Spinor = 128 := by
  rw [Module.finrank_eq_card_basis spinorBasis, Fintype.card_finset, Fintype.card_fin]
  rfl

private def positive : (Index → ℝ) →ₗ[ℝ] Half :=
  LinearMap.pi fun i => LinearMap.proj (Fin.castAdd 7 i)

private def negative : (Index → ℝ) →ₗ[ℝ] Half :=
  LinearMap.pi fun i => LinearMap.proj (Fin.natAdd 7 i)

/-- Left exterior multiplication by a vector on the spinor space. -/
def creation : Half →ₗ[ℝ] Module.End ℝ Spinor :=
  (Algebra.lmul ℝ Spinor).toLinearMap.comp (ExteriorAlgebra.ι ℝ)

/-- Contraction by a covector on the spinor space. -/
def contraction : Module.Dual ℝ Half →ₗ[ℝ] Module.End ℝ Spinor :=
  CliffordAlgebra.contractLeft (Q := (0 : QuadraticForm ℝ Half))

private def vectorOperator : (Index → ℝ) →ₗ[ℝ] Module.End ℝ Spinor :=
  creation.comp (positive + negative) +
    contraction.comp ((dotProductBilin ℝ ℝ).comp (positive - negative))

private theorem dot_creation_contraction (x : Index → ℝ) :
    dotProductBilin ℝ ℝ ((positive - negative) x) ((positive + negative) x) = splitForm x := by
  change (∑ i : Fin 7, (x (Fin.castAdd 7 i) - x (Fin.natAdd 7 i)) *
    (x (Fin.castAdd 7 i) + x (Fin.natAdd 7 i))) = _
  rw [splitForm, QuadraticMap.weightedSumSquares_apply,
    Fin.sum_univ_add (a := 7) (b := 7) (fun i => metricSign i • (x i * x i))]
  simp only [metricSign, Fin.val_castAdd, Fin.val_natAdd, Fin.isLt, if_true,
    show ∀ i : Fin 7, ¬ 7 + i.val < 7 from fun i => by omega, if_false, smul_eq_mul,
    one_mul, neg_one_mul, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  ring

private theorem creation_contraction_square (v : Half) (d : Module.Dual ℝ Half) (z : Spinor) :
    (creation v + contraction d) ((creation v + contraction d) z) = d v • z := by
  change ExteriorAlgebra.ι ℝ v * (ExteriorAlgebra.ι ℝ v * z + contraction d z) +
    contraction d (ExteriorAlgebra.ι ℝ v * z + contraction d z) = _
  have h : contraction d (ExteriorAlgebra.ι ℝ v * z) =
      d v • z - ExteriorAlgebra.ι ℝ v * contraction d z :=
    CliffordAlgebra.contractLeft_ι_mul (Q := (0 : QuadraticForm ℝ Half)) d v z
  have hzero : contraction d (contraction d z) = 0 :=
    CliffordAlgebra.contractLeft_contractLeft (Q := (0 : QuadraticForm ℝ Half)) d z
  rw [mul_add, ← mul_assoc (ExteriorAlgebra.ι ℝ v) (ExteriorAlgebra.ι ℝ v),
    ExteriorAlgebra.ι_sq_zero, zero_mul, zero_add, map_add, h, hzero, add_zero]
  abel

private theorem vectorOperator_square (x : Index → ℝ) :
    vectorOperator x * vectorOperator x = algebraMap ℝ (Module.End ℝ Spinor) (splitForm x) := by
  apply LinearMap.ext
  intro z
  change (creation ((positive + negative) x) + contraction
      (dotProductBilin ℝ ℝ ((positive - negative) x)))
      ((creation ((positive + negative) x) + contraction
        (dotProductBilin ℝ ℝ ((positive - negative) x))) z) = splitForm x • z
  rw [creation_contraction_square, dot_creation_contraction]

/-- Creation and contraction give the split real Clifford action. -/
def endRepresentation : Cl →ₐ[ℝ] Module.End ℝ Spinor :=
  CliffordAlgebra.lift splitForm ⟨vectorOperator, vectorOperator_square⟩

private theorem positive_basis (i : Fin 7) :
    positive (WitnessW1.basisVector (Fin.castAdd 7 i)) = Pi.basisFun ℝ (Fin 7) i := by
  funext j
  change WitnessW1.basisVector (Fin.castAdd 7 i) (Fin.castAdd 7 j) =
    Pi.basisFun ℝ (Fin 7) i j
  have h : Fin.castAdd 7 j = Fin.castAdd 7 i ↔ j = i := by simp [Fin.ext_iff]
  simp only [WitnessW1.basisVector, Pi.basisFun_apply, Pi.single_apply, h]

private theorem negative_basis (i : Fin 7) :
    negative (WitnessW1.basisVector (Fin.natAdd 7 i)) = Pi.basisFun ℝ (Fin 7) i := by
  funext j
  change WitnessW1.basisVector (Fin.natAdd 7 i) (Fin.natAdd 7 j) =
    Pi.basisFun ℝ (Fin 7) i j
  have h : Fin.natAdd 7 j = Fin.natAdd 7 i ↔ j = i := by simp [Fin.ext_iff]
  simp only [WitnessW1.basisVector, Pi.basisFun_apply, Pi.single_apply, h]

private theorem positive_wrongHalf (i : Fin 7) :
    positive (WitnessW1.basisVector (Fin.natAdd 7 i)) = 0 := by
  funext j
  have h : Fin.castAdd 7 j ≠ Fin.natAdd 7 i := by
    simp [Fin.ext_iff]
    omega
  change WitnessW1.basisVector (Fin.natAdd 7 i) (Fin.castAdd 7 j) = 0
  rw [WitnessW1.basisVector, Pi.single_apply, if_neg h]

private theorem negative_wrongHalf (i : Fin 7) :
    negative (WitnessW1.basisVector (Fin.castAdd 7 i)) = 0 := by
  funext j
  have h : Fin.natAdd 7 j ≠ Fin.castAdd 7 i := by
    simp [Fin.ext_iff]
    omega
  change WitnessW1.basisVector (Fin.castAdd 7 i) (Fin.natAdd 7 j) = 0
  rw [WitnessW1.basisVector, Pi.single_apply, if_neg h]

private theorem dotProduct_basis (i : Fin 7) :
    dotProductBilin ℝ ℝ (Pi.basisFun ℝ (Fin 7) i) = (Pi.basisFun ℝ (Fin 7)).coord i := by
  apply LinearMap.ext
  intro x
  simp [dotProductBilin, dotProduct, Pi.basisFun_apply, Pi.single_apply,
    Module.Basis.coord_apply, Pi.basisFun_repr, ite_mul]

theorem endRepresentation_gamma_pos (i : Fin 7) :
    endRepresentation (gamma (Fin.castAdd 7 i)) =
      creation (Pi.basisFun ℝ (Fin 7) i) + contraction ((Pi.basisFun ℝ (Fin 7)).coord i) := by
  rw [gamma, endRepresentation, CliffordAlgebra.lift_ι_apply]
  simp only [vectorOperator, LinearMap.comp_apply, LinearMap.add_apply, LinearMap.sub_apply,
    positive_basis, negative_wrongHalf, add_zero, sub_zero, dotProduct_basis]

theorem endRepresentation_gamma_neg (i : Fin 7) :
    endRepresentation (gamma (Fin.natAdd 7 i)) =
      creation (Pi.basisFun ℝ (Fin 7) i) - contraction ((Pi.basisFun ℝ (Fin 7)).coord i) := by
  rw [gamma, endRepresentation, CliffordAlgebra.lift_ι_apply]
  simp only [vectorOperator, LinearMap.comp_apply, LinearMap.add_apply, LinearMap.sub_apply,
    positive_wrongHalf, negative_basis, zero_add, zero_sub, map_neg, dotProduct_basis]
  rw [sub_eq_add_neg]

/-- The Clifford action in the exterior basis of the spinor space. -/
def matrixRepresentation : Cl →ₐ[ℝ] Mat :=
  (LinearMap.toMatrixAlgEquiv spinorBasis).toAlgHom.comp endRepresentation

theorem clifford_finrank : Module.finrank ℝ Cl = 16384 := by
  let b := (Pi.basisFun ℝ Index).ExteriorAlgebra
  rw [(CliffordAlgebra.equivExterior splitForm).finrank_eq, Module.finrank_eq_card_basis b,
    Fintype.card_finset, Fintype.card_fin]
  rfl

private theorem matrix_finrank : Module.finrank ℝ Mat = 16384 := by
  rw [Module.finrank_matrix, Module.finrank_self, Fintype.card_finset, Fintype.card_fin]
  rfl

private theorem generator_inverse (i : Index) :
    gamma i * (metricSign i • gamma i) = 1 := by
  rw [mul_smul_comm, WitnessW1.gamma_square, Algebra.smul_def, ← map_mul]
  have hs : metricSign i * metricSign i = 1 := by unfold metricSign; split <;> norm_num
  rw [hs, map_one]

private def generatorUnit (i : Index) : Clˣ where
  val := gamma i
  inv := metricSign i • gamma i
  val_inv := generator_inverse i
  inv_val := by rw [smul_mul_assoc, ← mul_smul_comm, generator_inverse]

private def matrixGenerator (i : Index) : Matˣ :=
  Units.map matrixRepresentation.toMonoidHom (generatorUnit i)

private def bladeUnit (S : Finset Index) : Matˣ := (S.toList.map matrixGenerator).prod

private def conjugation (u : Matˣ) : Mat ≃ₐ[ℝ] Mat :=
  MulSemiringAction.toAlgEquiv ℝ Mat (ConjAct.toConjAct u)

private theorem conjugation_apply (u : Matˣ) (X : Mat) :
    conjugation u X = (u : Mat) * X * (↑u⁻¹ : Mat) := by
  change ConjAct.toConjAct u • X = _
  rw [ConjAct.units_smul_def, ConjAct.ofConjAct_toConjAct]

private def generatorSign (i j : Index) : ℝ := if i = j then 1 else -1

private theorem conjugation_generator (i j : Index) :
    conjugation (matrixGenerator i) (matrixGenerator j : Mat) =
      generatorSign i j • (matrixGenerator j : Mat) := by
  by_cases h : i = j
  · subst j
    rw [conjugation_apply, generatorSign, if_pos rfl, one_smul, mul_assoc,
      (matrixGenerator i).mul_inv, mul_one]
  · have hswap : (matrixGenerator i : Mat) * (matrixGenerator j : Mat) =
        -((matrixGenerator j : Mat) * (matrixGenerator i : Mat)) := by
      change matrixRepresentation (gamma i) * matrixRepresentation (gamma j) =
        -(matrixRepresentation (gamma j) * matrixRepresentation (gamma i))
      rw [← map_mul, WitnessW1.gamma_anticommute i j h, map_neg, map_mul]
    rw [conjugation_apply, generatorSign, if_neg h, hswap, neg_mul, mul_assoc,
      (matrixGenerator i).mul_inv, mul_one, neg_one_smul]

private def character (i : Index) (S : Finset Index) : ℝ :=
  ∏ j ∈ S, generatorSign i j

private theorem conjugation_blade (i : Index) (S : Finset Index) :
    conjugation (matrixGenerator i) (bladeUnit S : Mat) = character i S • (bladeUnit S : Mat) := by
  have h (L : List Index) : conjugation (matrixGenerator i) (↑(L.map matrixGenerator).prod : Mat) =
      (L.map (generatorSign i)).prod • (↑(L.map matrixGenerator).prod : Mat) := by
    induction L with
    | nil => simp
    | cons j L ih =>
      simp only [List.map_cons, List.prod_cons, Units.val_mul, map_mul, conjugation_generator,
        ih, Matrix.smul_mul, Matrix.mul_smul, smul_smul]
      rw [mul_comm]
  exact (h S.toList).trans (by rw [Finset.prod_map_toList]; rfl)

private def membershipSign (i : Index) (S : Finset Index) : ℝ :=
  if i ∈ S then -1 else 1

private theorem character_formula (i : Index) (S : Finset Index) :
    character i S = (-1 : ℝ) ^ S.card * membershipSign i S := by
  induction S using Finset.induction_on with
  | empty => simp [character, membershipSign]
  | insert j S hj ih =>
    rw [show character i (insert j S) = generatorSign i j * character i S from
      Finset.prod_insert hj, ih, Finset.card_insert_of_notMem hj, pow_succ]
    by_cases hij : i = j
    · subst j
      simp [generatorSign, membershipSign, hj]
    · simp [generatorSign, membershipSign, hij]

private theorem generatorSign_total (j : Index) : (∏ i : Index, generatorSign i j) = -1 := by
  calc
    _ = (∏ i ∈ Finset.univ.erase j, generatorSign i j) * generatorSign j j :=
      (Finset.prod_erase_mul Finset.univ (fun i => generatorSign i j) (Finset.mem_univ j)).symm
    _ = (∏ i ∈ Finset.univ.erase j, (-1 : ℝ)) * 1 := by
      congr 1
      · exact Finset.prod_congr rfl fun i hi => if_neg (Finset.ne_of_mem_erase hi)
      · exact if_pos rfl
    _ = -1 := by
      rw [mul_one, Finset.prod_const, Finset.card_erase_of_mem (Finset.mem_univ j),
        Finset.card_univ, Fintype.card_fin]
      norm_num

private theorem character_total (S : Finset Index) :
    (∏ i : Index, character i S) = (-1 : ℝ) ^ S.card := by
  unfold character
  rw [Finset.prod_comm, Finset.prod_congr rfl (fun j _ => generatorSign_total j), Finset.prod_const]

private theorem character_injective : Function.Injective (fun S : Finset Index => fun i =>
    character i S) := by
  intro S T h
  have hpar : (-1 : ℝ) ^ S.card = (-1 : ℝ) ^ T.card :=
    (character_total S).symm.trans
      ((congrArg (fun f : Index → ℝ => ∏ i, f i) h).trans (character_total T))
  ext i
  have hi := congrFun h i
  change character i S = character i T at hi
  rw [character_formula, character_formula, hpar] at hi
  have hs : membershipSign i S = membershipSign i T :=
    mul_left_cancel₀ (pow_ne_zero _ (by norm_num)) hi
  by_cases hsS : i ∈ S <;> by_cases hsT : i ∈ T <;> simp [hsS, hsT]
  all_goals norm_num [membershipSign, hsS, hsT] at hs

private theorem trace_conjugation (u : Matˣ) (X : Mat) :
    Matrix.trace (conjugation u X) = Matrix.trace X := by
  rw [conjugation_apply, Matrix.trace_mul_comm _ (↑u⁻¹ : Mat), ← mul_assoc, u.inv_mul, one_mul]

private def tracePair (S : Finset Index) : Mat →ₗ[ℝ] ℝ :=
  (Matrix.traceLinearMap SpinorIndex ℝ ℝ).comp (LinearMap.mulLeft ℝ (↑(bladeUnit S)⁻¹ : Mat))

private theorem tracePair_self (S : Finset Index) : tracePair S (bladeUnit S : Mat) = 128 := by
  change Matrix.trace ((↑(bladeUnit S)⁻¹ : Mat) * (bladeUnit S : Mat)) = _
  rw [(bladeUnit S).inv_mul, Matrix.trace_one, Fintype.card_finset, Fintype.card_fin]
  norm_num

private theorem tracePair_other {S T : Finset Index} (h : S ≠ T) :
    tracePair S (bladeUnit T : Mat) = 0 := by
  obtain ⟨i, hi⟩ := Function.ne_iff.mp (character_injective.ne h)
  let f := conjugation (matrixGenerator i)
  let u := bladeUnit S
  let v := bladeUnit T
  let A : Mat := ↑u⁻¹ * (v : Mat)
  have hu : f (u : Mat) = character i S • (u : Mat) := conjugation_blade i S
  have hv : f (v : Mat) = character i T • (v : Mat) := conjugation_blade i T
  have hinv : character i S • f (↑u⁻¹ : Mat) = (↑u⁻¹ : Mat) := by
    calc
      _ = (↑u⁻¹ : Mat) * (f (u : Mat) * f (↑u⁻¹ : Mat)) := by
        rw [hu, Matrix.smul_mul, Matrix.mul_smul, ← mul_assoc, u.inv_mul, one_mul]
      _ = _ := by rw [← map_mul, u.mul_inv, map_one, mul_one]
  have hscale : character i S • f A = character i T • A := by
    change character i S • f ((↑u⁻¹ : Mat) * ↑v) = _
    rw [map_mul, hv, Matrix.mul_smul, smul_comm, ← Matrix.smul_mul, hinv]
  have ht := congrArg Matrix.trace hscale
  simp only [Matrix.trace_smul, f, trace_conjugation, smul_eq_mul] at ht
  change Matrix.trace A = 0
  exact (mul_eq_zero.mp (show (character i S - character i T) * Matrix.trace A = 0 by
    rw [sub_mul, ht, sub_self])).resolve_left (sub_ne_zero.mpr hi)

private theorem matrixBlades_independent :
    LinearIndependent ℝ (fun S : Finset Index => (bladeUnit S : Mat)) := by
  apply Fintype.linearIndependent_iff.mpr
  intro c hc S
  have hz := congrArg (tracePair S) hc
  simp only [map_sum, map_smul, map_zero] at hz
  rw [Finset.sum_eq_single S] at hz
  · rw [tracePair_self, smul_eq_mul] at hz
    exact (mul_eq_zero.mp hz).resolve_right (by norm_num)
  · intro T _ hTS
    rw [tracePair_other hTS.symm, smul_zero]
  · simp

private theorem blade_in_image (S : Finset Index) :
    ∃ x : Cl, matrixRepresentation x = (bladeUnit S : Mat) := by
  refine ⟨(S.toList.map gamma).prod, ?_⟩
  unfold bladeUnit
  generalize S.toList = L
  induction L with
  | nil => simp
  | cons i L ih =>
    simp only [List.map_cons, List.prod_cons, map_mul, Units.val_mul, ih]
    rfl

private theorem matrixRepresentation_surjective : Function.Surjective matrixRepresentation := by
  have hcard : Fintype.card (Finset Index) = Module.finrank ℝ Mat := by
    rw [matrix_finrank, Fintype.card_finset, Fintype.card_fin]
    rfl
  let b := basisOfLinearIndependentOfCardEqFinrank' _ matrixBlades_independent hcard
  have hb : ⇑b = fun S : Finset Index => (bladeUnit S : Mat) :=
    coe_basisOfLinearIndependentOfCardEqFinrank' _ _ _
  change Function.Surjective matrixRepresentation.toLinearMap
  apply LinearMap.range_eq_top.mp
  apply top_unique
  rw [← b.span_eq, hb]
  exact Submodule.span_le.mpr (by rintro _ ⟨S, rfl⟩; exact blade_in_image S)

/-- The real Clifford algebra of signature `(7,7)` is the full real
matrix algebra on the 128 exterior basis states. -/
def matrixEquiv : Cl ≃ₐ[ℝ] Mat := by
  let b := ((Pi.basisFun ℝ Index).ExteriorAlgebra).map (CliffordAlgebra.equivExterior splitForm).symm
  have : Module.Finite ℝ Cl := Module.Finite.of_basis b
  have hdim := clifford_finrank.trans matrix_finrank.symm
  exact AlgEquiv.ofBijective matrixRepresentation
    ⟨(LinearMap.injective_iff_surjective_of_finrank_eq_finrank hdim
      (f := matrixRepresentation.toLinearMap)).mpr matrixRepresentation_surjective,
      matrixRepresentation_surjective⟩

@[simp] theorem matrixEquiv_apply (x : Cl) : matrixEquiv x = matrixRepresentation x := rfl

abbrev ComplexMat := Matrix SpinorIndex SpinorIndex ℂ

/-- Embed the real spinor matrices entrywise into complex matrices. -/
def complexEmbedding : Mat →ₐ[ℝ] ComplexMat :=
  (Algebra.ofId ℝ ℂ).mapMatrix

private def complexMatrixRepresentation : ℂ ⊗[ℝ] Cl →ₐ[ℂ] ComplexMat :=
  Algebra.TensorProduct.lift (Algebra.ofId ℂ ComplexMat)
    (complexEmbedding.comp matrixRepresentation) (fun z X =>
      Algebra.commutes z (complexEmbedding (matrixRepresentation X)))

private theorem complexMatrixRepresentation_tmul (z : ℂ) (x : Cl) :
    complexMatrixRepresentation (z ⊗ₜ[ℝ] x) = z • complexEmbedding (matrixRepresentation x) := by
  change (algebraMap ℂ ComplexMat) z * complexEmbedding (matrixRepresentation x) = _
  rw [Algebra.smul_def]

private theorem complexMatrixRepresentation_surjective :
    Function.Surjective complexMatrixRepresentation := by
  intro X
  obtain ⟨x, hx⟩ := matrixRepresentation_surjective (X.map Complex.re)
  obtain ⟨y, hy⟩ := matrixRepresentation_surjective (X.map Complex.im)
  refine ⟨(1 : ℂ) ⊗ₜ[ℝ] x + Complex.I ⊗ₜ[ℝ] y, ?_⟩
  rw [map_add, complexMatrixRepresentation_tmul, complexMatrixRepresentation_tmul, hx, hy, one_smul]
  ext i j
  change (↑(X i j).re : ℂ) + Complex.I * ↑(X i j).im = X i j
  rw [mul_comm Complex.I]
  exact Complex.re_add_im _

/-- The complexified split Clifford algebra in the same spinor basis. -/
def complexMatrixEquiv : ℂ ⊗[ℝ] Cl ≃ₐ[ℂ] ComplexMat := by
  let b := ((Pi.basisFun ℝ Index).ExteriorAlgebra).map (CliffordAlgebra.equivExterior splitForm).symm
  have : Module.Finite ℂ (ℂ ⊗[ℝ] Cl) := Module.Finite.of_basis (b.baseChange ℂ)
  have hdim : Module.finrank ℂ (ℂ ⊗[ℝ] Cl) = Module.finrank ℂ ComplexMat := by
    rw [Module.finrank_baseChange, clifford_finrank, Module.finrank_matrix, Module.finrank_self,
      Fintype.card_finset, Fintype.card_fin]
    rfl
  exact AlgEquiv.ofBijective complexMatrixRepresentation
    ⟨(LinearMap.injective_iff_surjective_of_finrank_eq_finrank hdim
      (f := complexMatrixRepresentation.toLinearMap)).mpr complexMatrixRepresentation_surjective,
      complexMatrixRepresentation_surjective⟩

theorem complexMatrixEquiv_tmul (z : ℂ) (x : Cl) :
    complexMatrixEquiv (z ⊗ₜ[ℝ] x) = z • complexEmbedding (matrixEquiv x) :=
  complexMatrixRepresentation_tmul z x

/-- The Spin group acts on the spinor space by the units of the Clifford
matrix model. -/
def spinorUnits : D7SpinAction.Spin →* ComplexMatˣ :=
  (Units.map (complexEmbedding.comp matrixRepresentation).toMonoidHom).comp spinGroup.toUnits

theorem spinorUnits_val (g : D7SpinAction.Spin) :
    (spinorUnits g : ComplexMat) = complexEmbedding (matrixEquiv g.val) := rfl

private theorem spinorUnits_conjugation (g : D7SpinAction.Spin) (x : Cl) :
    complexEmbedding (matrixEquiv (D7SpinAction.cliffordConjugation g x)) =
      (spinorUnits g : ComplexMat) * complexEmbedding (matrixEquiv x) *
        (↑(spinorUnits g)⁻¹ : ComplexMat) := by
  change complexEmbedding (matrixRepresentation
    (ConjAct.toConjAct (spinGroup.toUnits g) • x)) = _
  rw [ConjAct.units_smul_def, ConjAct.ofConjAct_toConjAct]
  simp only [map_mul]
  rfl

/-- The actual Clifford Spin conjugation becomes matrix conjugation
after complexifying the Clifford algebra. -/
theorem complexMatrixEquiv_intertwines (g : D7SpinAction.Spin) :
    complexMatrixEquiv.toLinearMap.comp
        ((D7SpinAction.cliffordConjugation g).toLinearMap.baseChange ℂ) =
      (LinearMap.mulLeftRight ℂ ((spinorUnits g : ComplexMat), (↑(spinorUnits g)⁻¹ : ComplexMat))).comp
        complexMatrixEquiv.toLinearMap := by
  apply TensorProduct.AlgebraTensorModule.ext
  intro z x
  simp only [LinearMap.comp_apply, LinearMap.baseChange_tmul, AlgEquiv.toLinearMap_apply,
    complexMatrixEquiv_tmul, LinearMap.mulLeftRight_apply, Matrix.mul_smul, Matrix.smul_mul,
    spinorUnits_conjugation]

end

end GeometricUnity.D7CliffordMatrix
