import D7SpinAction
import Mathlib.Tactic.NoncommRing

/-!
# Real Spin lifts of isotropic transvections

For orthogonal isotropic vectors `a,b`, the lift of the root action has
Clifford value `1 + t • (ι a * ι b)`. An auxiliary orthogonal vector
`c` of square one expresses that element as a product of four vectors
of square one.
-/

namespace GeometricUnity.D7SpinRootLifts

open D7SpinAction (Vector Spin)
open WitnessW1 (splitForm Cl)

noncomputable section

private abbrev ι := CliffordAlgebra.ι splitForm

private theorem vector_square_one {v : Vector} (h : splitForm v = 1) : ι v * ι v = 1 := by
  rw [CliffordAlgebra.ι_sq_scalar, h, map_one]

private def vectorUnit (v : Vector) (h : splitForm v = 1) : Clˣ :=
  ⟨ι v, ι v, vector_square_one h, vector_square_one h⟩

private theorem vectorUnit_mem (v : Vector) (h : splitForm v = 1) :
    vectorUnit v h ∈ lipschitzGroup splitForm :=
  Subgroup.subset_closure ⟨v, rfl⟩

private def vectorPair (v w : Vector) (hv : splitForm v = 1) (hw : splitForm w = 1) : Spin :=
  ⟨ι v * ι w, spinGroup.mem_iff.mpr ⟨by
    apply (pinGroup.units_mem_iff (x := vectorUnit v hv * vectorUnit w hw)).mpr
    refine ⟨(lipschitzGroup splitForm).mul_mem (vectorUnit_mem v hv) (vectorUnit_mem w hw),
      Unitary.mem_iff.mpr ?_⟩
    change star (ι v * ι w) * (ι v * ι w) = 1 ∧ (ι v * ι w) * star (ι v * ι w) = 1
    simp only [star_mul, CliffordAlgebra.star_ι, neg_mul_neg]
    constructor
    · rw [mul_assoc (ι w), ← mul_assoc (ι v) (ι v), vector_square_one hv, one_mul,
        vector_square_one hw]
    · rw [mul_assoc (ι v), ← mul_assoc (ι w) (ι w), vector_square_one hw, one_mul,
        vector_square_one hv]
    , CliffordAlgebra.ι_mul_ι_mem_evenOdd_zero splitForm v w⟩⟩

private theorem isotropic_square {a : Vector} (ha : splitForm a = 0) : ι a * ι a = 0 := by
  rw [CliffordAlgebra.ι_sq_scalar, ha, map_zero]

private theorem isotropic_mul_mul {a u : Vector} (ha : splitForm a = 0)
    (h : splitForm.IsOrtho a u) : ι a * ι u * ι a = 0 := by
  rw [mul_assoc, CliffordAlgebra.ι_mul_ι_comm_of_isOrtho h.symm, mul_neg, ← mul_assoc,
    isotropic_square ha, zero_mul, neg_zero]

private theorem add_isotropic_square {a u : Vector} (t : ℝ)
    (ha : splitForm a = 0) (hu : splitForm u = 1) (h : splitForm.IsOrtho a u) :
    splitForm (u + t • a) = 1 := by
  have horth : splitForm.IsOrtho u (t • a) := by
    apply QuadraticMap.isOrtho_polarBilin.mp
    rw [QuadraticMap.polarBilin_apply_apply, QuadraticMap.polar_smul_right, h.symm.polar_eq_zero,
      smul_zero]
  rw [QuadraticMap.isOrtho_def] at horth
  rw [horth, QuadraticMap.map_smul, ha, hu, smul_zero, add_zero]

private theorem isOrtho_add {a b c : Vector} (hab : splitForm.IsOrtho a b)
    (hac : splitForm.IsOrtho a c) : splitForm.IsOrtho a (b + c) := by
  apply QuadraticMap.isOrtho_polarBilin.mp
  rw [QuadraticMap.polarBilin_apply_apply, QuadraticMap.polar_add_right, hab.polar_eq_zero,
    hac.polar_eq_zero, add_zero]

/-- An element of the actual real Spin group whose value is the
transvection Clifford word. -/
def isotropicLift (a b c : Vector) (t : ℝ) (ha : splitForm a = 0)
    (hb : splitForm b = 0) (hc : splitForm c = 1)
    (hab : splitForm.IsOrtho a b) (hac : splitForm.IsOrtho a c)
    (hbc : splitForm.IsOrtho b c) : Spin :=
  let hsum : splitForm (b + c) = 1 := by
    rw [QuadraticMap.isOrtho_def] at hbc
    rw [hbc, hb, hc, zero_add]
  vectorPair ((b + c) + t • a) (b + c)
      (add_isotropic_square t ha hsum (isOrtho_add hab hac)) hsum *
    vectorPair (c + (-t) • a) c (add_isotropic_square (-t) ha hc hac) hc

theorem isotropicLift_val (a b c : Vector) (t : ℝ) (ha : splitForm a = 0)
    (hb : splitForm b = 0) (hc : splitForm c = 1)
    (hab : splitForm.IsOrtho a b) (hac : splitForm.IsOrtho a c)
    (hbc : splitForm.IsOrtho b c) :
    (isotropicLift a b c t ha hb hc hab hac hbc).val = 1 + t • (ι a * ι b) := by
  have hsum : splitForm (b + c) = 1 := by
    rw [QuadraticMap.isOrtho_def] at hbc
    rw [hbc, hb, hc, zero_add]
  change (ι ((b + c) + t • a) * ι (b + c)) * (ι (c + (-t) • a) * ι c) = _
  have hp : ι ((b + c) + t • a) * ι (b + c) = 1 + t • (ι a * ι (b + c)) := by
    rw [map_add, add_mul, map_smul, smul_mul_assoc, vector_square_one hsum]
  have hm : ι (c + (-t) • a) * ι c = 1 + (-t) • (ι a * ι c) := by
    rw [map_add, add_mul, map_smul, smul_mul_assoc, vector_square_one hc]
  have hzero : (ι a * ι (b + c)) * (ι a * ι c) = 0 := by
    rw [← mul_assoc, isotropic_mul_mul ha (isOrtho_add hab hac), zero_mul]
  rw [hp, hm]
  simp only [mul_add, add_mul, one_mul, mul_one, smul_mul_assoc, mul_smul_comm,
    hzero, smul_zero, add_zero]
  rw [map_add, mul_add, smul_add, neg_smul]
  abel

private theorem bivector_commutator (a b x : Vector) :
    (ι a * ι b) * ι x - ι x * (ι a * ι b) =
      QuadraticMap.polar splitForm b x • ι a - QuadraticMap.polar splitForm a x • ι b := by
  calc
    _ = ι a * (ι b * ι x + ι x * ι b) - (ι a * ι x + ι x * ι a) * ι b := by
      noncomm_ring
    _ = _ := by
      rw [CliffordAlgebra.ι_mul_ι_add_swap (Q := splitForm) b x,
        CliffordAlgebra.ι_mul_ι_add_swap (Q := splitForm) a x,
        Algebra.algebraMap_eq_smul_one, Algebra.algebraMap_eq_smul_one,
        mul_smul_comm, smul_mul_assoc, mul_one, one_mul]

/-- The induced vector action is the isotropic orthogonal transvection. -/
theorem isotropicLift_action (a b c x : Vector) (t : ℝ) (ha : splitForm a = 0)
    (hb : splitForm b = 0) (hc : splitForm c = 1)
    (hab : splitForm.IsOrtho a b) (hac : splitForm.IsOrtho a c)
    (hbc : splitForm.IsOrtho b c) :
    D7SpinAction.vectorRepresentation (isotropicLift a b c t ha hb hc hab hac hbc) x =
      x + t • (QuadraticMap.polar splitForm b x • a - QuadraticMap.polar splitForm a x • b) := by
  let g := isotropicLift a b c t ha hb hc hab hac hbc
  let D := ι a * ι b
  let X := ι x
  have hDA : D * ι a = 0 := isotropic_mul_mul ha hab
  have hDB : D * ι b = 0 := by
    change (ι a * ι b) * ι b = 0
    rw [mul_assoc, isotropic_square hb, mul_zero]
  have hDD : D * D = 0 := by
    change D * (ι a * ι b) = 0
    rw [← mul_assoc, hDA, zero_mul]
  have hcomm : D * X - X * D =
      QuadraticMap.polar splitForm b x • ι a - QuadraticMap.polar splitForm a x • ι b :=
    bivector_commutator a b x
  have hquad : (D * X) * D = 0 := by
    calc
      _ = D * (D * X) - D * (D * X - X * D) := by noncomm_ring
      _ = 0 := by
        rw [← mul_assoc D D X, hDD, zero_mul, hcomm, mul_sub, mul_smul_comm, mul_smul_comm,
          hDA, hDB, smul_zero, smul_zero, sub_zero, sub_zero]
  have hg : (g.val : Cl) = 1 + t • D := isotropicLift_val a b c t ha hb hc hab hac hbc
  have hstar : star (g.val : Cl) = 1 + (-t) • D := by
    rw [hg, star_add, star_one, CliffordAlgebra.star_smul]
    change 1 + t • star (ι a * ι b) = _
    rw [star_mul, CliffordAlgebra.star_ι, CliffordAlgebra.star_ι, neg_mul_neg,
      CliffordAlgebra.ι_mul_ι_comm_of_isOrtho hab.symm, smul_neg, neg_smul]
  have hact := D7SpinAction.iota_vectorRepresentation g x
  change ι (D7SpinAction.vectorRepresentation g x) = (g.val : Cl) * X * star (g.val : Cl) at hact
  apply D7SpinAction.iota_injective
  rw [hact, hstar, hg]
  calc
    (1 + t • D) * X * (1 + (-t) • D) =
        X + t • (D * X) + (-t) • (X * D) + (-t) • (t • ((D * X) * D)) := by
      simp only [mul_add, add_mul, one_mul, mul_one, smul_mul_assoc, mul_smul_comm, smul_add]
      abel
    _ = X + t • (D * X - X * D) := by
      rw [hquad, smul_zero, smul_zero, add_zero, smul_sub, neg_smul]
      abel
    _ = _ := by rw [hcomm, map_add, map_smul, map_sub, map_smul, map_smul]

end

end GeometricUnity.D7SpinRootLifts
