import D7TensorRotations

/-!
# Irreducibility of the non-middle vector–exterior kernels

Even sign changes select a block up to complement. Within a chosen block,
zero contraction or zero wedge forces the sum of the coefficients to vanish.
A quarter-turn extracts a difference from two unequal coefficients and fixes
any complementary block. Signed permutations and plane rotations transport
the difference to the two spanning families.
-/

namespace GeometricUnity.D7GradeIrreducible

open D7Exterior D7Hodge D7Irreducible D7VectorGrades D7Hook D7TensorColumns D7TensorRotations
open scoped BigOperators

noncomputable section

private def Stable {n : ℕ} (W : Submodule ℂ (Product (n + 1))) : Prop :=
  ∀ g : splitSpecialOrthogonal, ∀ x ∈ W, action (n + 1) g x ∈ W

private theorem block_sums_zero {n : ℕ} (x : Product (n + 1)) (hx : x ∈ jointKernel n) :
    let c := (normalizedBasis n).repr x
    (∀ R : Index n, ∑ i : {i : Axis // i ∉ R.val}, c (.inl ⟨R, i⟩) = 0) ∧
    (∀ S : Index (n + 2), ∑ i : ↥S.val, c (.inr ⟨S, i⟩) = 0) := by
  classical
  let c := (normalizedBasis n).repr x
  have hex := (normalizedBasis n).sum_repr x
  have ⟨hw, hc⟩ := (mem_jointKernel n x).mp hx
  rw [Fintype.sum_sum_type, Fintype.sum_sigma, Fintype.sum_sigma] at hex
  have hR := congrArg (contract n) hex
  have hS := congrArg (wedge (n + 1)) hex
  have hcon (R : Index n) (i : {i : Axis // i ∉ R.val}) :
      contract n (repeated R i.val) = basis n R := trace_repeated R i.val i.prop
  have hwedge (S : Index (n + 2)) (i : ↥S.val) :
      wedge (n + 1) (distinct S i.val) = basis (n + 2) S := wedge_distinct S i.val i.prop
  simp only [hc, normalizedBasis_repeated, normalizedBasis_distinct, map_add, map_sum, map_smul,
    hcon, trace_distinct, smul_zero, Finset.sum_const_zero, add_zero, ← Finset.sum_smul] at hR
  simp only [hw, normalizedBasis_repeated, normalizedBasis_distinct, map_add, map_sum, map_smul,
    hwedge, wedge_repeated, smul_zero, Finset.sum_const_zero, zero_add, ← Finset.sum_smul] at hS
  exact ⟨Fintype.linearIndependent_iff.mp (basis n).linearIndependent _ hR,
    Fintype.linearIndependent_iff.mp (basis (n + 2)).linearIndependent _ hS⟩

private theorem second_coefficient {ι : Type*} [Fintype ι] (c : ι → ℂ) (i : ι)
    (hs : ∑ k, c k = 0) (hi : c i ≠ 0) : ∃ j, c i ≠ c j := by
  by_contra! h
  simp_rw [← h] at hs
  rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at hs
  have : Nonempty ι := ⟨i⟩
  exact hi ((mul_eq_zero.mp hs).resolve_left (Nat.cast_ne_zero.mpr Fintype.card_ne_zero))

private theorem extract_by_swap {n : ℕ} (W : Submodule ℂ (Product (n + 1))) (hW : Stable W)
    (x : Product (n + 1)) (hx : x ∈ W) (a b : NormalizedIndex n)
    (hne : (normalizedBasis n).repr x a ≠ (normalizedBasis n).repr x b)
    (g : splitSpecialOrthogonal)
    (hg : ∀ t, (normalizedBasis n).repr x t ≠ 0 →
      action (n + 1) g (normalizedBasis n t) = normalizedBasis n (Equiv.swap a b t)) :
    normalizedBasis n a - normalizedBasis n b ∈ W := by
  classical
  let c := (normalizedBasis n).repr x
  have hne' : a ≠ b := fun h => hne (congrArg c h)
  have hact : action (n + 1) g x = ∑ t, c t • normalizedBasis n (Equiv.swap a b t) := by
    conv_lhs => rw [← (normalizedBasis n).sum_repr x, map_sum]
    apply Finset.sum_congr rfl
    intro t _
    rw [map_smul]
    by_cases ht : c t = 0
    · rw [ht, zero_smul, zero_smul]
    · rw [hg t ht]
  have h := W.sub_mem hx (hW g x hx)
  have he := congrArg (fun y => y - ∑ t, c t • normalizedBasis n (Equiv.swap a b t))
    ((normalizedBasis n).sum_repr x)
  rw [swap_sum_difference c (normalizedBasis n) a b hne'] at he
  rw [hact, ← he] at h
  exact basis_mem_of_scaled W _ _ (sub_ne_zero.mpr hne) h

private theorem not_compl_mixed {n : ℕ} (hn : n ≠ 6) (R : Index n) (S : Index (n + 2)) :
    R.val ≠ S.val ∧ R.val ≠ S.valᶜ := by
  constructor <;> intro h
  · have hc := congrArg Finset.card h
    rw [R.prop, S.prop] at hc
    omega
  · have hc := congrArg Finset.card h
    rw [R.prop, Finset.card_compl, Fintype.card_fin, S.prop] at hc
    have hc' := Finset.card_le_univ S.val
    rw [Fintype.card_fin, S.prop] at hc'
    omega

private theorem repeated_swap_action {n : ℕ} (hn : n ≠ 6) (R : Index n)
    (i j : {k : Axis // k ∉ R.val}) (hij : i.val ≠ j.val) (t : NormalizedIndex n)
    (ht : block t = R.val ∨ block t = R.valᶜ) :
    action (n + 1) (quarterTurn i.val j.val) (normalizedBasis n t) =
      normalizedBasis n (Equiv.swap (.inl ⟨R, i⟩) (.inl ⟨R, j⟩) t) := by
  let a : NormalizedIndex n := .inl ⟨R, i⟩
  let b : NormalizedIndex n := .inl ⟨R, j⟩
  by_cases ha : t = a
  · rw [ha, Equiv.swap_apply_left, normalizedBasis_repeated, normalizedBasis_repeated,
      quarterTurn_repeated _ _ hij R (iff_of_false i.prop j.prop), Equiv.swap_apply_left]
  by_cases hb : t = b
  · rw [hb, Equiv.swap_apply_right, normalizedBasis_repeated, normalizedBasis_repeated,
      quarterTurn_repeated _ _ hij R (iff_of_false i.prop j.prop), Equiv.swap_apply_right]
  rw [Equiv.swap_apply_of_ne_of_ne ha hb]
  rcases t with ⟨Q, k⟩ | ⟨S, k⟩
  · simp only [block] at ht
    have hk : k.val ≠ i.val ∧ k.val ≠ j.val := by
      rcases ht with h | h
      · have hQR : Q = R := Subtype.ext h
        subst Q
        let f (l : {k : Axis // k ∉ R.val}) : NormalizedIndex n := .inl ⟨R, l⟩
        exact ⟨fun h => ha (congrArg f (Subtype.ext h)), fun h => hb (congrArg f (Subtype.ext h))⟩
      · have hiQ : i.val ∈ Q.val := h.symm ▸ Finset.mem_compl.mpr i.prop
        have hjQ : j.val ∈ Q.val := h.symm ▸ Finset.mem_compl.mpr j.prop
        exact ⟨fun h => k.prop (h.symm ▸ hiQ), fun h => k.prop (h.symm ▸ hjQ)⟩
    have hQ : i.val ∈ Q.val ↔ j.val ∈ Q.val := by
      rcases ht with h | h
      · rw [h]; exact iff_of_false i.prop j.prop
      · rw [h]; exact iff_of_true (Finset.mem_compl.mpr i.prop) (Finset.mem_compl.mpr j.prop)
    rw [normalizedBasis_repeated, quarterTurn_repeated _ _ hij Q hQ, Equiv.swap_apply_of_ne_of_ne hk.1 hk.2]
  · simp only [block] at ht
    have hm := not_compl_mixed hn R S
    exact (ht.elim (fun h => hm.1 h.symm)
      (fun h => hm.2 (by rw [h, compl_compl]))).elim

private theorem distinct_swap_action {n : ℕ} (hn : n ≠ 6) (S : Index (n + 2))
    (i j : ↥S.val) (hij : i.val ≠ j.val) (t : NormalizedIndex n)
    (ht : block t = S.val ∨ block t = S.valᶜ) :
    action (n + 1) (quarterTurn i.val j.val) (normalizedBasis n t) =
      normalizedBasis n (Equiv.swap (.inr ⟨S, i⟩) (.inr ⟨S, j⟩) t) := by
  let a : NormalizedIndex n := .inr ⟨S, i⟩
  let b : NormalizedIndex n := .inr ⟨S, j⟩
  by_cases ha : t = a
  · rw [ha, Equiv.swap_apply_left, normalizedBasis_distinct, normalizedBasis_distinct,
      quarterTurn_distinct _ _ hij S (iff_of_true i.prop j.prop), Equiv.swap_apply_left]
  by_cases hb : t = b
  · rw [hb, Equiv.swap_apply_right, normalizedBasis_distinct, normalizedBasis_distinct,
      quarterTurn_distinct _ _ hij S (iff_of_true i.prop j.prop), Equiv.swap_apply_right]
  rw [Equiv.swap_apply_of_ne_of_ne ha hb]
  rcases t with ⟨R, k⟩ | ⟨Q, k⟩
  · simp only [block] at ht
    have hm := not_compl_mixed hn R S
    exact (ht.elim hm.1 hm.2).elim
  · simp only [block] at ht
    have hk : k.val ≠ i.val ∧ k.val ≠ j.val := by
      rcases ht with h | h
      · have hQS : Q = S := Subtype.ext h
        subst Q
        let f (l : ↥S.val) : NormalizedIndex n := .inr ⟨S, l⟩
        exact ⟨fun h => ha (congrArg f (Subtype.ext h)), fun h => hb (congrArg f (Subtype.ext h))⟩
      · have hiQ : i.val ∉ Q.val := by rw [h]; exact fun hh => (Finset.mem_compl.mp hh) i.prop
        have hjQ : j.val ∉ Q.val := by rw [h]; exact fun hh => (Finset.mem_compl.mp hh) j.prop
        exact ⟨fun h => hiQ (h ▸ k.prop), fun h => hjQ (h ▸ k.prop)⟩
    have hQ : i.val ∈ Q.val ↔ j.val ∈ Q.val := by
      rcases ht with h | h
      · rw [h]; exact iff_of_true i.prop j.prop
      · rw [h]; exact iff_of_false (fun hi => (Finset.mem_compl.mp hi) i.prop)
          (fun hj => (Finset.mem_compl.mp hj) j.prop)
    rw [normalizedBasis_distinct, quarterTurn_distinct _ _ hij Q hQ, Equiv.swap_apply_of_ne_of_ne hk.1 hk.2]

private theorem some_difference {n : ℕ} (hn : n ≠ 6) (W : Submodule ℂ (Product (n + 1)))
    (hW : Stable W) (hK : W ≤ jointKernel n) (hne : W ≠ ⊥) :
    (∃ (R : Index n) (i j : Axis), i ∉ R.val ∧ j ∉ R.val ∧ i ≠ j ∧ repeated R i - repeated R j ∈ W) ∨
    (∃ (S : Index (n + 2)) (i j : Axis), i ∈ S.val ∧ j ∈ S.val ∧ i ≠ j ∧ distinct S i - distinct S j ∈ W) := by
  classical
  obtain ⟨x, q, hx, hq, hblock⟩ := support_sign_block (normalizedBasis n) block
    (fun i j => action (n + 1) (doubleFlip i j)) normalizedBasis_doubleFlip
    W (fun i j => hW (doubleFlip i j)) hne
  have ⟨hR, hS⟩ := block_sums_zero x (hK hx)
  rcases q with ⟨R, i⟩ | ⟨S, i⟩
  · let c := fun t : {i : Axis // i ∉ R.val} => (normalizedBasis n).repr x (.inl ⟨R, t⟩)
    obtain ⟨j, hj⟩ := second_coefficient c i (hR R) hq
    have hij : i.val ≠ j.val := fun h => hj (congrArg c (Subtype.ext h))
    have hdiff := extract_by_swap W hW x hx (.inl ⟨R, i⟩) (.inl ⟨R, j⟩) hj
      (quarterTurn i.val j.val) (fun t ht => repeated_swap_action hn R i j hij t (hblock t ht))
    rw [normalizedBasis_repeated, normalizedBasis_repeated] at hdiff
    exact Or.inl ⟨R, i.val, j.val, i.prop, j.prop, hij, hdiff⟩
  · let c := fun t : ↥S.val => (normalizedBasis n).repr x (.inr ⟨S, t⟩)
    obtain ⟨j, hj⟩ := second_coefficient c i (hS S) hq
    have hij : i.val ≠ j.val := fun h => hj (congrArg c (Subtype.ext h))
    have hdiff := extract_by_swap W hW x hx (.inr ⟨S, i⟩) (.inr ⟨S, j⟩) hj
      (quarterTurn i.val j.val) (fun t ht => distinct_swap_action hn S i j hij t (hblock t ht))
    rw [normalizedBasis_distinct, normalizedBasis_distinct] at hdiff
    exact Or.inr ⟨S, i.val, j.val, i.prop, j.prop, hij, hdiff⟩

private theorem erase_pair {n : ℕ} (S : Index (n + 2)) (i j : Axis)
    (hi : i ∈ S.val) (hj : j ∈ S.val) (hij : i ≠ j) :
    ∃ R : Index n, i ∉ R.val ∧ j ∉ R.val ∧ S.val = insert i (insert j R.val) := by
  let T := eraseIndex S i hi
  have hjT : j ∈ T.val := Finset.mem_erase.mpr ⟨hij.symm, hj⟩
  let R := eraseIndex T j hjT
  refine ⟨R, fun h => (notMem_eraseIndex S i hi) (Finset.mem_erase.mp h).2,
    notMem_eraseIndex T j hjT, ?_⟩
  change S.val = insert i (insert j (T.val.erase j))
  rw [Finset.insert_erase hjT]
  change S.val = insert i (S.val.erase i)
  rw [Finset.insert_erase hi]

private theorem some_repeated {n : ℕ} (hn : n ≠ 6) (W : Submodule ℂ (Product (n + 1)))
    (hW : Stable W) (hK : W ≤ jointKernel n) (hne : W ≠ ⊥) :
    ∃ (R : Index n) (i j : Axis), i ∉ R.val ∧ j ∉ R.val ∧ i ≠ j ∧ repeated R i - repeated R j ∈ W := by
  rcases some_difference hn W hW hK hne with h | ⟨S, i, j, hi, hj, hij, hd⟩
  · exact h
  · obtain ⟨R, hiR, hjR, hS⟩ := erase_pair S i j hi hj hij
    exact ⟨R, i, j, hiR, hjR, hij, (rotation_bridge W hW R S i j hij hiR hjR hS).mpr hd⟩

private theorem transport_repeated {n : ℕ} (W : Submodule ℂ (Product (n + 1))) (hW : Stable W)
    (R S : Index n) (i j a b : Axis)
    (hi : i ∉ R.val) (hj : j ∉ R.val) (hij : i ≠ j)
    (ha : a ∉ S.val) (hb : b ∉ S.val) (hd : repeated R i - repeated R j ∈ W) :
    repeated S a - repeated S b ∈ W := by
  by_cases hab : a = b
  · subst b
    rw [sub_self]
    exact W.zero_mem
  obtain ⟨σ, hS, hia, hjb⟩ := perm_marked R S i j a b hi hj hij ha hb hab
  obtain ⟨d, hd', hσ⟩ := perm_repeated σ 0 R
  have h := hW (orientedPermAt σ 0) _ hd
  rw [map_sub, hσ i, hσ j, hS, hia, hjb, ← smul_sub d (repeated S a) (repeated S b)] at h
  exact basis_mem_of_scaled W _ d hd' h

theorem jointKernel_invariant_subspace {n : ℕ} (hn : n < 14) (hm : n ≠ 6)
    (W : Submodule ℂ (Product (n + 1)))
    (hW : ∀ g : splitSpecialOrthogonal, ∀ x ∈ W, action (n + 1) g x ∈ W)
    (hK : W ≤ jointKernel n) : W = ⊥ ∨ W = jointKernel n := by
  by_cases hne : W = ⊥
  · exact Or.inl hne
  obtain ⟨R, i, j, hi, hj, hij, hdiff⟩ := some_repeated hm W hW hK hne
  have hR (S : Index n) (a b : Axis) (ha : a ∉ S.val) (hb : b ∉ S.val) :
      repeated S a - repeated S b ∈ W :=
    transport_repeated W hW R S i j a b hi hj hij ha hb hdiff
  have hS (S : Index (n + 2)) (a b : Axis) (ha : a ∈ S.val) (hb : b ∈ S.val) :
      distinct S a - distinct S b ∈ W := by
    by_cases hab : a = b
    · subst b
      rw [sub_self]
      exact W.zero_mem
    obtain ⟨T, haT, hbT, he⟩ := erase_pair S a b ha hb hab
    exact (rotation_bridge W hW T S a b hab haT hbT he).mp (hR T a b haT hbT)
  exact Or.inr (le_antisymm hK (jointKernel_le_of_differences n hn W hR hS))

set_option backward.isDefEq.respectTransparency false in
/-- In input degrees one through thirteen, except for degree seven, the
joint kernel carries an irreducible complex special orthogonal action. -/
theorem jointKernel_isIrreducible (n : Fin 13) (hn : n.val ≠ 6) :
    Representation.IsIrreducible (k := ℂ) (V := ↥(jointKernel n.val)) (jointKernelAction n.val) := by
  have : Nontrivial (↥(jointKernel n.val)) :=
    ⟨⟨⟨nullTensor (highestPlus (internalGrade n)), internalGrade_candidate n⟩, 0,
      fun h => nullTensor_ne_zero _ (congrArg Subtype.val h)⟩⟩
  apply irreducible_of_subrepresentations
  intro U
  let K := jointKernel n.val
  let W : Submodule ℂ (Product (n.val + 1)) := U.toSubmodule.map K.subtype
  have hW : Stable W := by
    intro g x hx
    obtain ⟨y, hy, rfl⟩ := Submodule.mem_map.mp hx
    exact Submodule.mem_map.mpr ⟨jointKernelAction n.val g y, U.apply_mem_toSubmodule g hy, rfl⟩
  have hK : W ≤ K := by
    intro x hx
    obtain ⟨y, _, rfl⟩ := Submodule.mem_map.mp hx
    exact y.prop
  rcases jointKernel_invariant_subspace (n.isLt.trans (by decide)) hn W hW hK with h | h
  · left
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective K.subtype_injective
    change W = (⊥ : Submodule ℂ K).map K.subtype
    rw [Submodule.map_bot, h]
  · right
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective K.subtype_injective
    change W = (⊤ : Submodule ℂ K).map K.subtype
    rw [Submodule.map_top, Submodule.range_subtype, h]

end
end GeometricUnity.D7GradeIrreducible
