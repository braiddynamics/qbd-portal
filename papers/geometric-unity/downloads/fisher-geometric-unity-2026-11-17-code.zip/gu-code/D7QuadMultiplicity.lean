import D7QuadInvariants

/-!
# Realization of the unrestricted intertwiners

A contraction selects one of the three partners of the vector slot. The
remaining three wedges are evaluated by an even invariant trilinear form.
Complementing the last grade by Hodge duality realizes the other parity.
-/

namespace GeometricUnity.D7QuadMultiplicity

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7TensorColumns
open D7ComplementaryGrades D7TripleMultiplicity D7QuadInvariants
open scoped BigOperators symmDiff TensorProduct

noncomputable section

private abbrev e := orthBasis
private abbrev Triform := D7TripleInvariants.Form

private def OrthInvariant {k l : ℕ} (F : Form k l) : Prop :=
  ∀ (f : Space →ₗ[ℂ] Space), Orthogonal f → ∀ x y z w,
    F (f x) (exteriorPower.map 2 f y) (exteriorPower.map k f z) (exteriorPower.map l f w) = F x y z w

private theorem invariant_of_orth {k l : ℕ} {F : Form k l} (h : OrthInvariant F) :
    F ∈ invariantForms k l := fun g x y z w => h g.val g.prop.2 x y z w

set_option maxHeartbeats 600000 in
private theorem full_parity_zero {k l : ℕ} {F : Form k l} (h : OrthInvariant F)
    (q : Quad k l) (hp : parity q = Finset.univ) : coefficient F q = 0 := by
  have hx := h vectorReflection vectorReflection_isometry (e q.axis) (basis 2 q.first)
    (basis k q.second) (basis l q.third)
  have hvec : vectorReflection (e q.axis) = subsetFlip {q.axis} 0 • e q.axis := by
    simp only [vectorReflection, orthDiagonal_basis, subsetFlip, Finset.mem_singleton, eq_comm]
  rw [hvec, reflect_basis, reflect_basis, reflect_basis] at hx
  simp only [map_smul, LinearMap.smul_apply, smul_eq_mul] at hx
  change subsetFlip q.third.val 0 * (subsetFlip q.second.val 0 * (subsetFlip q.first.val 0 *
    (subsetFlip {q.axis} 0 * coefficient F q))) = coefficient F q at hx
  have hs : subsetFlip (parity q) 0 = -1 := by rw [hp]; simp [subsetFlip]
  rw [parity, D7TripleInvariants.subsetFlip_diff, D7TripleInvariants.subsetFlip_diff,
    D7TripleInvariants.subsetFlip_diff] at hs
  have hz : -coefficient F q = coefficient F q := by
    calc
      _ = (subsetFlip q.first.val 0 * subsetFlip q.second.val 0 * subsetFlip {q.axis} 0 *
          subsetFlip q.third.val 0) * coefficient F q := by rw [hs, neg_one_mul]
      _ = _ := by
        convert hx using 1
        ac_rfl
  have hz' : (2 : ℂ) * coefficient F q = 0 := by linear_combination -hz
  exact (mul_eq_zero.mp hz').resolve_left (by norm_num)

private def contractFirst {k l : ℕ} (F : Triform 1 k l) : Form k l :=
  (contractLeft 1).compr₂ₛₗ F

private def contractSecond {k l : ℕ} (F : Triform 2 k l) : Form (k + 1) l where
  toFun x := (LinearMap.lcomp ℂ (Ext l →ₗ[ℂ] ℂ) (contractLeft k x)).comp F
  map_add' _ _ := by
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    simp only [LinearMap.comp_apply, LinearMap.lcomp_apply, map_add, LinearMap.add_apply]
  map_smul' _ _ := by
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    simp only [LinearMap.comp_apply, LinearMap.lcomp_apply, map_smul, LinearMap.smul_apply, RingHom.id_apply]

private def contractThird {k l : ℕ} (F : Triform 2 k l) : Form k (l + 1) where
  toFun x :=
    { toFun y := (LinearMap.lcomp ℂ ℂ (contractLeft l x)).comp (F y)
      map_add' _ _ := by simp only [map_add, LinearMap.comp_add]
      map_smul' _ _ := by simp only [map_smul, LinearMap.comp_smul, RingHom.id_apply] }
  map_add' x x' := by
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    change F y z (contractLeft l (x + x') w) = F y z (contractLeft l x w) + F y z (contractLeft l x' w)
    simp only [map_add, LinearMap.add_apply]
  map_smul' c x := by
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    change F y z (contractLeft l (c • x) w) = c • F y z (contractLeft l x w)
    simp only [map_smul, LinearMap.smul_apply]

private theorem contractFirst_invariant {k l : ℕ} {F : Triform 1 k l}
    (h : orthInvariant F) : OrthInvariant (contractFirst F) := by
  intro f hf x y z w
  change F (contractLeft 1 (f x) (exteriorPower.map 2 f y)) (exteriorPower.map k f z)
    (exteriorPower.map l f w) = F (contractLeft 1 x y) z w
  rw [contract_natural_left 1 f hf]
  exact h f hf _ _ _

private theorem contractSecond_invariant {k l : ℕ} {F : Triform 2 k l}
    (h : orthInvariant F) : OrthInvariant (contractSecond F) := by
  intro f hf x y z w
  change F (exteriorPower.map 2 f y) (contractLeft k (f x) (exteriorPower.map (k + 1) f z))
    (exteriorPower.map l f w) = F y (contractLeft k x z) w
  rw [contract_natural_left k f hf]
  exact h f hf _ _ _

private theorem contractThird_invariant {k l : ℕ} {F : Triform 2 k l}
    (h : orthInvariant F) : OrthInvariant (contractThird F) := by
  intro f hf x y z w
  change F (exteriorPower.map 2 f y) (exteriorPower.map k f z)
    (contractLeft l (f x) (exteriorPower.map (l + 1) f w)) = F y z (contractLeft l x w)
  rw [contract_natural_left l f hf]
  exact h f hf _ _ _

private theorem contract_insert {n : ℕ} (R : Index n) (a : Axis) (ha : a ∉ R.val) :
    ∃ z : ℂ, z ≠ 0 ∧ contractLeft n (e a) (basis (n + 1) (insertIndex R a ha)) = z • basis n R := by
  obtain ⟨z, hz, he⟩ := enlarged_wedge R a ha
  refine ⟨z, hz, ?_⟩
  rw [he, map_smul, contract_wedge_basis R a ha]

private theorem even_with_unused {r k l : ℕ} (hf : r + k < 14) {F : Triform r k l}
    (hF : orthInvariant F) (hF0 : F ≠ 0) :
    ∃ q : D7TripleInvariants.Triple r k l, D7TripleInvariants.parity q = ∅ ∧
      D7TripleInvariants.value F q ≠ 0 ∧ ∃ a : Axis, a ∉ q.1.val ∧ a ∉ q.2.1.val ∧ a ∉ q.2.2.val := by
  obtain ⟨q, hp, hz⟩ := even_nonzero_coordinate hF hF0
  have hc := Finset.card_union_le q.1.val q.2.1.val
  rw [q.1.prop, q.2.1.prop] at hc
  have hb : (q.1.val ∪ q.2.1.val).card < (Finset.univ : Finset Axis).card := by
    rw [Finset.card_univ, Fintype.card_fin]
    omega
  obtain ⟨a, _, ha⟩ := Finset.exists_mem_notMem_of_card_lt_card hb
  have ha₁ : a ∉ q.1.val := fun h => ha (Finset.mem_union_left _ h)
  have ha₂ : a ∉ q.2.1.val := fun h => ha (Finset.mem_union_right _ h)
  refine ⟨q, hp, hz, a, ha₁, ha₂, ?_⟩
  have hq : q.2.2.val = q.1.val ∆ q.2.1.val := D7TripleInvariants.third_of_parity q false hp
  exact fun hm => ha (Finset.symmDiff_subset_union (hq ▸ hm))

private structure EvenWitness (k l : ℕ) (c : Bool × Bool) where
  form : Form k l
  invariant : OrthInvariant form
  q : Quad k l
  even : parity q = ∅
  reg : regular q
  tag : code q = c
  nonzero : coefficient form q ≠ 0
  other : ∀ p : Quad k l, parity p = ∅ → regular p → code p ≠ c → coefficient form p = 0

private theorem firstWitness {k l : ℕ} (hk : k ≤ 7) (h : D7TripleInvariants.feasible 1 k l) :
    Nonempty (EvenWitness k l (true, false)) := by
  obtain ⟨F, hf, hF0⟩ := even_exists (Or.inl rfl) h
  obtain ⟨q, hp, hz, a, ha, hb, _⟩ := even_with_unused (by omega) hf hF0
  let p : Quad k l := ⟨a, insertIndex q.1 a ha, q.2.1, q.2.2⟩
  have hA : a ∈ p.first.val := Finset.mem_insert_self _ _
  have hP : parity p = ∅ := by
    change ((insert a q.1.val ∆ q.2.1.val) ∆ {a}) ∆ q.2.2.val = _
    rw [insert_eq_diff _ _ ha, symmDiff_right_comm q.1.val {a} q.2.1.val, symmDiff_symmDiff_cancel_right]
    exact hp
  refine ⟨⟨contractFirst F, contractFirst_invariant hf, p, hP, Or.inr hb, ?_, ?_, ?_⟩⟩
  · change (decide (a ∈ p.first.val), decide (a ∈ q.2.1.val)) = _
    simp [hA, hb]
  · obtain ⟨z, hz', he⟩ := contract_insert q.1 a ha
    change F (contractLeft 1 (e a) (basis 2 (insertIndex q.1 a ha))) (basis k q.2.1) (basis l q.2.2) ≠ 0
    rw [he, map_smul, LinearMap.smul_apply, LinearMap.smul_apply]
    exact smul_ne_zero hz' hz
  · intro q' _ hr ht
    have ha' : q'.axis ∉ q'.first.val := by
      intro h
      have ht' := hr.resolve_left (not_not_intro h)
      apply ht
      simp [code, h, ht']
    change F (contractLeft 1 (e q'.axis) (basis 2 q'.first)) (basis k q'.second) (basis l q'.third) = 0
    rw [contractLeft_basis_zero q'.first q'.axis ha', map_zero, LinearMap.zero_apply, LinearMap.zero_apply]

private theorem secondWitness {k l : ℕ} (hk : k + 1 ≤ 7) (h : D7TripleInvariants.feasible 2 k l) :
    Nonempty (EvenWitness (k + 1) l (false, true)) := by
  obtain ⟨F, hf, hF0⟩ := even_exists_two h
  obtain ⟨q, hp, hz, a, ha, hb, _⟩ := even_with_unused (by omega) hf hF0
  let p : Quad (k + 1) l := ⟨a, q.1, insertIndex q.2.1 a hb, q.2.2⟩
  have hB : a ∈ p.second.val := Finset.mem_insert_self _ _
  have hP : parity p = ∅ := by
    change ((q.1.val ∆ insert a q.2.1.val) ∆ {a}) ∆ q.2.2.val = _
    rw [insert_eq_diff _ _ hb, ← symmDiff_assoc q.1.val, symmDiff_symmDiff_cancel_right]
    exact hp
  refine ⟨⟨contractSecond F, contractSecond_invariant hf, p, hP, Or.inl ha, ?_, ?_, ?_⟩⟩
  · change (decide (a ∈ q.1.val), decide (a ∈ p.second.val)) = _
    simp [ha, hB]
  · obtain ⟨z, hz', he⟩ := contract_insert q.2.1 a hb
    change F (basis 2 q.1) (contractLeft k (e a) (basis (k + 1) (insertIndex q.2.1 a hb))) (basis l q.2.2) ≠ 0
    rw [he, map_smul, LinearMap.smul_apply]
    exact smul_ne_zero hz' hz
  · intro q' _ hr ht
    have ha' : q'.axis ∉ q'.second.val := by
      intro h
      have ht' := hr.resolve_right (not_not_intro h)
      apply ht
      simp [code, h, ht']
    change F (basis 2 q'.first) (contractLeft k (e q'.axis) (basis (k + 1) q'.second)) (basis l q'.third) = 0
    rw [contractLeft_basis_zero q'.second q'.axis ha', map_zero, LinearMap.zero_apply]

private theorem thirdWitness {k l : ℕ} (hk : k ≤ 7) (h : D7TripleInvariants.feasible 2 k l) :
    Nonempty (EvenWitness k (l + 1) (false, false)) := by
  obtain ⟨F, hf, hF0⟩ := even_exists_two h
  obtain ⟨q, hp, hz, a, ha, hb, hc⟩ := even_with_unused (by omega) hf hF0
  let p : Quad k (l + 1) := ⟨a, q.1, q.2.1, insertIndex q.2.2 a hc⟩
  have hP : parity p = ∅ := by
    change ((q.1.val ∆ q.2.1.val) ∆ {a}) ∆ insert a q.2.2.val = _
    rw [insert_eq_diff _ _ hc, ← symmDiff_assoc, symmDiff_right_comm (q.1.val ∆ q.2.1.val) {a} q.2.2.val,
      symmDiff_symmDiff_cancel_right]
    exact hp
  refine ⟨⟨contractThird F, contractThird_invariant hf, p, hP, Or.inl ha, ?_, ?_, ?_⟩⟩
  · change (decide (a ∈ q.1.val), decide (a ∈ q.2.1.val)) = _
    simp [ha, hb]
  · obtain ⟨z, hz', he⟩ := contract_insert q.2.2 a hc
    change F (basis 2 q.1) (basis k q.2.1) (contractLeft l (e a)
      (basis (l + 1) (insertIndex q.2.2 a hc))) ≠ 0
    rw [he, map_smul]
    exact smul_ne_zero hz' hz
  · intro q' hp' hr ht
    have ha' : q'.axis ∉ q'.third.val := by
      intro h
      have hi := (axis_mem_third_even q' hp').mp h
      have hA : q'.axis ∉ q'.first.val := hr.elim id (fun h' hx => h' (hi.mp hx))
      have hB : q'.axis ∉ q'.second.val := fun hx => hA (hi.mpr hx)
      apply ht
      simp [code, hA, hB]
    change F (basis 2 q'.first) (basis k q'.second)
      (contractLeft l (e q'.axis) (basis (l + 1) q'.third)) = 0
    rw [contractLeft_basis_zero q'.third q'.axis ha', map_zero]

private theorem realizeEven {k l : ℕ} (hk : k ≤ 7) (c : Bool × Bool) (h : possible k l c) :
    Nonempty (EvenWitness k l c) := by
  rcases c with ⟨a, b⟩
  cases a <;> cases b
  · have h' : 0 < l ∧ D7TripleInvariants.feasible 2 k (l - 1) := h
    cases l
    · omega
    · exact thirdWitness hk h'.2
  · have h' : 0 < k ∧ D7TripleInvariants.feasible 2 (k - 1) l := h
    cases k
    · omega
    · exact secondWitness hk h'.2
  · exact firstWitness hk h
  · exact h.elim

private def recognizes {k l : ℕ} (c : OrbitCode) (q : Quad k l) : Prop :=
  regular q ∧ code q = c.2 ∧ parity q = if c.1 then Finset.univ else ∅

private structure Witness (k l : ℕ) (c : OrbitCode) where
  form : ↥(invariantForms k l)
  q : Quad k l
  recognized : recognizes c q
  nonzero : coefficient form.val q ≠ 0
  other : ∀ p : Quad k l, ∀ d : OrbitCode, recognizes d p → d ≠ c → coefficient form.val p = 0

private theorem realize {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) (c : OrbitCode) (hc : allowed k l c) :
    Nonempty (Witness k l c) := by
  rcases c with ⟨b, c⟩
  cases b
  · obtain ⟨w⟩ := realizeEven hk c hc
    refine ⟨⟨⟨w.form, invariant_of_orth w.invariant⟩, w.q, ⟨w.reg, w.tag, w.even⟩, w.nonzero, ?_⟩⟩
    rintro p ⟨b, t⟩ ⟨hr, ht, hp⟩ he
    cases b
    · exact w.other p hp hr (fun h => he (Prod.ext rfl (ht.symm.trans h)))
    · exact full_parity_zero w.invariant p hp
  · have h : l + (14 - l) = 14 := by omega
    have h' : (14 - l) + l = 14 := by omega
    obtain ⟨w⟩ := realizeEven hk c hc
    let F := twistThird h w.form
    let q := complementThird h' w.q
    have hq : parity q = Finset.univ := by rw [complementThird_parity, w.even]; simp
    refine ⟨⟨⟨F, twistThird_mem h ⟨w.form, invariant_of_orth w.invariant⟩⟩, q,
      ⟨w.reg, w.tag, hq⟩, ?_, ?_⟩⟩
    · obtain ⟨a, ha, he⟩ := eval_twistThird h w.form q
      change coefficient F q = a • coefficient w.form (complementThird h (complementThird h' w.q)) at he
      rw [complementary_twice] at he
      rw [he]
      exact smul_ne_zero ha w.nonzero
    · rintro p ⟨b, t⟩ ⟨hr, ht, hp⟩ he
      obtain ⟨a, _, hA⟩ := eval_twistThird h w.form p
      change coefficient F p = a • coefficient w.form (complementThird h p) at hA
      change coefficient F p = 0
      rw [hA]
      cases b
      · have hp' : parity (complementThird h p) = Finset.univ := by rw [complementThird_parity, hp]; simp
        rw [full_parity_zero w.invariant _ hp', smul_zero]
      · have hp' : parity (complementThird h p) = ∅ := by rw [complementThird_parity, hp]; simp
        rw [w.other _ hp' hr (fun hh => he (Prod.ext rfl (ht.symm.trans hh))), smul_zero]

private def evaluation {k l : ℕ} (q : Quad k l) : invariantForms k l →ₗ[ℂ] ℂ where
  toFun F := coefficient F.val q
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

local instance (k l : ℕ) : AddCommGroup ↥(invariantForms k l) :=
  invariantFormsAddCommGroup k l

local instance (k l : ℕ) : Module ℂ ↥(invariantForms k l) :=
  Submodule.module (R := ℂ) (M := Form k l) (invariantForms k l)

set_option maxHeartbeats 600000 in
private theorem finrank_lower {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) :
    quadMultiplicity k l ≤ Module.finrank ℂ (invariantForms k l) := by
  classical
  let : Module.Finite ℂ ↥(invariantForms k l) := invariantForms_finite hk hl
  let I := {c : OrbitCode // allowed k l c}
  let w (i : I) : Witness k l i.val := Classical.choice (realize hk hl i.val i.prop)
  let v (i : I) : ↥(invariantForms k l) := (w i).form
  have hv : LinearIndependent ℂ v := by
    apply Fintype.linearIndependent_iff.mpr
    intro a ha i
    have h := congrArg (evaluation (w i).q) ha
    rw [map_sum, map_zero] at h
    simp only [map_smul, smul_eq_mul] at h
    rw [Finset.sum_eq_single i] at h
    · exact (mul_eq_zero.mp h).resolve_right (w i).nonzero
    · intro j _ hj
      have hz : evaluation (w i).q (v j) = 0 :=
        (w j).other (w i).q i.val (w i).recognized (fun he => hj (Subtype.ext he.symm))
      rw [hz, mul_zero]
    · simp
  exact hv.fintype_card_le_finrank

/-- In each grade pair there is exactly one independent invariant for
each feasible partner of the vector slot and each feasible parity. -/
theorem finrank_invariantForms {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) :
    Module.finrank ℂ (invariantForms k l) = quadMultiplicity k l :=
  le_antisymm (finrank_invariantForms_le hk hl) (finrank_lower hk hl)

end
end GeometricUnity.D7QuadMultiplicity
