# Geometric Unity verification archive

*Clifford Contractions and the First-Order Bosonic Action in Geometric Unity*

R. Fisher · Braid Dynamics Applied Research Group

November 17, 2026

DOI: [10.5281/zenodo.24325062](https://doi.org/10.5281/zenodo.24325062)

## Contents and use

This archive contains 40 Lean files, the Python verification program `GU-test.py`, and three project configuration files. Extract `fisher-geometric-unity-2026-11-17-code.zip` to obtain the `gu-code` directory. The accompanying `fisher-geometric-unity-2026-11-17-code-guide.pdf` describes every source file, the assumptions of the formalizations, dependency installation, execution commands, and benchmark results. The accompanying `fisher-geometric-unity-2026-11-17-computational-supplement.md` contains the complete source listings in Markdown.

`SHA256SUMS` records the SHA-256 digest of every other file in this archive, including this README and both license files. Source files match their listings in the computational supplement, using UTF-8 text and Unix line endings.

## License scope

Copyright (c) 2026 R. Fisher.

- **Text and figures:** the technical note, the Code Guide, the prose and figures in the computational supplement, and this README are licensed under Creative Commons Attribution 4.0 International (CC BY 4.0). The full terms are included in `LICENSE-CC-BY-4.0.txt` and at <https://creativecommons.org/licenses/by/4.0/>.
- **Software:** all 40 Lean source files, `GU-test.py`, and the project configuration files `lakefile.toml`, `lake-manifest.json`, and `lean-toolchain` are licensed under the MIT License. This applies equally to their source listings embedded in the computational supplement. The full terms, including the copyright and permission notice, are included in `LICENSE-MIT.txt`.

These grants apply specifically to this Geometric Unity publication and its accompanying software, including copies obtained from Zenodo or the website. They take precedence for these materials over general website or repository notices. Third-party works and dependencies retain their own licenses; dependencies are downloaded separately and are not included in this archive. The reproduced license texts retain their own applicable terms.

## Citation

Fisher, R. (2026). *Clifford Contractions and the First-Order Bosonic Action in Geometric Unity*. https://doi.org/10.5281/zenodo.24325062
