import D7SpinRootLifts
import D7SpinOrientation
import D7Hodge
import Mathlib.LinearAlgebra.Complex.Module
import Mathlib.LinearAlgebra.Matrix.ToLin

/-!
# The real Spin vector action in split null coordinates

The two entries of each diagonal pair `(p,n)` become `p+n` and
`(p-n)/2`. This normalization gives the exact complex pairing used by
`D7Exterior.splitForm`.
-/

namespace GeometricUnity.D7SpinNullFrame

open D7Exterior
open scoped BigOperators Matrix

noncomputable section

abbrev RealSpace := Axis → ℝ

private abbrev diagPositive (i : Pair) : Axis := Fin.castAdd 7 i
private abbrev diagNegative (i : Pair) : Axis := Fin.natAdd 7 i
private abbrev coordinate (i : Axis) : RealSpace →ₗ[ℝ] ℝ := LinearMap.proj i

theorem pairIndex_plus (i : Pair) : pairIndex (plusAxis i) = i :=
  Fin.ext (by change 2 * i.val / 2 = i.val; omega)

theorem pairIndex_minus (i : Pair) : pairIndex (minusAxis i) = i :=
  Fin.ext (by change (2 * i.val + 1) / 2 = i.val; omega)

private def toNull : RealSpace →ₗ[ℝ] RealSpace :=
  LinearMap.pi fun j =>
    let i := pairIndex j
    if j.val % 2 = 0 then
      coordinate (diagPositive i) + coordinate (diagNegative i)
    else
      (1 / 2 : ℝ) • (coordinate (diagPositive i) - coordinate (diagNegative i))

private def fromNull : RealSpace →ₗ[ℝ] RealSpace :=
  LinearMap.pi (Fin.addCases (m := 7) (n := 7)
    (fun i => (1 / 2 : ℝ) • LinearMap.proj (plusAxis i) + LinearMap.proj (minusAxis i))
    (fun i => (1 / 2 : ℝ) • LinearMap.proj (plusAxis i) - LinearMap.proj (minusAxis i)))

private theorem toNull_plus (x : RealSpace) (i : Pair) :
    toNull x (plusAxis i) = x (diagPositive i) + x (diagNegative i) := by
  have hp : (plusAxis i).val % 2 = 0 := by
    change (2 * i.val) % 2 = 0
    omega
  simp only [toNull, LinearMap.pi_apply, pairIndex_plus, hp, if_true, LinearMap.add_apply,
    LinearMap.proj_apply]

private theorem toNull_minus (x : RealSpace) (i : Pair) :
    toNull x (minusAxis i) = (1 / 2 : ℝ) * (x (diagPositive i) - x (diagNegative i)) := by
  have hp : (minusAxis i).val % 2 ≠ 0 := by
    change (2 * i.val + 1) % 2 ≠ 0
    omega
  simp only [toNull, LinearMap.pi_apply, pairIndex_minus, if_neg hp, LinearMap.smul_apply,
    LinearMap.sub_apply, LinearMap.proj_apply, smul_eq_mul]

private theorem fromNull_pos (x : RealSpace) (i : Pair) :
    fromNull x (diagPositive i) = (1 / 2 : ℝ) * x (plusAxis i) + x (minusAxis i) := by
  simp only [fromNull, LinearMap.pi_apply, Fin.addCases_left, LinearMap.add_apply,
    LinearMap.smul_apply, LinearMap.proj_apply, smul_eq_mul]

private theorem fromNull_neg (x : RealSpace) (i : Pair) :
    fromNull x (diagNegative i) = (1 / 2 : ℝ) * x (plusAxis i) - x (minusAxis i) := by
  simp only [fromNull, LinearMap.pi_apply, Fin.addCases_right, LinearMap.sub_apply,
    LinearMap.smul_apply, LinearMap.proj_apply, smul_eq_mul]

theorem null_axis_cases (j : Axis) :
    j = plusAxis (pairIndex j) ∨ j = minusAxis (pairIndex j) := by
  by_cases h : j.val % 2 = 0
  · exact Or.inl (Fin.ext (by change j.val = 2 * (j.val / 2); omega))
  · exact Or.inr (Fin.ext (by change j.val = 2 * (j.val / 2) + 1; omega))

/-- The real diagonal-to-null linear equivalence. -/
def nullFrame : RealSpace ≃ₗ[ℝ] RealSpace where
  __ := toNull
  invFun := fromNull
  left_inv x := by
    funext j
    refine Fin.addCases (m := 7) (n := 7) ?_ ?_ j
    · intro i
      change fromNull (toNull x) (diagPositive i) = _
      rw [fromNull_pos, toNull_plus, toNull_minus]
      ring
    · intro i
      change fromNull (toNull x) (diagNegative i) = _
      rw [fromNull_neg, toNull_plus, toNull_minus]
      ring
  right_inv x := by
    funext j
    change toNull (fromNull x) j = x j
    rcases null_axis_cases j with h | h
    · conv_lhs => rw [h]
      conv_rhs => rw [h]
      rw [toNull_plus, fromNull_pos, fromNull_neg]
      ring
    · conv_lhs => rw [h]
      conv_rhs => rw [h]
      rw [toNull_minus, fromNull_pos, fromNull_neg]
      ring

/-- The real form of the complex pairing in the split coordinates. -/
def realSplitPairing (x y : RealSpace) : ℝ :=
  ∑ i : Pair, (x (plusAxis i) * y (minusAxis i) + x (minusAxis i) * y (plusAxis i))

private theorem splitForm_diag (x : RealSpace) :
    WitnessW1.splitForm x =
      ∑ i : Pair, (x (diagPositive i) ^ 2 - x (diagNegative i) ^ 2) := by
  rw [WitnessW1.splitForm, QuadraticMap.weightedSumSquares_apply,
    Fin.sum_univ_add (a := 7) (b := 7) (fun i => WitnessW1.metricSign i • (x i * x i))]
  simp only [WitnessW1.metricSign, Fin.val_castAdd, Fin.val_natAdd, Fin.isLt, if_true,
    show ∀ i : Pair, ¬ 7 + i.val < 7 from fun i => by omega, if_false, smul_eq_mul,
    one_mul, neg_one_mul, ← Finset.sum_add_distrib, pow_two, sub_eq_add_neg]

theorem nullFrame_pairing (x y : RealSpace) :
    realSplitPairing (nullFrame x) (nullFrame y) =
      (WitnessW1.splitForm (x + y) - WitnessW1.splitForm x - WitnessW1.splitForm y) / 2 := by
  change realSplitPairing (toNull x) (toNull y) = _
  simp only [realSplitPairing, toNull_plus, toNull_minus, splitForm_diag, Pi.add_apply,
    ← Finset.sum_sub_distrib, div_eq_mul_inv, Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro i _
  ring

theorem polar_eq_pairing (x y : RealSpace) :
    QuadraticMap.polar WitnessW1.splitForm x y =
      2 * realSplitPairing (nullFrame x) (nullFrame y) := by
  rw [nullFrame_pairing, QuadraticMap.polar]
  ring

/-- The real Spin action in the normalized null basis. -/
def realNullAction : Representation ℝ D7SpinAction.Spin RealSpace :=
  (nullFrame.conjAlgEquiv ℝ).toAlgHom.toMonoidHom.comp D7SpinAction.vectorRepresentation

theorem realNullAction_apply (g : D7SpinAction.Spin) (x : RealSpace) :
    realNullAction g x = nullFrame (D7SpinAction.vectorRepresentation g (nullFrame.symm x)) := rfl

theorem realNullAction_preserves (g : D7SpinAction.Spin) (x y : RealSpace) :
    realSplitPairing (realNullAction g x) (realNullAction g y) = realSplitPairing x y := by
  obtain ⟨x, rfl⟩ := nullFrame.surjective x
  obtain ⟨y, rfl⟩ := nullFrame.surjective y
  simp only [realNullAction_apply, LinearEquiv.symm_apply_apply, nullFrame_pairing, ← map_add,
    D7SpinAction.vectorRepresentation_preserves]

theorem realNullAction_det (g : D7SpinAction.Spin) : (realNullAction g).det = 1 := by
  change ((nullFrame.conjAlgEquiv ℝ) (D7SpinAction.vectorRepresentation g)).det = 1
  rw [LinearEquiv.conjAlgEquiv_apply, LinearMap.det_comp, LinearMap.det_comp,
    D7SpinOrientation.vectorRepresentation_det, one_mul, LinearEquiv.det_mul_det_symm]

/-- The Clifford lift acts by the two signed terms of a split
transvection in null coordinates. The root parameter is twice the
coefficient of the bivector in the Clifford lift. -/
theorem realNullAction_isotropicLift (a b c x : RealSpace) (r : ℝ)
    (ha : WitnessW1.splitForm a = 0) (hb : WitnessW1.splitForm b = 0)
    (hc : WitnessW1.splitForm c = 1)
    (hab : WitnessW1.splitForm.IsOrtho a b) (hac : WitnessW1.splitForm.IsOrtho a c)
    (hbc : WitnessW1.splitForm.IsOrtho b c) :
    realNullAction (D7SpinRootLifts.isotropicLift a b c (r / 2) ha hb hc hab hac hbc) x =
      x + r • (realSplitPairing (nullFrame b) x • nullFrame a -
        realSplitPairing (nullFrame a) x • nullFrame b) := by
  rw [realNullAction_apply, D7SpinRootLifts.isotropicLift_action,
    polar_eq_pairing b, polar_eq_pairing a]
  simp only [map_add, map_sub, map_smul, LinearEquiv.apply_symm_apply]
  funext i
  simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
  ring

private def complexifyEnd : Module.End ℝ RealSpace →ₐ[ℝ] Module.End ℂ Space :=
  ((Matrix.toLinAlgEquiv' : Matrix Axis Axis ℂ ≃ₐ[ℂ] Module.End ℂ Space).toAlgHom.restrictScalars ℝ).comp
    ((Algebra.ofId ℝ ℂ).mapMatrix.comp LinearMap.toMatrixAlgEquiv'.toAlgHom)

/-- The real vector action extended to the complex split coordinate space. -/
def complexNullAction : Representation ℂ D7SpinAction.Spin Space :=
  complexifyEnd.toMonoidHom.comp realNullAction

theorem complexNullAction_det (g : D7SpinAction.Spin) : (complexNullAction g).det = 1 := by
  let M : Matrix Axis Axis ℝ := LinearMap.toMatrixAlgEquiv' (realNullAction g)
  have hM : LinearMap.toMatrix' (complexNullAction g) = M.map Complex.ofRealHom :=
    LinearMap.toMatrixAlgEquiv'.apply_symm_apply (M.map Complex.ofRealHom)
  rw [← LinearMap.det_toMatrix', hM]
  change (Complex.ofRealHom.mapMatrix M).det = 1
  rw [← Complex.ofRealHom.map_det]
  change Complex.ofRealHom (Matrix.det (LinearMap.toMatrix' (realNullAction g))) = 1
  rw [LinearMap.det_toMatrix', realNullAction_det, map_one]

private def ofRealVector (x : RealSpace) : Space := fun i => ↑(x i)

theorem complexNullAction_ofReal (g : D7SpinAction.Spin) (x : RealSpace) :
    complexNullAction g (ofRealVector x) = ofRealVector (realNullAction g x) := by
  let M : Matrix Axis Axis ℝ := LinearMap.toMatrixAlgEquiv' (realNullAction g)
  have hM : M.mulVecLin = realNullAction g := LinearMap.toMatrixAlgEquiv'.symm_apply_apply _
  funext i
  change (M.map Complex.ofRealHom *ᵥ (Complex.ofRealHom ∘ x)) i = ↑((realNullAction g x) i)
  rw [← Complex.ofRealHom.map_mulVec, ← Matrix.mulVecLin_apply, hM]
  rfl

private theorem splitPairing_ofReal (x y : RealSpace) :
    splitForm (ofRealVector x) (ofRealVector y) = (realSplitPairing x y : ℂ) := by
  change (∑ i : Pair, ((x (plusAxis i) : ℂ) * (y (minusAxis i) : ℂ) +
    (x (minusAxis i) : ℂ) * (y (plusAxis i) : ℂ))) =
    Complex.ofRealHom (∑ i : Pair,
      (x (plusAxis i) * y (minusAxis i) + x (minusAxis i) * y (plusAxis i)))
  simp only [map_sum, map_add, map_mul, Complex.ofRealHom_eq_coe]

private theorem axisBasis_ofReal (i : Axis) :
    axisBasis i = ofRealVector (Pi.basisFun ℝ Axis i) := by
  funext j
  by_cases h : j = i <;> simp [axisBasis, Pi.basisFun_apply, ofRealVector, h]

theorem complexNullAction_preserves (g : D7SpinAction.Spin) (x y : Space) :
    splitForm (complexNullAction g x) (complexNullAction g y) = splitForm x y := by
  let f := complexNullAction g
  have h : (f.dualMap.comp D7Hodge.splitMetric).comp f = D7Hodge.splitMetric := by
    apply axisBasis.ext
    intro i
    apply axisBasis.ext
    intro j
    change D7Hodge.splitMetric (f (axisBasis i)) (f (axisBasis j)) =
      D7Hodge.splitMetric (axisBasis i) (axisBasis j)
    simp only [D7Hodge.splitMetric_apply, axisBasis_ofReal, f, complexNullAction_ofReal,
      splitPairing_ofReal, realNullAction_preserves]
  have hv := DFunLike.congr_fun (DFunLike.congr_fun h x) y
  change D7Hodge.splitMetric (f x) (f y) = D7Hodge.splitMetric x y at hv
  simpa only [D7Hodge.splitMetric_apply] using hv

/-- The complexified real Spin action as a homomorphism into the split
special orthogonal group used in the (D_7) calculation. -/
def spinToSO : D7SpinAction.Spin →* splitSpecialOrthogonal where
  toFun g := ⟨complexNullAction g, complexNullAction_det g, complexNullAction_preserves g⟩
  map_one' := Subtype.ext (map_one complexNullAction)
  map_mul' g h := Subtype.ext (map_mul complexNullAction g h)

/-! ## Real parameters in the split root families -/

/-- The other null axis in the same hyperbolic pair. -/
def pairedAxis (i : Axis) : Axis :=
  if i.val % 2 = 0 then minusAxis (pairIndex i) else plusAxis (pairIndex i)

@[simp] theorem pairedAxis_plus (i : Pair) : pairedAxis (plusAxis i) = minusAxis i := by
  rw [pairedAxis, pairIndex_plus, if_pos]
  change (2 * i.val) % 2 = 0
  omega

@[simp] theorem pairedAxis_minus (i : Pair) : pairedAxis (minusAxis i) = plusAxis i := by
  rw [pairedAxis, pairIndex_minus, if_neg]
  change (2 * i.val + 1) % 2 ≠ 0
  omega

private theorem plus_ne_minus (i j : Pair) : plusAxis i ≠ minusAxis j := by
  intro h
  have h' := congrArg Fin.val h
  change 2 * i.val = 2 * j.val + 1 at h'
  omega

theorem pairedAxis_pairIndex (i : Axis) : pairIndex (pairedAxis i) = pairIndex i := by
  rcases null_axis_cases i with h | h
  · rw [h, pairedAxis_plus, pairIndex_plus, pairIndex_minus]
  · rw [h, pairedAxis_minus, pairIndex_plus, pairIndex_minus]

theorem pairedAxis_ne (i : Axis) : pairedAxis i ≠ i := by
  rcases null_axis_cases i with h | h
  · rw [h, pairedAxis_plus]
    exact (plus_ne_minus _ _).symm
  · rw [h, pairedAxis_minus]
    exact plus_ne_minus _ _

@[simp] theorem pairedAxis_pairedAxis (i : Axis) : pairedAxis (pairedAxis i) = i := by
  rcases null_axis_cases i with h | h
  · rw [h, pairedAxis_plus, pairedAxis_minus]
  · rw [h, pairedAxis_minus, pairedAxis_plus]

private abbrev realBasis := Pi.basisFun ℝ Axis

private theorem realBasis_apply (i j : Axis) : realBasis i j = if j = i then 1 else 0 := by
  rw [Pi.basisFun_apply, Pi.single_apply]

private theorem realSplitPairing_basis (i : Axis) (x : RealSpace) :
    realSplitPairing (realBasis i) x = x (pairedAxis i) := by
  have hplus (j k : Pair) : plusAxis j = plusAxis k ↔ j = k := by
    constructor
    · intro h
      simpa only [pairIndex_plus] using congrArg pairIndex h
    · exact congrArg plusAxis
  have hminus (j k : Pair) : minusAxis j = minusAxis k ↔ j = k := by
    constructor
    · intro h
      simpa only [pairIndex_minus] using congrArg pairIndex h
    · exact congrArg minusAxis
  rcases null_axis_cases i with h | h
  · rw [h, pairedAxis_plus]
    simp only [realSplitPairing, realBasis_apply, hplus, Ne.symm (plus_ne_minus _ _), if_false,
      zero_mul, add_zero, ite_mul, one_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  · rw [h, pairedAxis_minus]
    simp only [realSplitPairing, realBasis_apply, hminus, plus_ne_minus, if_false, zero_mul,
      zero_add, ite_mul, one_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true]

private theorem realSplitPairing_add_left (x y z : RealSpace) :
    realSplitPairing (x + y) z = realSplitPairing x z + realSplitPairing y z := by
  simp only [realSplitPairing, Pi.add_apply, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro i _
  ring

private theorem realSplitPairing_smul_left (r : ℝ) (x y : RealSpace) :
    realSplitPairing (r • x) y = r * realSplitPairing x y := by
  simp only [realSplitPairing, Pi.smul_apply, smul_eq_mul, Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro i _
  ring

private theorem quadratic_eq_pairing (x : RealSpace) :
    WitnessW1.splitForm x = realSplitPairing (nullFrame x) (nullFrame x) := by
  have h := polar_eq_pairing x x
  rw [QuadraticMap.polar_self, two_smul] at h
  linarith

private theorem ortho_of_null_pairing {x y : RealSpace}
    (h : realSplitPairing (nullFrame x) (nullFrame y) = 0) :
    WitnessW1.splitForm.IsOrtho x y := by
  apply QuadraticMap.isOrtho_polarBilin.mp
  rw [QuadraticMap.polarBilin_apply_apply, polar_eq_pairing, h, mul_zero]

private theorem auxiliary_pair (i j : Pair) (h : i ≠ j) : ∃ k : Pair, k ≠ i ∧ k ≠ j := by
  classical
  by_contra! hn
  have hsub : (Finset.univ : Finset Pair) ⊆ {i, j} := by
    intro k _
    simp only [Finset.mem_insert, Finset.mem_singleton]
    specialize hn k
    tauto
  have hcard := Finset.card_le_card hsub
  rw [Finset.card_univ, Fintype.card_fin, Finset.card_pair_eq_two_iff.mpr h] at hcard
  omega

private theorem rootGroup_ofReal (r : ℝ) (a q b u : Axis) (x : RealSpace) :
    rootGroup (r : ℂ) a q b u (ofRealVector x) =
      ofRealVector (x + r • (x q • realBasis a - x u • realBasis b)) := by
  have hcoord (i : Axis) : axisBasis.coord i (ofRealVector x) = (x i : ℂ) := by
    simp [axisBasis, Module.Basis.coord_apply, Pi.basisFun_repr, ofRealVector]
  change ofRealVector x + (r : ℂ) • (axisBasis.coord q (ofRealVector x) • axisBasis a) -
    (r : ℂ) • (axisBasis.coord u (ofRealVector x) • axisBasis b) = _
  rw [hcoord, hcoord, axisBasis_ofReal a, axisBasis_ofReal b]
  funext i
  simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, ofRealVector, smul_eq_mul,
    Complex.ofReal_add, Complex.ofReal_mul, Complex.ofReal_sub]
  ring

/-- Each pair of axes from distinct hyperbolic pairs gives a split root
action at every real parameter, realized by an element of real Spin. -/
theorem exists_rootGroup_lift (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (r : ℝ) :
    ∃ g : D7SpinAction.Spin,
      complexNullAction g = rootGroup (r : ℂ) a (pairedAxis b) b (pairedAxis a) := by
  obtain ⟨k, hka, hkb⟩ := auxiliary_pair (pairIndex a) (pairIndex b) hab
  let A := nullFrame.symm (realBasis a)
  let B := nullFrame.symm (realBasis b)
  let cNull := realBasis (plusAxis k) + (1 / 2 : ℝ) • realBasis (minusAxis k)
  let C := nullFrame.symm cNull
  have hA : nullFrame A = realBasis a := nullFrame.apply_symm_apply _
  have hB : nullFrame B = realBasis b := nullFrame.apply_symm_apply _
  have hC : nullFrame C = cNull := nullFrame.apply_symm_apply _
  have ha0 : WitnessW1.splitForm A = 0 := by
    rw [quadratic_eq_pairing, hA, realSplitPairing_basis, realBasis_apply, if_neg (pairedAxis_ne a)]
  have hb0 : WitnessW1.splitForm B = 0 := by
    rw [quadratic_eq_pairing, hB, realSplitPairing_basis, realBasis_apply, if_neg (pairedAxis_ne b)]
  have hc1 : WitnessW1.splitForm C = 1 := by
    rw [quadratic_eq_pairing, hC]
    simp only [cNull, realSplitPairing_add_left, realSplitPairing_smul_left, realSplitPairing_basis,
      pairedAxis_plus, pairedAxis_minus, Pi.add_apply, Pi.smul_apply, smul_eq_mul, realBasis_apply,
      plus_ne_minus, Ne.symm (plus_ne_minus _ _), if_false, if_true]
    norm_num
  have hab' : WitnessW1.splitForm.IsOrtho A B := by
    apply ortho_of_null_pairing
    rw [hA, hB, realSplitPairing_basis, realBasis_apply]
    apply if_neg
    intro h
    exact hab (by simpa only [pairedAxis_pairIndex] using congrArg pairIndex h)
  have hcp (i : Axis) (hi : k ≠ pairIndex i) : cNull (pairedAxis i) = 0 := by
    have hplus : pairedAxis i ≠ plusAxis k := by
      intro h
      exact hi (by simpa only [pairedAxis_pairIndex, pairIndex_plus] using (congrArg pairIndex h).symm)
    have hminus : pairedAxis i ≠ minusAxis k := by
      intro h
      exact hi (by simpa only [pairedAxis_pairIndex, pairIndex_minus] using (congrArg pairIndex h).symm)
    simp only [cNull, Pi.add_apply, Pi.smul_apply, realBasis_apply, if_neg hplus, if_neg hminus,
      smul_zero, add_zero]
  have hac : WitnessW1.splitForm.IsOrtho A C := by
    apply ortho_of_null_pairing
    rw [hA, hC, realSplitPairing_basis, hcp a hka]
  have hbc : WitnessW1.splitForm.IsOrtho B C := by
    apply ortho_of_null_pairing
    rw [hB, hC, realSplitPairing_basis, hcp b hkb]
  let g := D7SpinRootLifts.isotropicLift A B C (r / 2) ha0 hb0 hc1 hab' hac hbc
  have hreal (x : RealSpace) : realNullAction g x =
      x + r • (x (pairedAxis b) • realBasis a - x (pairedAxis a) • realBasis b) := by
    rw [show realNullAction g x =
      x + r • (realSplitPairing (nullFrame B) x • nullFrame A -
        realSplitPairing (nullFrame A) x • nullFrame B) from
      realNullAction_isotropicLift A B C x r ha0 hb0 hc1 hab' hac hbc,
      hA, hB, realSplitPairing_basis, realSplitPairing_basis]
  refine ⟨g, axisBasis.ext ?_⟩
  intro j
  rw [axisBasis_ofReal, complexNullAction_ofReal, hreal, rootGroup_ofReal]

theorem exists_rootMinus_lift (i j : Pair) (h : i ≠ j) (r : ℝ) :
    ∃ g : D7SpinAction.Spin, complexNullAction g = rootMinus (r : ℂ) i j := by
  have hn : pairIndex (plusAxis i) ≠ pairIndex (minusAxis j) := by
    simpa only [pairIndex_plus, pairIndex_minus] using h
  simpa only [pairedAxis_plus, pairedAxis_minus, rootMinus] using
    exists_rootGroup_lift (plusAxis i) (minusAxis j) hn r

theorem exists_rootPlus_lift (i j : Pair) (h : i ≠ j) (r : ℝ) :
    ∃ g : D7SpinAction.Spin, complexNullAction g = rootPlus (r : ℂ) i j := by
  have hn : pairIndex (plusAxis i) ≠ pairIndex (plusAxis j) := by
    simpa only [pairIndex_plus] using h
  simpa only [pairedAxis_plus, rootPlus] using
    exists_rootGroup_lift (plusAxis i) (plusAxis j) hn r

theorem rootMinusElement_mem_spinRange (i j : Pair) (h : i < j) (r : ℝ) :
    rootMinusElement (r : ℂ) i j h ∈ Set.range spinToSO := by
  obtain ⟨g, hg⟩ := exists_rootMinus_lift i j (ne_of_lt h) r
  exact ⟨g, Subtype.ext hg⟩

theorem rootPlusElement_mem_spinRange (i j : Pair) (h : i < j) (r : ℝ) :
    rootPlusElement (r : ℂ) i j h ∈ Set.range spinToSO := by
  obtain ⟨g, hg⟩ := exists_rootPlus_lift i j (ne_of_lt h) r
  exact ⟨g, Subtype.ext hg⟩

end

end GeometricUnity.D7SpinNullFrame
