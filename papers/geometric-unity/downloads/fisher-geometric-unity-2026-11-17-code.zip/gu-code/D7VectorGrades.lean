import D7VectorTensor
import Mathlib.LinearAlgebra.Alternating.Uncurry.Fin

/-!
# Wedge and contraction in all grades of the D₇ vector tensor product

The two maps use exterior multiplication and the split form. Their sections
come from alternating tensor insertion and the invariant metric tensor.
-/

namespace GeometricUnity.D7VectorGrades

open D7Exterior D7Hodge D7VectorTensor TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

abbrev Ext (n : ℕ) := ⋀[ℂ]^n Space
abbrev Product (n : ℕ) := Space ⊗[ℂ] Ext n

def action (n : ℕ) : Representation ℂ splitSpecialOrthogonal (Product n) :=
  vectorAction.tprod (exteriorRepresentation n)

private abbrev pureWedge (n : ℕ) (v : Fin n → Space) : Ext n := exteriorPower.ιMulti ℂ n v

theorem ext_on_wedges {n : ℕ} {W : Type*} [AddCommGroup W] [Module ℂ W]
    {f g : Ext n →ₗ[ℂ] W} (h : ∀ v, f (pureWedge n v) = g (pureWedge n v)) : f = g := by
  apply exteriorPower.linearMap_ext
  exact AlternatingMap.ext h

theorem ext_on_tensor_wedges {n : ℕ} {W : Type*} [AddCommGroup W] [Module ℂ W]
    {f g : Product n →ₗ[ℂ] W}
    (h : ∀ x v, f (x ⊗ₜ[ℂ] pureWedge n v) = g (x ⊗ₜ[ℂ] pureWedge n v)) : f = g := by
  apply TensorProduct.ext'
  intro x u
  have he : f.comp (TensorProduct.mk ℂ Space (Ext n) x) =
      g.comp (TensorProduct.mk ℂ Space (Ext n) x) := ext_on_wedges (h x)
  exact DFunLike.congr_fun he u

theorem wedgeLeft_pure (n : ℕ) (x : Space) (v : Fin n → Space) :
    wedgeLeftLinear n x (pureWedge n v) = pureWedge (n + 1) (Matrix.vecCons x v) := by
  apply Subtype.ext
  change ExteriorAlgebra.ι ℂ x * ExteriorAlgebra.ιMulti ℂ n v =
    ExteriorAlgebra.ιMulti ℂ (n + 1) (Matrix.vecCons x v)
  simp only [ExteriorAlgebra.ιMulti_apply]
  rw [List.ofFn_succ, List.prod_cons]
  rfl

/-- Exterior multiplication `x ⊗ u ↦ x ∧ u`. -/
def wedge (n : ℕ) : Product n →ₗ[ℂ] Ext (n + 1) := TensorProduct.lift (wedgeLeftLinear n)

theorem wedge_pure (n : ℕ) (x : Space) (v : Fin n → Space) :
    wedge n (x ⊗ₜ[ℂ] pureWedge n v) = pureWedge (n + 1) (Matrix.vecCons x v) := by
  rw [wedge, TensorProduct.lift.tmul, wedgeLeft_pure]

private def metricAlternating (n : ℕ) :
    Space →ₗ[ℂ] Space →ₗ[ℂ] (Space [⋀^Fin n]→ₗ[ℂ] Ext n) :=
  LinearMap.mk₂ ℂ (fun x y => splitMetric x y • exteriorPower.ιMulti ℂ n)
    (fun x y z => by simp [add_smul])
    (fun c x y => by simp [smul_smul])
    (fun x y z => by simp [add_smul])
    (fun c x y => by simp [smul_smul])

private theorem metricAlternating_eval (n : ℕ) (x y : Space) (v : Fin n → Space) :
    metricAlternating n x y v = splitForm x y • pureWedge n v := by
  change splitMetric x y • pureWedge n v = _
  rw [splitMetric_apply]

private def contractAlt (n : ℕ) : Space →ₗ[ℂ] (Space [⋀^Fin (n + 1)]→ₗ[ℂ] Ext n) :=
  AlternatingMap.alternatizeUncurryFinLM.comp (metricAlternating n)

def contractLeft (n : ℕ) : Space →ₗ[ℂ] Ext (n + 1) →ₗ[ℂ] Ext n :=
  exteriorPower.alternatingMapLinearEquiv.toLinearMap.comp (contractAlt n)

/-- Metric contraction, with the alternating sign of the removed position. -/
def contract (n : ℕ) : Product (n + 1) →ₗ[ℂ] Ext n := TensorProduct.lift (contractLeft n)

theorem contract_pure (n : ℕ) (x : Space) (v : Fin (n + 1) → Space) :
    contract n (x ⊗ₜ[ℂ] pureWedge (n + 1) v) =
      ∑ i : Fin (n + 1), (-1 : ℤ) ^ i.val •
        (splitForm x (v i) • pureWedge n (i.removeNth v)) := by
  simp only [contract, TensorProduct.lift.tmul, contractLeft, LinearMap.comp_apply, LinearEquiv.coe_coe,
    exteriorPower.alternatingMapLinearEquiv_apply_ιMulti, contractAlt,
    AlternatingMap.alternatizeUncurryFinLM_apply, AlternatingMap.alternatizeUncurryFin_apply,
    metricAlternating_eval]

theorem action_tmul (n : ℕ) (g : splitSpecialOrthogonal) (x : Space) (u : Ext n) :
    action n g (x ⊗ₜ[ℂ] u) = g.val x ⊗ₜ[ℂ] exteriorPower.map n g.val u :=
  TensorProduct.map_tmul _ _ _ _

private theorem comp_vecCons (f : Space →ₗ[ℂ] Space) {n : ℕ} (x : Space) (v : Fin n → Space) :
    f ∘ Matrix.vecCons x v = Matrix.vecCons (f x) (f ∘ v) := by
  funext j
  refine Fin.cases ?_ (fun _ => ?_) j <;> rfl

theorem wedge_natural (n : ℕ) (f : Space →ₗ[ℂ] Space) :
    (wedge n).comp (TensorProduct.map f (exteriorPower.map n f)) =
      (exteriorPower.map (n + 1) f).comp (wedge n) := by
  apply ext_on_tensor_wedges
  intro x v
  simp only [LinearMap.comp_apply, TensorProduct.map_tmul, exteriorPower.map_apply_ιMulti, wedge_pure,
    comp_vecCons]

theorem wedge_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (wedge n).comp (action n g) = (exteriorRepresentation (n + 1) g).comp (wedge n) :=
  wedge_natural n g.val

theorem contract_natural (n : ℕ) (f : Space →ₗ[ℂ] Space)
    (hf : ∀ x y, splitForm (f x) (f y) = splitForm x y) :
    (contract n).comp (TensorProduct.map f (exteriorPower.map (n + 1) f)) =
      (exteriorPower.map n f).comp (contract n) := by
  apply ext_on_tensor_wedges
  intro x v
  simp only [LinearMap.comp_apply, TensorProduct.map_tmul, exteriorPower.map_apply_ιMulti, contract_pure,
    Function.comp_apply, hf, map_sum, map_zsmul, map_smul]
  rfl

theorem contract_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (contract n).comp (action (n + 1) g) = (exteriorRepresentation n g).comp (contract n) :=
  contract_natural n g.val g.prop.2

private def tensorAlternating (n : ℕ) : Space →ₗ[ℂ] (Space [⋀^Fin n]→ₗ[ℂ] Product n) where
  toFun x := (TensorProduct.mk ℂ Space (Ext n) x).compAlternatingMap (exteriorPower.ιMulti ℂ n)
  map_add' x y := by
    apply AlternatingMap.ext
    intro v
    exact TensorProduct.add_tmul _ _ _
  map_smul' c x := by
    apply AlternatingMap.ext
    intro v
    exact (TensorProduct.smul_tmul' c x (pureWedge n v)).symm

private def rawWedgeSection (n : ℕ) : Ext (n + 1) →ₗ[ℂ] Product n :=
  exteriorPower.alternatingMapLinearEquiv (AlternatingMap.alternatizeUncurryFin (tensorAlternating n))

private theorem rawWedgeSection_pure (n : ℕ) (v : Fin (n + 1) → Space) :
    rawWedgeSection n (pureWedge (n + 1) v) =
      ∑ i : Fin (n + 1), (-1 : ℤ) ^ i.val • (v i ⊗ₜ[ℂ] pureWedge n (i.removeNth v)) := by
  rw [rawWedgeSection, exteriorPower.alternatingMapLinearEquiv_apply_ιMulti,
    AlternatingMap.alternatizeUncurryFin_apply]
  rfl

private theorem wedge_rawWedgeSection (n : ℕ) :
    (wedge n).comp (rawWedgeSection n) = (n + 1 : ℂ) • LinearMap.id := by
  apply ext_on_wedges
  intro v
  simp only [LinearMap.comp_apply, rawWedgeSection_pure, map_sum, map_zsmul, wedge_pure,
    LinearMap.smul_apply, LinearMap.id_apply]
  have h (i : Fin (n + 1)) : (-1 : ℤ) ^ i.val • pureWedge (n + 1) (Matrix.vecCons (v i) (i.removeNth v)) =
      pureWedge (n + 1) v := by
    rw [← AlternatingMap.map_insertNth, Fin.insertNth_self_removeNth]
  simp only [h, Finset.sum_const, Finset.card_univ, Fintype.card_fin, ← Nat.cast_smul_eq_nsmul ℂ]
  norm_cast

private theorem rawWedgeSection_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (rawWedgeSection n).comp (exteriorRepresentation (n + 1) g) = (action n g).comp (rawWedgeSection n) := by
  apply ext_on_wedges
  intro v
  change rawWedgeSection n (exteriorPower.map (n + 1) g.val (pureWedge (n + 1) v)) = _
  simp only [exteriorPower.map_apply_ιMulti, rawWedgeSection_pure, LinearMap.comp_apply,
    map_sum, map_zsmul, action_tmul, Function.comp_apply]
  rfl

/-- Section of the wedge map normalized by the number of exterior slots. -/
def includeWedge (n : ℕ) : Ext (n + 1) →ₗ[ℂ] Product n := (n + 1 : ℂ)⁻¹ • rawWedgeSection n

theorem includeWedge_pure (n : ℕ) (v : Fin (n + 1) → Space) :
    includeWedge n (pureWedge (n + 1) v) = (n + 1 : ℂ)⁻¹ •
      ∑ i : Fin (n + 1), (-1 : ℤ) ^ i.val • (v i ⊗ₜ[ℂ] pureWedge n (i.removeNth v)) := by
  rw [includeWedge, LinearMap.smul_apply, rawWedgeSection_pure]

theorem wedge_includeWedge (n : ℕ) : (wedge n).comp (includeWedge n) = LinearMap.id := by
  have hn : (n + 1 : ℂ) ≠ 0 := by exact_mod_cast Nat.succ_ne_zero n
  rw [includeWedge, LinearMap.comp_smul, wedge_rawWedgeSection, smul_smul, inv_mul_cancel₀ hn, one_smul]

theorem includeWedge_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (includeWedge n).comp (exteriorRepresentation (n + 1) g) = (action n g).comp (includeWedge n) := by
  rw [includeWedge, LinearMap.smul_comp, LinearMap.comp_smul, rawWedgeSection_equivariant]

theorem contract_includeWedge (n : ℕ) : (contract n).comp (includeWedge (n + 1)) = 0 := by
  rw [includeWedge, LinearMap.comp_smul]
  suffices (contract n).comp (rawWedgeSection (n + 1)) = 0 by rw [this, smul_zero]
  apply ext_on_wedges
  intro v
  have hs (x y : Space) : metricAlternating n x y = metricAlternating n y x := by
    apply AlternatingMap.ext
    intro w
    rw [metricAlternating_eval, metricAlternating_eval, splitForm_symm x y]
  have h := DFunLike.congr_fun
    (AlternatingMap.alternatizeUncurryFin_alternatizeUncurryFinLM_comp_of_symmetric hs) v
  simpa only [AlternatingMap.alternatizeUncurryFin_apply, LinearMap.comp_apply,
    AlternatingMap.alternatizeUncurryFinLM_apply, metricAlternating_eval, AlternatingMap.zero_apply,
    rawWedgeSection_pure, map_sum, map_zsmul, contract_pure, LinearMap.zero_apply]
    using (show (AlternatingMap.alternatizeUncurryFin
      (AlternatingMap.alternatizeUncurryFinLM.comp (metricAlternating n))) v = 0 from h)

theorem contractLeft_pure (n : ℕ) (x : Space) (v : Fin (n + 1) → Space) :
    contractLeft n x (pureWedge (n + 1) v) =
      ∑ i : Fin (n + 1), (-1 : ℤ) ^ i.val •
        (splitForm x (v i) • pureWedge n (i.removeNth v)) := by
  have h := contract_pure n x v
  rw [contract, TensorProduct.lift.tmul] at h
  exact h

private theorem remove_vecCons {n : ℕ} (i : Fin (n + 1)) (y : Space) (v : Fin (n + 1) → Space) :
    i.succ.removeNth (Matrix.vecCons y v) = Matrix.vecCons y (i.removeNth v) :=
  Fin.cons_comp_succ_succAbove y v i

theorem contract_wedgeLeft (n : ℕ) (x y : Space) (u : Ext (n + 1)) :
    contractLeft (n + 1) x (wedgeLeftLinear (n + 1) y u) =
      splitForm x y • u - wedgeLeftLinear n y (contractLeft n x u) := by
  have h : (contractLeft (n + 1) x).comp (wedgeLeftLinear (n + 1) y) =
      splitForm x y • LinearMap.id - (wedgeLeftLinear n y).comp (contractLeft n x) := by
    apply ext_on_wedges
    intro v
    simp only [LinearMap.comp_apply, LinearMap.sub_apply, LinearMap.smul_apply, LinearMap.id_apply,
      wedgeLeft_pure, contractLeft_pure]
    rw [Fin.sum_univ_succ]
    simp only [Fin.val_zero, pow_zero, one_zsmul, Fin.removeNth_zero,
      Matrix.vecCons, Fin.tail_cons, Fin.val_succ, pow_succ, mul_neg_one,
      neg_zsmul, map_sum, map_zsmul, map_smul]
    rw [sub_eq_add_neg, ← Finset.sum_neg_distrib]
    congr 1
    apply Finset.sum_congr rfl
    intro i _
    rw [wedgeLeft_pure]
    have he := remove_vecCons i y v
    simp only [Matrix.vecCons] at he ⊢
    rw [Fin.cons_succ, he]
  exact DFunLike.congr_fun h u

theorem contract_wedgeLeft_zero (x y : Space) (u : Ext 0) :
    contractLeft 0 x (wedgeLeftLinear 0 y u) = splitForm x y • u := by
  have h : (contractLeft 0 x).comp (wedgeLeftLinear 0 y) = splitForm x y • LinearMap.id := by
    apply ext_on_wedges
    intro v
    simp only [LinearMap.comp_apply, LinearMap.smul_apply, LinearMap.id_apply, wedgeLeft_pure,
      contractLeft_pure]
    rw [Fin.sum_univ_succ]
    simp
  exact DFunLike.congr_fun h u

private theorem wedge_contract_sum (n : ℕ) (u : Ext (n + 1)) :
    (∑ a : Axis, wedgeLeftLinear n (orthBasis a) (contractLeft n (orthBasis a) u)) = (n + 1 : ℂ) • u := by
  have h : (∑ a : Axis, (wedgeLeftLinear n (orthBasis a)).comp (contractLeft n (orthBasis a))) =
      (n + 1 : ℂ) • (LinearMap.id : Ext (n + 1) →ₗ[ℂ] Ext (n + 1)) := by
    apply ext_on_wedges
    intro v
    simp only [LinearMap.sum_apply, LinearMap.comp_apply, LinearMap.smul_apply, LinearMap.id_apply,
      contractLeft_pure, map_sum, map_zsmul, map_smul]
    rw [Finset.sum_comm]
    have he (i : Fin (n + 1)) :
        (∑ a : Axis, splitForm (orthBasis a) (v i) •
          wedgeLeftLinear n (orthBasis a) (pureWedge n (i.removeNth v))) =
        wedgeLeftLinear n (v i) (pureWedge n (i.removeNth v)) := by
      conv_rhs => rw [← orth_sum (v i)]
      simp only [map_sum, map_smul, LinearMap.sum_apply, LinearMap.smul_apply]
    simp only [← Finset.smul_sum, he]
    simp only [wedgeLeft_pure, ← AlternatingMap.map_insertNth,
      Fin.insertNth_self_removeNth, Finset.sum_const, Finset.card_univ, Fintype.card_fin,
      ← Nat.cast_smul_eq_nsmul ℂ]
    norm_cast
  simpa only [LinearMap.sum_apply, LinearMap.comp_apply, LinearMap.smul_apply, LinearMap.id_apply]
    using DFunLike.congr_fun h u

private def rawMetricSection (n : ℕ) : Ext n →ₗ[ℂ] Product (n + 1) :=
  ∑ a : Axis, (TensorProduct.mk ℂ Space (Ext (n + 1)) (orthBasis a)).comp
    (wedgeLeftLinear n (orthBasis a))

private theorem rawMetricSection_apply (n : ℕ) (u : Ext n) : rawMetricSection n u =
    ∑ a : Axis, orthBasis a ⊗ₜ[ℂ] wedgeLeftLinear n (orthBasis a) u := by
  simp only [rawMetricSection, LinearMap.sum_apply, LinearMap.comp_apply, TensorProduct.mk_apply]

private theorem contract_rawMetricSection (n : ℕ) :
    (contract n).comp (rawMetricSection n) = (14 - (n : ℂ)) • LinearMap.id := by
  apply LinearMap.ext
  intro u
  simp only [LinearMap.comp_apply, rawMetricSection_apply, LinearMap.smul_apply, LinearMap.id_apply,
    map_sum, contract, TensorProduct.lift.tmul]
  cases n with
  | zero =>
    simp only [contract_wedgeLeft_zero, orthBasis_pair, if_true, one_smul, Finset.sum_const,
      Finset.card_univ, Fintype.card_fin, Nat.cast_zero, sub_zero, ← Nat.cast_smul_eq_nsmul ℂ]
    norm_cast
  | succ n =>
    simp only [contract_wedgeLeft, Finset.sum_sub_distrib, orthBasis_pair, if_true, one_smul,
      Finset.sum_const, Finset.card_univ, Fintype.card_fin, wedge_contract_sum,
      ← Nat.cast_smul_eq_nsmul ℂ, Nat.cast_succ]
    module

private theorem wedge_rawMetricSection (n : ℕ) : (wedge (n + 1)).comp (rawMetricSection n) = 0 := by
  apply LinearMap.ext
  intro u
  simp only [LinearMap.comp_apply, rawMetricSection_apply, map_sum, wedge, TensorProduct.lift.tmul,
    LinearMap.zero_apply]
  apply Finset.sum_eq_zero
  intro i _
  apply Subtype.ext
  change ExteriorAlgebra.ι ℂ (orthBasis i) * (ExteriorAlgebra.ι ℂ (orthBasis i) * u.val) = 0
  rw [← mul_assoc, ExteriorAlgebra.ι_sq_zero, zero_mul]

theorem wedgeLeft_naturality (n : ℕ) (g : splitSpecialOrthogonal) (x : Space) (u : Ext n) :
    exteriorPower.map (n + 1) g.val (wedgeLeftLinear n x u) =
      wedgeLeftLinear n (g.val x) (exteriorPower.map n g.val u) := by
  have h := DFunLike.congr_fun (wedge_equivariant n g) (x ⊗ₜ[ℂ] u)
  change wedge n (action n g (x ⊗ₜ[ℂ] u)) = exteriorPower.map (n + 1) g.val (wedge n (x ⊗ₜ[ℂ] u)) at h
  simpa only [LinearMap.comp_apply, action_tmul, wedge, TensorProduct.lift.tmul] using h.symm

theorem contractLeft_naturality (n : ℕ) (g : splitSpecialOrthogonal) (x : Space) (u : Ext (n + 1)) :
    exteriorPower.map n g.val (contractLeft n x u) =
      contractLeft n (g.val x) (exteriorPower.map (n + 1) g.val u) := by
  have h := DFunLike.congr_fun (contract_equivariant n g) (x ⊗ₜ[ℂ] u)
  change contract n (action (n + 1) g (x ⊗ₜ[ℂ] u)) = exteriorPower.map n g.val (contract n (x ⊗ₜ[ℂ] u)) at h
  simpa only [LinearMap.comp_apply, action_tmul, contract, TensorProduct.lift.tmul] using h.symm

private def insertMetric {n : ℕ} (u : Ext n) : Space ⊗[ℂ] Space →ₗ[ℂ] Product (n + 1) :=
  TensorProduct.map LinearMap.id ((wedgeLeftLinear n).flip u)

private theorem insertMetric_metricTensor {n : ℕ} (u : Ext n) :
    insertMetric u metricTensor = rawMetricSection n u := by
  simp only [insertMetric, metricTensor, rawMetricSection_apply, map_sum, TensorProduct.map_tmul,
    LinearMap.id_apply, LinearMap.flip_apply]

private theorem rawMetricSection_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (rawMetricSection n).comp (exteriorRepresentation n g) = (action (n + 1) g).comp (rawMetricSection n) := by
  apply LinearMap.ext
  intro u
  have h : (action (n + 1) g).comp (insertMetric u) =
      (insertMetric (exteriorPower.map n g.val u)).comp (TensorProduct.map g.val g.val) := by
    apply TensorProduct.ext'
    intro x y
    simp only [LinearMap.comp_apply, insertMetric, TensorProduct.map_tmul, LinearMap.id_apply,
      LinearMap.flip_apply, action_tmul, wedgeLeft_naturality]
  have he := DFunLike.congr_fun h metricTensor
  change (rawMetricSection n) (exteriorPower.map n g.val u) = action (n + 1) g (rawMetricSection n u)
  simpa only [LinearMap.comp_apply, metricTensor_invariant, insertMetric_metricTensor] using he.symm

/-- The section through the metric tensor. The normalization is nonzero for
`n < 14`, which covers tensor input degrees one through fourteen. -/
def includeMetric (n : ℕ) : Ext n →ₗ[ℂ] Product (n + 1) := (14 - (n : ℂ))⁻¹ • rawMetricSection n

theorem includeMetric_apply (n : ℕ) (u : Ext n) : includeMetric n u =
    (14 - (n : ℂ))⁻¹ • ∑ i : Axis, orthBasis i ⊗ₜ[ℂ] wedgeLeftLinear n (orthBasis i) u := by
  rw [includeMetric, LinearMap.smul_apply, rawMetricSection_apply]

theorem contract_includeMetric (n : ℕ) (hn : n < 14) : (contract n).comp (includeMetric n) = LinearMap.id := by
  have h : (14 - (n : ℂ)) ≠ 0 := sub_ne_zero.mpr (by exact_mod_cast (Nat.ne_of_lt hn).symm)
  rw [includeMetric, LinearMap.comp_smul, contract_rawMetricSection, smul_smul, inv_mul_cancel₀ h, one_smul]

theorem wedge_includeMetric (n : ℕ) : (wedge (n + 1)).comp (includeMetric n) = 0 := by
  rw [includeMetric, LinearMap.comp_smul, wedge_rawMetricSection, smul_zero]

theorem includeMetric_equivariant (n : ℕ) (g : splitSpecialOrthogonal) :
    (includeMetric n).comp (exteriorRepresentation n g) = (action (n + 1) g).comp (includeMetric n) := by
  rw [includeMetric, LinearMap.smul_comp, LinearMap.comp_smul, rawMetricSection_equivariant]

/-- The residual representation in input degree `n + 1`. -/
def jointKernel (n : ℕ) : Submodule ℂ (Product (n + 1)) := (wedge (n + 1)).ker ⊓ (contract n).ker

theorem mem_jointKernel (n : ℕ) (x : Product (n + 1)) :
    x ∈ jointKernel n ↔ wedge (n + 1) x = 0 ∧ contract n x = 0 := by
  simp [jointKernel, LinearMap.mem_ker]

theorem jointKernel_invariant (n : ℕ) (g : splitSpecialOrthogonal) (x : Product (n + 1))
    (hx : x ∈ jointKernel n) : action (n + 1) g x ∈ jointKernel n := by
  rw [mem_jointKernel] at hx ⊢
  have hw := DFunLike.congr_fun (wedge_equivariant (n + 1) g) x
  have hc := DFunLike.congr_fun (contract_equivariant n g) x
  simp only [LinearMap.comp_apply, hx.1, hx.2, map_zero] at hw hc
  exact ⟨hw, hc⟩

def jointKernelAction (n : ℕ) : Representation ℂ splitSpecialOrthogonal (jointKernel n) :=
  (action (n + 1)).subrepresentation (jointKernel n) (fun g x hx => jointKernel_invariant n g x hx)

private theorem wedge_section_eval (n : ℕ) (x : Ext (n + 1)) : wedge n (includeWedge n x) = x :=
  LinearMap.congr_fun (wedge_includeWedge n) x

private theorem contract_wedge_section_eval (n : ℕ) (x : Ext (n + 2)) : contract n (includeWedge (n + 1) x) = 0 :=
  LinearMap.congr_fun (contract_includeWedge n) x

private theorem contract_metric_section_eval (n : ℕ) (hn : n < 14) (x : Ext n) :
    contract n (includeMetric n x) = x := by
  have h := LinearMap.congr_fun (contract_includeMetric n hn) x
  simpa only [LinearMap.comp_apply, LinearMap.id_apply] using h

private theorem wedge_metric_section_eval (n : ℕ) (x : Ext n) : wedge (n + 1) (includeMetric n x) = 0 := by
  have h := LinearMap.congr_fun (wedge_includeMetric n) x
  simpa only [LinearMap.comp_apply, LinearMap.zero_apply] using h

private def remainder (n : ℕ) : Product (n + 1) →ₗ[ℂ] Product (n + 1) :=
  LinearMap.id - (includeWedge (n + 1)).comp (wedge (n + 1)) - (includeMetric n).comp (contract n)

private theorem remainder_mem (n : ℕ) (hn : n < 14) (x : Product (n + 1)) : remainder n x ∈ jointKernel n := by
  simp [mem_jointKernel, remainder, wedge_section_eval, wedge_metric_section_eval,
    contract_wedge_section_eval, contract_metric_section_eval n hn]

def splitLinear (n : ℕ) (hn : n < 14) : Product (n + 1) ≃ₗ[ℂ] Ext (n + 2) × Ext n × jointKernel n where
  toFun x := (wedge (n + 1) x, contract n x, ⟨remainder n x, remainder_mem n hn x⟩)
  invFun p := includeWedge (n + 1) p.1 + includeMetric n p.2.1 + p.2.2.val
  left_inv x := by
    change includeWedge (n + 1) (wedge (n + 1) x) + includeMetric n (contract n x) + remainder n x = x
    simp only [remainder, LinearMap.sub_apply, LinearMap.id_apply, LinearMap.comp_apply]
    abel
  right_inv p := by
    rcases p with ⟨u, v, w⟩
    have hw := (mem_jointKernel n w.val).mp w.prop
    refine Prod.ext ?_ (Prod.ext ?_ (Subtype.ext ?_))
    · change wedge (n + 1) (includeWedge (n + 1) u + includeMetric n v + w.val) = u
      simp [wedge_section_eval, wedge_metric_section_eval, hw.1]
    · change contract n (includeWedge (n + 1) u + includeMetric n v + w.val) = v
      simp [contract_wedge_section_eval, contract_metric_section_eval n hn, hw.2]
    · change remainder n (includeWedge (n + 1) u + includeMetric n v + w.val) = w.val
      simp [remainder, wedge_section_eval, wedge_metric_section_eval, contract_wedge_section_eval,
        contract_metric_section_eval n hn, hw.1, hw.2]
      abel
  map_add' x y := Prod.ext ((wedge (n + 1)).map_add x y)
    (Prod.ext ((contract n).map_add x y) (Subtype.ext ((remainder n).map_add x y)))
  map_smul' c x := Prod.ext ((wedge (n + 1)).map_smul c x)
    (Prod.ext ((contract n).map_smul c x) (Subtype.ext ((remainder n).map_smul c x)))

private theorem splitLinear_equivariant (n : ℕ) (hn : n < 14) (g : splitSpecialOrthogonal) (x : Product (n + 1)) :
    splitLinear n hn (action (n + 1) g x) =
      ((exteriorRepresentation (n + 2)).prod ((exteriorRepresentation n).prod (jointKernelAction n))) g
        (splitLinear n hn x) := by
  have hw := DFunLike.congr_fun (wedge_equivariant (n + 1) g) x
  have hc := DFunLike.congr_fun (contract_equivariant n g) x
  simp only [LinearMap.comp_apply] at hw hc
  refine Prod.ext hw (Prod.ext hc (Subtype.ext ?_))
  change remainder n (action (n + 1) g x) = action (n + 1) g (remainder n x)
  simp only [remainder, LinearMap.sub_apply, LinearMap.comp_apply, LinearMap.id_apply, hw, hc, map_sub]
  have h₁ := DFunLike.congr_fun (includeWedge_equivariant (n + 1) g) (wedge (n + 1) x)
  have h₂ := DFunLike.congr_fun (includeMetric_equivariant n g) (contract n x)
  simp only [LinearMap.comp_apply] at h₁ h₂
  rw [h₁, h₂]

/-- Equivariant wedge, contraction, and joint-kernel decomposition in every
positive exterior input degree up to fourteen. -/
def splitRepresentation (n : ℕ) (hn : n < 14) :
    (action (n + 1)).Equiv ((exteriorRepresentation (n + 2)).prod
      ((exteriorRepresentation n).prod (jointKernelAction n))) :=
  Representation.Equiv.mk (splitLinear n hn) (fun g => LinearMap.ext (splitLinear_equivariant n hn g))

set_option backward.isDefEq.respectTransparency false in
theorem jointKernel_finrank (n : ℕ) (hn : n < 14) : Module.finrank ℂ (jointKernel n) =
    14 * Nat.choose 14 (n + 1) - Nat.choose 14 (n + 2) - Nat.choose 14 n := by
  let : Module.Free ℂ (↥(jointKernel n)) := Module.Free.of_divisionRing ℂ (↥(jointKernel n))
  have h := (splitLinear n hn).finrank_eq
  rw [Module.finrank_tensorProduct, Module.finrank_prod, Module.finrank_prod,
    exteriorPower.finrank_eq, exteriorPower.finrank_eq, exteriorPower.finrank_eq,
    Module.finrank_pi, Fintype.card_fin] at h
  omega

/-- Degree zero gives the vector representation via multiplication by the scalar wedge. -/
def degreeZero : (action 0).Equiv vectorAction := by
  let f : Product 0 ≃ₗ[ℂ] Space :=
    (TensorProduct.congr (LinearEquiv.refl ℂ Space) (exteriorPower.zeroEquiv ℂ Space)).trans
      (TensorProduct.rid ℂ Space)
  refine Representation.Equiv.mk f fun g => TensorProduct.ext' fun x u => ?_
  have h := DFunLike.congr_fun (exteriorPower.zeroEquiv_naturality g.val) u
  change exteriorPower.zeroEquiv ℂ Space (exteriorPower.map 0 g.val u) = exteriorPower.zeroEquiv ℂ Space u at h
  simp only [LinearMap.comp_apply, LinearEquiv.coe_coe, f, action_tmul, LinearEquiv.trans_apply,
    TensorProduct.congr_tmul, LinearEquiv.refl_apply, TensorProduct.rid_tmul, map_smul, h]
  rfl

/-- In degree two, applying the canonical degree-one identification to the
uniform contraction gives the trace already used in the hook proof. -/
theorem degreeTwo_contract : (exteriorPower.oneEquiv ℂ Space).toLinearMap.comp (contract 1) = trace := by
  apply ext_on_tensor_wedges
  intro x v
  have hv : (![v 0, v 1] : Fin 2 → Space) = v := by funext i; fin_cases i <;> rfl
  simp only [LinearMap.comp_apply, contract_pure, LinearEquiv.coe_coe, map_sum, map_zsmul, map_smul,
    exteriorPower.oneEquiv_ιMulti]
  conv_rhs => rw [← hv]
  change _ = trace (x ⊗ₜ[ℂ] wedgeTwo (v 0) (v 1))
  rw [trace_pure]
  simp [Fin.removeNth, Fin.succAbove, sub_eq_add_neg]

theorem degreeTwo_jointKernel : jointKernel 1 = hook := by
  ext x
  rw [mem_jointKernel, mem_hook]
  have ht := DFunLike.congr_fun degreeTwo_contract x
  change exteriorPower.oneEquiv ℂ Space (contract 1 x) = trace x at ht
  rw [← ht, (exteriorPower.oneEquiv ℂ Space).map_eq_zero_iff]
  rfl

private abbrev firstAxis : Space := axisBasis (plusAxis 0)

/-- The tensor of the first positive null axis with a null-basis wedge. -/
def nullTensor {k : ℕ} (s : Index k) : Product k := firstAxis ⊗ₜ[ℂ] axisBasis.exteriorPower k s

theorem nullTensor_ne_zero {k : ℕ} (s : Index k) : nullTensor s ≠ 0 := by
  simpa only [nullTensor, Module.Basis.tensorProduct_apply'] using
    (axisBasis.tensorProduct (axisBasis.exteriorPower k)).ne_zero (plusAxis 0, s)

theorem nullTensor_mem_jointKernel (n : ℕ) (s : Index (n + 1)) (hp : plusAxis 0 ∈ s.val)
    (hm : minusAxis 0 ∉ s.val) : nullTensor s ∈ jointKernel n := by
  rw [mem_jointKernel]
  let a := Set.powersetCard.ofFinEmbEquiv.symm s
  have hmem (i : Fin (n + 1)) : a i ∈ s.val := Finset.orderEmbOfFin_mem s.val s.prop i
  have hb : nullTensor s = firstAxis ⊗ₜ[ℂ] pureWedge (n + 1) (axisBasis ∘ a) := by
    rw [nullTensor, exteriorPower.basis_apply, exteriorPower.ιMulti_family]
  rw [hb]
  constructor
  · rw [wedge_pure]
    change plusAxis 0 ∈ s at hp
    obtain ⟨i, hi⟩ := (Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem s _).mpr hp
    change a i = plusAxis 0 at hi
    exact (exteriorPower.ιMulti ℂ (n + 2)).map_eq_zero_of_eq _ (i := 0) (j := i.succ)
      (show firstAxis = axisBasis (a i) by rw [hi]) (Ne.symm (Fin.succ_ne_zero i))
  · rw [contract_pure]
    apply Finset.sum_eq_zero
    intro i _
    have hi : a i ≠ minusAxis 0 := fun e => hm (e ▸ hmem i)
    have h : splitForm firstAxis (axisBasis (a i)) = 0 := by
      rw [← splitMetric_apply, splitMetric_null_plus, Module.Basis.coord_apply,
        Module.Basis.repr_self, Finsupp.single_apply, if_neg hi]
    simp only [Function.comp_apply, h, zero_smul, smul_zero]

def nullTensorWeight {k : ℕ} (s : Index k) (i : Pair) : ℤ :=
  axisWeight (plusAxis 0) i + subsetWeight s.val i

theorem nullTensor_torus {k : ℕ} (s : Index k) (t : Pair → ℂˣ) :
    action k (torusElement t) (nullTensor s) =
      ((∏ i : Pair, t i ^ nullTensorWeight s i : ℂˣ) : ℂ) • nullTensor s := by
  rw [nullTensor, action_tmul]
  change torus t firstAxis ⊗ₜ[ℂ] exteriorPower.map k (torus t) (axisBasis.exteriorPower k s) = _
  rw [torus_axis, torus_exterior, smul_tmul_smul]
  congr 1
  rw [← Units.val_mul]
  congr 1
  have h := subset_character t ({plusAxis 0} : Finset Axis)
  rw [Finset.prod_singleton] at h
  simp only [subsetWeight, Finset.sum_singleton] at h
  simp only [nullTensorWeight, zpow_add, Finset.prod_mul_distrib, ← h]

private theorem nullTensor_fixed {k : ℕ} (s : Index k) (g : splitSpecialOrthogonal)
    (hx : g.val firstAxis = firstAxis)
    (hw : exteriorRepresentation k g (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s) :
    action k g (nullTensor s) = nullTensor s := by
  rw [nullTensor, action_tmul, hx]
  change firstAxis ⊗ₜ[ℂ] exteriorRepresentation k g (axisBasis.exteriorPower k s) = _
  rw [hw]

/-- Positive input degrees with a nontrivial joint kernel. -/
def internalGrade (n : Fin 13) : Fin 15 := ⟨n.val + 1, by omega⟩

theorem internalGrade_candidate (n : Fin 13) :
    nullTensor (highestPlus (internalGrade n)) ∈ jointKernel n.val := by
  have hp : ∀ n : Fin 13, plusAxis 0 ∈ (highestPlus (internalGrade n)).val := by decide +kernel
  have hm : ∀ n : Fin 13, minusAxis 0 ∉ (highestPlus (internalGrade n)).val := by decide +kernel
  exact nullTensor_mem_jointKernel n.val (highestPlus (internalGrade n)) (hp n) (hm n)

theorem internalGrade_label : ∀ n : Fin 13,
    List.ofFn (nullTensorWeight (highestPlus (internalGrade n))) =
      D7Counts.nu (min (n.val + 1) (13 - n.val)) := by
  decide +kernel

theorem internalGrade_candidate_fixed (n : Fin 13) (c : ℂ) (i j : Pair) (h : i < j) :
    action (n.val + 1) (rootMinusElement c i j h) (nullTensor (highestPlus (internalGrade n))) =
        nullTensor (highestPlus (internalGrade n)) ∧
      action (n.val + 1) (rootPlusElement c i j h) (nullTensor (highestPlus (internalGrade n))) =
        nullTensor (highestPlus (internalGrade n)) := by
  have ha := firstAxis_root_fixed c i j h
  have hw := highestPlus_root_fixed (internalGrade n) c i j h
  exact ⟨nullTensor_fixed _ _ ha.1 hw.1, nullTensor_fixed _ _ ha.2 hw.2⟩

theorem middleMinus_candidate : nullTensor lastMinus ∈ jointKernel 6 :=
  nullTensor_mem_jointKernel 6 lastMinus (by decide +kernel) (by decide +kernel)

theorem middleMinus_label : List.ofFn (nullTensorWeight lastMinus) = D7Counts.nuMinus := by
  decide +kernel

theorem middleMinus_candidate_fixed (c : ℂ) (i j : Pair) (h : i < j) :
    action 7 (rootMinusElement c i j h) (nullTensor lastMinus) = nullTensor lastMinus ∧
      action 7 (rootPlusElement c i j h) (nullTensor lastMinus) = nullTensor lastMinus := by
  have ha := firstAxis_root_fixed c i j h
  have hw := lastMinus_root_fixed c i j h
  exact ⟨nullTensor_fixed _ _ ha.1 hw.1, nullTensor_fixed _ _ ha.2 hw.2⟩

/-- The numerical Weyl products of the candidate labels exhaust the rank of
the joint kernel. Degree seven contributes both signed labels. -/
theorem candidate_products_eq_jointKernel_finrank (n : Fin 13) :
    (Module.finrank ℂ (jointKernel n.val) : ℚ) =
      weylProduct (D7Counts.nu (min (n.val + 1) (13 - n.val))) +
        (if n.val = 6 then weylProduct D7Counts.nuMinus else 0) := by
  rw [jointKernel_finrank n.val (by omega)]
  have h : ∀ n : Fin 13,
      ((14 * Nat.choose 14 (n.val + 1) - Nat.choose 14 (n.val + 2) - Nat.choose 14 n.val : ℕ) : ℚ) =
        weylProduct (D7Counts.nu (min (n.val + 1) (13 - n.val))) +
          (if n.val = 6 then weylProduct D7Counts.nuMinus else 0) := by decide +kernel
  exact h n

set_option maxRecDepth 4096 in
set_option maxHeartbeats 2000000 in
/-- The signed vector-product table in all fifteen degrees. The exterior
labels are those of the two split summands, and the residual labels are the
checked highest-weight candidates. -/
theorem vector_grade_multiplicities : ∀ k : Fin 15,
    D7Counts.gradeMultiplicities 1 k.val = D7Counts.tally
      ((if k.val = 0 then D7Counts.gradeWeights 1 else
        D7Counts.gradeWeights (k.val + 1) ++ D7Counts.gradeWeights (k.val - 1) ++
          (if k.val = 14 then [] else if k.val = 7 then [D7Counts.nu 7, D7Counts.nuMinus]
            else [D7Counts.nu (min k.val (14 - k.val))])).map (·, 1)) := by
  decide +kernel

end
end GeometricUnity.D7VectorGrades
