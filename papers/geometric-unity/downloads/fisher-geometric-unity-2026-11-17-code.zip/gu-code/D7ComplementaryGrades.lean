import D7GradeIrreducible
import D7MiddleTensor

/-!
# Hodge duality for complementary degrees

The determinant metric and oriented volume determine the Hodge map. On the
orthogonal wedge basis it takes a subset to its complement with the volume
sign. The induced tensor equivalence restricts to the joint kernels in
complementary non-middle degrees.
-/

namespace GeometricUnity.D7ComplementaryGrades

open D7Exterior D7Hodge D7Irreducible D7VectorGrades D7GradeIrreducible TensorProduct
open D7MiddleTensor (multiply multiply_pure)
open scoped TensorProduct

noncomputable section

private abbrev pure (k : ℕ) (v : Fin k → Space) : Ext k := exteriorPower.ιMulti ℂ k v

private def complementIndex {m n : ℕ} (h : m + n = 14) (s : Index m) : Index n :=
  ⟨s.valᶜ, by
    change (s.valᶜ).card = n
    rw [Finset.card_compl, Fintype.card_fin, s.prop]
    omega⟩

private def complementEquiv {m n : ℕ} (h : m + n = 14) : Index m ≃ Index n where
  toFun := complementIndex h
  invFun := complementIndex ((Nat.add_comm n m).trans h)
  left_inv s := Subtype.ext (compl_compl s.val)
  right_inv s := Subtype.ext (compl_compl s.val)

private theorem disjoint_iff_complement {m n : ℕ} (h : m + n = 14) (s : Index m) (t : Index n) :
    Disjoint s.val t.val ↔ t = complementEquiv h s := by
  constructor
  · intro hd
    apply Subtype.ext
    apply Finset.eq_of_subset_of_card_le
    · intro a ha
      exact Finset.mem_compl.mpr (Finset.disjoint_left.mp hd.symm ha)
    · exact Nat.le_of_eq ((complementEquiv h s).prop.trans t.prop.symm)
  · rintro rfl
    exact disjoint_compl_right

private def topVolume {k : ℕ} (h : k = 14) : Ext k →ₗ[ℂ] ℂ := by
  subst k
  exact volume

private theorem topVolume_basis {k : ℕ} (h : k = 14) (s : Index k) : topVolume h (basis k s) = 1 := by
  subst k
  rw [exteriorPower.basis_apply]
  exact volume_top s

private theorem topVolume_map {k : ℕ} (h : k = 14) (g : splitSpecialOrthogonal) (v : Fin k → Space) :
    topVolume h (pure k (g.val ∘ v)) = topVolume h (pure k v) := by
  subst k
  simp only [topVolume, volume, exteriorPower.alternatingMapLinearEquiv_apply_ιMulti,
    Module.Basis.det_comp, g.prop.1, one_mul]

/-- Oriented top coefficient of a product of complementary exterior powers. -/
def pairing {m n : ℕ} (h : m + n = 14) : Ext m →ₗ[ℂ] Ext n →ₗ[ℂ] ℂ :=
  (multiply m n).compr₂ₛₗ (topVolume h)

theorem append_map {m n : ℕ} (f : Space →ₗ[ℂ] Space) (u : Fin m → Space) (v : Fin n → Space) :
    Fin.append (f ∘ u) (f ∘ v) = f ∘ Fin.append u v := by
  funext j
  refine Fin.addCases ?_ ?_ j
  · intro i; rw [Function.comp_apply, Fin.append_left, Fin.append_left]; rfl
  · intro i; rw [Function.comp_apply, Fin.append_right, Fin.append_right]; rfl

private theorem pairing_invariant {m n : ℕ} (h : m + n = 14) (g : splitSpecialOrthogonal)
    (x : Ext m) (y : Ext n) :
    pairing h (exteriorRepresentation m g x) (exteriorRepresentation n g y) = pairing h x y := by
  let A := exteriorRepresentation m g
  let B := exteriorRepresentation n g
  have he : (((pairing h).comp A).flip.comp B).flip = pairing h := by
    apply ext_on_wedges
    intro u
    apply ext_on_wedges
    intro v
    change pairing h (exteriorPower.map m g.val (pure m u)) (exteriorPower.map n g.val (pure n v)) = _
    simp only [exteriorPower.map_apply_ιMulti, pairing, LinearMap.compr₂ₛₗ_apply,
      multiply_pure, append_map, topVolume_map]
  exact DFunLike.congr_fun (DFunLike.congr_fun he x) y

theorem metric_map_invariant (k : ℕ) (f : Space →ₗ[ℂ] Space)
    (hf : ∀ x y, splitForm (f x) (f y) = splitForm x y) (x y : Ext k) :
    exteriorMetric k (exteriorPower.map k f x) (exteriorPower.map k f y) = exteriorMetric k x y := by
  let A := exteriorPower.map k f
  have he : (((exteriorMetric k).comp A).flip.comp A).flip = exteriorMetric k := by
    apply ext_on_wedges
    intro u
    apply ext_on_wedges
    intro v
    change exteriorMetric k (exteriorPower.map k f (pure k u)) (exteriorPower.map k f (pure k v)) = _
    simp only [exteriorPower.map_apply_ιMulti, exteriorMetric_pure, Function.comp_apply, hf]
  exact DFunLike.congr_fun (DFunLike.congr_fun he x) y

theorem metric_invariant (k : ℕ) (g : splitSpecialOrthogonal) (x y : Ext k) :
    exteriorMetric k (exteriorRepresentation k g x) (exteriorRepresentation k g y) = exteriorMetric k x y :=
  metric_map_invariant k g.val g.prop.2 x y

private theorem pairing_zero {m n : ℕ} (h : m + n = 14) (s : Index m) (t : Index n)
    (ht : t ≠ complementEquiv h s) : pairing h (basis m s) (basis n t) = 0 := by
  have hz : multiply m n (basis m s) (basis n t) = 0 := by
    apply Subtype.ext
    change (basis m s).val * (basis n t).val = 0
    simpa only [exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe] using
      ExteriorAlgebra.ιMulti_family_mul_of_not_disjoint ℂ orthBasis s t (mt (disjoint_iff_complement h s t).mp ht)
  change topVolume h (multiply m n (basis m s) (basis n t)) = 0
  rw [hz, map_zero]

private def scale {m n : ℕ} (h : m + n = 14) (s : Index m) : ℂ :=
  pairing h (basis m s) (basis n (complementEquiv h s))

private theorem scale_ne_zero {m n : ℕ} (h : m + n = 14) (s : Index m) : scale h s ≠ 0 := by
  let t := complementEquiv h s
  have hd : Disjoint s.val t.val := disjoint_compl_right
  let p := (Set.powersetCard.permOfDisjoint hd).sign
  have hm : multiply m n (basis m s) (basis n t) =
      p • basis (m + n) (Set.powersetCard.disjUnion hd) := by
    apply Subtype.ext
    change (basis m s).val * (basis n t).val =
      (p • basis (m + n) (Set.powersetCard.disjUnion hd) : Ext (m + n)).val
    simpa only [exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe,
      Submodule.coe_smul_of_tower, p] using
      ExteriorAlgebra.ιMulti_family_mul_of_disjoint ℂ orthBasis s t hd
  change topVolume h (multiply m n (basis m s) (basis n t)) ≠ 0
  rw [hm]
  rcases Int.units_eq_one_or p with hp | hp
  · rw [hp, one_smul, topVolume_basis]
    exact one_ne_zero
  · have hneg : (-1 : ℤˣ) • basis (m + n) (Set.powersetCard.disjUnion hd) =
        -basis (m + n) (Set.powersetCard.disjUnion hd) := by simp
    rw [hp, hneg, map_neg, topVolume_basis]
    norm_num

/-- The Hodge linear equivalence sends each coordinate wedge to its signed
complement. Both degrees use the same orthonormal orientation. -/
def starEquiv {m n : ℕ} (h : m + n = 14) : Ext m ≃ₗ[ℂ] Ext n :=
  (basis m).equiv ((basis n).unitsSMul fun t =>
    Units.mk0 (scale h ((complementEquiv h).symm t)) (scale_ne_zero h _)) (complementEquiv h)

private theorem starEquiv_basis {m n : ℕ} (h : m + n = 14) (s : Index m) :
    starEquiv h (basis m s) = scale h s • basis n (complementEquiv h s) := by
  simp only [starEquiv, Module.Basis.equiv_apply, Module.Basis.unitsSMul_apply,
    Equiv.symm_apply_apply, Units.smul_def, Units.val_mk0]

theorem starEquiv_complement {m n : ℕ} (h : m + n = 14) (s : Index m) :
    ∃ t : Index n, t.val = s.valᶜ ∧ ∃ a : ℂ, a ≠ 0 ∧ starEquiv h (basis m s) = a • basis n t :=
  ⟨complementEquiv h s, rfl, scale h s, scale_ne_zero h s, starEquiv_basis h s⟩

theorem metric_starEquiv {m n : ℕ} (h : m + n = 14) (x : Ext m) (y : Ext n) :
    exteriorMetric n (starEquiv h x) y = pairing h x y := by
  have he : (exteriorMetric n).comp (starEquiv h).toLinearMap = pairing h := by
    apply (basis m).ext
    intro s
    apply (basis n).ext
    intro t
    change exteriorMetric n (starEquiv h (basis m s)) (basis n t) = _
    simp only [starEquiv_basis, map_smul, LinearMap.smul_apply, exteriorMetric_axis,
      Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
    by_cases ht : t = complementEquiv h s
    · subst t
      simp [scale]
    · rw [if_neg ht, smul_zero, pairing_zero h s t ht]
  exact DFunLike.congr_fun (DFunLike.congr_fun he x) y

theorem exterior_surjective (n : ℕ) (g : splitSpecialOrthogonal) :
    Function.Surjective (exteriorRepresentation n g) := by
  let e := LinearMap.equivOfIsUnitDet (g.prop.1 ▸ isUnit_one : IsUnit g.val.det)
  have he : e.toLinearMap = g.val := LinearMap.coe_equivOfIsUnitDet _
  intro w
  refine ⟨exteriorPower.map n e.symm.toLinearMap w, ?_⟩
  change (exteriorPower.map n g.val).comp (exteriorPower.map n e.symm.toLinearMap) w = w
  rw [← exteriorPower.map_comp, ← he, LinearEquiv.comp_coe, LinearEquiv.symm_trans_self,
    LinearEquiv.refl_toLinearMap, exteriorPower.map_id, LinearMap.id_apply]

theorem starEquiv_equivariant {m n : ℕ} (h : m + n = 14) (g : splitSpecialOrthogonal) (x : Ext m) :
    starEquiv h (exteriorRepresentation m g x) = exteriorRepresentation n g (starEquiv h x) := by
  apply exteriorMetric_injective n
  apply LinearMap.ext
  intro y
  obtain ⟨w, rfl⟩ := exterior_surjective n g y
  rw [metric_starEquiv, pairing_invariant, metric_invariant, metric_starEquiv]

/-- Hodge equivalence of the complementary exterior representations. -/
def exteriorDuality {m n : ℕ} (h : m + n = 14) :
    (exteriorRepresentation m).Equiv (exteriorRepresentation n) :=
  Representation.Equiv.mk (starEquiv h) (fun g => LinearMap.ext (starEquiv_equivariant h g))

/-- Hodge equivalence tensoring on the left by the vector representation. -/
def tensorDuality {m n : ℕ} (h : m + n = 14) : (action m).Equiv (action n) :=
  Representation.Equiv.mk (TensorProduct.congr (LinearEquiv.refl ℂ Space) (starEquiv h)) (by
    intro g
    apply TensorProduct.ext'
    intro x u
    simp only [LinearMap.comp_apply, action_tmul, LinearEquiv.coe_coe, TensorProduct.congr_tmul,
      LinearEquiv.refl_apply]
    congr 1
    exact starEquiv_equivariant h g u)

/-- The degree-fourteen vector product is another copy of the vector action. -/
def degreeFourteen : (action 14).Equiv D7VectorTensor.vectorAction :=
  (tensorDuality (m := 14) (n := 0) (by decide)).trans degreeZero

private theorem pairing_middle (x y : Mid) : pairing (m := 7) (n := 7) (by decide) x y = volumePair x y := by
  have he : pairing (m := 7) (n := 7) (by decide) = volumePair := by
    apply ext_on_wedges
    intro u
    apply ext_on_wedges
    intro v
    simp only [pairing, LinearMap.compr₂ₛₗ_apply, multiply_pure, topVolume, volume,
      exteriorPower.alternatingMapLinearEquiv_apply_ιMulti, volumePair_pure]
  exact DFunLike.congr_fun (DFunLike.congr_fun he x) y

/-- In degree seven the general Hodge map has the same orientation as the
middle-degree star used to define the two signed sectors. -/
theorem starEquiv_middle (x : Mid) : starEquiv (m := 7) (n := 7) (by decide) x = star x := by
  apply exteriorMetric_injective 7
  apply LinearMap.ext
  intro y
  rw [metric_starEquiv, pairing_middle]
  exact (metric_star x y).symm

private abbrev kernelRank (n : ℕ) :=
  14 * Nat.choose 14 (n + 1) - Nat.choose 14 (n + 2) - Nat.choose 14 n

private theorem complementary_ranks :
    ∀ p q : Fin 13, (p.val + 1) + (q.val + 1) = 14 →
      Nat.choose 14 (q.val + 2) < kernelRank p.val ∧ Nat.choose 14 q.val < kernelRank p.val ∧
        kernelRank p.val = kernelRank q.val := by
  decide +kernel

private theorem ext_finrank (k : ℕ) : Module.finrank ℂ (Ext k) = Nat.choose 14 k := by
  rw [exteriorPower.finrank_eq, Module.finrank_pi, Fintype.card_fin]

private theorem intertwiner_zero_of_small_target {U W : Type*}
    [AddCommGroup U] [AddCommGroup W] [Module ℂ U] [Module ℂ W] [Module.Finite ℂ W]
    {ρ : Representation ℂ splitSpecialOrthogonal U} {σ : Representation ℂ splitSpecialOrthogonal W}
    (hρ : ρ.IsIrreducible) (f : Representation.IntertwiningMap ρ σ)
    (h : Module.finrank ℂ W < Module.finrank ℂ U) (x : U) : f x = 0 := by
  rcases hρ.eq_bot_or_eq_top f.ker with hb | ht
  · have hf : f.toLinearMap.ker = ⊥ := congrArg Subrepresentation.toSubmodule hb
    exact (not_le_of_gt h (LinearMap.finrank_le_finrank_of_injective (LinearMap.ker_eq_bot.mp hf))).elim
  · have hx : x ∈ f.ker := by rw [ht]; exact Submodule.mem_top
    exact (Representation.IntertwiningMap.mem_ker ρ σ f x).mp hx

set_option backward.isDefEq.respectTransparency false in
private theorem projectedDual_zero (p q : Fin 13) (h : (p.val + 1) + (q.val + 1) = 14) (hp : p.val ≠ 6)
    {W : Type} [AddCommGroup W] [Module ℂ W] [Module.Finite ℂ W]
    (σ : Representation ℂ splitSpecialOrthogonal W) (F : Product (q.val + 1) →ₗ[ℂ] W)
    (hF : ∀ g, F.comp (action (q.val + 1) g) = (σ g).comp F)
    (hd : Module.finrank ℂ W < Module.finrank ℂ (jointKernel p.val)) (x : ↥(jointKernel p.val)) :
    F ((tensorDuality h).toLinearEquiv x.val) = 0 := by
  let d := tensorDuality h
  let f := (F.comp d.toLinearMap).comp (jointKernel p.val).subtype
  have hf (g : splitSpecialOrthogonal) (y : ↥(jointKernel p.val)) :
      f (jointKernelAction p.val g y) = σ g (f y) := by
    change F (d.toLinearEquiv (action (p.val + 1) g y.val)) = σ g (F (d.toLinearEquiv y.val))
    have he : d.toLinearEquiv (action (p.val + 1) g y.val) = action (q.val + 1) g (d.toLinearEquiv y.val) :=
      Representation.IntertwiningMap.isIntertwining (action (p.val + 1)) (action (q.val + 1))
        d.toIntertwiningMap g y.val
    rw [he]
    exact DFunLike.congr_fun (hF g) (d.toLinearEquiv y.val)
  exact intertwiner_zero_of_small_target (jointKernel_isIrreducible p hp)
    (f.intertwiningMap_of_isIntertwiningMap _ σ hf) hd x

private theorem tensorDual_mem_jointKernel (p q : Fin 13) (h : (p.val + 1) + (q.val + 1) = 14)
    (hp : p.val ≠ 6) (x : ↥(jointKernel p.val)) :
    (tensorDuality h).toLinearEquiv x.val ∈ jointKernel q.val := by
  obtain ⟨hw, hc, _⟩ := complementary_ranks p q h
  rw [mem_jointKernel]
  constructor
  · apply projectedDual_zero p q h hp (exteriorRepresentation (q.val + 2)) _ (wedge_equivariant _) _ x
    rw [ext_finrank, jointKernel_finrank p.val (by omega)]
    exact hw
  · apply projectedDual_zero p q h hp (exteriorRepresentation q.val) _ (contract_equivariant _) _ x
    rw [ext_finrank, jointKernel_finrank p.val (by omega)]
    exact hc

set_option backward.isDefEq.respectTransparency false in
/-- Tensor Hodge duality restricts to an equivalence of the irreducible joint
kernels in complementary non-middle grades. -/
def residualDuality (p q : Fin 13) (h : (p.val + 1) + (q.val + 1) = 14) (hp : p.val ≠ 6) :
    (jointKernelAction p.val).Equiv (jointKernelAction q.val) := by
  let d := tensorDuality h
  let K := jointKernel p.val
  let L := jointKernel q.val
  let f : K →ₗ[ℂ] L := (d.toLinearMap.comp K.subtype).codRestrict L (tensorDual_mem_jointKernel p q h hp)
  have hi : Function.Injective f := fun x y hxy =>
    Subtype.ext (d.toLinearEquiv.injective (congrArg Subtype.val hxy))
  have hr : Module.finrank ℂ K = Module.finrank ℂ L := by
    change Module.finrank ℂ (jointKernel p.val) = Module.finrank ℂ (jointKernel q.val)
    rw [jointKernel_finrank p.val (by omega), jointKernel_finrank q.val (by omega)]
    exact (complementary_ranks p q h).2.2
  have hs : Function.Surjective f :=
    (LinearMap.injective_iff_surjective_of_finrank_eq_finrank (K := ℂ) (V := ↥K) (V₂ := ↥L) hr (f := f)).mp hi
  refine Representation.Equiv.mk (LinearEquiv.ofBijective f ⟨hi, hs⟩) (fun g => ?_)
  apply LinearMap.ext
  intro x
  apply Subtype.ext
  exact Representation.IntertwiningMap.isIntertwining (action (p.val + 1)) (action (q.val + 1))
    d.toIntertwiningMap g x.val

private theorem exterior_rank_matches :
    ∀ p q : Fin 15, Nat.choose 14 p.val = Nat.choose 14 q.val → p = q ∨ p.val + q.val = 14 := by
  decide +kernel

private theorem residual_rank_matches :
    ∀ p q : Fin 13, kernelRank p.val = kernelRank q.val →
      p = q ∨ (p.val + 1) + (q.val + 1) = 14 := by
  decide +kernel

private theorem residual_rank_ne_exterior :
    ∀ (p : Fin 13) (q : Fin 15), kernelRank p.val ≠ Nat.choose 14 q.val := by
  decide +kernel

/-- The full exterior powers are equivalent exactly for equal or complementary degrees. -/
theorem exterior_equiv_iff (p q : Fin 15) :
    Nonempty ((exteriorRepresentation p.val).Equiv (exteriorRepresentation q.val)) ↔
      p = q ∨ p.val + q.val = 14 := by
  constructor
  · rintro ⟨e⟩
    have he := e.toLinearEquiv.finrank_eq
    rw [ext_finrank, ext_finrank] at he
    exact exterior_rank_matches p q he
  · rintro (rfl | h)
    · exact ⟨Representation.Equiv.refl _⟩
    · exact ⟨exteriorDuality h⟩

/-- The irreducible non-middle residuals are equivalent exactly for equal or
complementary input degrees. The indexing of `jointKernel` is one below the
exterior input degree. -/
theorem residual_equiv_iff (p q : Fin 13) (hp : p.val ≠ 6) :
    Nonempty ((jointKernelAction p.val).Equiv (jointKernelAction q.val)) ↔
      p = q ∨ (p.val + 1) + (q.val + 1) = 14 := by
  constructor
  · rintro ⟨e⟩
    have he := e.toLinearEquiv.finrank_eq
    rw [jointKernel_finrank p.val (by omega), jointKernel_finrank q.val (by omega)] at he
    exact residual_rank_matches p q he
  · rintro (rfl | h)
    · exact ⟨Representation.Equiv.refl _⟩
    · exact ⟨residualDuality p q h hp⟩

theorem residual_not_equiv_exterior (p : Fin 13) (q : Fin 15) :
    ¬ Nonempty ((jointKernelAction p.val).Equiv (exteriorRepresentation q.val)) := by
  rintro ⟨e⟩
  have he := e.toLinearEquiv.finrank_eq
  rw [jointKernel_finrank p.val (by omega), ext_finrank] at he
  exact residual_rank_ne_exterior p q he

end
end GeometricUnity.D7ComplementaryGrades
