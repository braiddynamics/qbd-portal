import D7Final
import D7RealComparison
import D7RootGeneration
import Mathlib.LinearAlgebra.Charpoly.BaseChange

/-! # Dimensions of real Spin(7,7)-equivariant maps -/

namespace GeometricUnity.D7RealTheorem

open D7Exterior D7VectorGrades D7VectorTensor D7SpinAction D7SpinNullFrame
open D7RealComparison D7RootInterpolation D7RootGeneration
open scoped DirectSum TensorProduct BigOperators

noncomputable section

set_option backward.isDefEq.respectTransparency false
set_option maxHeartbeats 1200000

def transportHom {K G M N U W : Type*} [CommSemiring K] [Monoid G]
    [AddCommMonoid M] [Module K M] [AddCommMonoid N] [Module K N]
    [AddCommMonoid U] [Module K U] [AddCommMonoid W] [Module K W]
    {ρ : Representation K G M} {τ : Representation K G N}
    {σ : Representation K G U} {π : Representation K G W}
    (e : ρ.Equiv σ) (f : τ.Equiv π) : ρ.IntertwiningMap τ ≃ₗ[K] σ.IntertwiningMap π where
  toFun T := f.toIntertwiningMap.comp (T.comp e.symm.toIntertwiningMap)
  invFun T := f.symm.toIntertwiningMap.comp (T.comp e.toIntertwiningMap)
  left_inv T := by ext x; simp
  right_inv T := by ext x; simp
  map_add' T S := by ext x; simp
  map_smul' c T := by ext x; simp

private theorem toMatrix_complexify {M ι : Type*} [AddCommGroup M] [Module ℝ M]
    [Fintype ι] [DecidableEq ι] (b : Module.Basis ι ℝ M) (f : Module.End ℝ M) :
    D7Classification.complexMatrices (LinearMap.toMatrix b b f) =
      LinearMap.toMatrix (b.baseChange ℂ) (b.baseChange ℂ) (f.baseChange ℂ) := by
  ext i j
  simp [D7Classification.complexMatrices, LinearMap.toMatrix_apply, ← Algebra.algebraMap_eq_smul_one]

private theorem finrank_complexify {U W : Type} [AddCommGroup U] [Module ℝ U]
    [AddCommGroup W] [Module ℝ W] [Module.Finite ℝ U] [Module.Finite ℝ W]
    (ρ : Representation ℝ Spin U) (τ : Representation ℝ Spin W) :
    Module.finrank ℝ (ρ.IntertwiningMap τ) =
      Module.finrank ℂ ((complexify ρ).IntertwiningMap (complexify τ)) := by
  let b := Module.Free.chooseBasis ℝ U
  let c := Module.Free.chooseBasis ℝ W
  let ρm := fun g => LinearMap.toMatrix b b (ρ g)
  let τm := fun g => LinearMap.toMatrix c c (τ g)
  let e := D7Final.intertwinerMatrices b c ρ τ
  have hρ : D7Classification.complexMatrices ∘ ρm =
      fun g => LinearMap.toMatrix (b.baseChange ℂ) (b.baseChange ℂ) (complexify ρ g) :=
    funext fun g => toMatrix_complexify b (ρ g)
  have hτ : D7Classification.complexMatrices ∘ τm =
      fun g => LinearMap.toMatrix (c.baseChange ℂ) (c.baseChange ℂ) (complexify τ g) :=
    funext fun g => toMatrix_complexify c (τ g)
  exact e.finrank_eq.trans (D7Final.real_dimension_of_comparison ρm τm (by
    change ↥(D7Classification.matrixIntertwiners (D7Classification.complexMatrices ∘ ρm)
      (D7Classification.complexMatrices ∘ τm)) ≃ₗ[ℂ] _
    rw [hρ, hτ]
    exact (D7Final.intertwinerMatrices (b.baseChange ℂ) (c.baseChange ℂ)
      (complexify ρ) (complexify τ)).symm))

section Blocks

variable {G I J : Type*} [Monoid G] [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]
variable {U : I → Type*} {W : J → Type*}
variable [∀ i, AddCommGroup (U i)] [∀ j, AddCommGroup (W j)]
variable [∀ i, Module ℂ (U i)] [∀ j, Module ℂ (W j)]
variable (ρ : ∀ i, Representation ℂ G (U i)) (τ : ∀ j, Representation ℂ G (W j))

private def block (T : (⨁ i, U i) →ₗ[ℂ] ⨁ j, W j) (i : I) (j : J) : U i →ₗ[ℂ] W j :=
  (DirectSum.component ℂ J W j).comp (T.comp (DirectSum.lof ℂ I U i))

omit [Fintype I] [Fintype J] [DecidableEq J] in
private theorem directSum_comm_iff (T : (⨁ i, U i) →ₗ[ℂ] ⨁ j, W j) (g : G) :
    T.comp (Representation.directSum ρ g) = (Representation.directSum τ g).comp T ↔
      ∀ i j, (block T i j).comp (ρ i g) = (τ j g).comp (block T i j) := by
  constructor
  · intro h i j
    apply LinearMap.ext
    intro x
    have hx := DFunLike.congr_fun h (DirectSum.lof ℂ I U i x)
    have hj := congrArg (DirectSum.component ℂ J W j) hx
    simpa [block, Representation.directSum_apply, ← DirectSum.apply_eq_component] using hj
  · intro h
    apply DirectSum.linearMap_ext
    intro i
    apply LinearMap.ext
    intro x
    apply DirectSum.ext_component ℂ
    intro j
    simpa [block, Representation.directSum_apply, ← DirectSum.apply_eq_component]
      using DFunLike.congr_fun (h i j) x

private def assembleBlocks (B : ∀ i j, U i →ₗ[ℂ] W j) : (⨁ i, U i) →ₗ[ℂ] ⨁ j, W j :=
  DirectSum.toModule ℂ I _ fun i =>
    (DirectSum.linearEquivFunOnFintype ℂ J W).symm.toLinearMap.comp (LinearMap.pi (B i))

omit [Fintype I] [DecidableEq J] in
@[simp] private theorem block_assemble (B : ∀ i j, U i →ₗ[ℂ] W j) (i : I) (j : J) :
    block (assembleBlocks B) i j = B i j := by
  apply LinearMap.ext
  intro x
  simp [block, assembleBlocks, ← DirectSum.apply_eq_component]
  exact congrFun ((DirectSum.linearEquivFunOnFintype ℂ J W).apply_symm_apply ((LinearMap.pi (B i)) x)) j

omit [Fintype I] [Fintype J] [DecidableEq J] in
private theorem blocks_injective :
    Function.Injective (fun T : (⨁ i, U i) →ₗ[ℂ] ⨁ j, W j => fun i j => block T i j) := by
  intro T S h
  apply DirectSum.linearMap_ext
  intro i
  apply LinearMap.ext
  intro x
  apply DirectSum.ext_component ℂ
  intro j
  exact DFunLike.congr_fun (congrFun (congrFun h i) j) x

private def blockHom :
    (Representation.directSum ρ).IntertwiningMap (Representation.directSum τ) ≃ₗ[ℂ]
      (∀ i j, (ρ i).IntertwiningMap (τ j)) where
  toFun T i j := ⟨block T.toLinearMap i j, fun g =>
    (directSum_comm_iff ρ τ T.toLinearMap g).mp (T.isIntertwining' g) i j⟩
  invFun B := ⟨assembleBlocks (fun i j => (B i j).toLinearMap), fun g =>
    (directSum_comm_iff ρ τ _ g).mpr fun i j => by simpa using (B i j).isIntertwining' g⟩
  left_inv T := by
    apply Representation.IntertwiningMap.ext
    apply blocks_injective
    funext i j
    exact block_assemble _ i j
  right_inv B := by
    funext i j
    exact Representation.IntertwiningMap.ext (block_assemble _ i j)
  map_add' T S := by
    funext i j
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    exact map_add (DirectSum.component ℂ J W j) _ _
  map_smul' a T := by
    funext i j
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    exact map_smul (DirectSum.component ℂ J W j) _ _

end Blocks

private abbrev exteriorTensorAction (r k : ℕ) :
    Representation ℂ splitSpecialOrthogonal (Ext r ⊗[ℂ] Ext k) :=
  (exteriorRepresentation r).tprod (exteriorRepresentation k)

private def actionSpanEquiv (r k s l : ℕ) :
    (exteriorTensorAction r k).IntertwiningMap (exteriorTensorAction s l) ≃ₗ[ℂ]
    Representation.IntertwiningMap ((exteriorTensorAction r k).comp spinToSO)
      ((exteriorTensorAction s l).comp spinToSO) := by
  refine D7Final.restrictGroupEquiv (U := Ext r ⊗[ℂ] Ext k) (W := Ext s ⊗[ℂ] Ext l)
    spinToSO (exteriorTensorAction r k) (exteriorTensorAction s l) ?_
  intro g
  exact splitSO_tensorActions_mem_spin_span r k s l g

private def exteriorOne :
    (exteriorRepresentation 1).Equiv vectorAction :=
  Representation.Equiv.mk (exteriorPower.oneEquiv ℂ Space) fun f =>
    exteriorPower.oneEquiv_naturality f.val

def liftTensorEquiv {K G U W E : Type*} [CommSemiring K] [Monoid G]
    [AddCommMonoid U] [Module K U] [AddCommMonoid W] [Module K W]
    [AddCommMonoid E] [Module K E]
    {ρ : Representation K G U} {τ : Representation K G W}
    (e : ρ.Equiv τ) (σ : Representation K G E) :
    (ρ.tprod σ).Equiv (τ.tprod σ) := by
  refine Representation.Equiv.mk (TensorProduct.congr e.toLinearEquiv (LinearEquiv.refl K E))
    fun g => ?_
  apply TensorProduct.ext'
  intro x y
  have h := DFunLike.congr_fun (e.isIntertwining' g) x
  change e (ρ g x) = τ g (e x) at h
  simp [Representation.tprod_apply, h]

private def restrictRepEquiv {G H U W : Type*} [Monoid G] [Monoid H]
    [AddCommMonoid U] [Module ℂ U] [AddCommMonoid W] [Module ℂ W]
    {ρ : Representation ℂ G U} {τ : Representation ℂ G W}
    (φ : H →* G) (e : ρ.Equiv τ) : Representation.Equiv (ρ.comp φ) (τ.comp φ) :=
  Representation.Equiv.mk e.toLinearEquiv fun g => e.isIntertwining' (φ g)

private def exteriorUnit (l : ℕ) :
    (((exteriorRepresentation 0).tprod (exteriorRepresentation l))).Equiv
      (exteriorRepresentation l) := by
  let e := (TensorProduct.congr (exteriorPower.zeroEquiv ℂ Space) (LinearEquiv.refl ℂ (Ext l))).trans
    (TensorProduct.lid ℂ (Ext l))
  refine Representation.Equiv.mk e fun g => ?_
  apply TensorProduct.ext'
  intro x y
  have h := DFunLike.congr_fun (exteriorPower.zeroEquiv_naturality g.val) x
  change exteriorPower.zeroEquiv ℂ Space (exteriorPower.map 0 g.val x) =
    exteriorPower.zeroEquiv ℂ Space x at h
  simp [e, Representation.tprod_apply, exteriorRepresentation, h]

private def unrestrictedBlock (k l : Fin 15) :
    Representation.IntertwiningMap (((exteriorRepresentation 2).tprod
      (exteriorRepresentation k.val)).comp spinToSO)
      ((vectorAction.tprod (exteriorRepresentation l.val)).comp spinToSO) ≃ₗ[ℂ]
    D7Unrestricted.Intertwiners k.val l.val :=
  let e := liftTensorEquiv exteriorOne (exteriorRepresentation l.val)
  (transportHom (Representation.Equiv.refl ((exteriorTensorAction 2 k.val).comp spinToSO))
    (restrictRepEquiv spinToSO e.symm)).trans
    ((actionSpanEquiv 2 k.val 1 l.val).symm.trans
      (transportHom (Representation.Equiv.refl (exteriorTensorAction 2 k.val)) e))

private def exteriorBlock (r : ℕ) (k l : Fin 15) :
    Representation.IntertwiningMap (((exteriorRepresentation r).tprod
      (exteriorRepresentation k.val)).comp spinToSO)
      ((exteriorRepresentation l.val).comp spinToSO) ≃ₗ[ℂ]
    D7TripleInvariants.ExteriorIntertwiners r k.val l.val :=
  let e := exteriorUnit l.val
  (transportHom (Representation.Equiv.refl ((exteriorTensorAction r k.val).comp spinToSO))
    (restrictRepEquiv spinToSO e.symm)).trans
    ((actionSpanEquiv r k.val 0 l.val).symm.trans
      (transportHom (Representation.Equiv.refl (exteriorTensorAction r k.val)) e))

abbrev FormCoefficients (k : ℕ) := (⋀[ℝ]^k Covector) ⊗[ℝ] Coefficients
abbrev OneFormCoefficients := Covector ⊗[ℝ] Coefficients

abbrev formCoefficientsAction (k : ℕ) : Representation ℝ Spin (FormCoefficients k) :=
  (formAction k).tprod coefficientAction

abbrev oneFormCoefficientsAction : Representation ℝ Spin OneFormCoefficients :=
  vectorRepresentation.dual.tprod coefficientAction

abbrev Operators := (formCoefficientsAction 2).IntertwiningMap oneFormCoefficientsAction
abbrev ExteriorSymbols (r : ℕ) := (formCoefficientsAction r).IntertwiningMap coefficientAction

private theorem finiteIntertwiners {G U W I J : Type} [Monoid G]
    [AddCommGroup U] [Module ℂ U] [AddCommGroup W] [Module ℂ W]
    [Fintype I] [Fintype J] [DecidableEq I] [DecidableEq J]
    (b : Module.Basis I ℂ U) (c : Module.Basis J ℂ W)
    (ρ : Representation ℂ G U) (τ : Representation ℂ G W) :
    Module.Finite ℂ (ρ.IntertwiningMap τ) := by
  let e := D7Final.intertwinerMatrices b c ρ τ
  exact Module.Finite.of_injective (_root_.Submodule.subtype _ ∘ₗ e.toLinearMap)
    (Subtype.val_injective.comp e.injective)

private theorem finrank_blocks {M : Fin 15 → Fin 15 → Type}
    [∀ k l, AddCommGroup (M k l)] [∀ k l, Module ℂ (M k l)]
    [∀ k l, Module.Finite ℂ (M k l)] :
    Module.finrank ℂ (∀ k l, M k l) = ∑ k, ∑ l, Module.finrank ℂ (M k l) := by
  rw [Module.finrank_pi_fintype]
  exact Finset.sum_congr rfl fun k _ => Module.finrank_pi_fintype ℂ

theorem unrestricted_dimension : Module.finrank ℝ Operators = 200 := by
  let e := transportHom (formCoefficientComparison 2) covectorCoefficientComparison
  have h := finrank_complexify (U := FormCoefficients 2) (W := OneFormCoefficients)
    (formCoefficientsAction 2) oneFormCoefficientsAction
  refine h.trans (e.finrank_eq.trans ?_)
  let b := blockHom (U := fun k : Fin 15 => Ext 2 ⊗[ℂ] Ext k.val)
    (W := fun l : Fin 15 => Space ⊗[ℂ] Ext l.val) (fun k : Fin 15 =>
      ((exteriorRepresentation 2).tprod (exteriorRepresentation k.val)).comp spinToSO)
    (fun l : Fin 15 => (vectorAction.tprod (exteriorRepresentation l.val)).comp spinToSO)
  refine (b.trans (LinearEquiv.piCongrRight fun k => LinearEquiv.piCongrRight (unrestrictedBlock k))).finrank_eq.trans ?_
  have finite (k l : Fin 15) : Module.Finite ℂ (D7Unrestricted.Intertwiners k.val l.val) :=
    finiteIntertwiners (U := D7Unrestricted.Source k.val) (W := Product l.val)
      ((axisBasis.exteriorPower 2).tensorProduct (axisBasis.exteriorPower k.val))
      (axisBasis.tensorProduct (axisBasis.exteriorPower l.val))
      (D7Unrestricted.sourceAction k.val) (D7VectorGrades.action l.val)
  exact (@finrank_blocks (fun k l => D7Unrestricted.Intertwiners k.val l.val) _ _ finite).trans
    D7Unrestricted.unrestricted_total

private def coefficientComparison :
    (complexify coefficientAction).Equiv (coefficientGradeAction.comp spinToSO) :=
  Representation.Equiv.mk coefficientComplexEquiv coefficientComplexEquiv_intertwines

private theorem exterior_symbol_rank (r : ℕ) : Module.finrank ℝ (ExteriorSymbols r) =
      ∑ k : Fin 15, ∑ l : Fin 15,
        Module.finrank ℂ (D7TripleInvariants.ExteriorIntertwiners r k.val l.val) := by
  let e := transportHom (formCoefficientComparison r) coefficientComparison
  let : Module.Finite ℝ (⋀[ℝ]^r Covector) :=
    Module.Finite.of_basis ((Pi.basisFun ℝ Axis).dualBasis.exteriorPower r)
  have h := finrank_complexify (U := FormCoefficients r) (W := Coefficients)
    (formCoefficientsAction r) coefficientAction
  refine h.trans (e.finrank_eq.trans ?_)
  let b := blockHom (U := fun k : Fin 15 => Ext r ⊗[ℂ] Ext k.val)
    (W := fun l : Fin 15 => Ext l.val) (fun k : Fin 15 =>
      ((exteriorRepresentation r).tprod (exteriorRepresentation k.val)).comp spinToSO)
    (fun l : Fin 15 => (exteriorRepresentation l.val).comp spinToSO)
  refine (b.trans
    (LinearEquiv.piCongrRight fun k => LinearEquiv.piCongrRight (exteriorBlock r k))).finrank_eq.trans ?_
  have finite (k l : Fin 15) : Module.Finite ℂ (D7TripleInvariants.ExteriorIntertwiners r k.val l.val) :=
    finiteIntertwiners (U := Ext r ⊗[ℂ] Ext k.val) (W := Ext l.val)
      ((axisBasis.exteriorPower r).tensorProduct (axisBasis.exteriorPower k.val))
      (axisBasis.exteriorPower l.val) (exteriorTensorAction r k.val) (exteriorRepresentation l.val)
  exact @finrank_blocks (fun k l => D7TripleInvariants.ExteriorIntertwiners r k.val l.val) _ _ finite

theorem exterior_symbol_dimensions :
    Module.finrank ℝ (ExteriorSymbols 1) = 56 ∧ Module.finrank ℝ (ExteriorSymbols 3) = 96 :=
  ⟨(exterior_symbol_rank 1).trans D7TripleMultiplicity.vector_and_alternating_totals.1,
   (exterior_symbol_rank 3).trans D7TripleMultiplicity.vector_and_alternating_totals.2⟩

end
end GeometricUnity.D7RealTheorem
