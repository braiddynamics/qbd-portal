import D7Hodge
import Mathlib.RepresentationTheory.Irreducible

/-!
# Irreducibility in the D₇ exterior powers

Double sign changes separate the orthonormal exterior basis up to
complementary index sets. Determinant-one signed permutations act
transitively on the index sets in each degree.
-/

namespace GeometricUnity.D7Irreducible

open D7Exterior D7Hodge
open scoped BigOperators

noncomputable section

abbrev Exterior (k : ℕ) := ⋀[ℂ]^k Space
abbrev basis (k : ℕ) := orthBasis.exteriorPower k

def signScalar {α : Type*} [DecidableEq α] [Fintype α] (σ : Equiv.Perm α) : ℂ :=
  σ.sign • (1 : ℂ)

private theorem signScalar_sq {α : Type*} [DecidableEq α] [Fintype α] (σ : Equiv.Perm α) :
    signScalar σ * signScalar σ = 1 := by
  rcases Int.units_eq_one_or σ.sign with h | h <;> simp [signScalar, h]

private theorem signScalar_ne_zero {α : Type*} [DecidableEq α] [Fintype α] (σ : Equiv.Perm α) :
    signScalar σ ≠ 0 := by
  intro h
  have hs := signScalar_sq σ
  rw [h, zero_mul] at hs
  exact zero_ne_one hs

private def monomial (σ : Equiv.Perm Axis) (c : Axis → ℂ) : Space →ₗ[ℂ] Space :=
  orthBasis.constr ℂ fun j => c j • orthBasis (σ j)

private theorem monomial_basis (σ : Equiv.Perm Axis) (c : Axis → ℂ) (j : Axis) :
    monomial σ c (orthBasis j) = c j • orthBasis (σ j) := orthBasis.constr_basis _ _ _

private theorem monomial_det (σ : Equiv.Perm Axis) (c : Axis → ℂ) :
    (monomial σ c).det = (∏ j, c j) * signScalar σ := by
  calc
    _ = orthBasis.det (monomial σ c ∘ orthBasis) := by
      rw [Module.Basis.det_comp, Module.Basis.det_self, mul_one]
    _ = (∏ j, c j) • orthBasis.det ((orthBasis : Axis → Space) ∘ σ) := by
      change orthBasis.det (fun j => monomial σ c (orthBasis j)) = _
      simp only [monomial_basis, AlternatingMap.map_smul_univ]
      rfl
    _ = _ := by rw [AlternatingMap.map_perm, Module.Basis.det_self]; rfl

private def specialMonomial (σ : Equiv.Perm Axis) (c : Axis → ℂ)
    (hsq : ∀ j, c j * c j = 1) (hdet : (∏ j, c j) * signScalar σ = 1) : splitSpecialOrthogonal := by
  refine ⟨monomial σ c, (monomial_det σ c).trans hdet, preserves_splitForm_of_basis _ ?_⟩
  intro i j
  have h := fun (v w : Space) => splitMetric_apply v w
  rw [monomial_basis, monomial_basis, ← h]
  simp only [map_smul, LinearMap.smul_apply, h, orthBasis_pair, σ.injective.eq_iff]
  by_cases he : i = j
  · subst j
    simpa [smul_eq_mul] using hsq i
  · simp [he]

def orientationCorrection (σ : Equiv.Perm Axis) (pivot j : Axis) : ℂ :=
  if j = pivot then signScalar σ else 1

theorem correction_sq (σ : Equiv.Perm Axis) (pivot j : Axis) :
    orientationCorrection σ pivot j * orientationCorrection σ pivot j = 1 := by
  by_cases h : j = pivot <;> simp [orientationCorrection, h, signScalar_sq]

def orientedPermAt (σ : Equiv.Perm Axis) (pivot : Axis) : splitSpecialOrthogonal := by
  refine specialMonomial σ (orientationCorrection σ pivot) (correction_sq σ pivot) ?_
  rw [Finset.prod_eq_single pivot]
  · simp [orientationCorrection, signScalar_sq]
  · intro j _ hj; simp [orientationCorrection, hj]
  · simp

theorem orientedPermAt_basis (σ : Equiv.Perm Axis) (pivot j : Axis) :
    (orientedPermAt σ pivot).val (orthBasis j) =
      orientationCorrection σ pivot j • orthBasis (σ j) := monomial_basis _ _ _

private abbrev orientedPerm (σ : Equiv.Perm Axis) := orientedPermAt σ 0

def permIndex (σ : Equiv.Perm Axis) {k : ℕ} (s : Index k) : Index k :=
  ⟨s.val.map σ.toEmbedding, by change (s.val.map σ.toEmbedding).card = k; simp⟩

theorem orientedPerm_exterior {k : ℕ} (σ : Equiv.Perm Axis) (pivot : Axis) (s : Index k) :
    ∃ a : ℂ, a ≠ 0 ∧ exteriorRepresentation k (orientedPermAt σ pivot) (basis k s) =
      a • basis k (permIndex σ s) := by
  let t := permIndex σ s
  let e := (s.val.orderIsoOfFin s.prop).toEquiv
  let d := (t.val.orderIsoOfFin t.prop).toEquiv
  let m : s.val ≃ t.val := Finset.equivMap (s := s.val) (f := σ.toEmbedding)
  let p : Equiv.Perm (Fin k) := (e.trans m).trans d.symm
  have hp (j : Fin k) : σ (e j).val = (d (p j)).val := by
    exact (congrArg Subtype.val (d.apply_symm_apply (m (e j)))).symm
  let c := orientationCorrection σ pivot
  refine ⟨(∏ j, c (e j).val) * signScalar p, mul_ne_zero ?_ (signScalar_ne_zero p), ?_⟩
  · apply Finset.prod_ne_zero_iff.mpr
    intro j _
    have h := correction_sq σ pivot (e j).val
    intro hzero
    rw [show orientationCorrection σ pivot (e j).val = 0 from hzero, zero_mul] at h
    exact zero_ne_one h
  change exteriorPower.map k (monomial σ c) (orthBasis.exteriorPower k s) = _ • orthBasis.exteriorPower k t
  rw [exteriorPower.basis_apply, exteriorPower.basis_apply]
  change exteriorPower.map k (monomial σ c) (exteriorPower.ιMulti ℂ k (fun j => orthBasis (e j).val)) =
    _ • exteriorPower.ιMulti ℂ k (fun j => orthBasis (d j).val)
  rw [exteriorPower.map_apply_ιMulti]
  change exteriorPower.ιMulti ℂ k (fun j => monomial σ c (orthBasis (e j).val)) = _
  simp_rw [monomial_basis, hp]
  have hw : (fun j => orthBasis (d (p j)).val) = (fun j => orthBasis (d j).val) ∘ p := rfl
  rw [AlternatingMap.map_smul_univ, hw, AlternatingMap.map_perm]
  rcases Int.units_eq_one_or p.sign with h | h <;> simp [signScalar, h]
  module

private theorem index_transitive {k : ℕ} (s t : Index k) : ∃ σ : Equiv.Perm Axis, permIndex σ s = t := by
  classical
  let e : s.val ≃ t.val := Finset.equivOfCardEq (s.prop.trans t.prop.symm)
  let e' : {j // j ∉ s.val} ≃ {j // j ∉ t.val} := Fintype.equivOfCardEq (by
    rw [Fintype.card_subtype_compl, Fintype.card_subtype_compl, Fintype.card_coe, Fintype.card_coe,
      s.prop, t.prop])
  let σ : Equiv.Perm Axis := ((Equiv.sumCompl (· ∈ s.val)).symm.trans (e.sumCongr e')).trans
    (Equiv.sumCompl (· ∈ t.val))
  have hσ (j : Axis) (hj : j ∈ s.val) : σ j = (e ⟨j, hj⟩).val := by
    change Equiv.sumCompl (· ∈ t.val) ((e.sumCongr e') ((Equiv.sumCompl (· ∈ s.val)).symm j)) = _
    rw [Equiv.sumCompl_symm_apply_pos ⟨j, hj⟩]
    rfl
  refine ⟨σ, Subtype.ext (Finset.eq_of_subset_of_card_le ?_ ?_)⟩
  · intro j hj
    obtain ⟨a, ha, rfl⟩ := Finset.mem_map.mp hj
    change σ a ∈ t.val
    rw [hσ a ha]
    exact (e ⟨a, ha⟩).prop
  · change t.val.card ≤ (s.val.map σ.toEmbedding).card
    rw [Finset.card_map, s.prop, t.prop]

private theorem basis_transitive {k : ℕ} (s t : Index k) :
    ∃ g : splitSpecialOrthogonal, ∃ a : ℂ, a ≠ 0 ∧
      exteriorRepresentation k g (basis k s) = a • basis k t := by
  obtain ⟨σ, hσ⟩ := index_transitive s t
  obtain ⟨a, ha, h⟩ := orientedPerm_exterior σ 0 s
  exact ⟨orientedPerm σ, a, ha, h.trans (by rw [hσ])⟩

def axisFlip (i j : Axis) : ℂ := if j = i then -1 else 1

def subsetFlip (s : Finset Axis) (i : Axis) : ℂ := if i ∈ s then -1 else 1

private theorem prod_axisFlip (s : Finset Axis) (i : Axis) : ∏ j ∈ s, axisFlip i j = subsetFlip s i := by
  by_cases hi : i ∈ s
  · rw [Finset.prod_eq_single i]
    · simp [axisFlip, subsetFlip, hi]
    · intro j _ h; simp [axisFlip, h]
    · exact fun h => (h hi).elim
  · rw [subsetFlip, if_neg hi]
    apply Finset.prod_eq_one
    intro j hj
    simp [axisFlip, show j ≠ i from fun h => hi (h ▸ hj)]

def doubleFlip (i j : Axis) : splitSpecialOrthogonal := by
  let c := fun a => axisFlip i a * axisFlip j a
  refine specialMonomial 1 c ?_ ?_
  · intro a
    have hs (b : Axis) : axisFlip b a * axisFlip b a = 1 := by
      by_cases h : a = b <;> simp [axisFlip, h]
    change (axisFlip i a * axisFlip j a) * (axisFlip i a * axisFlip j a) = 1
    rw [mul_mul_mul_comm, hs i, hs j, mul_one]
  · simp [c, Finset.prod_mul_distrib, prod_axisFlip, subsetFlip, signScalar]

theorem doubleFlip_basis (i j a : Axis) : (doubleFlip i j).val (orthBasis a) =
    (axisFlip i a * axisFlip j a) • orthBasis a := monomial_basis _ _ _

def character (s : Finset Axis) (i j : Axis) : ℂ := subsetFlip s i * subsetFlip s j

private theorem character_sq (s : Finset Axis) (i j : Axis) : character s i j * character s i j = 1 := by
  by_cases hi : i ∈ s <;> by_cases hj : j ∈ s <;> simp [character, subsetFlip, hi, hj]

theorem doubleFlip_exterior {k : ℕ} (i j : Axis) (s : Index k) :
    exteriorRepresentation k (doubleFlip i j) (basis k s) = character s.val i j • basis k s := by
  let c := fun a => axisFlip i a * axisFlip j a
  have h : (doubleFlip i j).val = orthDiagonal c := by
    apply orthBasis.ext
    intro a
    change monomial 1 c (orthBasis a) = orthDiagonal c (orthBasis a)
    rw [monomial_basis, orthDiagonal_basis]
    rfl
  change exteriorPower.map k (doubleFlip i j).val (basis k s) = _
  rw [h, orthDiagonal_exterior]
  simp only [c, Finset.prod_mul_distrib, prod_axisFlip, character]

private theorem character_separates (s t : Finset Axis) (hne : t ≠ s) (hnc : t ≠ sᶜ) :
    ∃ i j : Axis, character t i j = -character s i j := by
  classical
  have h₁ : ∃ i : Axis, ¬ (i ∈ t ↔ i ∈ s) := by
    by_contra! h
    exact hne (Finset.ext h)
  have h₂ : ∃ j : Axis, j ∈ t ↔ j ∈ s := by
    by_contra! h
    apply hnc
    ext j
    have hl := h j
    by_cases hm : j ∈ s <;> simp_all
  obtain ⟨i, hi⟩ := h₁
  obtain ⟨j, hj⟩ := h₂
  refine ⟨i, j, ?_⟩
  by_cases his : i ∈ s <;> by_cases hit : i ∈ t <;> by_cases hjs : j ∈ s <;>
    simp_all [character, subsetFlip]

/-- Stability under the actual split special orthogonal exterior representation. -/
def Stable {k : ℕ} (W : Submodule ℂ (Exterior k)) : Prop :=
  ∀ (g : splitSpecialOrthogonal) (x : Exterior k), x ∈ W → exteriorRepresentation k g x ∈ W

private theorem diagonal_coordinate {E ι : Type*} [AddCommGroup E] [Module ℂ E]
    (b : Module.Basis ι ℂ E) (f : E →ₗ[ℂ] E) (d : ι → ℂ) (hf : ∀ s, f (b s) = d s • b s)
    (x : E) (t : ι) : b.repr (f x) t = d t * b.repr x t := by
  classical
  let c := b.coord t
  have h : c.comp f = d t • c := by
    apply b.ext
    intro s
    simp only [LinearMap.comp_apply, hf, map_smul, LinearMap.smul_apply,
      c, Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
    by_cases h : t = s <;> simp [h, eq_comm, smul_eq_mul]
  exact DFunLike.congr_fun h x

private theorem coordinate_ne_zero {E ι : Type*} [AddCommGroup E] [Module ℂ E]
    (b : Module.Basis ι ℂ E) (x : E) (hx : x ≠ 0) : ∃ s : ι, b.repr x s ≠ 0 := by
  classical
  by_contra! h
  apply hx
  apply b.repr.injective
  ext s
  simpa using h s

/-- Coordinate sign changes separate subsets up to complement. A minimum-support
vector in a nonzero invariant subspace occupies one such block. -/
theorem support_sign_block {E ι : Type*} [AddCommGroup E] [Module ℂ E]
    (b : Module.Basis ι ℂ E) (weight : ι → Finset Axis) (f : Axis → Axis → E →ₗ[ℂ] E)
    (hf : ∀ i j s, f i j (b s) = character (weight s) i j • b s)
    (W : Submodule ℂ E) (hW : ∀ i j x, x ∈ W → f i j x ∈ W) (hne : W ≠ ⊥) :
    ∃ (x : E) (s : ι), x ∈ W ∧ b.repr x s ≠ 0 ∧
      ∀ t : ι, b.repr x t ≠ 0 → weight t = weight s ∨ weight t = (weight s)ᶜ := by
  classical
  let P (n : ℕ) : Prop := ∃ x ∈ W, x ≠ 0 ∧ (b.repr x).support.card = n
  obtain ⟨v, hv, hv0⟩ := Submodule.exists_mem_ne_zero_of_ne_bot hne
  have hex : ∃ n, P n := ⟨_, v, hv, hv0, rfl⟩
  obtain ⟨x, hx, hx0, hcard⟩ := Nat.find_spec hex
  obtain ⟨s, hs⟩ := coordinate_ne_zero b x hx0
  refine ⟨x, s, hx, hs, ?_⟩
  intro t ht
  by_contra! hst
  obtain ⟨i, j, hsep⟩ := character_separates (weight s) (weight t) hst.1 hst.2
  let a := character (weight s) i j
  let y := x + a • f i j x
  have hy : y ∈ W := W.add_mem hx (W.smul_mem a (hW _ _ _ hx))
  have hrepr (q : ι) : b.repr y q =
      (1 + a * character (weight q) i j) * b.repr x q := by
    simp only [y, map_add, map_smul, Finsupp.add_apply, Finsupp.smul_apply, smul_eq_mul,
      diagonal_coordinate b (f i j) (fun s => character (weight s) i j) (hf i j)]
    ring
  have hys : b.repr y s ≠ 0 := by
    rw [hrepr, show a * character (weight s) i j = 1 from character_sq (weight s) i j]
    exact mul_ne_zero (by norm_num) hs
  have hyt : b.repr y t = 0 := by
    rw [hrepr, hsep, mul_neg, show a * character (weight s) i j = 1 from character_sq (weight s) i j]
    ring
  have hy0 : y ≠ 0 := fun hy' => hys (by simp [hy'])
  have hsub : (b.repr y).support ⊂ (b.repr x).support := by
    apply Finset.ssubset_iff_subset_ne.mpr
    refine ⟨?_, ?_⟩
    · intro q hq
      rw [Finsupp.mem_support_iff, hrepr] at hq
      rw [Finsupp.mem_support_iff]
      exact (mul_ne_zero_iff.mp hq).2
    · intro he
      exact (Finsupp.mem_support_iff.not.mpr (not_not_intro hyt))
        (he.symm ▸ Finsupp.mem_support_iff.mpr ht)
  have hle := Nat.find_min' hex (show P (b.repr y).support.card from ⟨y, hy, hy0, rfl⟩)
  exact (not_lt_of_ge hle) (hcard ▸ Finset.card_lt_card hsub)

private theorem support_block {k : ℕ} (W : Submodule ℂ (Exterior k)) (hW : Stable W) (hne : W ≠ ⊥) :
    ∃ (x : Exterior k) (s : Index k), x ∈ W ∧ (basis k).repr x s ≠ 0 ∧
      ∀ t : Index k, (basis k).repr x t ≠ 0 → t = s ∨ t.val = s.valᶜ := by
  obtain ⟨x, s, hx, hs, hblock⟩ := support_sign_block (basis k) Subtype.val
    (fun i j => exteriorRepresentation k (doubleFlip i j)) doubleFlip_exterior W (fun i j => hW (doubleFlip i j)) hne
  exact ⟨x, s, hx, hs, fun t ht => (hblock t ht).imp Subtype.ext id⟩

theorem basis_mem_of_scaled {E : Type*} [AddCommGroup E] [Module ℂ E] (W : Submodule ℂ E) (x : E)
    (a : ℂ) (ha : a ≠ 0) (hx : a • x ∈ W) : x ∈ W := by
  have h := W.smul_mem a⁻¹ hx
  rwa [smul_smul, inv_mul_cancel₀ ha, one_smul] at h

/-- In every degree other than seven the exterior action admits only the zero
and whole invariant subspaces. -/
theorem exterior_irreducible (k : ℕ) (hk : k ≠ 7) (W : Submodule ℂ (Exterior k))
    (hW : Stable W) : W = ⊥ ∨ W = ⊤ := by
  classical
  by_cases hne : W = ⊥
  · exact Or.inl hne
  right
  obtain ⟨x, s, hx, hs, hblock⟩ := support_block W hW hne
  have hsupp (t : Index k) (ht : (basis k).repr x t ≠ 0) : t = s := by
    rcases hblock t ht with h | h
    · exact h
    · have hc := congrArg Finset.card h
      rw [t.prop, Finset.card_compl, Fintype.card_fin, s.prop] at hc
      exact (hk (by omega)).elim
  have he : x = (basis k).repr x s • basis k s := by
    apply (basis k).repr.injective
    ext t
    simp only [map_smul, Finsupp.smul_apply, Module.Basis.repr_self, Finsupp.single_apply]
    by_cases h : t = s
    · subst t; simp
    · have hz : (basis k).repr x t = 0 := by by_contra hh; exact h (hsupp _ hh)
      simp [hz, Ne.symm h]
  have hbs : basis k s ∈ W := basis_mem_of_scaled W _ _ hs (he ▸ hx)
  apply top_unique
  rw [← (basis k).span_eq]
  apply Submodule.span_le.mpr
  rintro _ ⟨t, rfl⟩
  obtain ⟨g, a, ha, h⟩ := basis_transitive s t
  exact basis_mem_of_scaled W _ _ ha (h ▸ hW g _ hbs)

private theorem complement_ne (s : MiddleIndex) : complement s ≠ s := by
  intro h
  have he : (0 : Axis) ∈ (complement s).val ↔ (0 : Axis) ∈ s.val := by rw [h]
  change (0 : Axis) ∈ s.valᶜ ↔ (0 : Axis) ∈ s.val at he
  by_cases h' : (0 : Axis) ∈ s.val <;> simp_all

private theorem middle_block_expansion (x : Mid) (s : MiddleIndex)
    (hblock : ∀ t : MiddleIndex, middleBasis.repr x t ≠ 0 → t = s ∨ t.val = s.valᶜ) :
    x = middleBasis.repr x s • middleBasis s +
      middleBasis.repr x (complement s) • middleBasis (complement s) := by
  classical
  apply middleBasis.repr.injective
  ext t
  by_cases h₁ : t = s
  · subst t
    simp [Module.Basis.repr_self, Ne.symm (complement_ne s)]
  · by_cases h₂ : t = complement s
    · subst t
      simp [Module.Basis.repr_self, complement_ne s]
    · have hz : middleBasis.repr x t = 0 := by
        by_contra hh
        exact (hblock t hh).elim h₁ fun hv => h₂ (Subtype.ext hv)
      simp [Module.Basis.repr_self, h₁, h₂, hz]

private def sectorMap (a : ℂ) : Mid →ₗ[ℂ] Mid := LinearMap.id + a • involution

private theorem sectorMap_self (a : ℂ) (ha : a * a = 1) (x : Mid) (hx : x ∈ sector a) :
    sectorMap a x = (2 : ℂ) • x := by
  change x + a • involution x = _
  rw [(mem_sector a x).mp hx, smul_smul, ha, one_smul, two_smul]

private theorem sectorMap_comp (a : ℂ) (ha : a * a = 1) (x : Mid) :
    sectorMap a (involution x) = a • sectorMap a x := by
  change involution x + a • involution (involution x) = a • (x + a • involution x)
  rw [involution_square, smul_add, smul_smul, ha, one_smul, add_comm]

private theorem sectorMap_equivariant (a : ℂ) (g : splitSpecialOrthogonal) (x : Mid) :
    exteriorRepresentation 7 g (sectorMap a x) = sectorMap a (exteriorRepresentation 7 g x) := by
  change exteriorRepresentation 7 g (x + a • involution x) = _ + a • involution _
  rw [map_add, map_smul, involution_equivariant, LinearMap.id_apply]

/-- Each middle Hodge eigenspace is irreducible under the same split action. -/
theorem middle_sector_irreducible (a : ℂ) (ha : a * a = 1) (W : Submodule ℂ Mid)
    (hW : Stable W) (hsub : W ≤ sector a) : W = ⊥ ∨ W = sector a := by
  classical
  by_cases hne : W = ⊥
  · exact Or.inl hne
  right
  obtain ⟨x, s, hx, hs, hblock⟩ := support_block W hW hne
  have h2x : sectorMap a x ∈ W := by rw [sectorMap_self a ha x (hsub hx)]; exact W.smul_mem _ hx
  have hx0 : x ≠ 0 := fun e => hs (by simp [e])
  obtain ⟨c, hc, hcs⟩ := involution_basis s
  have hm : sectorMap a (middleBasis (complement s)) = (c⁻¹ * a) • sectorMap a (middleBasis s) := by
    have he := sectorMap_comp a ha (middleBasis s)
    rw [hcs, map_smul] at he
    calc
      _ = c⁻¹ • (c • sectorMap a (middleBasis (complement s))) := by
        rw [smul_smul, inv_mul_cancel₀ hc, one_smul]
      _ = _ := by rw [he, smul_smul]
  let r := middleBasis.repr x s + middleBasis.repr x (complement s) * (c⁻¹ * a)
  have hr : sectorMap a x = r • sectorMap a (middleBasis s) := by
    conv_lhs => rw [middle_block_expansion x s hblock]
    rw [map_add, map_smul, map_smul, hm, smul_smul, ← add_smul]
  have hr0 : r ≠ 0 := by
    intro hz
    rw [hz, zero_smul, sectorMap_self a ha x (hsub hx)] at hr
    exact hx0 ((smul_eq_zero.mp hr).resolve_left (by norm_num))
  have hb : sectorMap a (middleBasis s) ∈ W := basis_mem_of_scaled W _ _ hr0 (hr ▸ h2x)
  have hall (t : MiddleIndex) : sectorMap a (middleBasis t) ∈ W := by
    obtain ⟨g, b, hb0, he⟩ := basis_transitive s t
    change exteriorRepresentation 7 g (middleBasis s) = b • middleBasis t at he
    have hf := hW g _ hb
    rw [sectorMap_equivariant, he, map_smul] at hf
    exact basis_mem_of_scaled W _ _ hb0 hf
  apply le_antisymm hsub
  intro y hy
  have hp : sectorMap a y ∈ W := by
    rw [← middleBasis.sum_repr y, map_sum]
    exact W.sum_mem fun t _ => by rw [map_smul]; exact W.smul_mem _ (hall t)
  rw [sectorMap_self a ha y hy] at hp
  exact basis_mem_of_scaled W _ _ (by norm_num : (2 : ℂ) ≠ 0) hp

theorem irreducible_of_subrepresentations {V : Type*} [AddCommGroup V] [Module ℂ V]
    [Nontrivial V] (ρ : Representation ℂ splitSpecialOrthogonal V)
    (h : ∀ U : Subrepresentation ρ, U = ⊥ ∨ U = ⊤) : ρ.IsIrreducible := by
  refine { toNontrivial := ⟨?_⟩, eq_bot_or_eq_top := h }
  refine ⟨⊥, ⊤, ?_⟩
  intro e
  obtain ⟨x, hx⟩ := exists_ne (0 : V)
  have hz : x ∈ (⊥ : Subrepresentation ρ).toSubmodule := by
    rw [e]
    exact Submodule.mem_top
  change x ∈ (⊥ : Submodule ℂ V) at hz
  rw [Submodule.mem_bot] at hz
  exact hx hz

/-- Mathlib's irreducibility predicate for each non-middle exterior power in dimension 14. -/
theorem exterior_isIrreducible (k : Fin 15) (hk : k.val ≠ 7) :
    (exteriorRepresentation k.val).IsIrreducible := by
  have : Nontrivial (Exterior k.val) :=
    ⟨⟨axisBasis.exteriorPower k.val (highestPlus k), 0, highestPlus_ne_zero k⟩⟩
  apply irreducible_of_subrepresentations
  intro U
  have h := exterior_irreducible k.val hk U.toSubmodule (fun g x hx => U.apply_mem_toSubmodule g (v := x) hx)
  exact h.imp (fun e => Subrepresentation.toSubmodule_injective e)
    (fun e => Subrepresentation.toSubmodule_injective e)

/-- The exterior action restricted to a middle Hodge eigenspace. -/
def sectorRepresentation (a : ℂ) : Representation ℂ splitSpecialOrthogonal (sector a) :=
  (exteriorRepresentation 7).subrepresentation (sector a) (fun g x hx => sector_invariant a g x hx)

/-- Both invariant middle Hodge eigenspaces satisfy Mathlib's irreducibility predicate. -/
theorem middle_isIrreducible (a : ℂ) (ha : a = 1 ∨ a = -1) :
    Representation.IsIrreducible (k := ℂ) (V := ↥(sector a)) (sectorRepresentation a) := by
  have hd : Module.finrank ℂ (sector a) = 1716 := by
    rcases ha with h | h
    · rw [h]; exact middle_sector_dimensions.1
    · rw [h]; exact middle_sector_dimensions.2
  have : Nontrivial (sector a) := Module.nontrivial_of_finrank_pos (by rw [hd]; decide)
  have ha' : a * a = 1 := by rcases ha with rfl | rfl <;> simp
  apply irreducible_of_subrepresentations
  intro U
  let W : Submodule ℂ Mid := U.toSubmodule.map (sector a).subtype
  have hW : Stable W := by
    intro g x hx
    obtain ⟨y, hy, rfl⟩ := Submodule.mem_map.mp hx
    exact Submodule.mem_map.mpr ⟨sectorRepresentation a g y, U.apply_mem_toSubmodule g hy, rfl⟩
  have hle : W ≤ sector a := by
    intro x hx
    obtain ⟨y, _, rfl⟩ := Submodule.mem_map.mp hx
    exact y.prop
  rcases middle_sector_irreducible a ha' W hW hle with h | h
  · left
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective (sector a).subtype_injective
    change W = (⊥ : Submodule ℂ (sector a)).map (sector a).subtype
    rw [Submodule.map_bot, h]
  · right
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective (sector a).subtype_injective
    change W = (⊤ : Submodule ℂ (sector a)).map (sector a).subtype
    rw [Submodule.map_top, Submodule.range_subtype, h]

/-- The subspace generated by the orbit of a vector in an exterior power. -/
def orbitSpan {k : ℕ} (x : Exterior k) : Submodule ℂ (Exterior k) :=
  Submodule.span ℂ (Set.range fun g => exteriorRepresentation k g x)

theorem orbitSpan_stable {k : ℕ} (x : Exterior k) : Stable (orbitSpan x) := by
  intro g y hy
  have hle : orbitSpan x ≤ (orbitSpan x).comap (exteriorRepresentation k g) := by
    apply Submodule.span_le.mpr
    rintro _ ⟨h, rfl⟩
    exact Submodule.subset_span ⟨g * h, by
      change exteriorRepresentation k (g * h) x = exteriorRepresentation k g (exteriorRepresentation k h x)
      rw [map_mul]
      rfl⟩
  exact hle hy

private theorem mem_orbitSpan {k : ℕ} (x : Exterior k) : x ∈ orbitSpan x :=
  Submodule.subset_span ⟨1, by
    change exteriorRepresentation k 1 x = x
    rw [map_one]
    rfl⟩

/-- The null-basis highest-weight wedge generates the full exterior power
in every non-middle degree. -/
theorem highestPlus_generates (k : Fin 15) (hk : k.val ≠ 7) :
    orbitSpan (axisBasis.exteriorPower k.val (highestPlus k)) = ⊤ := by
  let x := axisBasis.exteriorPower k.val (highestPlus k)
  have hx : orbitSpan x ≠ ⊥ := by
    intro h
    have hv := mem_orbitSpan x
    rw [h, Submodule.mem_bot] at hv
    exact highestPlus_ne_zero k hv
  exact (exterior_irreducible k.val hk (orbitSpan x) (orbitSpan_stable x)).resolve_left hx

private theorem orbitSpan_eq_sector (a : ℂ) (ha : a * a = 1) (x : Mid)
    (hx : x ≠ 0) (hmem : x ∈ sector a) : orbitSpan x = sector a := by
  have hle : orbitSpan x ≤ sector a := by
    apply Submodule.span_le.mpr
    rintro _ ⟨g, rfl⟩
    exact sector_invariant a g x hmem
  apply (middle_sector_irreducible a ha _ (orbitSpan_stable x) hle).resolve_left
  intro h
  have hv := mem_orbitSpan x
  rw [h, Submodule.mem_bot] at hv
  exact hx hv

/-- The degree-seven wedge of weight `μ₇⁺` generates the negative Hodge sector. -/
theorem middlePlus_generates :
    orbitSpan (axisBasis.exteriorPower 7 (highestPlus (7 : Fin 15))) = sector (-1) :=
  orbitSpan_eq_sector (-1) (by norm_num) _ (highestPlus_ne_zero (7 : Fin 15)) highestPlus_mem_sector

/-- The degree-seven wedge of weight `μ₇⁻` generates the positive Hodge sector. -/
theorem middleMinus_generates : orbitSpan (axisBasis.exteriorPower 7 lastMinus) = sector 1 :=
  orbitSpan_eq_sector 1 (by norm_num) _ lastMinus_ne_zero lastMinus_mem_sector

end
end GeometricUnity.D7Irreducible
