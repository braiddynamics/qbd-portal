#!/usr/bin/env python3
"""
Unified Computational & Symbolic Verification Suite for Geometric Unity
=======================================================================
The program runs six groups of verification checks using exact integer counts
and BLAS-accelerated matrix calculations. The final line reports the peak
allocation measured by tracemalloc for the current run.

  [V1] Cl(7,7) = End(C^128), J vs J' = i*J*Gamma_*, Eq. (3.27) Checkerboard,
       and u(64,64) Cartan / Killing Decomposition (8190 + 2 compact, 8192 coset).
  [V2] 6-Op to 3-Blade Reduction (Prop. 2), 4-Jet Proof Table, 8D Equivariant
       Space -> 4D Bianchi SVD, 3-Example Independence, 5th Trace Operator,
       and Exact D_7 = so(14,C) Klimyk Representation Count (200 -> 96).
  [V3] Non-Degenerate 14D Curved Riemann Normal Coordinates, Real Einstein
       Tensor Reconstruction (Prop. 1), Differential Bianchi Identity, and
       Finite U(64,64) Gauge Covariance (Bare vs Dressed across all 4 operators).
  [V4] Non-Abelian Bianchi Identity (D_A F_A = 0), Non-Circular Direct 3-Blade
       D_A-Divergence Formula, and D_{B_w} Torsion-Source Identity (Prop. 3).
  [V5] Typed Exterior Algebra on (R^{7,7}, eta), Hodge Star Involution ** = (-1)^{p+1},
       Eq. (9.3) Bracket Audit, Corrected 2-Bracket Realization, Exact Clifford
       Obstruction Witness (-8/3 gamma^{01234}), and Sparse Finite Differences.
  [V6] Full Derivative-Dependent 14D Periodic Action (Eq. 9.4) with F_B = 0,
       1D (N = 8, 10, 14) & Full 2D (N = 8, 10) Continuum Grid Convergence,
       -256 Dressed Kinetic Witness, Mixed-Harmonic Integration by Parts,
       Commutator-Sector Invisibility, Case A & Case B 4-Channel Variations,
       and True Fixed-A Coupled Dressing Variation (E_eps = D_{A,a} E_A^a).
"""

from functools import lru_cache
import gc
import hashlib
from itertools import combinations
from pathlib import Path
import platform
import sys
import time
import tracemalloc
import numpy as np

tracemalloc.start()
t0 = time.perf_counter()


class LiveProgress:
    """In-place live terminal progress bar with elapsed time & ETA (< 80 cols)."""
    def __init__(self, tag: str, total: int, desc: str, width: int = 18):
        self.tag = tag
        self.total = max(1, total)
        self.desc = desc
        self.width = width
        self.t_start = time.perf_counter()
        self.last_draw = 0.0
        self.update(0, force=True)

    def update(self, current: int, force: bool = False):
        now = time.perf_counter()
        if not force and (now - self.last_draw) < 0.04 and current < self.total:
            return
        self.last_draw = now
        frac = min(1.0, current / self.total)
        filled = int(self.width * frac)
        bar = "#" * filled + "-" * (self.width - filled)
        elapsed = now - self.t_start
        eta = (elapsed / frac - elapsed) if frac > 0.02 else 0.0
        line = (f"\r[{self.tag}] [{bar}] {int(frac * 100):3d}% ({current}/{self.total}) "
                f"{self.desc} | {elapsed:4.1f}s ETA {eta:3.1f}s")
        sys.stdout.write(f"{line[:79]:<79}")
        sys.stdout.flush()

    def finish(self, summary: str):
        total_elapsed = time.perf_counter() - t0
        line = f"\r[{self.tag} | {total_elapsed:5.2f}s] {summary}"
        sys.stdout.write(f"{line:<79}\n")
        sys.stdout.flush()


# ==============================================================================
# VERIFICATION GROUP 1: Cl_C(7,7) = End(C^128), Hermitian Forms J vs J' = i J Gamma_*,
#              Eq. (3.27) Checkerboard, and u(64,64) Signature Decomposition
# ==============================================================================
p1 = LiveProgress("V1", 18, "Cl(7,7), J vs J', Eq.(3.27)")

DIM = 14
ETA_REAL = np.array([1.0] * 7 + [-1.0] * 7, dtype=np.float64)
ETA_DIAG = ETA_REAL.astype(np.complex128)
ETA_MAT = np.diag(ETA_DIAG)
ALL_INDICES = tuple(range(DIM))

I2 = np.eye(2, dtype=np.complex128)
sx = np.array([[0, 1], [1, 0]], dtype=np.complex128)
sy = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
sz = np.array([[1, 0], [0, -1]], dtype=np.complex128)


def kron_list(mats):
    res = mats[0]
    for m in mats[1:]:
        res = np.kron(res, m)
    return res


gammas_eucl = []
for k in range(7):
    gammas_eucl.append(kron_list([sz] * k + [sx] + [I2] * (6 - k)))
    gammas_eucl.append(kron_list([sz] * k + [sy] + [I2] * (6 - k)))

gammas = np.array([gammas_eucl[a] if a < 7 else 1j * gammas_eucl[a] for a in range(DIM)])
I128 = np.eye(128, dtype=np.complex128)

cliff_err = max(
    np.max(np.abs(gammas[a] @ gammas[b] + gammas[b] @ gammas[a] - 2.0 * ETA_DIAG[a] * (a == b) * I128))
    for a in range(DIM) for b in range(DIM)
)
assert cliff_err < 1e-14, f"Clifford anticommutator failed: {cliff_err}"

J = I128.copy()
for a in range(7):
    J = J @ gammas[a]
if np.allclose(J @ J, -I128):
    J = 1j * J

Gamma_star = I128.copy()
for a in range(DIM):
    Gamma_star = Gamma_star @ gammas[a]
GSTAR_DIAG = np.diag(Gamma_star).copy()
assert np.max(np.abs(Gamma_star - np.diag(GSTAR_DIAG))) < 1e-15

J_prime = 1j * J @ Gamma_star
assert np.max(np.abs(J_prime.conj().T - J_prime)) < 1e-14
assert np.max(np.abs(J_prime @ J_prime - I128)) < 1e-14
assert np.isclose(np.trace(J_prime), 0.0)


def assert_in_u64(mat_batch, name: str = "tensor"):
    scale = max(1.0, float(np.max(np.abs(mat_batch))))
    err = float(np.max(np.abs(np.swapaxes(mat_batch.conj(), -1, -2) @ J_prime + J_prime @ mat_batch))) / scale
    assert err < 1e-12, f"{name} failed J'-skew-adjointness: rel err = {err}"


g_self_J_err = max(np.max(np.abs(gammas[a].conj().T @ J - J @ gammas[a])) for a in range(DIM))
g_skew_Jp_err = max(np.max(np.abs(gammas[a].conj().T @ J_prime + J_prime @ gammas[a])) for a in range(DIM))
p1.update(1, force=True)

rng = np.random.default_rng(42)
eq327_under_J_err = 0.0
rev_under_J_err = 0.0
eq327_under_Jp_err = 0.0

for k in range(DIM + 1):
    mat = np.zeros((128, 128), dtype=np.complex128)
    for _ in range(5):
        idx = sorted(rng.choice(DIM, size=k, replace=False))
        blade = I128.copy()
        for a in idx:
            blade = blade @ gammas[a]
        mat += rng.normal() * blade
    mat_eq327 = (1j * mat) if (k % 4 in (0, 3)) else mat
    mat_rev = (1j * mat) if (k % 4 in (0, 1)) else mat
    eq327_under_J_err = max(eq327_under_J_err, np.max(np.abs(mat_eq327.conj().T @ J + J @ mat_eq327)))
    rev_under_J_err = max(rev_under_J_err, np.max(np.abs(mat_rev.conj().T @ J + J @ mat_rev)))
    eq327_under_Jp_err = max(eq327_under_Jp_err, np.max(np.abs(mat_eq327.conj().T @ J_prime + J_prime @ mat_eq327)))
    p1.update(k + 2, force=True)

# Cartan decomposition of u(64,64): k = su(64) + su(64) + u(1)_center + u(1)_{J'} (8190 + 2) vs p (8192)
P_pos = 0.5 * (I128 + J_prime)
P_neg = 0.5 * (I128 - J_prime)
M_raw = rng.normal(size=(128, 128)) + 1j * rng.normal(size=(128, 128))
X_sample = J_prime @ (M_raw - M_raw.conj().T)
X_comp = P_pos @ X_sample @ P_pos + P_neg @ X_sample @ P_neg
X_noncomp = P_pos @ X_sample @ P_neg + P_neg @ X_sample @ P_pos
tr_comp_sq = float(np.trace(X_comp @ X_comp).real)
tr_noncomp_sq = float(np.trace(X_noncomp @ X_noncomp).real)

Z_center = 1j * I128
Z_rel_u1 = 1j * J_prime
assert_in_u64(Z_center, "Z_center")
assert_in_u64(Z_rel_u1, "Z_rel_u1")
killing_center = float((256.0 * np.trace(Z_center @ Z_center) - 2.0 * (np.trace(Z_center) ** 2)).real)
killing_rel_u1 = float((256.0 * np.trace(Z_rel_u1 @ Z_rel_u1) - 2.0 * (np.trace(Z_rel_u1) ** 2)).real)
dim_k_semisimple = 2 * (64 * 64 - 1)  # 8190
assert tr_comp_sq < 0.0 and tr_noncomp_sq > 0.0
assert abs(killing_center) < 1e-12 and np.isclose(killing_rel_u1, -32768.0) and dim_k_semisimple == 8190
p1.update(18, force=True)

p1.finish(f"Cl(7,7) err={cliff_err:.1e} | Eq.3.27(J)={eq327_under_J_err:.2f}, Eq.3.27(J')={eq327_under_Jp_err:.1e}")
print(f"    * Reversal J vs Conjugation J': ||g_a^dag J - J g_a|| = {g_self_J_err:.1e}, ||g_a^dag J' + J' g_a|| = {g_skew_Jp_err:.1e}")
print(f"    * Cartan Tr(X^2) in u(64,64):   Tr(X_comp^2) = {tr_comp_sq:+.4e} (<0), Tr(X_noncomp^2) = {tr_noncomp_sq:+.4e} (>0)")
print(f"    * Compact k = su(64)+su(64)+u(1)^2: [k,k]={dim_k_semisimple}, B(iI,iI)={killing_center:.1e}, B(iJ',iJ')={killing_rel_u1:.0f}, coset p=8192")


# ==============================================================================
# VERIFICATION GROUP 2: 2D-BLAS Shiab Operators, 6-Op -> 3-Blade Identity,
#              8 -> 4 Bianchi SVD, and Exact D_7 = so(14,C) Count (200 -> 96)
# ==============================================================================
p2 = LiveProgress("V2", 30, "6->2, 8->4 SVD & D_7 200->96")

gamma_up = gammas * ETA_DIAG[:, None, None]
g_up_star = gamma_up * GSTAR_DIAG[None, None, :]

G_up_row = gamma_up.transpose(1, 0, 2).reshape(128, 14 * 128)
G_up_col = gamma_up.reshape(14 * 128, 128)
G_dn_col = gammas.reshape(14 * 128, 128)
G_dn_row = gammas.transpose(1, 0, 2).reshape(128, 14 * 128)
G_ups_row = g_up_star.transpose(1, 0, 2).reshape(128, 14 * 128)
G_ups_col = g_up_star.reshape(14 * 128, 128)


def _L3_R3_from_L1_R1(L1, R1):
    S_L = -(G_up_row @ L1.reshape(14 * 128, 128))
    S_R = R1.transpose(1, 0, 2).reshape(128, 14 * 128) @ G_up_col
    L3 = (G_dn_col @ S_L).reshape(14, 128, 128) + 2.0 * L1
    R3 = (S_R @ G_dn_row).reshape(128, 14, 128).transpose(1, 0, 2) - 2.0 * R1
    return L3, R3


def theta_both_from_M(M):
    """Evaluates (Theta_Ein, Theta_Bianchi) directly from 2D layout M of shape (1792, 1792)."""
    L1 = (G_up_row @ M).reshape(128, 14, 128).transpose(1, 0, 2)
    R1 = -(M @ G_up_col).reshape(14, 128, 128)
    L3, R3 = _L3_R3_from_L1_R1(L1, R1)
    return 0.5 * (L3 + R3), 0.5j * (L3 - R3)


def theta_both_bare(F):
    return theta_both_from_M(F.transpose(0, 2, 1, 3).reshape(14 * 128, 14 * 128))


def theta_ein_bare(F):
    M = F.transpose(0, 2, 1, 3).reshape(14 * 128, 14 * 128)
    L1 = (G_up_row @ M).reshape(128, 14, 128).transpose(1, 0, 2)
    R1 = -(M @ G_up_col).reshape(14, 128, 128)
    L3, R3 = _L3_R3_from_L1_R1(L1, R1)
    return 0.5 * (L3 + R3)


def eval_6_and_8_ops(F):
    M = F.transpose(0, 2, 1, 3).reshape(14 * 128, 14 * 128)
    L1 = (G_up_row @ M).reshape(128, 14, 128).transpose(1, 0, 2)
    R1 = -(M @ G_up_col).reshape(14, 128, 128)
    O1_c = L1 - R1
    O1_a = 1j * (L1 + R1)

    S_L = -(G_up_row @ L1.reshape(14 * 128, 128))
    S_R = R1.transpose(1, 0, 2).reshape(128, 14 * 128) @ G_up_col
    S_c = S_L - S_R
    S_a = 1j * (S_L + S_R)

    O2_cc = (gammas @ S_c[None]) - (S_c[None] @ gammas)
    O2_ca = (gammas @ S_a[None]) - (S_a[None] @ gammas)
    O2_ac = 1j * ((gammas @ S_c[None]) + (S_c[None] @ gammas))
    O2_aa = 1j * ((gammas @ S_a[None]) + (S_a[None] @ gammas))

    L3 = (G_dn_col @ S_L).reshape(14, 128, 128) + 2.0 * L1
    R3 = (S_R @ G_dn_row).reshape(128, 14, 128).transpose(1, 0, 2) - 2.0 * R1
    T3_ein = 0.5 * (L3 + R3)
    T3_bia = 0.5j * (L3 - R3)

    L13 = (G_ups_row @ M).reshape(128, 14, 128).transpose(1, 0, 2)
    R13 = -(M @ G_ups_col).reshape(14, 128, 128)
    O13_c = L13 - R13
    O13_a = 1j * (L13 + R13)

    Sh_L = GSTAR_DIAG[:, None] * S_L
    Sh_R = S_R * GSTAR_DIAG[None, :]
    L11 = (G_dn_col @ Sh_L).reshape(14, 128, 128) + 2.0 * L13
    R11 = -(Sh_R @ G_dn_row).reshape(128, 14, 128).transpose(1, 0, 2) - 2.0 * R13
    T11_ein = 0.5 * (L11 + R11)
    T11_bia = 0.5j * (L11 - R11)

    ops6 = [O1_c, O1_a, O2_cc, O2_ca, O2_ac, O2_aa]
    ops8 = [O1_c, O1_a, O13_c, O13_a, T3_ein, T3_bia, T11_ein, T11_bia]
    return ops6, ops8


def trace_shiab(F):
    tr_F = np.trace(F, axis1=2, axis2=3)
    return theta_ein_bare(tr_F[:, :, None, None] * I128[None, None])


def random_u64(shape=()):
    M = rng.normal(size=shape + (128, 128)) + 1j * rng.normal(size=shape + (128, 128))
    return J_prime @ (M - np.swapaxes(M.conj(), -1, -2))


F_rand2 = random_u64((14, 14))
F_rand2 = 0.5 * (F_rand2 - np.swapaxes(F_rand2, 0, 1))
ops6_test, ops8_test = eval_6_and_8_ops(F_rand2)
tr_op_test = trace_shiab(F_rand2)

O1_c, O1_a, O2_cc, O2_ca, O2_ac, O2_aa = ops6_test
T3_ein, T3_bia = ops8_test[4], ops8_test[5]
prop2_ein_err = float(np.linalg.norm((O1_c + 0.25 * (O2_cc - O2_aa)) - T3_ein) / np.linalg.norm(T3_ein))
prop2_bia_err = float(np.linalg.norm((O1_a + 0.25 * (O2_ca + O2_ac)) - T3_bia) / np.linalg.norm(T3_bia))
assert prop2_ein_err < 1e-13 and prop2_bia_err < 1e-13

for idx, op in enumerate(ops8_test + [tr_op_test]):
    assert_in_u64(op, f"equivariant_op_{idx}")
p2.update(1, force=True)

d0F = np.zeros((14, 14, 128, 128), dtype=np.complex128)
names6 = ["O1_c", "O1_a", "O2_cc", "O2_ca", "O2_ac", "O2_aa"]
four_jet_results = {}
for label, M_jet in [
    ("i*I", 1j * I128),
    ("gamma^1", gamma_up[1]),
    ("gamma^0", gamma_up[0]),
    ("gamma^{01}", gamma_up[0] @ gamma_up[1]),
]:
    assert_in_u64(M_jet, label)
    d0F.fill(0.0)
    d0F[0, 1] = M_jet
    d0F[1, 0] = -M_jet
    o6, _ = eval_6_and_8_ops(d0F)
    four_jet_results[label] = [(n, round(float(np.linalg.norm(op[0])), 2)) for n, op in zip(names6, o6) if np.linalg.norm(op[0]) > 1e-10]

names_bia4 = ["T3_ein", "T3_bia", "T11_ein", "T11_bia"]
indep3_results = {}
for label, X_ind in [("i*I", 1j * I128), ("gamma^0", gamma_up[0]), ("gamma^3", gamma_up[3])]:
    F_ind = np.zeros((14, 14, 128, 128), dtype=np.complex128)
    F_ind[1, 2] = X_ind
    F_ind[2, 1] = -X_ind
    _, o8 = eval_6_and_8_ops(F_ind)
    indep3_results[label] = [n for n, op in zip(names_bia4, o8[4:]) if np.linalg.norm(op[0]) > 1e-10]
assert indep3_results["i*I"] == ["T3_ein", "T11_ein"]
assert indep3_results["gamma^0"] == ["T3_ein", "T11_bia"]
assert indep3_results["gamma^3"] == ["T3_bia", "T11_ein"]

# Low-memory factored closed 2-form jet SVD (28 MiB vs 686 MiB)
S_m2 = rng.normal(size=(8, 14, 14))
S_m2 = 0.5 * (S_m2 + np.swapaxes(S_m2, 1, 2))
W_m2 = random_u64((8, 14))
divs6 = [np.zeros((128, 128), dtype=np.complex128) for _ in range(6)]
divs8 = [np.zeros((128, 128), dtype=np.complex128) for _ in range(8)]
for a in range(DIM):
    Q_a = np.einsum('rb,rcjk->bcjk', S_m2[:, a, :], W_m2)
    F1_a = Q_a - np.swapaxes(Q_a, 0, 1)
    o6, o8 = eval_6_and_8_ops(F1_a)
    for k in range(6):
        divs6[k] += ETA_DIAG[a] * o6[k][a]
    for k in range(8):
        divs8[k] += ETA_DIAG[a] * o8[k][a]
    p2.update(a + 2, force=True)
del S_m2, W_m2, Q_a, F1_a

A6_mat = np.column_stack([np.concatenate([divs6[k].real.ravel(), divs6[k].imag.ravel()]) for k in range(6)])
_, s6, _ = np.linalg.svd(A6_mat, full_matrices=False)
null_6 = int(np.sum(s6 < 1e-7))

A8_mat = np.column_stack([np.concatenate([divs8[k].real.ravel(), divs8[k].imag.ravel()]) for k in range(8)])
_, s8, _ = np.linalg.svd(A8_mat, full_matrices=False)
null_8 = int(np.sum(s8 < 1e-7))

B5_mat = np.column_stack([np.concatenate([op.real.ravel(), op.imag.ravel()]) for op in (ops8_test[4:] + [tr_op_test])])
_, s5, _ = np.linalg.svd(B5_mat, full_matrices=False)
rank_5 = int(np.sum(s5 > 1e-7))
assert null_6 == 2 and null_8 == 4 and rank_5 == 5
del A6_mat, A8_mat, B5_mat, divs6, divs8, ops6_test, ops8_test, tr_op_test

weights_V = [(i, s) for i in range(7) for s in (1, -1)]


def wedge_weights(k: int):
    out = []
    for comb in combinations(weights_V, k):
        w = [0] * 7
        for i, s in comb:
            w[i] += s
        out.append(tuple(w))
    return tuple(out)


rho_D7 = (6, 5, 4, 3, 2, 1, 0)


def reflect_D7(v):
    if len({abs(x) for x in v}) < 7:
        return None
    arr = list(v)
    sgn = 1
    for i in range(7):
        for j in range(6 - i):
            if abs(arr[j]) < abs(arr[j + 1]):
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                sgn = -sgn
    flips = 0
    for i in range(6):
        if arr[i] < 0:
            arr[i] = -arr[i]
            flips += 1
    if flips % 2 == 1:
        arr[6] = -arr[6]
    return tuple(arr), sgn


W_BY_DEG = {1: wedge_weights(1), 2: wedge_weights(2), 3: wedge_weights(3)}


@lru_cache(maxsize=None)
def klimyk_D7(deg: int, lam: tuple):
    mults = {}
    for nu in W_BY_DEG[deg]:
        res = reflect_D7([lam[i] + rho_D7[i] + nu[i] for i in range(7)])
        if res is not None:
            dom, sgn = res
            mu = tuple(dom[i] - rho_D7[i] for i in range(7))
            mults[mu] = mults.get(mu, 0) + sgn
    return {mu: m for mu, m in mults.items() if m != 0}


def irrep_Lambda_k(k: int):
    if k == 0 or k == 14:
        return [(0, 0, 0, 0, 0, 0, 0)]
    if k > 7:
        k = 14 - k
    if k < 7:
        return [tuple([1] * k + [0] * (7 - k))]
    return [(1, 1, 1, 1, 1, 1, 1), (1, 1, 1, 1, 1, 1, -1)]


decomp_Cl = {}
decomp_L1_Cl = {}
for k in range(DIM + 1):
    for lam in irrep_Lambda_k(k):
        decomp_Cl[lam] = decomp_Cl.get(lam, 0) + 1
        for mu, m in klimyk_D7(1, lam).items():
            decomp_L1_Cl[mu] = decomp_L1_Cl.get(mu, 0) + m

tot_unres = 0
tot_bianchi = 0
tot_vec_channel = 0
for k in range(DIM + 1):
    for lam in irrep_Lambda_k(k):
        d1 = klimyk_D7(1, lam)
        d2 = klimyk_D7(2, lam)
        d3 = klimyk_D7(3, lam)
        tot_unres += sum(m * decomp_L1_Cl.get(mu, 0) for mu, m in d2.items())
        tot_bianchi += sum(m * decomp_Cl.get(mu, 0) for mu, m in d3.items())
        tot_vec_channel += sum(m * decomp_Cl.get(mu, 0) for mu, m in d1.items())
    p2.update(16 + k, force=True)

tot_hook_channel = tot_unres - tot_bianchi - tot_vec_channel
assert tot_unres == 200 and tot_bianchi == 96 and tot_vec_channel == 56 and tot_hook_channel == 48

p2.finish(f"Classifications verified: 6->{null_6}, 8->{null_8} (SVD), unrestricted D_7: {tot_unres}->{tot_bianchi}")
print(f"    * Prop 2(1) 3-blade identity:  ||O1_c+1/4(O2_cc-O2_aa) - T3_ein||/||T3|| = {prop2_ein_err:.1e}, T3_bia = {prop2_bia_err:.1e}")
print(f"    * 4-jet proof table (a=0):     iI->{four_jet_results['i*I']}, g^0->{four_jet_results['gamma^0']}")
print(f"    * 8D Bianchi SVD spectrum:     {[round(float(x), 1) for x in s8[:4]]} + 4 null modes (~{s8[4]:.1e})")
print(f"    * D_7 = so(14,C) channels:     Lambda^3 V = {tot_bianchi} (Bianchi), V = {tot_vec_channel}, Hook H_(2,1) = {tot_hook_channel} (Total = {tot_unres})")


# ==============================================================================
# VERIFICATION GROUP 3: Non-Degenerate Curved Riemann Normal Coordinates, Real Einstein
#              Reconstruction (Prop. 1), and Finite U(64,64) Gauge Covariance
# ==============================================================================
p3 = LiveProgress("V3", 4, "Curved 14D Einstein & U(64,64)")

H = rng.normal(size=(14, 14, 14, 14))
H = 0.25 * (H + np.swapaxes(H, 0, 1) + np.swapaxes(H, 2, 3) + np.swapaxes(np.swapaxes(H, 0, 1), 2, 3))

K = rng.normal(size=(14, 14, 14, 14, 14))
K = 0.5 * (K + np.swapaxes(K, 0, 1))
K = (K + np.einsum('abcde->abdec', K) + np.einsum('abcde->abecd', K)
     + np.swapaxes(K, 2, 3) + np.swapaxes(K, 2, 4) + np.swapaxes(K, 3, 4)) / 6.0

R0 = 0.5 * (np.einsum('adbc->abcd', H) + np.einsum('bcad->abcd', H)
            - np.einsum('bdac->abcd', H) - np.einsum('acbd->abcd', H))
dR = 0.5 * (np.einsum('adbce->eabcd', K) + np.einsum('bcade->eabcd', K)
            - np.einsum('bdace->eabcd', K) - np.einsum('acbde->eabcd', K))

norm_R0 = float(np.linalg.norm(R0))
norm_dR = float(np.linalg.norm(dR))
assert norm_R0 > 50.0 and norm_dR > 100.0
p3.update(1, force=True)

gamma_2up = gamma_up[:, None, :, :] @ gamma_up[None, :, :, :]
for b in range(DIM):
    gamma_2up[b, b] = 0.0

F_riem = 0.25 * np.tensordot(R0, gamma_2up, axes=([2, 3], [0, 1]))
p3.update(2, force=True)

_, ops8_riem = eval_6_and_8_ops(F_riem)
T3_ein_riem, T3_bia_riem, T11_ein_riem, T11_bia_riem = ops8_riem[4:]

Ric = np.einsum('cd,cadb->ab', ETA_MAT, R0)
R_scal = np.einsum('ab,ab->', ETA_MAT, Ric)
G_exact = np.tensordot(Ric - 0.5 * R_scal * ETA_MAT, gamma_up, axes=([1], [0]))
norm_G = float(np.linalg.norm(G_exact))

ein_rel_err = float(np.linalg.norm(T3_ein_riem - G_exact) / norm_G)
ein_dual_err = float(np.linalg.norm(T11_ein_riem - (G_exact * GSTAR_DIAG[None, None, :])) / norm_G)
bia_riem_rel = float((np.linalg.norm(T3_bia_riem) + np.linalg.norm(T11_bia_riem)) / norm_G)

div_G = np.zeros((128, 128), dtype=np.complex128)
for a in range(DIM):
    dF_riem_a = 0.25 * np.tensordot(dR[a], gamma_2up, axes=([2, 3], [0, 1]))
    div_G += ETA_DIAG[a] * theta_ein_bare(dF_riem_a)[a]
div_G_norm = float(np.linalg.norm(div_G))
div_G_rel = div_G_norm / norm_G
assert ein_rel_err < 1e-13 and ein_dual_err < 1e-13 and bia_riem_rel < 1e-13 and div_G_rel < 1e-12
del H, K, R0, dR, F_riem, dF_riem_a, gamma_2up, ops8_riem, G_exact
p3.update(3, force=True)


def cayley(X):
    return np.linalg.solve(I128 + X, I128 - X)


eps_g = cayley(0.01 * random_u64())
eps_g_inv = np.linalg.inv(eps_g)
h_g = cayley(0.01 * random_u64())
h_g_inv = np.linalg.inv(h_g)
unitarity_err = float(np.max(np.abs(h_g.conj().T @ J_prime @ h_g - J_prime)))


def eval_4_bianchi_dressed(F, eps_mat, einv_mat):
    F_bar = eps_mat[None, None] @ F @ einv_mat[None, None]
    _, o8 = eval_6_and_8_ops(F_bar)
    return [einv_mat[None] @ op @ eps_mat[None] for op in o8[4:]]


F_cov = random_u64((14, 14))
F_cov = 0.5 * (F_cov - np.swapaxes(F_cov, 0, 1))
F_cov_rot = h_g_inv[None, None] @ F_cov @ h_g[None, None]

bare_0 = theta_ein_bare(F_cov)
bare_rot = theta_ein_bare(F_cov_rot)
bare_cov_err = float(np.linalg.norm(bare_rot - (h_g_inv[None] @ bare_0 @ h_g[None])) / np.linalg.norm(bare_0))

dressed_0 = eval_4_bianchi_dressed(F_cov, eps_g, eps_g_inv)
dressed_rot = eval_4_bianchi_dressed(F_cov_rot, eps_g @ h_g, h_g_inv @ eps_g_inv)
dressed_cov_errs = [
    float(np.linalg.norm(dr - (h_g_inv[None] @ d0 @ h_g[None])) / np.linalg.norm(d0))
    for d0, dr in zip(dressed_0, dressed_rot)
]
assert bare_cov_err > 0.1 and max(dressed_cov_errs) < 1e-12
del F_cov, F_cov_rot, bare_0, bare_rot, dressed_0, dressed_rot
gc.collect()
p3.update(4, force=True)

p3.finish(f"14D Einstein err={ein_rel_err:.2e} (||R||={norm_R0:.1f}) | Bianchi div={div_G_norm:.2e} | Cov={max(dressed_cov_errs):.2e}")
print(f"    * Prop 1 on F_Riem:            ||T3_ein - G_ab g^b||/||G|| = {ein_rel_err:.2e}, dual = {ein_dual_err:.2e}, ||T_bia||/||G|| = {bia_riem_rel:.2e}")
print(f"    * U(64,64) gauge covariance:   ||h^dag J' h - J'|| = {unitarity_err:.2e} | Bare err = {bare_cov_err:.2f} vs Dressed max err = {max(dressed_cov_errs):.2e}")


# ==============================================================================
# VERIFICATION GROUP 4: Low-Memory Non-Abelian Bianchi Identity (D_A F_A = 0),
#              Non-Circular Direct 3-Blade D_A-Divergence, and Prop. 3
# ==============================================================================
p4 = LiveProgress("V4", 16, "Non-Abelian D_{B_w} & Torsion")

eps0 = cayley(0.01 * random_u64())
eps0_inv = np.linalg.inv(eps0)
X_a = random_u64((14,))
T0_jet = random_u64((14,))
A1 = random_u64((14, 14))
A0 = X_a + T0_jet

comm_A0 = (A0[:, None] @ A0[None, :]) - (A0[None, :] @ A0[:, None])
F_A0 = A1 - np.swapaxes(A1, 0, 1) + comm_A0

S_jet = rng.normal(size=(4, 14, 14))
S_jet = 0.5 * (S_jet + np.swapaxes(S_jet, 1, 2))
W_jet = random_u64((4, 14))

TRIPLES_364 = list(combinations(range(DIM), 3))
bianchi_triples = np.zeros((len(TRIPLES_364), 128, 128), dtype=np.complex128)
triples_by_c = [[] for _ in range(DIM)]
for t_idx, (c_t, a_t, b_t) in enumerate(TRIPLES_364):
    triples_by_c[c_t].append((t_idx, a_t, b_t))
    triples_by_c[a_t].append((t_idx, b_t, c_t))
    triples_by_c[b_t].append((t_idx, c_t, a_t))

div_DB_T1 = np.zeros((128, 128), dtype=np.complex128)
div_DB_T2 = np.zeros((128, 128), dtype=np.complex128)
rhs_T1 = np.zeros((128, 128), dtype=np.complex128)
rhs_T2 = np.zeros((128, 128), dtype=np.complex128)
max_DA_FA_scale = 0.0
p4.update(2, force=True)

for c in range(DIM):
    Q_c = np.einsum('ra,rbjk->abjk', S_jet[:, c, :], W_jet)
    c_A1_A0 = (A1[c, :, None] @ A0[None, :]) - (A0[None, :] @ A1[c, :, None])
    dF_A_c = (Q_c - np.swapaxes(Q_c, 0, 1)) + (c_A1_A0 - np.swapaxes(c_A1_A0, 0, 1))

    DA_FA_c = dF_A_c + (A0[c, None, None] @ F_A0 - F_A0 @ A0[c, None, None])
    max_DA_FA_scale = max(max_DA_FA_scale, float(np.max(np.abs(DA_FA_c))))
    for t_idx, idx1, idx2 in triples_by_c[c]:
        bianchi_triples[t_idx] += DA_FA_c[idx1, idx2]

    DB_FA_c = dF_A_c + (X_a[c, None, None] @ F_A0 - F_A0 @ X_a[c, None, None])

    F_bc = F_A0[:, c]
    F_ca = F_A0[c, :]
    comm_TF_c = ((T0_jet[c, None, None] @ F_A0 - F_A0 @ T0_jet[c, None, None])
                 + (T0_jet[:, None] @ F_bc[None, :] - F_bc[None, :] @ T0_jet[:, None])
                 + (T0_jet[None, :] @ F_ca[:, None] - F_ca[:, None] @ T0_jet[None, :]))

    db_bar = eps0[None, None] @ DB_FA_c @ eps0_inv[None, None]
    tf_bar = eps0[None, None] @ comm_TF_c @ eps0_inv[None, None]
    t1_db, t2_db = theta_both_bare(db_bar)
    t1_tf, t2_tf = theta_both_bare(tf_bar)
    div_DB_T1 += ETA_DIAG[c] * (eps0_inv @ t1_db[c] @ eps0)
    div_DB_T2 += ETA_DIAG[c] * (eps0_inv @ t2_db[c] @ eps0)
    rhs_T1 += ETA_DIAG[c] * (eps0_inv @ t1_tf[c] @ eps0)
    rhs_T2 += ETA_DIAG[c] * (eps0_inv @ t2_tf[c] @ eps0)
    p4.update(c + 3, force=True)

bianchi_nonab_err = float(np.max(np.abs(bianchi_triples)))
bianchi_nonab_rel = bianchi_nonab_err / max_DA_FA_scale
err_prop3_ein = float(np.linalg.norm(div_DB_T1 + (1.0 / 3.0) * rhs_T1) / np.linalg.norm(div_DB_T1))
err_prop3_bia = float(np.linalg.norm(div_DB_T2 + (1.0 / 3.0) * rhs_T2) / np.linalg.norm(div_DB_T2))

# Non-circular, direct 3-blade commutator verification of D_A^a Theta_{Ein,eps}(F_A)_a = 1/2 {[T^a, \tilde{\gamma}_a^{bc}], F_{A,bc}}
F_hat_m4 = eps0[None, None] @ F_A0 @ eps0_inv[None, None]
T_hat_m4 = eps0[None] @ T0_jet @ eps0_inv[None]
Theta_FA0_ein, _ = theta_both_bare(F_hat_m4)
Theta_FA0_ein = eps0_inv[None] @ Theta_FA0_ein @ eps0[None]
div_DA_T1 = div_DB_T1 + sum(ETA_DIAG[a] * (T0_jet[a] @ Theta_FA0_ein[a] - Theta_FA0_ein[a] @ T0_jet[a]) for a in range(DIM))

explicit_rhs_hat = np.zeros((128, 128), dtype=np.complex128)
for a in range(DIM):
    for b in range(DIM):
        for c in range(b + 1, DIM):
            if a == b or a == c:
                continue
            G_abc = gammas[a] @ gamma_up[b] @ gamma_up[c]  # \gamma_a^{bc} (a lowered, b<c raised)
            C_abc = T_hat_m4[a] @ G_abc - G_abc @ T_hat_m4[a]
            explicit_rhs_hat += ETA_DIAG[a] * (C_abc @ F_hat_m4[b, c] + F_hat_m4[b, c] @ C_abc)
explicit_rhs_DA = eps0_inv @ explicit_rhs_hat @ eps0
err_DA_formula = float(np.linalg.norm(div_DA_T1 - explicit_rhs_DA) / np.linalg.norm(div_DA_T1))

assert bianchi_nonab_err < 1e-9 and bianchi_nonab_rel < 1e-13 and err_prop3_ein < 1e-12 and err_prop3_bia < 1e-12 and err_DA_formula < 1e-12
del bianchi_triples, Q_c, c_A1_A0, dF_A_c, DA_FA_c, DB_FA_c, comm_TF_c, db_bar, tf_bar, F_A0, F_hat_m4, A1
gc.collect()

p4.finish(f"D_A F_A=0 ({bianchi_nonab_err:.2e}, rel={bianchi_nonab_rel:.2e}) | Prop 3 err: Ein={err_prop3_ein:.2e}, Bia={err_prop3_bia:.2e}")
print(f"    * Direct 3-blade D_A-div check: ||D_A^a Theta_Ein(F_A)_a|| = {np.linalg.norm(div_DA_T1):.4e} (explicit 1/2{{[T^a,g_a^bc],F_bc}} rel err = {err_DA_formula:.2e})")


# ==============================================================================
# VERIFICATION GROUP 5: Typed Exterior Algebra on (R^{7,7}, eta), Hodge Star Involution,
#              Eq. (9.3) Bracket Audit, and Sparse Blade Variational Check
# ==============================================================================
p5 = LiveProgress("V5", 10, "Typed Forms & Eq.(9.3) Audit")


def perm_sign(seq):
    arr = list(seq)
    swaps = 0
    for i in range(len(arr)):
        for j in range(len(arr) - 1 - i):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swaps += 1
    return -1 if (swaps % 2) else 1


HODGE_MAP = {}
for p in range(DIM + 1):
    for I in combinations(ALL_INDICES, p):
        Ic = tuple(x for x in ALL_INDICES if x not in I)
        sgn = perm_sign(I + Ic)
        metric_prod = float(np.prod([ETA_REAL[idx] for idx in I])) if p > 0 else 1.0
        HODGE_MAP[I] = (Ic, sgn * metric_prod)
p5.update(2, force=True)


class DifferentialForm:
    """Typed p-form on R^{7,7} valued in Mat(128, C)."""
    def __init__(self, degree: int, comps: dict):
        assert 0 <= degree <= DIM
        self.degree = degree
        self.comps = {I: np.asarray(M, dtype=np.complex128) for I, M in comps.items() if np.any(M != 0)}

    def __add__(self, other):
        assert self.degree == other.degree
        out = {I: M.copy() for I, M in self.comps.items()}
        for I, M in other.comps.items():
            out[I] = out[I] + M if I in out else M.copy()
        return DifferentialForm(self.degree, out)

    def __sub__(self, other):
        return self + (-1.0 * other)

    def __rmul__(self, scalar):
        if scalar == 0:
            return DifferentialForm(self.degree, {})
        return DifferentialForm(self.degree, {I: scalar * M for I, M in self.comps.items()})

    def norm(self):
        return float(np.sqrt(sum(np.sum(np.abs(M) ** 2) for M in self.comps.values()))) if self.comps else 0.0

    def hodge_star(self):
        return DifferentialForm(DIM - self.degree, {HODGE_MAP[I][0]: HODGE_MAP[I][1] * M for I, M in self.comps.items()})


def wedge(alpha: DifferentialForm, beta: DifferentialForm) -> DifferentialForm:
    new_deg = alpha.degree + beta.degree
    if new_deg > DIM:
        return DifferentialForm(DIM, {})
    out = {}
    for I, A in alpha.comps.items():
        setI = set(I)
        for J_idx, B in beta.comps.items():
            if setI.isdisjoint(J_idx):
                comb = I + J_idx
                K_idx = tuple(sorted(comb))
                term = perm_sign(comb) * (A @ B)
                out[K_idx] = out[K_idx] + term if K_idx in out else term
    return DifferentialForm(new_deg, out)


def graded_bracket_wedge(alpha: DifferentialForm, beta: DifferentialForm, mode: str) -> DifferentialForm:
    new_deg = alpha.degree + beta.degree
    assert new_deg <= DIM
    out = {}
    for I, A in alpha.comps.items():
        setI = set(I)
        for J_idx, B in beta.comps.items():
            if setI.isdisjoint(J_idx):
                comb = I + J_idx
                K_idx = tuple(sorted(comb))
                mat = (A @ B - B @ A) if mode == 'comm' else 1j * (A @ B + B @ A)
                term = perm_sign(comb) * mat
                out[K_idx] = out[K_idx] + term if K_idx in out else term
    return DifferentialForm(new_deg, out)


def trace_pairing(alpha: DifferentialForm, beta: DifferentialForm) -> complex:
    assert alpha.degree == beta.degree
    top = wedge(alpha, beta.hodge_star())
    if ALL_INDICES not in top.comps:
        return 0.0 + 0.0j
    return complex(np.trace(top.comps[ALL_INDICES]))


hodge_inv_err = 0.0
for p in range(DIM + 1):
    sample_I = tuple(range(p))
    f_p = DifferentialForm(p, {sample_I: I128})
    expected_sign = -1.0 if (p % 2 == 0) else 1.0
    hodge_inv_err = max(hodge_inv_err, (f_p.hodge_star().hodge_star() - expected_sign * f_p).norm())
assert hodge_inv_err < 1e-14
p5.update(4, force=True)

Phi1 = DifferentialForm(1, {(a,): gammas[a] for a in range(DIM)})
Phi2 = DifferentialForm(2, {
    (a, b): 0.5 * (gammas[a] @ gammas[b] - gammas[b] @ gammas[a])
    for a in range(DIM) for b in range(a + 1, DIM)
})


def eq93_single_pair(xi: DifferentialForm, m1: str, m2: str, w: float = 0.5) -> DifferentialForm:
    star_xi = xi.hodge_star()
    t1 = graded_bracket_wedge(Phi1, star_xi, m1)
    inner = graded_bracket_wedge(Phi2, star_xi, m2).hodge_star()
    t2 = graded_bracket_wedge(Phi1, inner, m1).hodge_star()
    return t1 - w * t2


def eq93_corrected_typed(xi: DifferentialForm) -> DifferentialForm:
    """Exact typed realization: *Theta_Ein(xi) = -C1 - 1/2 (C2c - C2a)."""
    star_xi = xi.hodge_star()
    C1 = graded_bracket_wedge(Phi1, star_xi, 'comm')
    C2c = graded_bracket_wedge(Phi1, graded_bracket_wedge(Phi2, star_xi, 'comm').hodge_star(), 'comm').hodge_star()
    C2a = graded_bracket_wedge(Phi1, graded_bracket_wedge(Phi2, star_xi, 'anticomm').hodge_star(), 'anticomm').hodge_star()
    return (-1.0) * C1 - 0.5 * (C2c - C2a)


xi_riem_const = DifferentialForm(2, {
    (a, b): 0.5 * (gammas[a] @ gammas[b])
    for a in range(DIM) for b in range(a + 1, DIM)
})
F_riem_const_arr = np.zeros((14, 14, 128, 128), dtype=np.complex128)
for (a, b), M in xi_riem_const.comps.items():
    F_riem_const_arr[a, b] = M
    F_riem_const_arr[b, a] = -M
target_13_riem = DifferentialForm(1, {(a,): theta_ein_bare(F_riem_const_arr)[a] for a in range(DIM)}).hodge_star()

out_cc_riem = eq93_single_pair(xi_riem_const, 'comm', 'comm', 0.5)
err_cc_riem = min((out_cc_riem - target_13_riem).norm(), (out_cc_riem + target_13_riem).norm()) / target_13_riem.norm()
out_aa_riem = eq93_single_pair(xi_riem_const, 'anticomm', 'anticomm', 0.5)
err_aa_riem = min((out_aa_riem - target_13_riem).norm(), (out_aa_riem + target_13_riem).norm()) / target_13_riem.norm()
p5.update(6, force=True)

xi_gen_typed = DifferentialForm(2, {(a, b): F_rand2[a, b] for a in range(DIM) for b in range(a + 1, DIM)})
target_13_gen = DifferentialForm(1, {(a,): theta_ein_bare(F_rand2)[a] for a in range(DIM)}).hodge_star()
corr_13_gen = eq93_corrected_typed(xi_gen_typed)
err_corr_typed = (corr_13_gen - target_13_gen).norm() / target_13_gen.norm()
assert abs(err_cc_riem - 5.0 / 6.0) < 1e-12 and abs(err_aa_riem - 1.0 / 6.0) < 1e-12 and err_corr_typed < 1e-14
del F_rand2, F_riem_const_arr
p5.update(8, force=True)


def theta_both_dBT_fast(row0, row7):
    """Exact O(14) evaluation of (Theta_Ein(d_B T), Theta_Bianchi(d_B T)) on active rows 0, 7."""
    U0 = row0.copy()
    U7 = row7.copy()
    U0[0] = 0.0
    U7[7] = 0.0

    L1 = gamma_up[0, None] @ U0 + gamma_up[7, None] @ U7
    L1[0] -= G_up_row @ U0.reshape(14 * 128, 128)
    L1[7] -= G_up_row @ U7.reshape(14 * 128, 128)

    R1 = U0 @ gamma_up[0, None] + U7 @ gamma_up[7, None]
    R1[0] -= U0.transpose(1, 0, 2).reshape(128, 14 * 128) @ G_up_col
    R1[7] -= U7.transpose(1, 0, 2).reshape(128, 14 * 128) @ G_up_col

    L3, R3 = _L3_R3_from_L1_R1(L1, R1)
    return 0.5 * (L3 + R3), 0.5j * (L3 - R3)


def theta_both_TT_fast(T_hat):
    """Computes (Theta_Ein(T^T), Theta_Bianchi(T^T)) via a single 2D BLAS outer product."""
    T_col = T_hat.reshape(14 * 128, 128)
    T_row = T_hat.transpose(1, 0, 2).reshape(128, 14 * 128)
    W_4d = (T_col @ T_row).reshape(14, 128, 14, 128)
    M_TT = (W_4d - W_4d.transpose(2, 1, 0, 3)).reshape(14 * 128, 14 * 128)
    return theta_both_from_M(M_TT)


def noncentral_delta_E_bare(T_site, ein_tt=None):
    """2D-BLAS evaluation of Delta E_a^{unit} = -sum_{b,c} {T_b, [T_c, gamma_a^{bc}]}."""
    if ein_tt is None:
        ein_tt, _ = theta_both_TT_fast(T_site)
    P_L = T_site.transpose(1, 0, 2).reshape(128, 14 * 128) @ G_up_col
    P_R = G_up_row @ T_site.reshape(14 * 128, 128)
    PgP = ((P_L @ G_dn_row).reshape(128 * 14, 128) @ P_R).reshape(128, 14, 128).transpose(1, 0, 2)
    diag_term = np.zeros_like(T_site)
    for b in range(DIM):
        Tb_g = (ETA_DIAG[b] * T_site[b]) @ G_dn_row
        diag_term += (Tb_g.reshape(128 * 14, 128) @ T_site[b]).reshape(128, 14, 128).transpose(1, 0, 2)
    mid_term = (T_site @ P_R[None]) + (P_L[None] @ T_site) - PgP - diag_term
    return 2.0 * mid_term - ein_tt


T_ce = np.zeros((14, 128, 128), dtype=np.complex128)
T_ce[1] = gamma_up[3]
T_ce[2] = gamma_up[4]
DE_ce0 = (1.0 / 3.0) * noncentral_delta_E_bare(T_ce)[0]
g01234 = gamma_up[0] @ gamma_up[1] @ gamma_up[2] @ gamma_up[3] @ gamma_up[4]
ce_err = float(np.linalg.norm(DE_ce0 - (-8.0 / 3.0) * g01234) / np.linalg.norm(g01234))
assert ce_err < 1e-13

T_sparse = DifferentialForm(1, {
    (1,): gammas[3],
    (2,): gammas[4],
    (5,): gammas[0] @ gammas[6],
    (8,): gammas[9],
})
FB_sparse = DifferentialForm(2, {
    (0, 1): gammas[2],
    (3, 4): 1j * I128,
})
alpha_sparse = DifferentialForm(1, {
    (0,): gammas[0] @ gammas[1] @ gammas[2] @ gammas[3] @ gammas[4],
    (1,): gammas[3] + gammas[9],
    (7,): gammas[1] @ gammas[2] @ gammas[5] @ gammas[6] @ gammas[7],
})
for f_sp in (T_sparse, FB_sparse, alpha_sparse):
    for M_sp in f_sp.comps.values():
        assert_in_u64(M_sp, "sparse_field")


def sparse_alg_action(T_f: DifferentialForm, kappa1: float = 1.5) -> float:
    K_f = FB_sparse + (1.0 / 3.0) * wedge(T_f, T_f)
    F_arr = np.zeros((14, 14, 128, 128), dtype=np.complex128)
    for (a, b), M in K_f.comps.items():
        F_arr[a, b] = M
        F_arr[b, a] = -M
    th_arr = theta_ein_bare(F_arr)
    th_form = DifferentialForm(1, {(a,): th_arr[a] for a in range(DIM)})
    return float((trace_pairing(T_f, th_form) + kappa1 * trace_pairing(T_f, T_f)).real)


eps_sp = 1e-6
fd_sparse = (sparse_alg_action(T_sparse + eps_sp * alpha_sparse)
             - sparse_alg_action(T_sparse - eps_sp * alpha_sparse)) / (2.0 * eps_sp)

T_sp_arr = np.zeros((14, 128, 128), dtype=np.complex128)
for (a,), M in T_sparse.comps.items():
    T_sp_arr[a] = M
F_sp_alg = FB_sparse + wedge(T_sparse, T_sparse)
F_sp_arr = np.zeros((14, 14, 128, 128), dtype=np.complex128)
for (a, b), M in F_sp_alg.comps.items():
    F_sp_arr[a, b] = M
    F_sp_arr[b, a] = -M

Th_sp_form = DifferentialForm(1, {(a,): theta_ein_bare(F_sp_arr)[a] for a in range(DIM)})
DE_sp_arr = (1.0 / 3.0) * noncentral_delta_E_bare(T_sp_arr)
DE_sp_form = DifferentialForm(1, {(a,): DE_sp_arr[a] for a in range(DIM)})

ana_sp_with = float(trace_pairing(alpha_sparse, Th_sp_form + DE_sp_form + 3.0 * T_sparse).real)
ana_sp_naive = float(trace_pairing(alpha_sparse, Th_sp_form + 3.0 * T_sparse).real)
sp_rel_err_with = abs(fd_sparse - ana_sp_with) / abs(fd_sparse)
sp_rel_err_naive = abs(fd_sparse - ana_sp_naive) / abs(fd_sparse)
assert sp_rel_err_with < 1e-7 and sp_rel_err_naive > 0.2
del F_sp_arr, T_sp_arr
gc.collect()
p5.update(10, force=True)

p5.finish(f"Typed **=(-1)^(p+1) err={hodge_inv_err:.1e} | Corrected Eq.9.3 err={err_corr_typed:.2e} | Sparse FD={sp_rel_err_with:.2e}")
print(f"    * Literal Eq.(9.3) on F_Riem:  (comm,comm) rel err = {err_cc_riem:.4f} (5/6), (anticomm,anticomm) = {err_aa_riem:.4f} (1/6)")
print(f"    * Noncentral blade witness:    ||Delta E_0 - (-8/3 g^01234)||/||g|| = {ce_err:.1e} (||Delta E_0|| = {np.linalg.norm(DE_ce0):.2f})")
print(f"    * Sparse blade FD variation:   FD = {fd_sparse:+.6f}, With Delta_E = {ana_sp_with:+.6f} ({sp_rel_err_with:.2e}), Without = {ana_sp_naive:+.6f} ({sp_rel_err_naive:.1%})")


# ==============================================================================
# VERIFICATION GROUP 6: Low-Memory Full 14D Periodic Action (Eq. 9.4, F_B = 0),
#              1D & 2D Continuum Grid Convergence, -256 Kinetic Witness,
#              Case A & B Variations, and True Fixed-A Coupled Noether Test
# ==============================================================================
p6 = LiveProgress("V6", 15, "Full 14D Action & Coupled Noether")

_, eigvecs = np.linalg.eigh(J_prime)
V_neg, V_pos = eigvecs[:, :64], eigvecs[:, 64:]


def random_nilpotent_u64():
    A = rng.normal(size=(64, 64)) + 1j * rng.normal(size=(64, 64))
    A_skew = 0.05 * (A - A.conj().T)
    return (V_pos + V_neg) @ A_skew @ (V_pos.conj().T - V_neg.conj().T)


X0_gen = random_nilpotent_u64()
X7_gen = random_nilpotent_u64()

T_harm = [random_u64((14,)) for _ in range(5)]
alpha_harm = [random_u64((14,)) for _ in range(5)]
eta_harm = [random_u64() for _ in range(3)]
for h_arr in T_harm + alpha_harm + eta_harm:
    assert_in_u64(h_arr, "harmonic_coeff")


def d_dx0_grid(field, freqs):
    N_g = len(freqs)
    shape = (N_g,) + (1,) * (field.ndim - 1)
    return np.fft.ifft(1j * freqs.reshape(shape) * np.fft.fft(field, axis=0), axis=0)


def d_dx7_grid(field, freqs):
    N_g = len(freqs)
    shape = (1, N_g) + (1,) * (field.ndim - 2)
    return np.fft.ifft(1j * freqs.reshape(shape) * np.fft.fft(field, axis=1), axis=1)


# Verify fast kernels against theta_both_bare using relative Frobenius error (< 1e-12)
_r0_chk = random_u64((14,))
_r7_chk = random_u64((14,))
_r0_chk[0] = 0.0
_r7_chk[7] = 0.0
_r7_chk[0] = -_r0_chk[7]
_F_dbt_chk = np.zeros((14, 14, 128, 128), dtype=np.complex128)
_F_dbt_chk[0, :] += _r0_chk
_F_dbt_chk[:, 0] -= _r0_chk
_F_dbt_chk[7, :] += _r7_chk
_F_dbt_chk[:, 7] -= _r7_chk
_e1, _b1 = theta_both_dBT_fast(_r0_chk, _r7_chk)
_e2, _b2 = theta_both_bare(_F_dbt_chk)
assert np.linalg.norm(_e1 - _e2) / np.linalg.norm(_e2) < 1e-12
assert np.linalg.norm(_b1 - _b2) / np.linalg.norm(_b2) < 1e-12

_F_tt_chk = (T_harm[0][:, None] @ T_harm[0][None, :]) - (T_harm[0][None, :] @ T_harm[0][:, None])
_et1, _bt1 = theta_both_TT_fast(T_harm[0])
_et2, _bt2 = theta_both_bare(_F_tt_chk)
assert np.linalg.norm(_et1 - _et2) / np.linalg.norm(_et2) < 1e-12
assert np.linalg.norm(_bt1 - _bt2) / np.linalg.norm(_bt2) < 1e-12
del _F_dbt_chk, _F_tt_chk, _e1, _b1, _e2, _b2, _et1, _bt1, _et2, _bt2


# 1. 1D Slice Continuum Convergence Check across N = 8, 10, 14
def eval_1d_slice_convergence(N_1d: int):
    g1 = np.linspace(0, 2 * np.pi, N_1d, endpoint=False)
    fr1 = np.fft.fftfreq(N_1d, d=1.0 / N_1d)
    s0_1 = np.sin(g1)[:, None, None]
    c0_1 = np.cos(g1)[:, None, None]
    eps_1 = I128[None] + s0_1 * X0_gen[None]
    einv_1 = I128[None] - s0_1 * X0_gen[None]
    d0_eps_1 = np.fft.ifft(1j * fr1[:, None, None] * np.fft.fft(eps_1, axis=0), axis=0)
    B0_1 = einv_1 @ d0_eps_1
    B0_hat_1 = d0_eps_1 @ einv_1

    EA0_1 = np.zeros((N_1d, 128, 128), dtype=np.complex128)
    comm_A_EA_1 = np.zeros((N_1d, 128, 128), dtype=np.complex128)
    act_1 = 0.0
    zero_row = np.zeros((14, 128, 128), dtype=np.complex128)

    for i in range(N_1d):
        s_i, c_i = float(np.sin(g1[i])), float(np.cos(g1[i]))
        T_i = T_harm[0] + s_i * T_harm[1] + c_i * T_harm[2]
        d0T_i = c_i * T_harm[1] - s_i * T_harm[2]
        ep, ei = eps_1[i], einv_1[i]
        T_h = ep[None] @ T_i @ ei[None]
        d0T_h = ep[None] @ d0T_i @ ei[None]
        row0 = d0T_h + (B0_hat_1[i][None] @ T_h - T_h @ B0_hat_1[i][None])

        ein_dbt, _ = theta_both_dBT_fast(row0, zero_row)
        ein_tt, _ = theta_both_TT_fast(T_h)
        de_h = noncentral_delta_E_bare(T_h, ein_tt)

        K_hat = 0.5 * ein_dbt + (1.0 / 3.0) * ein_tt + 0.75 * T_h
        act_1 += float(np.einsum('a,akm,amk->', ETA_DIAG, T_h, K_hat).real)

        EA_hat = ein_dbt + ein_tt + (1.0 / 3.0) * de_h + 1.5 * T_h
        EA_i = ei[None] @ EA_hat @ ep[None]
        A_i = T_i.copy()
        A_i[0] += B0_1[i]
        EA0_1[i] = EA_i[0]
        comm_A_EA_1[i] = (np.einsum('a,akm,amn->kn', ETA_DIAG, A_i, EA_i)
                          - np.einsum('a,akm,amn->kn', ETA_DIAG, EA_i, A_i))

    eta_1 = eta_harm[0][None] + s0_1 * eta_harm[1][None] + c0_1 * eta_harm[2][None]
    d0_EA0 = np.fft.ifft(1j * fr1[:, None, None] * np.fft.fft(EA0_1, axis=0), axis=0)
    DA_EA_1 = ETA_DIAG[0] * d0_EA0 + comm_A_EA_1
    noether_1 = float(np.mean(np.einsum('ikm,imk->i', eta_1, DA_EA_1)).real)
    return act_1 / N_1d, noether_1


act_1d_8, noe_1d_8 = eval_1d_slice_convergence(8)
act_1d_10, noe_1d_10 = eval_1d_slice_convergence(10)
act_1d_14, noe_1d_14 = eval_1d_slice_convergence(14)
quad_1d_err = max(abs(act_1d_8 - act_1d_14), abs(act_1d_10 - act_1d_14)) / abs(act_1d_14)
noe_1d_err = max(abs(noe_1d_8 - noe_1d_14), abs(noe_1d_10 - noe_1d_14)) / abs(noe_1d_14)
assert quad_1d_err < 1e-10 and noe_1d_err < 1e-10
p6.update(2, force=True)


# 2. Setup 2D Active Grid Helper & Run Full 2D Grid Convergence (N = 8 vs N = 10)
def build_2d_grid_context(N_g: int):
    g1 = np.linspace(0, 2 * np.pi, N_g, endpoint=False)
    x0_g, x7_g = np.meshgrid(g1, g1, indexing='ij')
    fr_g = np.fft.fftfreq(N_g, d=1.0 / N_g)
    s0_g = np.sin(x0_g).reshape(N_g, N_g, 1, 1)
    c0_g = np.cos(x0_g).reshape(N_g, N_g, 1, 1)
    s7_g = np.sin(x7_g).reshape(N_g, N_g, 1, 1)
    c7_g = np.cos(x7_g).reshape(N_g, N_g, 1, 1)
    eps_g = (I128[None, None] + s0_g * X0_gen[None, None]) @ (I128[None, None] + c7_g * X7_gen[None, None])
    einv_g = (I128[None, None] - c7_g * X7_gen[None, None]) @ (I128[None, None] - s0_g * X0_gen[None, None])
    d0_ep = d_dx0_grid(eps_g, fr_g)
    d7_ep = d_dx7_grid(eps_g, fr_g)
    B0_g = einv_g @ d0_ep
    B7_g = einv_g @ d7_ep
    B0_h_g = d0_ep @ einv_g
    B7_h_g = d7_ep @ einv_g
    eta_g = eta_harm[0][None, None] + s0_g * eta_harm[1][None, None] + c7_g * eta_harm[2][None, None]
    return (N_g, g1, fr_g, np.sin(g1), np.cos(g1), s0_g, c0_g, s7_g, c7_g,
            eps_g, einv_g, B0_g, B7_g, B0_h_g, B7_h_g, eta_g)


ctx8 = build_2d_grid_context(8)
ctx10 = build_2d_grid_context(10)
(N, grid_1d, freqs, SIN_1D, COS_1D, s0_4d, c0_4d, s7_4d, c7_4d,
 eps, eps_inv, B0_field, B7_field, B0_hat_base, B7_hat_base, eta_gauge) = ctx8

assert_in_u64(B0_field, "B0_field")
assert_in_u64(B7_field, "B7_field")
assert_in_u64(eta_gauge, "eta_gauge")

F07_actual = d_dx0_grid(B7_field, freqs) - d_dx7_grid(B0_field, freqs) + (B0_field @ B7_field - B7_field @ B0_field)
mc_flat_err = float(np.max(np.abs(F07_actual)))
assert mc_flat_err < 1e-11
p6.update(3, force=True)

# 3. Deterministic -256 Dressed Kinetic Witness
T_wit_1 = eps_inv @ (s0_4d * (gammas[0] @ gammas[1])[None, None]) @ eps
T_wit_2 = eps_inv @ (c0_4d * gammas[2][None, None]) @ eps
d0_Tw1 = d_dx0_grid(T_wit_1, freqs)
d7_Tw1 = d_dx7_grid(T_wit_1, freqs)
d0_Tw2 = d_dx0_grid(T_wit_2, freqs)
d7_Tw2 = d_dx7_grid(T_wit_2, freqs)

I_kin_wit_acc = 0.0
_r0_w = np.zeros((14, 128, 128), dtype=np.complex128)
_r7_w = np.zeros((14, 128, 128), dtype=np.complex128)
for i in range(N):
    for j in range(N):
        ep, ei = eps[i, j], eps_inv[i, j]
        B0_h, B7_h = B0_hat_base[i, j], B7_hat_base[i, j]
        T1_h = ep @ T_wit_1[i, j] @ ei
        T2_h = ep @ T_wit_2[i, j] @ ei
        _r0_w.fill(0.0)
        _r7_w.fill(0.0)
        _r0_w[1] = ep @ d0_Tw1[i, j] @ ei + (B0_h @ T1_h - T1_h @ B0_h)
        _r0_w[2] = ep @ d0_Tw2[i, j] @ ei + (B0_h @ T2_h - T2_h @ B0_h)
        _r7_w[1] = ep @ d7_Tw1[i, j] @ ei + (B7_h @ T1_h - T1_h @ B7_h)
        _r7_w[2] = ep @ d7_Tw2[i, j] @ ei + (B7_h @ T2_h - T2_h @ B7_h)

        ein_dbt, _ = theta_both_dBT_fast(_r0_w, _r7_w)
        val_ij = 0.5 * (ETA_DIAG[1] * np.trace(T1_h @ ein_dbt[1]) + ETA_DIAG[2] * np.trace(T2_h @ ein_dbt[2]))
        I_kin_wit_acc += float(val_ij.real)

I_kin_wit = I_kin_wit_acc / (N * N)
h_wit = 1e-6
dI_kin_wit = (((1.0 + h_wit) ** 2 - (1.0 - h_wit) ** 2) / (2.0 * h_wit)) * I_kin_wit
wit_err = abs(dI_kin_wit + 256.0) / 256.0
assert abs(I_kin_wit + 128.0) < 1e-9 and wit_err < 1e-7
del T_wit_1, T_wit_2, d0_Tw1, d7_Tw1, d0_Tw2, d7_Tw2, _r0_w, _r7_w
p6.update(5, force=True)

# 4. Site-Streaming Evaluator for Mixed-Harmonic Action, 2D Convergence, & Coupled Dressing Variations
KAPPA1 = 1.5


def eval_streaming_grid(s_alpha: float = 0.0, s_eta: float = 0.0, full_el_analysis: bool = False, ctx=ctx8):
    (N_c, _, fr_c, sin_c, cos_c, _, _, _, _,
     eps_c, einv_c, B0_c, B7_c, B0_hat_c, B7_hat_c, eta_c) = ctx
    H_T = [T_harm[k] + s_alpha * alpha_harm[k] for k in range(5)]

    if s_eta == 0.0:
        eps_g, einv_g = eps_c, einv_c
        B0_g, B7_g = B0_c, B7_c
        B0_hat_g, B7_hat_g = B0_hat_c, B7_hat_c
        has_delta_B = False
    else:
        half_s_eta = 0.5 * s_eta * eta_c
        h_s = np.linalg.solve(I128[None, None] - half_s_eta, I128[None, None] + half_s_eta)
        h_s_inv = np.linalg.solve(I128[None, None] + half_s_eta, I128[None, None] - half_s_eta)
        eps_g = eps_c @ h_s
        einv_g = h_s_inv @ einv_c
        d0_eps_s = d_dx0_grid(eps_g, fr_c)
        d7_eps_s = d_dx7_grid(eps_g, fr_c)
        B0_g = einv_g @ d0_eps_s
        B7_g = einv_g @ d7_eps_s
        B0_hat_g = d0_eps_s @ einv_g
        B7_hat_g = d7_eps_s @ einv_g
        Delta_B0 = B0_c - B0_g
        Delta_B7 = B7_c - B7_g
        d0_DB0 = d_dx0_grid(Delta_B0, fr_c)
        d7_DB0 = d_dx7_grid(Delta_B0, fr_c)
        d0_DB7 = d_dx0_grid(Delta_B7, fr_c)
        d7_DB7 = d_dx7_grid(Delta_B7, fr_c)
        has_delta_B = True

    act_kin = 0.0
    act_cub = 0.0
    act_mas = 0.0
    act_bia_kin = 0.0
    act_bia_cub = 0.0

    if full_el_analysis:
        c_kin = 0.0
        c_tt = 0.0
        c_de = 0.0
        c_mas = 0.0
        EA0_full = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        EA7_full = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        EA0_naive = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        EA7_naive = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        comm_A_EA_full = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        comm_A_EA_naive = np.zeros((N_c, N_c, 128, 128), dtype=np.complex128)
        ibp_fixed_eps_acc = 0.0
        d0_eta_grid = d_dx0_grid(eta_c, fr_c)
        d7_eta_grid = d_dx7_grid(eta_c, fr_c)

    for i in range(N_c):
        s0_i, c0_i = sin_c[i], cos_c[i]
        T_x0 = H_T[0] + s0_i * H_T[1] + c0_i * H_T[2]
        d0T_base = c0_i * H_T[1] - s0_i * H_T[2]
        for j in range(N_c):
            s7_j, c7_j = sin_c[j], cos_c[j]
            T_ij = T_x0 + s7_j * H_T[3] + c7_j * H_T[4]
            d0T_ij = d0T_base
            d7T_ij = c7_j * H_T[3] - s7_j * H_T[4]

            if has_delta_B:
                T_ij = T_ij.copy()
                d0T_ij = d0T_ij.copy()
                d7T_ij = d7T_ij.copy()
                T_ij[0] += Delta_B0[i, j]
                T_ij[7] += Delta_B7[i, j]
                d0T_ij[0] += d0_DB0[i, j]
                d0T_ij[7] += d0_DB7[i, j]
                d7T_ij[0] += d7_DB0[i, j]
                d7T_ij[7] += d7_DB7[i, j]

            ep, ei = eps_g[i, j], einv_g[i, j]
            T_hat = ep[None] @ T_ij @ ei[None]
            d0T_hat = ep[None] @ d0T_ij @ ei[None]
            d7T_hat = ep[None] @ d7T_ij @ ei[None]
            B0_h, B7_h = B0_hat_g[i, j], B7_hat_g[i, j]

            row0 = d0T_hat + (B0_h[None] @ T_hat - T_hat @ B0_h[None])
            row7 = d7T_hat + (B7_h[None] @ T_hat - T_hat @ B7_h[None])

            ein_dbt, bia_dbt = theta_both_dBT_fast(row0, row7)
            ein_tt, bia_tt = theta_both_TT_fast(T_hat)

            act_kin += float(np.einsum('a,akm,amk->', ETA_DIAG, T_hat, 0.5 * ein_dbt).real)
            act_cub += float(np.einsum('a,akm,amk->', ETA_DIAG, T_hat, ein_tt).real)
            act_mas += float(np.einsum('a,akm,amk->', ETA_DIAG, T_hat, T_hat).real)
            act_bia_kin += float(np.einsum('a,akm,amk->', ETA_DIAG, T_hat, 0.5 * bia_dbt).real)
            act_bia_cub += float(np.einsum('a,akm,amk->', ETA_DIAG, T_hat, (1.0 / 3.0) * bia_tt).real)

            if full_el_analysis:
                de_hat = noncentral_delta_E_bare(T_hat, ein_tt)
                al_ij = (alpha_harm[0] + s0_i * alpha_harm[1] + c0_i * alpha_harm[2]
                         + s7_j * alpha_harm[3] + c7_j * alpha_harm[4])
                al_hat = ep[None] @ al_ij @ ei[None]

                c_kin += float(np.einsum('a,akm,amk->', ETA_DIAG, al_hat, ein_dbt).real)
                c_tt += float(np.einsum('a,akm,amk->', ETA_DIAG, al_hat, ein_tt).real)
                c_de += float(np.einsum('a,akm,amk->', ETA_DIAG, al_hat, de_hat).real)
                c_mas += float(np.einsum('a,akm,amk->', ETA_DIAG, al_hat, T_hat).real)

                EA_hat_full = ein_dbt + ein_tt + (1.0 / 3.0) * de_hat + 1.5 * T_hat
                EA_hat_naive = ein_dbt + ein_tt + 1.5 * T_hat
                EA_ij_full = ei[None] @ EA_hat_full @ ep[None]
                EA_ij_naive = ei[None] @ EA_hat_naive @ ep[None]

                EA0_full[i, j] = EA_ij_full[0]
                EA7_full[i, j] = EA_ij_full[7]
                EA0_naive[i, j] = EA_ij_naive[0]
                EA7_naive[i, j] = EA_ij_naive[7]

                A_ij = T_ij.copy()
                A_ij[0] += B0_g[i, j]
                A_ij[7] += B7_g[i, j]
                comm_A_EA_full[i, j] = (np.einsum('a,akm,amn->kn', ETA_DIAG, A_ij, EA_ij_full)
                                        - np.einsum('a,akm,amn->kn', ETA_DIAG, EA_ij_full, A_ij))
                comm_A_EA_naive[i, j] = (np.einsum('a,akm,amn->kn', ETA_DIAG, A_ij, EA_ij_naive)
                                         - np.einsum('a,akm,amn->kn', ETA_DIAG, EA_ij_naive, A_ij))

                eta_ij = eta_c[i, j]
                dA_eta_ij = A_ij @ eta_ij[None] - eta_ij[None] @ A_ij
                dA_eta_ij[0] += d0_eta_grid[i, j]
                dA_eta_ij[7] += d7_eta_grid[i, j]
                ibp_fixed_eps_acc -= float(np.einsum('a,akm,amk->', ETA_DIAG, dA_eta_ij, EA_ij_full).real)

    inv_N2 = 1.0 / (N_c * N_c)
    actions = (act_kin * inv_N2, act_cub * inv_N2, act_mas * inv_N2,
               act_bia_kin * inv_N2, act_bia_cub * inv_N2)
    if not full_el_analysis:
        return actions

    DA_EA_full = (ETA_DIAG[0] * d_dx0_grid(EA0_full, fr_c)
                  + ETA_DIAG[7] * d_dx7_grid(EA7_full, fr_c)
                  + comm_A_EA_full)
    DA_EA_naive = (ETA_DIAG[0] * d_dx0_grid(EA0_naive, fr_c)
                   + ETA_DIAG[7] * d_dx7_grid(EA7_naive, fr_c)
                   + comm_A_EA_naive)
    ana_noether_full = float(np.mean(np.einsum('ijkm,ijmk->ij', eta_c, DA_EA_full)).real)
    ana_noether_naive = float(np.mean(np.einsum('ijkm,ijmk->ij', eta_c, DA_EA_naive)).real)
    ana_ibp_fixed_eps = ibp_fixed_eps_acc * inv_N2

    return actions, (c_kin * inv_N2, c_tt * inv_N2, c_de * inv_N2, c_mas * inv_N2,
                     ana_noether_full, ana_noether_naive, ana_ibp_fixed_eps)


# Full 2D Grid Continuum Convergence Check: N = 8 vs N = 10
act_base_10, (_, _, _, _, noe_2d_10, _, _) = eval_streaming_grid(0.0, 0.0, full_el_analysis=True, ctx=ctx10)
del ctx10
gc.collect()
p6.update(7, force=True)

act_base_8, (c_kin_base, c_tt_base, c_de_base, c_mas_base,
             ana_noether_full, ana_noether_naive, ana_ibp_fixed_eps) = eval_streaming_grid(0.0, 0.0, full_el_analysis=True, ctx=ctx8)
p6.update(9, force=True)

I_2d_8 = act_base_8[0] + (1.0 / 3.0) * act_base_8[1] + 0.75 * act_base_8[2]
I_2d_10 = act_base_10[0] + (1.0 / 3.0) * act_base_10[1] + 0.75 * act_base_10[2]
quad_2d_err = abs(I_2d_8 - I_2d_10) / abs(I_2d_10)
noe_2d_err = abs(ana_noether_full - noe_2d_10) / abs(noe_2d_10)
assert quad_2d_err < 1e-10 and noe_2d_err < 1e-10

eps_fd = 1e-6
act_p = eval_streaming_grid(+eps_fd, 0.0, full_el_analysis=False, ctx=ctx8)
p6.update(11, force=True)
act_m = eval_streaming_grid(-eps_fd, 0.0, full_el_analysis=False, ctx=ctx8)
p6.update(12, force=True)

fd_kin_only = (act_p[0] - act_m[0]) / (2.0 * eps_fd)
ana_kin_only = c_kin_base
kin_ibp_err = abs(fd_kin_only - ana_kin_only) / abs(fd_kin_only)
assert kin_ibp_err < 1e-7

fd_bia_kin = (act_p[3] - act_m[3]) / (2.0 * eps_fd)
fd_bia_cub = (act_p[4] - act_m[4]) / (2.0 * eps_fd)
rel_bia_kin = abs(fd_bia_kin) / abs(ana_kin_only)
rel_bia_cub = abs(fd_bia_cub) / abs(c_tt_base)
assert rel_bia_kin < 1e-7 and rel_bia_cub < 1e-7

var_results = {}
for label, lam, m_coeff in [
    ("Case A (lam=1/3, m=kappa1/2)", 1.0 / 3.0, 0.5 * KAPPA1),
    ("Case B (lam=2/3, m=kappa1)  ", 2.0 / 3.0, KAPPA1),
]:
    I_p = act_p[0] + lam * act_p[1] + m_coeff * act_p[2]
    I_m = act_m[0] + lam * act_m[1] + m_coeff * act_m[2]
    fd_tot = (I_p - I_m) / (2.0 * eps_fd)
    ck = c_kin_base
    cc = 3.0 * lam * c_tt_base
    cn = lam * c_de_base
    cm = 2.0 * m_coeff * c_mas_base
    ana_exact = ck + cc + cn + cm
    ana_naive = ck + c_tt_base + cm
    err_exact = abs(fd_tot - ana_exact) / abs(fd_tot)
    err_naive = abs(fd_tot - ana_naive) / abs(fd_tot)
    assert err_exact < 1e-7 and err_naive > 0.05
    var_results[label] = (fd_tot, ana_exact, ana_naive, err_exact, err_naive, ck, cc, cn, cm)

lam_A, m_A = 1.0 / 3.0, 0.5 * KAPPA1
act_eta_p = eval_streaming_grid(0.0, +eps_fd, full_el_analysis=False, ctx=ctx8)
p6.update(14, force=True)
act_eta_m = eval_streaming_grid(0.0, -eps_fd, full_el_analysis=False, ctx=ctx8)

I_coupled_p = act_eta_p[0] + lam_A * act_eta_p[1] + m_A * act_eta_p[2]
I_coupled_m = act_eta_m[0] + lam_A * act_eta_m[1] + m_A * act_eta_m[2]
fd_coupled_fixed_A = (I_coupled_p - I_coupled_m) / (2.0 * eps_fd)

noether_rel_err = abs(fd_coupled_fixed_A - ana_noether_full) / abs(fd_coupled_fixed_A)
noether_naive_err = abs(fd_coupled_fixed_A - ana_noether_naive) / abs(fd_coupled_fixed_A)
ibp_match_err = abs(ana_ibp_fixed_eps - ana_noether_full) / abs(ana_noether_full)
assert noether_rel_err < 1e-7 and ibp_match_err < 1e-10 and noether_naive_err > 0.05
p6.update(15, force=True)

p6.finish(f"Full 14D Action: Wit={wit_err:.2e}, Kin IBP={kin_ibp_err:.2e}, Case A={var_results['Case A (lam=1/3, m=kappa1/2)'][3]:.2e}, Coupled Noether={noether_rel_err:.2e}")
print(f"    * 1D & 2D grid convergence:     1D(8,10,14) I={quad_1d_err:.2e}, Noe={noe_1d_err:.2e} | 2D(8 vs 10) I={quad_2d_err:.2e}, Noe={noe_2d_err:.2e}")
print(f"    * Dressed -256 kinetic witness: I_kin = {I_kin_wit:+.6f} (-128), dI_kin[T] = {dI_kin_wit:+.6f} (-256, err = {wit_err:.2e})")
print(f"    * Commutator-sector bulk var:   rel_kin = {rel_bia_kin:.2e}, rel_cub = {rel_bia_cub:.2e} (invisible in bulk)")
for label, (fd_v, ex_v, nv_v, e_ex, e_nv, ck, cc, cn, cm) in var_results.items():
    print(f"    * {label}:")
    print(f"        Channels: kin={ck:+.1f}, cub={cc:+.1f}, noncentral={cn:+.1f}, mass={cm:+.1f}")
    print(f"        FD = {fd_v:+.4f} | Exact EL = {ex_v:+.4f} (err = {e_ex:.2e}) | Naive Eq.9.7 = {nv_v:+.4f} (err = {e_nv:.1%})")
print(f"    * True Fixed-A Coupled Noether: FD dI/ds|_A = {fd_coupled_fixed_A:+.4f} | <eta, D_A^a E_A> = {ana_noether_full:+.4f} (err = {noether_rel_err:.2e}, IBP diff = {ibp_match_err:.2e}) | Naive (no Delta_E) = {ana_noether_naive:+.4f} (err = {noether_naive_err:.1%})")

_, peak_bytes = tracemalloc.get_traced_memory()
tracemalloc.stop()
script_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()[:16] if "__file__" in globals() else "interactive"
print(f"\n[ALL 6 VERIFICATION GROUPS PASSED IN {time.perf_counter() - t0:.2f}s | Peak tracemalloc allocation: {peak_bytes / (1024**2):.1f} MiB | Python {platform.python_version()} / NumPy {np.__version__} | SHA256: {script_hash}]")
