import D7Final
import BianchiSymbol
import Mathlib.LinearAlgebra.TensorProduct.Basis

/-!
# Coordinate first jets for the D₇ divergence symbol

The real coordinate labels refer to the split frame. Its raised covectors
are represented by the vectors of `axisBasis`. The coordinate array is
skew in the last two slots; the inverse tensor conversion sums over both
orders of those slots and therefore uses a factor of one half.
-/

namespace GeometricUnity.D7BianchiFields

open D7Exterior D7Hodge D7VectorGrades D7VectorTensor
open scoped BigOperators TensorProduct

noncomputable section

set_option backward.isDefEq.respectTransparency false

private def pairCoordinate (b c : Axis) : Two →ₗ[ℂ] ℂ :=
  exteriorPower.pairingDual ℂ Space 2
    (exteriorPower.ιMulti ℂ 2 ![axisBasis.coord b, axisBasis.coord c])

private theorem pairCoordinate_wedge (b c : Axis) (y z : Space) :
    pairCoordinate b c (wedgeTwo y z) =
      axisBasis.coord b y * axisBasis.coord c z - axisBasis.coord c y * axisBasis.coord b z := by
  simp [pairCoordinate, wedgeTwo, exteriorPower.pairingDual_ιMulti_ιMulti, Matrix.det_fin_two]

private theorem two_ext {f g : Two →ₗ[ℂ] ℂ}
    (h : ∀ x y, f (wedgeTwo x y) = g (wedgeTwo x y)) : f = g := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  have hv : (![v 0, v 1] : Fin 2 → Space) = v := by funext i; fin_cases i <;> rfl
  simpa only [LinearMap.compAlternatingMap_apply, wedgeTwo, hv] using h (v 0) (v 1)

private theorem pairCoordinate_swap (b c : Axis) :
    pairCoordinate c b = -pairCoordinate b c := by
  apply two_ext
  intro x y
  simp only [LinearMap.neg_apply, pairCoordinate_wedge]
  ring

private def tripleCoordinate (a b c : Axis) : VTwo →ₗ[ℂ] ℂ :=
  TensorProduct.lift ((axisBasis.coord a).smulRight (pairCoordinate b c))

@[simp] private theorem tripleCoordinate_tmul (a b c : Axis) (x : Space) (u : Two) :
    tripleCoordinate a b c (x ⊗ₜ[ℂ] u) = axisBasis.coord a x * pairCoordinate b c u := rfl

private theorem tripleCoordinate_swap (a b c : Axis) :
    tripleCoordinate a c b = -tripleCoordinate a b c := by
  apply TensorProduct.ext'
  intro x u
  rw [tripleCoordinate_tmul, LinearMap.neg_apply, tripleCoordinate_tmul,
    pairCoordinate_swap b c, LinearMap.neg_apply, mul_neg]

private theorem tripleCoordinate_average (a b c : Axis) (s : VTwo) :
    tripleCoordinate a b c (includeThree (D7VectorTensor.alternation s)) =
      (3 : ℂ)⁻¹ * (tripleCoordinate a b c s + tripleCoordinate b c a s +
        tripleCoordinate c a b s) := by
  let f := (tripleCoordinate a b c).comp (includeThree.comp D7VectorTensor.alternation)
  let g := (3 : ℂ)⁻¹ • (tripleCoordinate a b c + tripleCoordinate b c a +
    tripleCoordinate c a b)
  have h : f = g := by
    apply TensorProduct.ext'
    intro x u
    let m := TensorProduct.mk ℂ Space Two x
    have hm : f.comp m = g.comp m := by
      apply two_ext
      intro y z
      simp only [f, g, m, LinearMap.comp_apply, TensorProduct.mk_apply, alternation_pure,
        includeThree_pure, cyclicTensor, map_smul, map_add, LinearMap.smul_apply,
        LinearMap.add_apply, tripleCoordinate_tmul, pairCoordinate_wedge, smul_eq_mul]
      ring
    exact DFunLike.congr_fun hm u
  exact DFunLike.congr_fun h s

section Coefficients

variable {E : Type} [AddCommGroup E] [Module ℂ E]

private def coordinateEntry (a b c : Axis) : (VTwo ⊗[ℂ] E) →ₗ[ℂ] E :=
  (TensorProduct.lid ℂ E).toLinearMap.comp ((tripleCoordinate a b c).rTensor E)

@[simp] private theorem coordinateEntry_tmul (a b c : Axis) (s : VTwo) (x : E) :
    coordinateEntry a b c (s ⊗ₜ[ℂ] x) = tripleCoordinate a b c s • x := by
  simp [coordinateEntry]

private theorem coordinateEntry_swap (a b c : Axis) :
    (coordinateEntry a c b : (VTwo ⊗[ℂ] E) →ₗ[ℂ] E) = -coordinateEntry a b c := by
  apply TensorProduct.ext'
  intro s x
  rw [coordinateEntry_tmul, LinearMap.neg_apply, coordinateEntry_tmul,
    tripleCoordinate_swap a b c, LinearMap.neg_apply, neg_smul]

variable [Module ℝ E] [IsScalarTower ℝ ℂ E]

/-- The coordinates of a tensor with the derivative slot first and the
skew two-form slots second and third. -/
def tensorJet : (VTwo ⊗[ℂ] E) →ₗ[ℝ] BianchiSymbol.Jet Axis E where
  toFun s := ⟨fun a b c => coordinateEntry a b c s, by
    intro a b c
    change coordinateEntry a c b s = -coordinateEntry a b c s
    rw [coordinateEntry_swap, LinearMap.neg_apply]⟩
  map_add' s t := by
    apply Subtype.ext
    funext a b c
    exact map_add (coordinateEntry a b c) s t
  map_smul' r s := by
    apply Subtype.ext
    funext a b c
    exact (coordinateEntry a b c).restrictScalars ℝ |>.map_smul r s

/-- Assemble the skew pair using all ordered coordinate pairs. -/
def assembleJet (J : BianchiSymbol.Jet Axis E) : VTwo ⊗[ℂ] E :=
  (2 : ℂ)⁻¹ • ∑ a : Axis, ∑ b : Axis, ∑ c : Axis,
    (axisBasis a ⊗ₜ[ℂ] wedgeTwo (axisBasis b) (axisBasis c)) ⊗ₜ[ℂ] J.val a b c

private theorem axisCoordinate_basis (i j : Axis) :
    axisBasis.coord i (axisBasis j) = if i = j then 1 else 0 := by
  simp [Module.Basis.coord_apply, Finsupp.single_apply, eq_comm]

private theorem tensorJet_assemble (J : BianchiSymbol.Jet Axis E) :
    tensorJet (assembleJet J) = J := by
  apply Subtype.ext
  funext i j k
  change coordinateEntry i j k (assembleJet J) = J.val i j k
  simp only [assembleJet, map_smul, map_sum, coordinateEntry_tmul, tripleCoordinate_tmul,
    pairCoordinate_wedge, axisCoordinate_basis]
  have h (a b c : Axis) :
      ((if i = a then (1 : ℂ) else 0) *
        ((if j = b then 1 else 0) * (if k = c then 1 else 0) -
          (if k = b then 1 else 0) * (if j = c then 1 else 0))) • J.val a b c =
      (if k = c then if j = b then if i = a then J.val a b c else 0 else 0 else 0) -
      (if j = c then if k = b then if i = a then J.val a b c else 0 else 0 else 0) := by
    split_ifs <;> simp
  simp_rw [h, Finset.sum_sub_distrib]
  simp only [Finset.sum_ite_eq, Finset.mem_univ, if_true]
  rw [J.prop i j k]
  module

private def tensorBasis : Module.Basis (Axis × Index 2) ℂ VTwo :=
  axisBasis.tensorProduct (axisBasis.exteriorPower 2)

private theorem pairCoordinate_basis (s : Index 2) :
    let e := s.val.orderIsoOfFin s.prop
    pairCoordinate (e 0).val (e 1).val = (axisBasis.exteriorPower 2).coord s := by
  let e := s.val.orderIsoOfFin s.prop
  have he : (![axisBasis.coord (e 0).val, axisBasis.coord (e 1).val] : Fin 2 → _) =
      fun j => axisBasis.coord (e j).val := by
    funext j
    fin_cases j <;> rfl
  change pairCoordinate (e 0).val (e 1).val = _
  rw [pairCoordinate, he]
  exact (exteriorPower.basis_coord ℂ 2 axisBasis s).symm

private theorem tripleCoordinate_basis (a : Axis) (s : Index 2) :
    let e := s.val.orderIsoOfFin s.prop
    tripleCoordinate a (e 0).val (e 1).val = tensorBasis.coord (a, s) := by
  apply TensorProduct.ext'
  intro x u
  rw [tripleCoordinate_tmul, pairCoordinate_basis]
  simp only [Module.Basis.coord_apply, tensorBasis, Module.Basis.tensorProduct_repr_tmul_apply,
    smul_eq_mul]
  exact mul_comm _ _

private theorem tensorJet_injective :
    Function.Injective (tensorJet : (VTwo ⊗[ℂ] E) →ₗ[ℝ] BianchiSymbol.Jet Axis E) := by
  intro s t h
  apply (TensorProduct.equivFinsuppOfBasisLeft tensorBasis).injective
  ext ⟨a, ij⟩
  let e := ij.val.orderIsoOfFin ij.prop
  have hentry : coordinateEntry a (e 0).val (e 1).val s =
      coordinateEntry a (e 0).val (e 1).val t :=
    congrArg (fun J : BianchiSymbol.Jet Axis E => J.val a (e 0).val (e 1).val) h
  have hcoord : tripleCoordinate a (e 0).val (e 1).val = tensorBasis.coord (a, ij) :=
    tripleCoordinate_basis a ij
  simpa only [TensorProduct.equivFinsuppOfBasisLeft_apply, coordinateEntry, LinearMap.comp_apply,
    LinearEquiv.coe_coe, hcoord] using hentry

/-- Tensor and skew-array descriptions of a first jet. -/
def jetEquiv : (VTwo ⊗[ℂ] E) ≃ₗ[ℝ] BianchiSymbol.Jet Axis E where
  __ := tensorJet
  invFun := assembleJet
  left_inv s := tensorJet_injective (tensorJet_assemble (tensorJet s))
  right_inv := tensorJet_assemble

private theorem coordinateEntry_average (a b c : Axis) (s : VTwo ⊗[ℂ] E) :
    coordinateEntry a b c (includeThree.rTensor E (D7VectorTensor.alternation.rTensor E s)) =
      (3 : ℂ)⁻¹ • BianchiSymbol.cyclicSum (tensorJet s).val a b c := by
  let p := (includeThree.rTensor E).comp (D7VectorTensor.alternation.rTensor E)
  have h : (coordinateEntry a b c).comp p =
      (3 : ℂ)⁻¹ • ((coordinateEntry a b c) + coordinateEntry b c a + coordinateEntry c a b) := by
    apply TensorProduct.ext'
    intro t x
    simp only [p, LinearMap.comp_apply, LinearMap.rTensor_tmul, coordinateEntry_tmul,
      LinearMap.smul_apply, LinearMap.add_apply, tripleCoordinate_average, mul_smul, add_smul]
  exact DFunLike.congr_fun h s

/-- The cyclic mean in the coordinate model is the projection obtained
by exterior alternation followed by the normalized three-form inclusion. -/
theorem cyclic_average_eq_projection (s : VTwo ⊗[ℂ] E) (a b c : Axis) :
    (BianchiSymbol.alternation (tensorJet s)).val.val a b c =
      (tensorJet (includeThree.rTensor E (D7VectorTensor.alternation.rTensor E s))).val a b c := by
  rw [BianchiSymbol.alternation_apply]
  change _ = coordinateEntry a b c (includeThree.rTensor E (D7VectorTensor.alternation.rTensor E s))
  rw [coordinateEntry_average, ← algebraMap_smul ℂ (1 / 3 : ℝ)]
  congr 1
  norm_num

/-- The coordinate closed-jet condition is exactly the kernel of wedge
alternation on the derivative and form slots. -/
theorem closed_tensorJet_iff (s : VTwo ⊗[ℂ] E) :
    BianchiSymbol.ClosedJet (tensorJet s) ↔ D7VectorTensor.alternation.rTensor E s = 0 := by
  have hsection : (D7VectorTensor.alternation.rTensor E).comp (includeThree.rTensor E) =
      LinearMap.id := by
    apply TensorProduct.ext'
    intro u x
    simp only [LinearMap.comp_apply, LinearMap.rTensor_tmul, alternation_three, LinearMap.id_apply]
  rw [BianchiSymbol.closed_iff_alternation_eq_zero]
  constructor
  · intro h
    have hj : tensorJet (includeThree.rTensor E (D7VectorTensor.alternation.rTensor E s)) = 0 := by
      apply Subtype.ext
      funext a b c
      rw [← cyclic_average_eq_projection, h]
      rfl
    have hz := tensorJet_injective (hj.trans (map_zero tensorJet).symm)
    have hp := DFunLike.congr_fun hsection (D7VectorTensor.alternation.rTensor E s)
    change D7VectorTensor.alternation.rTensor E
        (includeThree.rTensor E (D7VectorTensor.alternation.rTensor E s)) = _ at hp
    rw [hz, map_zero] at hp
    exact hp.symm
  · intro h
    apply Subtype.ext
    apply Subtype.ext
    funext a b c
    rw [cyclic_average_eq_projection, h, map_zero, map_zero]
    rfl

end Coefficients

open D7Final
open D7Unrestricted (Intertwiners)
open D7TripleInvariants (metricEquiv metricEquiv_toLinearMap)

/-- Exterior blade coefficients in the split coordinate frame. -/
abbrev Coefficients (k : ℕ) := Index k → ℂ

def coefficientEquiv (k : ℕ) : Ext k ≃ₗ[ℂ] Coefficients k :=
  (axisBasis.exteriorPower k).equivFun

private def divergenceWithSymbol {S : Type} [AddCommMonoid S] [Module ℂ S] {k l : ℕ}
    (F : SymbolForm S k l) : S ⊗[ℂ] Coefficients k →ₗ[ℂ] Coefficients l :=
  ((metricEquiv l).symm.trans (coefficientEquiv l)).toLinearMap.comp
    ((TensorProduct.lift F).comp
      (TensorProduct.map LinearMap.id (coefficientEquiv k).symm.toLinearMap))

private theorem divergenceWithSymbol_tmul {S : Type} [AddCommMonoid S] [Module ℂ S] {k l : ℕ}
    (F : SymbolForm S k l) (s : S) (x : Coefficients k) :
    divergenceWithSymbol F (s ⊗ₜ[ℂ] x) =
      ((metricEquiv l).symm.trans (coefficientEquiv l)) (F s ((coefficientEquiv k).symm x)) := rfl

/-- The coordinate divergence of a block, expressed as a linear map of
first jets. The vector output index is paired with the raised derivative
index and the exterior output index is raised with its determinant metric. -/
def coordinateDivergence {k l : ℕ} (T : Intertwiners k l) :
    BianchiSymbol.Jet Axis (Coefficients k) →ₗ[ℝ] Coefficients l :=
  ((divergenceWithSymbol (divergenceSymbol k l T).val).restrictScalars ℝ).comp
    jetEquiv.symm.toLinearMap

private theorem coordinateDivergence_tensorJet {k l : ℕ} (T : Intertwiners k l)
    (s : VTwo ⊗[ℂ] Coefficients k) :
    coordinateDivergence T (tensorJet s) = divergenceWithSymbol (divergenceSymbol k l T).val s := by
  unfold coordinateDivergence
  change divergenceWithSymbol (divergenceSymbol k l T).val (jetEquiv.symm (jetEquiv s)) = _
  rw [LinearEquiv.symm_apply_apply]

theorem coordinateDivergence_pure_pair {k l : ℕ} (T : Intertwiners k l)
    (a : Space) (u : Ext 2) (x : Coefficients k) (y : Ext l) :
    exteriorMetric l ((coefficientEquiv l).symm
      (coordinateDivergence T (tensorJet ((a ⊗ₜ[ℂ] u) ⊗ₜ[ℂ] x)))) y =
      D7Unrestricted.tensorMetric l (T (u ⊗ₜ[ℂ] (coefficientEquiv k).symm x))
        (a ⊗ₜ[ℂ] y) := by
  rw [coordinateDivergence_tensorJet, ← metricEquiv_toLinearMap]
  simp only [divergenceWithSymbol_tmul, LinearEquiv.coe_coe, LinearEquiv.trans_apply,
    LinearEquiv.symm_apply_apply, LinearEquiv.apply_symm_apply, divergenceSymbol_tmul]

theorem mem_bianchiIntertwiners_iff_compatible {k l : ℕ} (T : Intertwiners k l) :
    T ∈ bianchiIntertwiners k l ↔ BianchiSymbol.Compatible (coordinateDivergence T) := by
  let F := divergenceSymbol k l T
  change F ∈ bianchiSymbols k l ↔ _
  constructor
  · intro h J hJ
    obtain ⟨A, hA, _⟩ := (bianchi_iff_factor F).mp h
    obtain ⟨s, rfl⟩ := jetEquiv.surjective J
    change BianchiSymbol.ClosedJet (tensorJet s) at hJ
    change coordinateDivergence T (tensorJet s) = 0
    have hF : divergenceWithSymbol F.val =
        (divergenceWithSymbol A.val).comp (D7VectorTensor.alternation.rTensor (Coefficients k)) := by
      rw [← hA]
      apply TensorProduct.ext'
      intro t x
      rfl
    rw [coordinateDivergence_tensorJet]
    change divergenceWithSymbol F.val s = 0
    rw [hF, LinearMap.comp_apply, (closed_tensorJet_iff s).mp hJ, map_zero]
  · intro h s hs
    apply LinearMap.ext
    intro x
    let t := s ⊗ₜ[ℂ] (coefficientEquiv k x)
    have ht : D7VectorTensor.alternation.rTensor (Coefficients k) t = 0 := by
      simp only [t, LinearMap.rTensor_tmul, hs, TensorProduct.zero_tmul]
    have hz := h (tensorJet t) ((closed_tensorJet_iff t).mpr ht)
    change coordinateDivergence T (tensorJet t) = 0 at hz
    rw [coordinateDivergence_tensorJet, divergenceWithSymbol_tmul,
      LinearEquiv.symm_apply_apply] at hz
    apply ((metricEquiv l).symm.trans (coefficientEquiv l)).injective
    rw [LinearMap.zero_apply, map_zero]
    exact hz

/-- Vanishing of the block divergence on all coordinatewise differentiable
closed two-forms with degree-`k` coefficients. -/
def VanishesOnClosedFields {k l : ℕ} (T : Intertwiners k l) : Prop :=
  ∀ (F : (Axis → ℝ) → Axis → Axis → Coefficients k)
    (hF : ∀ x b c, F x c b = -F x b c),
    (∀ x a b c, DifferentiableAt ℝ (fun t : ℝ => F (x + t • Pi.single a 1) b c) 0) →
    BianchiSymbol.ClosedField F →
    ∀ x, coordinateDivergence T (BianchiSymbol.firstJet F hF x) = 0

theorem mem_bianchiIntertwiners_iff_closed_fields {k l : ℕ} (T : Intertwiners k l) :
    T ∈ bianchiIntertwiners k l ↔ VanishesOnClosedFields T :=
  (mem_bianchiIntertwiners_iff_compatible T).trans
    (BianchiSymbol.compatible_iff_closed_fields (coordinateDivergence T))

section Bundled

open CategoryTheory

/-- The bundled Bianchi subspace is exactly the space of operators whose
divergences vanish on the closed-coordinate-field test in every block. -/
theorem mem_bianchiHom_iff_each_block
    (T : D7TripleMultiplicity.summedSource 2 ⟶ D7Unrestricted.summedVectorTarget) :
    T ∈ bianchiHom ↔ ∀ k l : Fin 15, VanishesOnClosedFields (unrestrictedBlocks T k l) := by
  rw [mem_bianchiHom]
  exact forall_congr' fun k => forall_congr' fun l =>
    mem_bianchiIntertwiners_iff_closed_fields _

private abbrev Field (k : Fin 15) := (Axis → ℝ) → Axis → Axis → Coefficients k.val

private theorem zeroField_closed (k : Fin 15) : BianchiSymbol.ClosedField (0 : Field k) := by
  intro x a b c
  simp [BianchiSymbol.cyclicSum, BianchiSymbol.coordinateDerivative]

private theorem zeroField_firstJet (k : Fin 15)
    (h : ∀ x b c, (0 : Field k) x c b = -(0 : Field k) x b c) (x : Axis → ℝ) :
    BianchiSymbol.firstJet (0 : Field k) h x = 0 := by
  apply Subtype.ext
  funext a b c
  simp [BianchiSymbol.firstJet, BianchiSymbol.coordinateDerivative]

/-- A full field is given by its exterior coefficient grades. Each output
grade of its divergence sums the contributions from all input grades. -/
def FullDivergenceVanishes
    (T : D7TripleMultiplicity.summedSource 2 ⟶ D7Unrestricted.summedVectorTarget) : Prop :=
  ∀ (F : ∀ k : Fin 15, Field k) (hF : ∀ k x b c, F k x c b = -F k x b c),
    (∀ k x a b c, DifferentiableAt ℝ (fun t : ℝ => F k (x + t • Pi.single a 1) b c) 0) →
    (∀ k, BianchiSymbol.ClosedField (F k)) →
    ∀ x l, (∑ k : Fin 15, coordinateDivergence (unrestrictedBlocks T k l)
      (BianchiSymbol.firstJet (F k) (hF k) x)) = 0

/-- Vanishing on all closed fields with arbitrary exterior-grade
coefficients is precisely membership in the bundled Bianchi subspace. -/
theorem mem_bianchiHom_iff_closed_fields
    (T : D7TripleMultiplicity.summedSource 2 ⟶ D7Unrestricted.summedVectorTarget) :
    T ∈ bianchiHom ↔ FullDivergenceVanishes T := by
  rw [mem_bianchiHom_iff_each_block]
  constructor
  · intro h F hF hd hc x l
    exact Finset.sum_eq_zero fun k _ => h k l (F k) (hF k) (hd k) (hc k) x
  · intro h k l F hF hd hc x
    let G : ∀ j : Fin 15, Field j := Function.update 0 k F
    have hG : ∀ j y b c, G j y c b = -G j y b c := by
      intro j y b c
      by_cases hj : j = k
      · subst j
        simpa only [G, Function.update_self] using hF y b c
      · simp [G, Function.update_of_ne hj]
    have hdiff : ∀ j y a b c,
        DifferentiableAt ℝ (fun t : ℝ => G j (y + t • Pi.single a 1) b c) 0 := by
      intro j y a b c
      by_cases hj : j = k
      · subst j
        simpa only [G, Function.update_self] using hd y a b c
      · simp [G, Function.update_of_ne hj]
    have hclosed : ∀ j, BianchiSymbol.ClosedField (G j) := by
      intro j
      by_cases hj : j = k
      · subst j
        simpa only [G, Function.update_self] using hc
      · simpa only [G, Function.update_of_ne hj, Pi.zero_apply] using zeroField_closed j
    have hz := h G hG hdiff hclosed x l
    rw [Finset.sum_eq_single k] at hz
    · simpa only [G, Function.update_self] using hz
    · intro j _ hj
      have hzero : G j = 0 := by simp [G, Function.update_of_ne hj]
      simp only [hzero, zeroField_firstJet, map_zero]
    · simp

end Bundled

end

end GeometricUnity.D7BianchiFields
