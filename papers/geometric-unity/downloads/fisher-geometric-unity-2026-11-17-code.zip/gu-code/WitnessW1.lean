import Mathlib.Algebra.CharP.Invertible
import Mathlib.Data.Real.Basic
import Mathlib.LinearAlgebra.CliffordAlgebra.Contraction
import Mathlib.LinearAlgebra.CliffordAlgebra.Conjugation
import Mathlib.Tactic.Module
import Mathlib.Tactic.NormNum

/-!
# Geometric Unity: Witness W1

Proposition 5.3, Eq. (57) of the technical note. The calculation takes place
in the real Clifford algebra of the actual split quadratic form on 14 axes.
The indices 0 through 6 have positive square and 7 through 13 have negative
square. The witness uses the first five positive generators.

Checked with Lean 4.33.1 and Mathlib v4.33.1.
-/

namespace GeometricUnity.WitnessW1

abbrev Index := Fin 14

def metricSign (i : Index) : ℝ := if i.val < 7 then 1 else -1

def splitForm : QuadraticForm ℝ (Index → ℝ) :=
  QuadraticMap.weightedSumSquares ℝ metricSign

abbrev Cl := CliffordAlgebra splitForm

noncomputable def basisVector (i : Index) : Index → ℝ := Pi.single i 1

noncomputable def gamma (i : Index) : Cl := CliffordAlgebra.ι splitForm (basisVector i)

theorem gamma_square (i : Index) : gamma i * gamma i = algebraMap ℝ Cl (metricSign i) := by
  rw [gamma, CliffordAlgebra.ι_sq_scalar]
  congr 1
  simp [splitForm, QuadraticMap.weightedSumSquares_apply, basisVector, Pi.single_apply]

theorem gamma_anticommute (i j : Index) (h : i ≠ j) :
    gamma i * gamma j = -(gamma j * gamma i) := by
  apply CliffordAlgebra.ι_mul_ι_comm_of_isOrtho
  rw [← QuadraticMap.isOrtho_polarBilin, QuadraticMap.polarBilin_apply_apply, QuadraticMap.polar]
  simp only [splitForm, QuadraticMap.weightedSumSquares_apply]
  rw [← Finset.sum_sub_distrib, ← Finset.sum_sub_distrib]
  apply Finset.sum_eq_zero
  intro k _
  by_cases ki : k = i
  · subst k
    simp [basisVector, h]
  by_cases kj : k = j
  · subst k
    simp [basisVector, h.symm]
  · simp [basisVector, ki, kj]

noncomputable def comm (X Y : Cl) : Cl := X * Y - Y * X
noncomputable def anti (X Y : Cl) : Cl := X * Y + Y * X

noncomputable def torsion (a : Index) : Cl :=
  if a = 1 then gamma 3 else if a = 2 then gamma 4 else 0

/-- The undressed insertion gamma_a{}^{bc}, including the two metric signs. -/
noncomputable def insertion (a b c : Index) : Cl :=
  if a = b ∨ a = c ∨ b = c then 0
  else (metricSign b * metricSign c) • (gamma a * gamma b * gamma c)

noncomputable def correction (a : Index) : Cl :=
  -(1 / 3 : ℝ) • (∑ b, ∑ c, anti (torsion b) (comm (torsion c) (insertion a b c)))

noncomputable def blade : Cl := gamma 0 * gamma 1 * gamma 2 * gamma 3 * gamma 4

private theorem swapDescending {i j : Index} (h : j < i) (x : Cl) :
    gamma i * (gamma j * x) = -(gamma j * (gamma i * x)) := by
  rw [← mul_assoc, gamma_anticommute i j (ne_of_gt h), neg_mul, mul_assoc]

private theorem swapLast {i j : Index} (h : j < i) :
    gamma i * gamma j = -(gamma j * gamma i) :=
  gamma_anticommute i j (ne_of_gt h)

private theorem cancelPositive {i : Index} (h : i.val < 7) (x : Cl) :
    gamma i * (gamma i * x) = x := by
  rw [← mul_assoc, gamma_square, metricSign, if_pos h, map_one, one_mul]

private theorem sum_supported {B : Type*} [AddCommMonoid B] (f : Index → B)
    (hf : ∀ i, i ≠ 1 → i ≠ 2 → f i = 0) :
    ∑ i, f i = f 1 + f 2 := by
  calc
    ∑ i, f i = ∑ i ∈ ({1, 2} : Finset Index), f i := by
      symm
      apply Finset.sum_subset (Finset.subset_univ _)
      intro i _ hi
      exact hf i (fun h => hi (by simp [h])) (fun h => hi (by simp [h]))
    _ = f 1 + f 2 := by simp

private theorem sum_correction (a : Index) :
    correction a =
      -(1 / 3 : ℝ) •
        (anti (gamma 3) (comm (gamma 4) (insertion a 1 2)) +
         anti (gamma 4) (comm (gamma 3) (insertion a 2 1))) := by
  unfold correction
  rw [sum_supported (fun b => ∑ c, anti (torsion b) (comm (torsion c) (insertion a b c)))]
  · simp_rw [sum_supported (fun c => anti (torsion 1) (comm (torsion c) (insertion a 1 c)))
        (by intro i hi hj; simp [torsion, hi, hj, comm, anti]),
      sum_supported (fun c => anti (torsion 2) (comm (torsion c) (insertion a 2 c)))
        (by intro i hi hj; simp [torsion, hi, hj, comm, anti])]
    simp [torsion, insertion, comm, anti]
  · intro i hi hj
    simp [torsion, hi, hj, anti]

private theorem insertion_012 : insertion 0 1 2 = gamma 0 * gamma 1 * gamma 2 := by
  rw [insertion, if_neg (by decide)]
  norm_num [metricSign]

private theorem insertion_021 : insertion 0 2 1 = -(gamma 0 * gamma 1 * gamma 2) := by
  rw [show insertion 0 2 1 = gamma 0 * gamma 2 * gamma 1 by
    rw [insertion, if_neg (by decide)]; norm_num [metricSign],
    mul_assoc, gamma_anticommute 2 1 (by decide), mul_neg, mul_assoc]

theorem blade_square : blade * blade = 1 := by
  -- Append a final unit so each adjacent interchange has the same form.
  rw [← mul_one (blade * blade)]
  simp (disch := decide) only [blade, mul_assoc, swapDescending, cancelPositive, mul_neg,
    neg_neg]

/-- On real blades the coefficient adjoint is grade involution followed by
reversion. The variation along this blade is skew-adjoint. -/
theorem blade_skew : CliffordAlgebra.reverse (CliffordAlgebra.involute blade) = -blade := by
  have hinv (i : Index) : CliffordAlgebra.involute (gamma i) = -gamma i :=
    CliffordAlgebra.involute_ι _
  have hrev (i : Index) : CliffordAlgebra.reverse (gamma i) = gamma i :=
    CliffordAlgebra.reverse_ι _
  simp (disch := decide) only [blade, map_mul, hinv, CliffordAlgebra.reverse.map_mul, map_neg, hrev,
    neg_mul, mul_neg, mul_assoc, swapDescending, swapLast, neg_neg]

theorem correction_value : correction 0 = (-8 / 3 : ℝ) • blade := by
  rw [sum_correction, insertion_012, insertion_021]
  -- Normalize the eight words using the Clifford anticommutation relations.
  simp (disch := decide) only [anti, comm, sub_eq_add_neg, neg_mul, mul_neg, add_mul,
    mul_add, mul_assoc, swapDescending, swapLast, neg_neg, blade]
  module

theorem correction_ne_zero : correction 0 ≠ 0 := by
  rw [correction_value]
  apply smul_ne_zero (by norm_num)
  intro h
  exact (one_ne_zero : (1 : Cl) ≠ 0) (by simpa [h] using blade_square.symm)

/-- With the 128-dimensional matrix trace normalization, this is the trace
pairing density obtained by setting alpha_0 = gamma^{01234}. -/
theorem pairing_density (trace : Cl →ₗ[ℝ] ℝ) (normalized : trace 1 = 128) :
    trace (blade * correction 0) = -1024 / 3 := by
  rw [correction_value, mul_smul_comm, blade_square, map_smul, normalized]
  norm_num

end GeometricUnity.WitnessW1
