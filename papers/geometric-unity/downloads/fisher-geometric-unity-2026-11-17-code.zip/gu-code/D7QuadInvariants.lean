import D7TripleMultiplicity

/-!
# Invariant forms with one vector and three exterior factors

In empty parity, a vector coordinate occurs in one or three exterior factors.
The first case gives the three possible partners of the vector slot. A plane
rotation into an unused axis determines the second case from the first.
-/

namespace GeometricUnity.D7QuadInvariants

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7TensorColumns
open D7TensorRotations D7ComplementaryGrades D7TripleMultiplicity
open D7TripleInvariants (character_diff subsetFlip_diff diff_card perm_pair_with_point feasible empty_parity_feasible)
open scoped symmDiff BigOperators TensorProduct

noncomputable section

abbrev Form (k l : ℕ) := Space →ₗ[ℂ] D7TripleInvariants.Form 2 k l

structure Quad (k l : ℕ) where
  axis : Axis
  first : Index 2
  second : Index k
  third : Index l

def invariantForms (k l : ℕ) : Submodule ℂ (Form k l) where
  carrier := {F | ∀ (g : splitSpecialOrthogonal) x y z w,
    F (g.val x) (exteriorRepresentation 2 g y) (exteriorRepresentation k g z)
      (exteriorRepresentation l g w) = F x y z w}
  add_mem' hF hG g x y z w := by simp only [LinearMap.add_apply, hF g x y z w, hG g x y z w]
  zero_mem' := by
    change ∀ (g : splitSpecialOrthogonal) (x : Space) (y : Ext 2) (z : Ext k) (w : Ext l), _ = _
    intros; rfl
  smul_mem' c F hF g x y z w := by simp only [LinearMap.smul_apply, hF g x y z w]

def parity {k l : ℕ} (q : Quad k l) : Finset Axis :=
  ((q.first.val ∆ q.second.val) ∆ {q.axis}) ∆ q.third.val

def code {k l : ℕ} (q : Quad k l) : Bool × Bool :=
  (decide (q.axis ∈ q.first.val), decide (q.axis ∈ q.second.val))

def regular {k l : ℕ} (q : Quad k l) : Prop :=
  q.axis ∉ q.first.val ∨ q.axis ∉ q.second.val

def coefficient {k l : ℕ} (F : Form k l) (q : Quad k l) : ℂ :=
  F (orthBasis q.axis) (basis 2 q.first) (basis k q.second) (basis l q.third)

theorem coefficient_ext {k l : ℕ} {F G : Form k l}
    (h : ∀ q, coefficient F q = coefficient G q) : F = G := by
  apply orthBasis.ext
  intro a
  apply (basis 2).ext
  intro s
  apply (basis k).ext
  intro t
  apply (basis l).ext
  intro u
  exact h ⟨a, s, t, u⟩

private theorem doubleFlip_singleton (i j a : Axis) :
    (doubleFlip i j).val (orthBasis a) = character ({a} : Finset Axis) i j • orthBasis a := by
  simpa only [character, subsetFlip, axisFlip, Finset.mem_singleton, eq_comm] using doubleFlip_basis i j a

set_option maxHeartbeats 600000 in
theorem support_parity {k l : ℕ} (F : ↥(invariantForms k l)) (q : Quad k l)
    (h : coefficient F.val q ≠ 0) : parity q = ∅ ∨ parity q = Finset.univ := by
  classical
  by_contra! hn
  obtain ⟨i, hi⟩ := hn.1
  have hex : ∃ j, j ∉ parity q := by
    by_contra! he
    exact hn.2 (Finset.eq_univ_of_forall he)
  obtain ⟨j, hj⟩ := hex
  have hc : character (parity q) i j = -1 := by simp [character, subsetFlip, hi, hj]
  have he := F.prop (doubleFlip i j) (orthBasis q.axis) (basis 2 q.first)
    (basis k q.second) (basis l q.third)
  rw [doubleFlip_singleton, doubleFlip_exterior, doubleFlip_exterior, doubleFlip_exterior] at he
  simp only [map_smul, LinearMap.smul_apply, smul_eq_mul] at he
  change character q.third.val i j * (character q.second.val i j *
    (character q.first.val i j * (character {q.axis} i j * coefficient F.val q))) = coefficient F.val q at he
  have he' : character (parity q) i j * coefficient F.val q = coefficient F.val q := by
    rw [parity, character_diff, character_diff, character_diff]
    calc
      _ = character q.third.val i j * (character q.second.val i j *
        (character q.first.val i j * (character {q.axis} i j * coefficient F.val q))) := by ac_rfl
      _ = _ := he
  rw [hc, neg_one_mul] at he'
  have hz : (2 : ℂ) * coefficient F.val q = 0 := by linear_combination -he'
  exact h ((mul_eq_zero.mp hz).resolve_left (by norm_num))

theorem third_of_even {k l : ℕ} (q : Quad k l) (h : parity q = ∅) :
    q.third.val = (q.first.val ∆ q.second.val) ∆ {q.axis} :=
  (Finset.symmDiff_eq_empty.mp h).symm

theorem axis_mem_third_even {k l : ℕ} (q : Quad k l) (h : parity q = ∅) :
    q.axis ∈ q.third.val ↔ (q.axis ∈ q.first.val ↔ q.axis ∈ q.second.val) := by
  rw [third_of_even q h]
  simp only [Finset.mem_symmDiff, Finset.mem_singleton, not_true, and_false, false_or, true_and]
  tauto

private theorem pair_diff_card {k l : ℕ} (q : Quad k l) (h : parity q = ∅) :
    (q.first.val ∆ q.second.val).card + 1 = l +
      2 * (if q.axis ∈ q.first.val ∆ q.second.val then 1 else 0) := by
  have he := diff_card (q.first.val ∆ q.second.val) {q.axis}
  rw [← third_of_even q h, q.third.prop, Finset.card_singleton, Finset.inter_singleton] at he
  by_cases ha : q.axis ∈ q.first.val ∆ q.second.val <;> simpa [ha] using he.symm

theorem perm_even {k l : ℕ} (q q' : Quad k l) (h : parity q = ∅) (h' : parity q' = ∅)
    (hc : code q = code q') :
    ∃ σ : Equiv.Perm Axis, σ q.axis = q'.axis ∧ permIndex σ q.first = q'.first ∧
      permIndex σ q.second = q'.second ∧ permIndex σ q.third = q'.third := by
  have h₁ : q.axis ∈ q.first.val ↔ q'.axis ∈ q'.first.val := by
    have he := congrArg Prod.fst hc
    change decide (q.axis ∈ q.first.val) = decide (q'.axis ∈ q'.first.val) at he
    by_cases hq : q.axis ∈ q.first.val <;> by_cases hq' : q'.axis ∈ q'.first.val <;> simp_all
  have h₂ : q.axis ∈ q.second.val ↔ q'.axis ∈ q'.second.val := by
    have he := congrArg Prod.snd hc
    change decide (q.axis ∈ q.second.val) = decide (q'.axis ∈ q'.second.val) at he
    by_cases hq : q.axis ∈ q.second.val <;> by_cases hq' : q'.axis ∈ q'.second.val <;> simp_all
  have hd : (q.first.val ∆ q.second.val).card = (q'.first.val ∆ q'.second.val).card := by
    have hx := pair_diff_card q h
    have hy := pair_diff_card q' h'
    have ha : q.axis ∈ q.first.val ∆ q.second.val ↔ q'.axis ∈ q'.first.val ∆ q'.second.val := by
      simp only [Finset.mem_symmDiff, h₁, h₂]
    by_cases hm : q.axis ∈ q.first.val ∆ q.second.val
    · rw [if_pos hm] at hx
      rw [if_pos (ha.mp hm)] at hy
      omega
    · rw [if_neg hm] at hx
      rw [if_neg (fun h => hm (ha.mpr h))] at hy
      omega
  have hi : (q.first.val ∩ q.second.val).card = (q'.first.val ∩ q'.second.val).card := by
    have hs := diff_card q.first.val q.second.val
    have ht := diff_card q'.first.val q'.second.val
    rw [q.first.prop, q.second.prop] at hs
    rw [q'.first.prop, q'.second.prop] at ht
    omega
  obtain ⟨σ, ha, hs, ht⟩ := perm_pair_with_point (q.first.prop.trans q'.first.prop.symm)
    (q.second.prop.trans q'.second.prop.symm) hi h₁ h₂
  refine ⟨σ, ha, Subtype.ext hs, Subtype.ext ht, ?_⟩
  apply Subtype.ext
  ext i
  obtain ⟨x, rfl⟩ := σ.surjective i
  change σ x ∈ q.third.val.map σ.toEmbedding ↔ σ x ∈ q'.third.val
  have hm (s : Finset Axis) : σ x ∈ s.map σ.toEmbedding ↔ x ∈ s := Finset.mem_map' σ.toEmbedding
  have hs' : σ x ∈ q'.first.val ↔ x ∈ q.first.val := hs ▸ hm q.first.val
  have ht' : σ x ∈ q'.second.val ↔ x ∈ q.second.val := ht ▸ hm q.second.val
  have ha' : σ x ∈ ({q'.axis} : Finset Axis) ↔ x ∈ ({q.axis} : Finset Axis) := by
    rw [← ha]
    simp
  rw [hm, third_of_even q h, third_of_even q' h']
  simp only [Finset.mem_symmDiff, hs', ht', ha']

set_option maxHeartbeats 600000 in
theorem same_even_zero {k l : ℕ} (F : ↥(invariantForms k l)) (q q' : Quad k l)
    (h : parity q = ∅) (h' : parity q' = ∅) (hc : code q = code q')
    (hz : coefficient F.val q' = 0) : coefficient F.val q = 0 := by
  obtain ⟨σ, ha, hs, ht, hu⟩ := perm_even q q' h h' hc
  obtain ⟨a, _, hA⟩ := orientedPerm_exterior σ 0 q.first
  obtain ⟨b, _, hB⟩ := orientedPerm_exterior σ 0 q.second
  obtain ⟨c, _, hC⟩ := orientedPerm_exterior σ 0 q.third
  have he := F.prop (orientedPermAt σ 0) (orthBasis q.axis) (basis 2 q.first)
    (basis k q.second) (basis l q.third)
  rw [orientedPermAt_basis, ha, hA, hB, hC, hs, ht, hu] at he
  simp only [map_smul, LinearMap.smul_apply] at he
  change c • b • a • orientationCorrection σ 0 q.axis • coefficient F.val q' = coefficient F.val q at he
  rw [hz, smul_zero, smul_zero, smul_zero, smul_zero] at he
  exact he.symm

theorem insert_eq_diff (s : Finset Axis) (a : Axis) (h : a ∉ s) :
    insert a s = s ∆ {a} := by
  ext i
  by_cases hi : i = a <;> simp [Finset.mem_symmDiff, hi, h]

private theorem insert_erase_val {n : ℕ} (s : Index (n + 1)) (a : Axis) (h : a ∈ s.val) :
    s.val = (eraseIndex s a h).val ∆ {a} := by
  rw [← insert_eq_diff _ _ (notMem_eraseIndex s a h)]
  exact (Finset.insert_erase h).symm

private theorem collision_residual_even {k l : ℕ} (q : Quad (k + 1) (l + 1))
    (hp : parity q = ∅) (hs : q.axis ∈ q.first.val) (ht : q.axis ∈ q.second.val)
    (hu : q.axis ∈ q.third.val) :
    ((eraseIndex q.first q.axis hs).val ∆ (eraseIndex q.second q.axis ht).val) ∆
      (eraseIndex q.third q.axis hu).val = ∅ := by
  let a : Finset Axis := {q.axis}
  let S := (eraseIndex q.first q.axis hs).val
  let T := (eraseIndex q.second q.axis ht).val
  let U := (eraseIndex q.third q.axis hu).val
  have hS : q.first.val = S ∆ a := insert_erase_val q.first q.axis hs
  have hT : q.second.val = T ∆ a := insert_erase_val q.second q.axis ht
  have hU : q.third.val = U ∆ a := insert_erase_val q.third q.axis hu
  change ((q.first.val ∆ q.second.val) ∆ a) ∆ q.third.val = ∅ at hp
  rw [hS, hT, hU] at hp
  have he : (((S ∆ a) ∆ (T ∆ a)) ∆ a) ∆ (U ∆ a) = ((S ∆ T) ∆ U) ∆ ((a ∆ a) ∆ (a ∆ a)) := by ac_rfl
  rw [he] at hp
  simpa using hp

private theorem exists_unused {k l : ℕ} (hk : k ≤ 7) (q : Quad k l) (hp : parity q = ∅) :
    ∃ b : Axis, b ≠ q.axis ∧ b ∉ q.first.val ∧ b ∉ q.second.val ∧ b ∉ q.third.val := by
  let s := insert q.axis (q.first.val ∪ q.second.val)
  have hA := Finset.card_insert_le q.axis (q.first.val ∪ q.second.val)
  have hB := Finset.card_union_le q.first.val q.second.val
  rw [q.first.prop, q.second.prop] at hB
  have hcard : s.card < (Finset.univ : Finset Axis).card := by
    rw [Finset.card_univ, Fintype.card_fin]
    dsimp [s]
    omega
  obtain ⟨b, _, hb⟩ := Finset.exists_mem_notMem_of_card_lt_card hcard
  have hx : b ≠ q.axis ∧ b ∉ q.first.val ∧ b ∉ q.second.val := by
    simpa [s, not_or] using hb
  refine ⟨b, hx.1, hx.2.1, hx.2.2, ?_⟩
  rw [third_of_even q hp]
  simp [Finset.mem_symmDiff, hx.1, hx.2.1, hx.2.2]

private abbrev e := orthBasis

private theorem rotation_wedge_fixed_tail {n : ℕ} (i j : Axis) (h : i ≠ j) (R : Index n)
    (hi : i ∉ R.val) (hj : j ∉ R.val) :
    exteriorRepresentation (n + 1) (D7Hook.rotation i j h)
      (wedgeLeftLinear n (e i) (basis n R)) =
        (-7 / 25 : ℂ) • wedgeLeftLinear n (e i) (basis n R) +
          (24 / 25 : ℂ) • wedgeLeftLinear n (e j) (basis n R) := by
  let g := D7Hook.rotation i j h
  have hR := map_basis_fixed g R (fun x hx => D7Hook.rotation_off_plane i j x h
    (fun he => hi (he ▸ hx)) (fun he => hj (he ▸ hx)))
  change exteriorPower.map (n + 1) g.val (wedgeLeftLinear n (e i) (basis n R)) = _
  rw [wedgeLeft_naturality n g, hR]
  have he := (D7Hook.rotation_on_plane i j h).1
  change g.val (e i) = _ at he
  rw [he, map_add, LinearMap.add_apply, map_smul, map_smul,
    LinearMap.smul_apply, LinearMap.smul_apply]

private theorem quarter_wedge_fixed_tail {n : ℕ} (i j : Axis) (h : i ≠ j) (R : Index n)
    (hi : i ∉ R.val) (hj : j ∉ R.val) :
    exteriorRepresentation (n + 1) (quarterTurn i j)
      (wedgeLeftLinear n (e i) (basis n R)) = -wedgeLeftLinear n (e j) (basis n R) := by
  let g := quarterTurn i j
  change exteriorPower.map (n + 1) g.val (wedgeLeftLinear n (e i) (basis n R)) = _
  rw [wedgeLeft_naturality n g, quarterTurn_exterior i j h R (iff_of_false hi hj),
    (quarterTurn_basis i j h).1, map_neg, LinearMap.neg_apply]

private theorem scaled_zero {a b c x : ℂ} (ha : a ≠ 0) (hb : b ≠ 0) (hc : c ≠ 0)
    (h : c • b • a • x = 0) : x = 0 := by
  exact (smul_eq_zero.mp ((smul_eq_zero.mp ((smul_eq_zero.mp h).resolve_left hc)).resolve_left hb)).resolve_left ha

set_option maxHeartbeats 800000 in
private theorem collision_wedge_zero {k l : ℕ} (F : ↥(invariantForms (k + 1) (l + 1)))
    (hz : ∀ q : Quad (k + 1) (l + 1), parity q = ∅ → regular q → coefficient F.val q = 0)
    (i j : Axis) (hij : i ≠ j) (R : Index 1) (S : Index k) (T : Index l)
    (hiR : i ∉ R.val) (hiS : i ∉ S.val) (hiT : i ∉ T.val)
    (hjR : j ∉ R.val) (hjS : j ∉ S.val) (hjT : j ∉ T.val)
    (hp : (R.val ∆ S.val) ∆ T.val = ∅) :
    F.val (e i) (wedgeLeftLinear 1 (e i) (basis 1 R))
      (wedgeLeftLinear k (e i) (basis k S)) (wedgeLeftLinear l (e i) (basis l T)) = 0 := by
  let a (b : Bool) : Axis := if b then j else i
  have ha : Function.Injective a := by
    intro b c h
    cases b <;> cases c <;> simp_all [a]
  have haR (b : Bool) : a b ∉ R.val := by
    cases b
    · exact hiR
    · exact hjR
  have haS (b : Bool) : a b ∉ S.val := by
    cases b
    · exact hiS
    · exact hjS
  have haT (b : Bool) : a b ∉ T.val := by
    cases b
    · exact hiT
    · exact hjT
  let X (b : Bool) := e (a b)
  let Y (b : Bool) := wedgeLeftLinear 1 (X b) (basis 1 R)
  let Z (b : Bool) := wedgeLeftLinear k (X b) (basis k S)
  let W (b : Bool) := wedgeLeftLinear l (X b) (basis l T)
  have hsmall : ({i, j} : Finset Axis).card < (Finset.univ : Finset Axis).card := by
    rw [Finset.card_pair hij, Finset.card_univ, Fintype.card_fin]
    decide
  obtain ⟨p, _, hpj⟩ := Finset.exists_mem_notMem_of_card_lt_card hsmall
  have hpmark (b : Bool) : p ≠ a b := by
    cases b
    · exact fun h => hpj (Finset.mem_insert.mpr (Or.inl h))
    · exact fun h => hpj (Finset.mem_insert.mpr (Or.inr (Finset.mem_singleton.mpr h)))
  have hMix (b c d f : Bool) (hh : b ≠ c ∨ b ≠ d ∨ b ≠ f) :
      F.val (X b) (Y c) (Z d) (W f) = 0 := by
    let q : Quad (k + 1) (l + 1) :=
      ⟨a b, insertIndex R (a c) (haR c), insertIndex S (a d) (haS d), insertIndex T (a f) (haT f)⟩
    have hpar : parity q = ((({a c} : Finset Axis) ∆ {a d}) ∆ {a b}) ∆ {a f} := by
      change ((insert (a c) R.val ∆ insert (a d) S.val) ∆ {a b}) ∆ insert (a f) T.val = _
      rw [insert_eq_diff _ _ (haR c), insert_eq_diff _ _ (haS d), insert_eq_diff _ _ (haT f)]
      have h : (((R.val ∆ {a c}) ∆ (S.val ∆ {a d})) ∆ {a b}) ∆ (T.val ∆ {a f}) =
          ((R.val ∆ S.val) ∆ T.val) ∆ ((({a c} ∆ {a d}) ∆ {a b}) ∆ {a f}) := by ac_rfl
      rw [h, hp]
      exact bot_symmDiff _
    have hnot : parity q ≠ Finset.univ := by
      intro he
      have he' : p ∈ parity q := he.symm ▸ Finset.mem_univ p
      rw [hpar] at he'
      simp [Finset.mem_symmDiff, hpmark] at he'
    have hzq : coefficient F.val q = 0 := by
      by_contra hn
      have he := (support_parity F q hn).resolve_right hnot
      have hrel : regular q := by
        by_contra h
        have h₁ : q.axis ∈ q.first.val := by by_contra hn; exact h (Or.inl hn)
        have h₂ : q.axis ∈ q.second.val := by by_contra hn; exact h (Or.inr hn)
        have hT' := (axis_mem_third_even q he).mpr (iff_of_true h₁ h₂)
        have hc : b = c := ha ((Finset.mem_insert.mp h₁).resolve_right (haR b))
        have hd : b = d := ha ((Finset.mem_insert.mp h₂).resolve_right (haS b))
        have hf : b = f := ha ((Finset.mem_insert.mp hT').resolve_right (haT b))
        exact hh.elim (fun H => H hc) (fun H => H.elim (fun H' => H' hd) (fun H' => H' hf))
      exact hn (hz q he hrel)
    obtain ⟨u, hu, hu'⟩ := enlarged_wedge R (a c) (haR c)
    obtain ⟨v, hv, hv'⟩ := enlarged_wedge S (a d) (haS d)
    obtain ⟨w, hw, hw'⟩ := enlarged_wedge T (a f) (haT f)
    change F.val (X b) (basis 2 (insertIndex R (a c) (haR c)))
      (basis (k + 1) (insertIndex S (a d) (haS d))) (basis (l + 1) (insertIndex T (a f) (haT f))) = 0 at hzq
    rw [hu', hv', hw'] at hzq
    simp only [map_smul, LinearMap.smul_apply] at hzq
    exact scaled_zero hu hv hw hzq
  have hQ := F.prop (quarterTurn i j) (X false) (Y false) (Z false) (W false)
  have hQx : (quarterTurn i j).val (X false) = -X true := (quarterTurn_basis i j hij).1
  have hQy : exteriorRepresentation 2 (quarterTurn i j) (Y false) = -Y true :=
    quarter_wedge_fixed_tail i j hij R hiR hjR
  have hQz : exteriorRepresentation (k + 1) (quarterTurn i j) (Z false) = -Z true :=
    quarter_wedge_fixed_tail i j hij S hiS hjS
  have hQw : exteriorRepresentation (l + 1) (quarterTurn i j) (W false) = -W true :=
    quarter_wedge_fixed_tail i j hij T hiT hjT
  rw [hQx, hQy, hQz, hQw] at hQ
  simp only [map_neg, LinearMap.neg_apply, neg_neg] at hQ
  let g := D7Hook.rotation i j hij
  let u : ℂ := -7 / 25
  let v : ℂ := 24 / 25
  have hx : g.val (X false) = u • X false + v • X true := (D7Hook.rotation_on_plane i j hij).1
  have hy : exteriorRepresentation 2 g (Y false) = u • Y false + v • Y true :=
    rotation_wedge_fixed_tail i j hij R hiR hjR
  have hZ : exteriorRepresentation (k + 1) g (Z false) = u • Z false + v • Z true :=
    rotation_wedge_fixed_tail i j hij S hiS hjS
  have hW : exteriorRepresentation (l + 1) g (W false) = u • W false + v • W true :=
    rotation_wedge_fixed_tail i j hij T hiT hjT
  have h := F.prop g (X false) (Y false) (Z false) (W false)
  rw [hx, hy, hZ, hW] at h
  simp (disch := decide) only [map_add, map_smul, LinearMap.add_apply, LinearMap.smul_apply, hMix,
    smul_eq_mul, hQ] at h
  change F.val (X false) (Y false) (Z false) (W false) = 0
  dsimp only [u, v] at h
  linear_combination -(390625 / 56448 : ℂ) * h

theorem even_coefficients_zero {k l : ℕ} (hk : k ≤ 7) (F : ↥(invariantForms k l))
    (hz : ∀ q : Quad k l, parity q = ∅ → regular q → coefficient F.val q = 0)
    (q : Quad k l) (hp : parity q = ∅) : coefficient F.val q = 0 := by
  by_cases hreg : regular q
  · exact hz q hp hreg
  have hs : q.axis ∈ q.first.val := by by_contra h; exact hreg (Or.inl h)
  have ht : q.axis ∈ q.second.val := by by_contra h; exact hreg (Or.inr h)
  have hu := (axis_mem_third_even q hp).mpr (iff_of_true hs ht)
  obtain ⟨j, hj, hjR, hjS, hjT⟩ := exists_unused hk q hp
  cases k with
  | zero =>
    have he : q.second.val = ∅ := Finset.card_eq_zero.mp q.second.prop
    rw [he] at ht
    exact (Finset.notMem_empty _ ht).elim
  | succ k =>
    cases l with
    | zero =>
      have he : q.third.val = ∅ := Finset.card_eq_zero.mp q.third.prop
      rw [he] at hu
      exact (Finset.notMem_empty _ hu).elim
    | succ l =>
      let R := eraseIndex q.first q.axis hs
      let S := eraseIndex q.second q.axis ht
      let T := eraseIndex q.third q.axis hu
      have h := collision_wedge_zero F hz q.axis j hj.symm R S T
        (notMem_eraseIndex _ _ _) (notMem_eraseIndex _ _ _) (notMem_eraseIndex _ _ _)
        (fun h => hjR (Finset.mem_erase.mp h).2) (fun h => hjS (Finset.mem_erase.mp h).2)
        (fun h => hjT (Finset.mem_erase.mp h).2) (collision_residual_even q hp hs ht hu)
      obtain ⟨a, _, ha⟩ := basis_eq_wedge_erase q.first q.axis hs
      obtain ⟨b, _, hb⟩ := basis_eq_wedge_erase q.second q.axis ht
      obtain ⟨c, _, hc⟩ := basis_eq_wedge_erase q.third q.axis hu
      change F.val (e q.axis) (basis 2 q.first) (basis (k + 1) q.second) (basis (l + 1) q.third) = 0
      rw [ha, hb, hc]
      simp only [map_smul, LinearMap.smul_apply]
      change c • b • a • F.val (e q.axis) (wedgeLeftLinear 1 (e q.axis) (basis 1 R))
        (wedgeLeftLinear k (e q.axis) (basis k S)) (wedgeLeftLinear l (e q.axis) (basis l T)) = 0
      rw [h, smul_zero, smul_zero, smul_zero]

def possible (k l : ℕ) : Bool × Bool → Prop
  | (true, false) => feasible 1 k l
  | (false, true) => 0 < k ∧ feasible 2 (k - 1) l
  | (false, false) => 0 < l ∧ feasible 2 k (l - 1)
  | (true, true) => False

instance (k l : ℕ) (c : Bool × Bool) : Decidable (possible k l c) := by
  rcases c with ⟨a, b⟩
  cases a <;> cases b <;> simp only [possible] <;> infer_instance

abbrev OrbitCode := Bool × (Bool × Bool)

def allowed (k l : ℕ) (c : OrbitCode) : Prop :=
  possible k (if c.1 then 14 - l else l) c.2

instance (k l : ℕ) (c : OrbitCode) : Decidable (allowed k l c) :=
  inferInstanceAs (Decidable (possible k (if c.1 then 14 - l else l) c.2))

def quadMultiplicity (k l : ℕ) : ℕ := Fintype.card {c : OrbitCode // allowed k l c}

private theorem cancel_insert₁ (s t u a : Finset Axis) :
    (((s ∆ a) ∆ t) ∆ a) ∆ u = (s ∆ t) ∆ u := by
  rw [symmDiff_right_comm s a t, symmDiff_symmDiff_cancel_right]

private theorem cancel_insert₃ (s t u a : Finset Axis) :
    ((s ∆ t) ∆ a) ∆ (u ∆ a) = (s ∆ t) ∆ u := by
  rw [← symmDiff_assoc, symmDiff_right_comm (s ∆ t) a u, symmDiff_symmDiff_cancel_right]

theorem possible_of_even {k l : ℕ} (q : Quad k l) (hp : parity q = ∅) (hr : regular q) :
    possible k l (code q) := by
  by_cases hS : q.axis ∈ q.first.val
  · have hT : q.axis ∉ q.second.val := hr.resolve_left (not_not_intro hS)
    have he := insert_erase_val q.first q.axis hS
    rw [parity, he, cancel_insert₁] at hp
    simp only [code, hS, hT, decide_true, decide_false, possible]
    exact empty_parity_feasible (eraseIndex q.first q.axis hS, q.second, q.third) hp
  by_cases hT : q.axis ∈ q.second.val
  · cases k with
    | zero =>
      have ht : q.second.val = ∅ := Finset.card_eq_zero.mp q.second.prop
      rw [ht] at hT
      exact (Finset.notMem_empty _ hT).elim
    | succ k =>
      have he := insert_erase_val q.second q.axis hT
      rw [parity, he, ← symmDiff_assoc q.first.val, symmDiff_symmDiff_cancel_right] at hp
      simp only [code, hS, hT, decide_true, decide_false, possible, Nat.add_sub_cancel]
      exact ⟨by omega, empty_parity_feasible (q.first, eraseIndex q.second q.axis hT, q.third) hp⟩
  have hU := (axis_mem_third_even q hp).mpr (iff_of_false hS hT)
  cases l with
  | zero =>
    have ht : q.third.val = ∅ := Finset.card_eq_zero.mp q.third.prop
    rw [ht] at hU
    exact (Finset.notMem_empty _ hU).elim
  | succ l =>
    have he := insert_erase_val q.third q.axis hU
    rw [parity, he, cancel_insert₃] at hp
    simp only [code, hS, hT, decide_false, possible, Nat.add_sub_cancel]
    exact ⟨by omega, empty_parity_feasible (q.first, q.second, eraseIndex q.third q.axis hU) hp⟩

def complementThird {k l m : ℕ} (h : l + m = 14) (q : Quad k l) : Quad k m :=
  ⟨q.axis, q.first, q.second, ⟨q.third.valᶜ, by
    change q.third.valᶜ.card = m
    rw [Finset.card_compl, Fintype.card_fin, q.third.prop]
    omega⟩⟩

theorem complementThird_parity {k l m : ℕ} (h : l + m = 14) (q : Quad k l) :
    parity (complementThird h q) = (parity q)ᶜ := by
  ext i
  change i ∈ (((q.first.val ∆ q.second.val) ∆ {q.axis}) ∆ q.third.valᶜ) ↔
    i ∈ ((((q.first.val ∆ q.second.val) ∆ {q.axis}) ∆ q.third.val)ᶜ)
  simp only [Finset.mem_symmDiff, Finset.mem_compl]
  tauto

theorem allowed_of_regular {k l : ℕ} (hl : l ≤ 14) (q : Quad k l) (hr : regular q) (b : Bool)
    (hp : parity q = if b then Finset.univ else ∅) : allowed k l (b, code q) := by
  cases b
  · exact possible_of_even q hp hr
  · have h : l + (14 - l) = 14 := by omega
    have hp' : parity (complementThird h q) = ∅ := by
      rw [complementThird_parity, hp]
      simp
    exact possible_of_even (complementThird h q) hp' hr

def twistThird {k l m : ℕ} (h : l + m = 14) (F : Form k m) : Form k l where
  toFun x :=
    { toFun y := ((LinearMap.lcomp ℂ ℂ (starEquiv h).toLinearMap).comp (F x y))
      map_add' y z := by simp only [map_add, LinearMap.comp_add]
      map_smul' c y := by simp only [map_smul, LinearMap.comp_smul, RingHom.id_apply] }
  map_add' x y := by
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    apply LinearMap.ext
    intro u
    change F (x + y) z w (starEquiv h u) = F x z w (starEquiv h u) + F y z w (starEquiv h u)
    simp only [map_add, LinearMap.add_apply]
  map_smul' c x := by
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    apply LinearMap.ext
    intro u
    change F (c • x) z w (starEquiv h u) = c • F x z w (starEquiv h u)
    simp only [map_smul, LinearMap.smul_apply]

theorem twistThird_apply {k l m : ℕ} (h : l + m = 14) (F : Form k m) (x : Space)
    (y : Ext 2) (z : Ext k) (w : Ext l) :
    twistThird h F x y z w = F x y z (starEquiv h w) := rfl

theorem twistThird_mem {k l m : ℕ} (h : l + m = 14) (F : ↥(invariantForms k m)) :
    twistThird h F.val ∈ invariantForms k l := by
  intro g x y z w
  rw [twistThird_apply, twistThird_apply, starEquiv_equivariant]
  exact F.prop g x y z (starEquiv h w)

theorem eval_twistThird {k l m : ℕ} (h : l + m = 14) (F : Form k m) (q : Quad k l) :
    ∃ a : ℂ, a ≠ 0 ∧ coefficient (twistThird h F) q = a • coefficient F (complementThird h q) := by
  obtain ⟨s, hs, a, ha, he⟩ := starEquiv_complement h q.third
  have hS : s = (complementThird h q).third := Subtype.ext hs
  refine ⟨a, ha, ?_⟩
  change twistThird h F (e q.axis) (basis 2 q.first) (basis k q.second) (basis l q.third) = _
  rw [twistThird_apply, he, hS, map_smul]
  rfl

theorem complementary_twice {k l m : ℕ} (h : l + m = 14) (h' : m + l = 14) (q : Quad k l) :
    complementThird h' (complementThird h q) = q := by
  cases q with
  | mk a s t u =>
    have he : (complementThird h' (complementThird h ⟨a, s, t, u⟩)).third = u :=
      Subtype.ext (compl_compl u.val)
    exact congrArg (Quad.mk a s t) he

private abbrev RegularOrbit (k l : ℕ) :=
  {c : OrbitCode // ∃ q : Quad k l, regular q ∧ code q = c.2 ∧
    parity q = if c.1 then Finset.univ else ∅}

private def sample {k l : ℕ} (c : RegularOrbit k l) : Quad k l := Classical.choose c.prop

private theorem sample_spec {k l : ℕ} (c : RegularOrbit k l) :
    regular (sample c) ∧ code (sample c) = c.val.2 ∧
      parity (sample c) = if c.val.1 then Finset.univ else ∅ := Classical.choose_spec c.prop

private def orbitEvaluation (k l : ℕ) : invariantForms k l →ₗ[ℂ] (RegularOrbit k l → ℂ) where
  toFun F c := coefficient F.val (sample c)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

@[instance_reducible] def invariantFormsAddCommGroup (k l : ℕ) : AddCommGroup ↥(invariantForms k l) := by
  letI : AddCommGroup (D7TripleInvariants.Form 2 k l) := inferInstance
  letI : AddCommGroup (Form k l) := LinearMap.addCommGroup
  exact Submodule.addCommGroup (R := ℂ) (M := Form k l) (invariantForms k l)

local instance (k l : ℕ) : AddCommGroup ↥(invariantForms k l) := invariantFormsAddCommGroup k l

set_option maxHeartbeats 800000 in
private theorem orbitEvaluation_injective {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) :
    Function.Injective (orbitEvaluation k l) := by
  intro U V hUV
  apply sub_eq_zero.mp
  let F := U - V
  have hF : orbitEvaluation k l F = 0 := by rw [map_sub, hUV, sub_self]
  change F = 0
  have hsample (c : RegularOrbit k l) : coefficient F.val (sample c) = 0 := congrFun hF c
  have he (q : Quad k l) (h : parity q = ∅) : coefficient F.val q = 0 := by
    apply even_coefficients_zero hk F _ q h
    intro Q hQ hr
    let c : RegularOrbit k l := ⟨(false, code Q), Q, hr, rfl, hQ⟩
    obtain ⟨_, hc, hp⟩ := sample_spec c
    exact same_even_zero F Q (sample c) hQ hp hc.symm (hsample c)
  have hf : l + (14 - l) = 14 := by omega
  have hh : (14 - l) + l = 14 := by omega
  let G : ↥(invariantForms k (14 - l)) := ⟨twistThird hh F.val, twistThird_mem hh F⟩
  have ho (q : Quad k l) (h : parity q = Finset.univ) : coefficient F.val q = 0 := by
    let Q := complementThird hf q
    have hp : parity Q = ∅ := by rw [complementThird_parity, h]; simp
    have hG : coefficient G.val Q = 0 := by
      apply even_coefficients_zero hk G _ Q hp
      intro T hT hr
      let T' := complementThird hh T
      have ht : parity T' = Finset.univ := by rw [complementThird_parity, hT]; simp
      let c : RegularOrbit k l := ⟨(true, code T'), T', hr, rfl, ht⟩
      obtain ⟨_, hc, ht'⟩ := sample_spec c
      let S := complementThird hf (sample c)
      have hS : parity S = ∅ := by rw [complementThird_parity, ht']; simp
      have hGS : coefficient G.val S = 0 := by
        obtain ⟨a, _, ha⟩ := eval_twistThird hh F.val S
        change coefficient G.val S = _ at ha
        change _ = a • coefficient F.val (complementThird hh (complementThird hf (sample c))) at ha
        rw [complementary_twice, hsample c, smul_zero] at ha
        exact ha
      exact same_even_zero G T S hT hS hc.symm hGS
    obtain ⟨a, ha, ha'⟩ := eval_twistThird hh F.val Q
    change coefficient G.val Q = a • coefficient F.val (complementThird hh (complementThird hf q)) at ha'
    rw [complementary_twice, hG] at ha'
    exact (smul_eq_zero.mp ha'.symm).resolve_left ha
  apply Subtype.ext
  apply coefficient_ext
  intro q
  change coefficient F.val q = 0
  by_contra h
  rcases support_parity F q h with h₁ | h₂
  · exact h (he q h₁)
  · exact h (ho q h₂)

theorem invariantForms_finite {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) :
    Module.Finite ℂ ↥(invariantForms k l) := by
  classical
  exact Module.Finite.of_injective (orbitEvaluation k l) (orbitEvaluation_injective hk hl)

/-- There is at most one independent coefficient for each feasible parity
and partner of the vector slot. -/
theorem finrank_invariantForms_le {k l : ℕ} (hk : k ≤ 7) (hl : l ≤ 14) :
    Module.finrank ℂ (invariantForms k l) ≤ quadMultiplicity k l := by
  classical
  let j (c : RegularOrbit k l) : {b : OrbitCode // allowed k l b} := ⟨c.val, by
    have h := allowed_of_regular hl (sample c) (sample_spec c).1 c.val.1 (sample_spec c).2.2
    rw [(sample_spec c).2.1] at h
    exact h⟩
  have hj : Function.Injective j := fun a b h => Subtype.ext (congrArg (fun t : {b : OrbitCode // allowed k l b} => t.val) h)
  have hh := LinearMap.finrank_le_finrank_of_injective (orbitEvaluation_injective hk hl)
  rw [Module.finrank_pi] at hh
  exact hh.trans (Fintype.card_le_of_injective j hj)

end
end GeometricUnity.D7QuadInvariants
