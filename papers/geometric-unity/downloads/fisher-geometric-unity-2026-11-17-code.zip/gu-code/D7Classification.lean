import D7Counts
import Mathlib.Analysis.Complex.Polynomial.Basic
import Mathlib.CategoryTheory.Preadditive.Biproducts
import Mathlib.Data.Matrix.Mul
import Mathlib.LinearAlgebra.Complex.FiniteDimensional
import Mathlib.RepresentationTheory.FDRep
import Mathlib.Tactic.Module
import Mathlib.Tactic.NormNum

/-!
# Geometric Unity: representation-theoretic dimension bridge

The Hom-dimension calculation applies to decompositions into pairwise
nonisomorphic simple representations. For the D₇ application, the
decomposition isomorphisms identifying the signed weight tables with
exterior-power tensor products are explicit hypotheses.
-/

noncomputable section

namespace GeometricUnity.D7Classification

open CategoryTheory CategoryTheory.Limits
open scoped BigOperators

/-- The linear block-matrix description of maps between finite biproducts. -/
def blockHomEquiv (k : Type*) [Field k] {C : Type*} [Category C]
    [Preadditive C] [Linear k C] [HasFiniteBiproducts C]
    {I J : Type} [Fintype I] [Fintype J] (P : I → C) (Q : J → C) :
    (⨁ P ⟶ ⨁ Q) ≃ₗ[k] (∀ i j, P i ⟶ Q j) where
  toEquiv := biproduct.matrixEquiv (f := P) (g := Q)
  map_add' f g := by
    funext i j
    change biproduct.components (f + g) i j = _
    simp [biproduct.components, Preadditive.comp_add, Preadditive.add_comp]
  map_smul' r f := by
    funext i j
    change biproduct.components (r • f) i j = _
    simp [biproduct.components, Linear.comp_smul, Linear.smul_comp]

section Multiplicities

variable {k : Type*} [Field k] {G : Type*} [Monoid G]

local instance : HasFiniteBiproducts (FDRep k G) :=
  HasFiniteBiproducts.of_hasFiniteProducts

/-- The copies of the simple objects indicated by the multiplicity function. -/
abbrev Copies {I : Type} (S : I → FDRep k G) (m : I → ℕ) :
    (Σ i, Fin (m i)) → FDRep k G := fun i => S i.1

/-- A simple Hom block has rank one precisely when its two labels agree. -/
private theorem simple_block [IsAlgClosed k] {I : Type} [DecidableEq I]
    (S : I → FDRep k G) (simple : ∀ i, Simple (S i))
    (distinct : ∀ i j, i ≠ j → ¬ Nonempty (S i ≅ S j)) (i j : I) :
    Module.finrank k (S i ⟶ S j) = if i = j then 1 else 0 := by
  let : Simple (S i) := simple i
  let : Simple (S j) := simple j
  rw [FDRep.finrank_hom_simple_simple]
  by_cases h : i = j
  · subst j
    simp [show Nonempty (S i ≅ S i) from ⟨Iso.refl _⟩]
  · simp [h, distinct i j h]

/-- With explicit decomposition isomorphisms, the dimension of the
intertwiner space is the sum of the products of the multiplicities. -/
theorem finrank_hom_of_decompositions [IsAlgClosed k] {I : Type} [Fintype I]
    (S : I → FDRep k G) (simple : ∀ i, Simple (S i))
    (distinct : ∀ i j, i ≠ j → ¬ Nonempty (S i ≅ S j))
    (p q : I → ℕ) (P Q : FDRep k G) (eP : P ≅ ⨁ Copies S p) (eQ : Q ≅ ⨁ Copies S q) :
    Module.finrank k (P ⟶ Q) = ∑ i, p i * q i := by
  classical
  have sumTarget (i : I) :
      (∑ u : Σ j, Fin (q j), if i = u.1 then 1 else 0) = q i := by
    have h (j : I) : (∑ _ : Fin (q j), if i = j then 1 else 0) = if i = j then q j else 0 := by
      by_cases hij : i = j <;> simp [hij]
    simp only [Fintype.sum_sigma, h]
    rw [Finset.sum_eq_single i]
    · simp
    · intro j _ hji
      exact if_neg (Ne.symm hji)
    · simp
  calc
    Module.finrank k (P ⟶ Q) = Module.finrank k (⨁ Copies S p ⟶ ⨁ Copies S q) :=
      (Linear.homCongr k eP eQ).finrank_eq
    _ = Module.finrank k (∀ u v, Copies S p u ⟶ Copies S q v) :=
      (blockHomEquiv k (Copies S p) (Copies S q)).finrank_eq
    _ = ∑ u : Σ i, Fin (p i), q u.1 := by
      simp only [Module.finrank_pi_fintype, Copies, simple_block S simple distinct, sumTarget]
    _ = ∑ i, p i * q i := by
      rw [Fintype.sum_sigma]
      simp

/-- Intertwiner dimensions add over the source grades. -/
theorem finrank_hom_biproduct_source {I : Type} [Fintype I] (P : I → FDRep k G)
    (C Q : FDRep k G) (e : C ≅ ⨁ P) :
    Module.finrank k (C ⟶ Q) = ∑ i, Module.finrank k (P i ⟶ Q) := by
  let B : (⨁ P ⟶ Q) ≃ₗ[k] (∀ i, P i ⟶ Q) :=
    { toFun := fun f i => biproduct.ι P i ≫ f
      invFun := biproduct.desc
      left_inv := fun f => biproduct.hom_ext' _ _ (by simp)
      right_inv := fun f => funext fun i => biproduct.ι_desc f i
      map_add' := by intro f g; funext i; simp [Preadditive.comp_add]
      map_smul' := by intro r f; funext i; simp [Linear.comp_smul] }
  rw [(Linear.homCongr k e (Iso.refl Q)).finrank_eq, B.finrank_eq, Module.finrank_pi_fintype]

/-! The integer weight lists are read as multiplicity functions on the
union of their supports. -/

open D7Counts

private def keys (entries : Multiplicities) : Finset Weight :=
  (entries.map Prod.fst).toFinset

private theorem coefficient_cons (w v : Weight) (n : ℤ) (tail : Multiplicities) :
    coefficient ((v, n) :: tail) w = if w = v then n else coefficient tail w := by
  by_cases h : w = v
  · subst v
    simp [coefficient]
  · have hb : (w == v) = false := Bool.eq_false_iff.mpr (fun he => h (eq_of_beq he))
    simp [coefficient, List.lookup_cons, hb, h]

private theorem coefficient_outside (entries : Multiplicities) (w : Weight) (h : w ∉ keys entries) :
    coefficient entries w = 0 := by
  have hn : entries.lookup w = none := List.lookup_eq_none_iff.mpr fun entry he => by
    have hne : w ≠ entry.1 := fun hw => h (by
      unfold keys
      exact List.mem_toFinset.mpr (List.mem_map.mpr ⟨entry, he, hw.symm⟩))
    simp [hne]
  simp [coefficient, hn]

private theorem pairing_eq_sum_keys (source target : Multiplicities) (h : (source.map Prod.fst).Nodup) :
    pairing source target = ∑ w ∈ keys source, coefficient source w * coefficient target w := by
  induction source with
  | nil => simp [pairing, keys]
  | cons head tail ih =>
    rcases head with ⟨v, n⟩
    simp only [List.map_cons, List.nodup_cons] at h
    have hv : v ∉ keys tail := by simpa [keys] using h.1
    have keyCons : keys ((v, n) :: tail) = insert v (keys tail) := by simp [keys]
    change n * coefficient target v + pairing tail target = _
    rw [keyCons, Finset.sum_insert hv, coefficient_cons v v n tail, if_pos rfl, ih h.2]
    congr 1
    apply Finset.sum_congr rfl
    intro w hw
    have hne : w ≠ v := fun hwv => hv (hwv ▸ hw)
    rw [coefficient_cons w v n tail, if_neg hne]

def labels (source target : Multiplicities) : Finset Weight := keys source ∪ keys target

private theorem pairing_eq_sum_labels (source target : Multiplicities) (h : (source.map Prod.fst).Nodup) :
    pairing source target = ∑ w ∈ labels source target, coefficient source w * coefficient target w := by
  rw [pairing_eq_sum_keys _ _ h]
  apply Finset.sum_subset Finset.subset_union_left
  intro w _ hw
  rw [coefficient_outside source w hw, zero_mul]

private def multiplicity (entries : Multiplicities) (w : Weight) : ℕ :=
  (coefficient entries w).toNat

/-- The representation-theoretic input for a checked pair of weight tables.
In the application the simple objects are identified by highest weight,
and the two isomorphisms are the exterior-power/tensor-product decompositions. -/
structure TableDecomposition (source target : Multiplicities) (P Q : FDRep ℂ G) where
  simples : ↥(labels source target) → FDRep ℂ G
  simple : ∀ i, Simple (simples i)
  distinct : ∀ i j, i ≠ j → ¬ Nonempty (simples i ≅ simples j)
  source_nonnegative : ∀ i : ↥(labels source target), 0 ≤ coefficient source i.val
  target_nonnegative : ∀ i : ↥(labels source target), 0 ≤ coefficient target i.val
  source_iso : P ≅ ⨁ Copies simples (fun i => multiplicity source i.val)
  target_iso : Q ≅ ⨁ Copies simples (fun i => multiplicity target i.val)

theorem finrank_hom_eq_pairing {source target : Multiplicities} {P Q : FDRep ℂ G}
    (decomp : TableDecomposition source target P Q) (h : (source.map Prod.fst).Nodup) :
    (Module.finrank ℂ (P ⟶ Q) : ℤ) = pairing source target := by
  rw [finrank_hom_of_decompositions decomp.simples decomp.simple decomp.distinct _ _ P Q
    decomp.source_iso decomp.target_iso, pairing_eq_sum_labels _ _ h, Nat.cast_sum]
  rw [Finset.sum_subtype (labels source target) (fun _ => Iff.rfl)]
  apply Finset.sum_congr rfl
  intro i _
  simp only [Nat.cast_mul, multiplicity, Int.toNat_of_nonneg (decomp.source_nonnegative i),
    Int.toNat_of_nonneg (decomp.target_nonnegative i)]

set_option maxRecDepth 4096 in
set_option maxHeartbeats 4000000 in
private theorem grade_keys_nodup :
    ∀ (r : Fin 3) (k : Fin 15), ((gradeMultiplicities (r.val + 1) k.val).map Prod.fst).Nodup := by
  decide +kernel

/-- The ordinary and signed middle-degree labels both enter the calculation. -/
theorem middle_grade_labels : gradeWeights 7 = [mu 7, muMinus] := by decide

private theorem sum_grade_column (f : Row → ℤ) :
    (∑ k : Fin 15, f (gradeRow k.val)) = (expectedRows.map f).sum := by
  rw [Fin.sum_univ_eq_sum_range (fun k => f (gradeRow k)) 15]
  have h := List.sum_toFinset (fun k => f (gradeRow k)) (List.nodup_range (n := 15))
  rw [List.toFinset_range] at h
  rw [h]
  change ((List.range 15).map (f ∘ gradeRow)).sum = _
  rw [← List.map_map]
  change (rows.map f).sum = _
  rw [grade_rows]

/-- The three checked totals are dimensions under the indicated
equivariant decomposition isomorphisms. For Theorem 3.4, the intended
source families are Λ²V ⊗ Cₖ, Λ³V ⊗ Cₖ, and V ⊗ Cₖ. The respective
targets are V ⊗ C, C, and C. The middle exterior degree is included
in each of the fifteen grade families. -/
theorem checked_hom_dimensions
    (U B V : Fin 15 → FDRep ℂ G) (Uall Ball Vall VC C : FDRep ℂ G)
    (uGrades : Uall ≅ ⨁ U) (bGrades : Ball ≅ ⨁ B) (vGrades : Vall ≅ ⨁ V)
    (uDecomp : ∀ k : Fin 15, TableDecomposition (gradeMultiplicities 2 k.val) vectorTarget (U k) VC)
    (bDecomp : ∀ k : Fin 15, TableDecomposition (gradeMultiplicities 3 k.val) cliffordMultiplicities (B k) C)
    (vDecomp : ∀ k : Fin 15, TableDecomposition (gradeMultiplicities 1 k.val) cliffordMultiplicities (V k) C) :
    (Module.finrank ℂ (Uall ⟶ VC), Module.finrank ℂ (Ball ⟶ C), Module.finrank ℂ (Vall ⟶ C)) =
    (200, 96, 56) := by
  have hu (k : Fin 15) : (Module.finrank ℂ (U k ⟶ VC) : ℤ) = (gradeRow k.val).unrestricted :=
    finrank_hom_eq_pairing (uDecomp k) (grade_keys_nodup 1 k)
  have hb (k : Fin 15) : (Module.finrank ℂ (B k ⟶ C) : ℤ) = (gradeRow k.val).alternating :=
    finrank_hom_eq_pairing (bDecomp k) (grade_keys_nodup 2 k)
  have hv (k : Fin 15) : (Module.finrank ℂ (V k ⟶ C) : ℤ) = (gradeRow k.val).vector :=
    finrank_hom_eq_pairing (vDecomp k) (grade_keys_nodup 0 k)
  have hU : (Module.finrank ℂ (Uall ⟶ VC) : ℤ) = 200 := by
    rw [finrank_hom_biproduct_source U Uall VC uGrades, Nat.cast_sum]
    simp_rw [hu]
    rw [sum_grade_column Row.unrestricted]
    decide
  have hB : (Module.finrank ℂ (Ball ⟶ C) : ℤ) = 96 := by
    rw [finrank_hom_biproduct_source B Ball C bGrades, Nat.cast_sum]
    simp_rw [hb]
    rw [sum_grade_column Row.alternating]
    decide
  have hV : (Module.finrank ℂ (Vall ⟶ C) : ℤ) = 56 := by
    rw [finrank_hom_biproduct_source V Vall C vGrades, Nat.cast_sum]
    simp_rw [hv]
    rw [sum_grade_column Row.vector]
    decide
  have Udim : Module.finrank ℂ (Uall ⟶ VC) = 200 := by exact_mod_cast hU
  have Bdim : Module.finrank ℂ (Ball ⟶ C) = 96 := by exact_mod_cast hB
  have Vdim : Module.finrank ℂ (Vall ⟶ C) = 56 := by exact_mod_cast hV
  rw [Udim, Bdim, Vdim]

/-- The residual hook dimension follows from the direct-sum splitting
of the unrestricted symbol Hom space. -/
theorem hook_finrank_of_split (U B V H : Type*) [AddCommGroup U] [Module ℂ U]
    [AddCommGroup B] [Module ℂ B] [AddCommGroup V] [Module ℂ V] [AddCommGroup H] [Module ℂ H]
    [FiniteDimensional ℂ B] [FiniteDimensional ℂ V] [FiniteDimensional ℂ H]
    (split : U ≃ₗ[ℂ] B × V × H)
    (hU : Module.finrank ℂ U = 200) (hB : Module.finrank ℂ B = 96) (hV : Module.finrank ℂ V = 56) :
    Module.finrank ℂ H = 48 := by
  have h := split.finrank_eq
  rw [Module.finrank_prod, Module.finrank_prod, hU, hB, hV] at h
  omega

end Multiplicities

section RealDescent

variable {E : Type*} [AddCommGroup E] [Module ℂ E]

/-- The fixed vectors of the real-linear conjugation. -/
def Fixed (s : E →ₗ[ℝ] E) : Submodule ℝ E :=
  LinearMap.ker (s - LinearMap.id)

theorem mem_fixed (s : E →ₗ[ℝ] E) (x : E) : x ∈ Fixed s ↔ s x = x := by
  change s x - x = 0 ↔ _
  exact sub_eq_zero

private def mulI : E →ₗ[ℝ] E where
  toFun x := Complex.I • x
  map_add' _ _ := smul_add _ _ _
  map_smul' r x := smul_comm Complex.I r x

private theorem mulI_sq (x : E) : mulI (mulI x) = -x := by
  change Complex.I • (Complex.I • x) = -x
  rw [smul_smul, Complex.I_mul_I, neg_one_smul]

private def realPart (s : E →ₗ[ℝ] E) (invol : Function.Involutive s) : E →ₗ[ℝ] Fixed s :=
  ((1 / 2 : ℝ) • (LinearMap.id + s)).codRestrict (Fixed s) (fun x => by
    apply (mem_fixed _ _).2
    change s ((1 / 2 : ℝ) • (x + s x)) = (1 / 2 : ℝ) • (x + s x)
    rw [map_smul, map_add, invol, add_comm])

/-- Real and imaginary parts of a complex vector with respect to its
real form. The inverse sends the pair (u,v) to u + i v. -/
private def realFormEquiv (s : E →ₗ[ℝ] E) (invol : Function.Involutive s)
    (anti : ∀ x, s (mulI x) = -mulI (s x)) : E ≃ₗ[ℝ] Fixed s × Fixed s := by
  let R := realPart s invol
  let split : E →ₗ[ℝ] Fixed s × Fixed s := R.prod (R.comp (-mulI))
  refine { split with invFun := fun p => p.1.val + mulI p.2.val, left_inv := ?_, right_inv := ?_ }
  · intro x
    change (1 / 2 : ℝ) • (x + s x) +
      mulI ((1 / 2 : ℝ) • (-mulI x + s (-mulI x))) = x
    simp only [map_neg, anti, neg_neg, map_smul, map_add, mulI_sq]
    module
  · rintro ⟨u,v⟩
    have hu := (mem_fixed s u.val).1 u.property
    have hv := (mem_fixed s v.val).1 v.property
    apply Prod.ext
    · apply Subtype.ext
      change (1 / 2 : ℝ) • (u.val + mulI v.val + s (u.val + mulI v.val)) = u.val
      simp only [map_add, hu, anti, hv]
      module
    · apply Subtype.ext
      change (1 / 2 : ℝ) •
        (-mulI (u.val + mulI v.val) + s (-mulI (u.val + mulI v.val))) = v.val
      simp only [map_neg, map_add, mulI_sq, anti, hu, hv]
      module

/-- A complex representation space and its real form have equal dimensions
over their respective fields. The same statement applies to a Hom space
equipped with its induced conjugation. -/
theorem finrank_fixed_of_conjugation [FiniteDimensional ℂ E] (s : E →ₗ[ℝ] E)
    (invol : Function.Involutive s)
    (anti : ∀ x, s (Complex.I • x) = -(Complex.I • s x)) :
    Module.finrank ℝ (Fixed s) = Module.finrank ℂ E := by
  have h := (realFormEquiv s invol anti).finrank_eq
  rw [finrank_real_of_complex, Module.finrank_prod] at h
  omega

end RealDescent

section MatrixDescent

open scoped ComplexConjugate

variable {G m n : Type*} [Fintype m] [Fintype n]

/-- Intertwiner equations written in chosen bases. The scalar-extension
argument works for arbitrary families of action matrices. -/
def matrixIntertwiners {K : Type*} [Field K]
    (ρ : G → Matrix m m K) (τ : G → Matrix n n K) : Submodule K (Matrix n m K) where
  carrier := {M | ∀ g, M * ρ g = τ g * M}
  zero_mem' := by intro g; simp
  add_mem' := by
    intro X Y hX hY g
    change (X + Y) * ρ g = τ g * (X + Y)
    rw [Matrix.add_mul, Matrix.mul_add, hX g, hY g]
  smul_mem' := by
    intro r X hX g
    change (r • X) * ρ g = τ g * (r • X)
    rw [Matrix.smul_mul, Matrix.mul_smul, hX g]

def complexMatrices {j l : Type*} (X : Matrix j l ℝ) : Matrix j l ℂ :=
  X.map Complex.ofRealHom

private theorem complexMatrices_mul {j l r : Type*} [Fintype l]
    (M : Matrix j l ℝ) (N : Matrix l r ℝ) :
    complexMatrices (M * N) = complexMatrices M * complexMatrices N := Matrix.map_mul

variable (ρ : G → Matrix m m ℝ) (τ : G → Matrix n n ℝ)

abbrev ComplexIntertwiners := ↥(matrixIntertwiners (complexMatrices ∘ ρ) (complexMatrices ∘ τ))
abbrev RealIntertwiners := ↥(matrixIntertwiners ρ τ)

private theorem conjugate_real_matrix {j l : Type*} (X : Matrix j l ℝ) :
    (complexMatrices X).map conj = complexMatrices X := by
  ext i j
  exact Complex.conj_ofReal _

private def conjugateIntertwiner :
    ComplexIntertwiners ρ τ →ₗ[ℝ] ComplexIntertwiners ρ τ where
  toFun X := ⟨X.val.map conj, by
    intro g
    have h := congrArg (fun M : Matrix n m ℂ => M.map conj) (X.property g)
    simpa only [Function.comp_apply, Matrix.map_mul, conjugate_real_matrix] using h⟩
  map_add' X Y := by
    apply Subtype.ext
    ext i j
    exact map_add conj (X.val i j) (Y.val i j)
  map_smul' r X := by
    apply Subtype.ext
    ext i j
    exact map_smul Complex.conjAe.toLinearEquiv r (X.val i j)

private theorem conjugateIntertwiner_invol :
    Function.Involutive (conjugateIntertwiner ρ τ) := by
  intro X
  apply Subtype.ext
  ext i j
  exact star_star (X.val i j)

private theorem conjugateIntertwiner_anti (X : ComplexIntertwiners ρ τ) :
    conjugateIntertwiner ρ τ (Complex.I • X) = -(Complex.I • conjugateIntertwiner ρ τ X) := by
  apply Subtype.ext
  ext i j
  change conj (Complex.I * X.val i j) = -(Complex.I * conj (X.val i j))
  rw [map_mul, Complex.conj_I, neg_mul]

private def extendIntertwiner (X : RealIntertwiners ρ τ) : ComplexIntertwiners ρ τ :=
  ⟨complexMatrices X.val, by
    intro g
    have h := congrArg complexMatrices (X.property g)
    simpa only [complexMatrices, Matrix.map_mul, Function.comp_apply] using h⟩

private theorem extendIntertwiner_fixed (X : RealIntertwiners ρ τ) :
    extendIntertwiner ρ τ X ∈ Fixed (conjugateIntertwiner ρ τ) := by
  apply (mem_fixed _ _).2
  exact Subtype.ext (conjugate_real_matrix X.val)

private theorem fixed_eq_real_extension (X : Fixed (conjugateIntertwiner ρ τ)) :
    complexMatrices (X.val.val.map Complex.re) = X.val.val := by
  ext i j
  have hf := (mem_fixed _ _).1 X.property
  have hij : conj (X.val.val i j) = X.val.val i j :=
    congrArg (fun Y : ComplexIntertwiners ρ τ => Y.val i j) hf
  exact Complex.conj_eq_iff_re.mp hij

private def restrictIntertwiner (X : Fixed (conjugateIntertwiner ρ τ)) : RealIntertwiners ρ τ :=
  ⟨X.val.val.map Complex.re, by
    intro g
    apply Matrix.map_injective (f := Complex.ofRealHom) Complex.ofReal_injective
    have h := fixed_eq_real_extension ρ τ X
    change complexMatrices (_ * ρ g) = complexMatrices (τ g * _)
    rw [complexMatrices_mul, complexMatrices_mul, h]
    exact X.val.property g⟩

private def realIntertwinersEquivFixed :
    RealIntertwiners ρ τ ≃ₗ[ℝ] Fixed (conjugateIntertwiner ρ τ) where
  toFun X := ⟨extendIntertwiner ρ τ X, extendIntertwiner_fixed ρ τ X⟩
  invFun := restrictIntertwiner ρ τ
  left_inv X := by
    apply Subtype.ext
    ext i j
    exact Complex.ofReal_re _
  right_inv X := by
    apply Subtype.ext
    apply Subtype.ext
    exact fixed_eq_real_extension ρ τ X
  map_add' X Y := by
    apply Subtype.ext
    apply Subtype.ext
    ext i j
    exact map_add Complex.ofRealHom (X.val i j) (Y.val i j)
  map_smul' r X := by
    apply Subtype.ext
    apply Subtype.ext
    ext i j
    exact map_smul Complex.ofRealAm.toLinearMap r (X.val i j)

/-- Entrywise complexification of the action matrices preserves the
intertwiner dimension. This applies to a real group action in chosen
bases with the same group acting on the complexified spaces. -/
theorem finrank_real_complex_intertwiners :
    Module.finrank ℝ (RealIntertwiners ρ τ) = Module.finrank ℂ (ComplexIntertwiners ρ τ) :=
  (realIntertwinersEquivFixed ρ τ).finrank_eq.trans
    (finrank_fixed_of_conjugation (conjugateIntertwiner ρ τ)
      (conjugateIntertwiner_invol ρ τ) (conjugateIntertwiner_anti ρ τ))

end MatrixDescent

end GeometricUnity.D7Classification
