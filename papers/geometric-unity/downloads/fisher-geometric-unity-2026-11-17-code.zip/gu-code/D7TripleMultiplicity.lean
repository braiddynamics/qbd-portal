import D7TripleInvariants
import D7Classification

/-!
# Realization of the three-exterior-factor multiplicities

Exterior multiplication realizes disjoint pairings. In the mixed degree-three
case, split off one vector, contract it against the second wedge, and wedge
the other two slots into the result. Hodge duality produces the odd-parity
forms from the even-parity forms.
-/

namespace GeometricUnity.D7TripleMultiplicity

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7TensorColumns
open D7MiddleTensor (multiply multiply_pure)
open D7TensorRotations (contract_wedge_basis_of_ne)
open D7ComplementaryGrades D7TripleInvariants
open scoped TensorProduct BigOperators symmDiff

noncomputable section

private abbrev pure (k : ℕ) (u : Fin k → Space) : Ext k := exteriorPower.ιMulti ℂ k u
private abbrev e := orthBasis

def Orthogonal (f : Space →ₗ[ℂ] Space) : Prop :=
  ∀ x y, splitForm (f x) (f y) = splitForm x y

def orthInvariant {r k l : ℕ} (F : Form r k l) : Prop :=
  ∀ (f : Space →ₗ[ℂ] Space), Orthogonal f → ∀ x y z,
    F (exteriorPower.map r f x) (exteriorPower.map k f y) (exteriorPower.map l f z) = F x y z

private theorem multiply_natural {r k : ℕ} (f : Space →ₗ[ℂ] Space) (x : Ext r) (y : Ext k) :
    multiply r k (exteriorPower.map r f x) (exteriorPower.map k f y) =
      exteriorPower.map (r + k) f (multiply r k x y) := by
  have h : (((multiply r k).comp (exteriorPower.map r f)).flip.comp (exteriorPower.map k f)).flip =
      (multiply r k).compr₂ₛₗ (exteriorPower.map (r + k) f) := by
    apply ext_on_wedges (n := r) (W := Ext k →ₗ[ℂ] Ext (r + k))
    intro u
    apply ext_on_wedges (n := k) (W := Ext (r + k))
    intro v
    simp only [LinearMap.comp_apply, LinearMap.flip_apply, LinearMap.compr₂ₛₗ_apply,
      exteriorPower.map_apply_ιMulti, multiply_pure, append_map]
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

private def wedgeForm (r k : ℕ) : Form r k (r + k) :=
  (multiply r k).compr₂ₛₗ (exteriorMetric (r + k))

private theorem wedgeForm_invariant (r k : ℕ) : orthInvariant (wedgeForm r k) := by
  intro f hf x y z
  change exteriorMetric (r + k) (multiply r k (exteriorPower.map r f x) (exteriorPower.map k f y))
    (exteriorPower.map (r + k) f z) = _
  rw [multiply_natural, metric_map_invariant _ _ hf]
  rfl

private theorem wedgeForm_ne_zero (r k : ℕ) (h : r + k ≤ 14) : wedgeForm r k ≠ 0 := by
  have hu : (Finset.univ : Finset Axis).card = 14 := by simp
  obtain ⟨s, _, hs⟩ := Finset.exists_subset_card_eq (s := (Finset.univ : Finset Axis)) (by omega : r ≤ _)
  have hc : sᶜ.card = 14 - r := by rw [Finset.card_compl, Fintype.card_fin, hs]
  obtain ⟨t, ht, htcard⟩ := Finset.exists_subset_card_eq (s := sᶜ) (by omega : k ≤ _)
  have hd : Disjoint s t := disjoint_compl_right.mono_right ht
  let S : Index r := ⟨s, hs⟩
  let T : Index k := ⟨t, htcard⟩
  let U := Set.powersetCard.disjUnion (s := S) (t := T) hd
  let a := (Set.powersetCard.permOfDisjoint (s := S) (t := T) hd).sign
  have hmul : multiply r k (basis r S) (basis k T) = a • basis (r + k) U := by
    apply Subtype.ext
    change (basis r S).val * (basis k T).val = (a • basis (r + k) U : Ext (r + k)).val
    simpa only [exteriorPower.basis_apply, exteriorPower.ιMulti_family_apply_coe,
      Submodule.coe_smul_of_tower, a, U] using
      ExteriorAlgebra.ιMulti_family_mul_of_disjoint ℂ orthBasis S T hd
  intro hz
  have hz' := DFunLike.congr_fun (DFunLike.congr_fun hz (basis r S)) (basis k T)
  change exteriorMetric (r + k) (multiply r k (basis r S) (basis k T)) = 0 at hz'
  have h0 := exteriorMetric_injective (r + k) (hz'.trans (map_zero _).symm)
  rw [hmul] at h0
  have hb : basis (r + k) U = 0 := by
    have h1 := congrArg (fun x : Ext (r + k) => a⁻¹ • x) h0
    simpa only [smul_smul, inv_mul_cancel, one_smul, smul_zero] using h1
  exact (basis (r + k)).ne_zero U hb

theorem contract_natural_left (n : ℕ) (f : Space →ₗ[ℂ] Space) (hf : Orthogonal f)
    (x : Space) (y : Ext (n + 1)) :
    contractLeft n (f x) (exteriorPower.map (n + 1) f y) =
      exteriorPower.map n f (contractLeft n x y) := by
  have h := DFunLike.congr_fun (contract_natural n f hf) (x ⊗ₜ[ℂ] y)
  simpa only [LinearMap.comp_apply, TensorProduct.map_tmul, contract, TensorProduct.lift.tmul] using h

private theorem includeWedge_natural (n : ℕ) (f : Space →ₗ[ℂ] Space) (x : Ext (n + 1)) :
    includeWedge n (exteriorPower.map (n + 1) f x) =
      TensorProduct.map f (exteriorPower.map n f) (includeWedge n x) := by
  have h : (includeWedge n).comp (exteriorPower.map (n + 1) f) =
      (TensorProduct.map f (exteriorPower.map n f)).comp (includeWedge n) := by
    apply ext_on_wedges
    intro v
    simp only [LinearMap.comp_apply, exteriorPower.map_apply_ιMulti, includeWedge_pure, map_smul,
      map_sum, map_zsmul, TensorProduct.map_tmul, Function.comp_apply]
    rfl
  exact DFunLike.congr_fun h x

private def transfer (b c : ℕ) : Space →ₗ[ℂ] Ext b →ₗ[ℂ] Ext (c + 1) →ₗ[ℂ] Ext (b + c) :=
  LinearMap.mk₂ ℂ (fun x u => (multiply b c u).comp (contractLeft c x))
    (fun x x' u => by
      apply LinearMap.ext
      intro y
      simp only [LinearMap.comp_apply, map_add, LinearMap.add_apply])
    (fun a x u => by
      apply LinearMap.ext
      intro y
      simp only [LinearMap.comp_apply, map_smul, LinearMap.smul_apply])
    (fun x u u' => by
      apply LinearMap.ext
      intro y
      simp only [LinearMap.comp_apply, map_add, LinearMap.add_apply])
    (fun a x u => by
      apply LinearMap.ext
      intro y
      simp only [LinearMap.comp_apply, map_smul, LinearMap.smul_apply])

private theorem transfer_apply (b c : ℕ) (x : Space) (u : Ext b) (y : Ext (c + 1)) :
    transfer b c x u y = multiply b c u (contractLeft c x y) := rfl

private def mixedMap (b c : ℕ) : Ext (b + 1) →ₗ[ℂ] Ext (c + 1) →ₗ[ℂ] Ext (b + c) :=
  (TensorProduct.lift (transfer b c)).comp (includeWedge b)

private def mixedForm (b c : ℕ) : Form (b + 1) (c + 1) (b + c) :=
  (mixedMap b c).compr₂ₛₗ (exteriorMetric (b + c))

private theorem mixedForm_invariant (b c : ℕ) : orthInvariant (mixedForm b c) := by
  intro f hf x y z
  have h : ((TensorProduct.lift (transfer b c)).comp (TensorProduct.map f (exteriorPower.map b f))).flip.comp
      (exteriorPower.map (c + 1) f) =
      (((TensorProduct.lift (transfer b c)).compr₂ₛₗ (exteriorPower.map (b + c) f)).flip) := by
    apply LinearMap.ext
    intro y
    apply TensorProduct.ext'
    intro x u
    simp only [LinearMap.comp_apply, LinearMap.flip_apply, TensorProduct.map_tmul,
      TensorProduct.lift.tmul, transfer_apply, LinearMap.compr₂ₛₗ_apply]
    rw [contract_natural_left c f hf, multiply_natural]
  change exteriorMetric (b + c)
    (TensorProduct.lift (transfer b c) (includeWedge b (exteriorPower.map (b + 1) f x)) (exteriorPower.map (c + 1) f y))
    (exteriorPower.map (b + c) f z) = _
  rw [includeWedge_natural]
  have he := DFunLike.congr_fun (DFunLike.congr_fun h y) (includeWedge b x)
  change TensorProduct.lift (transfer b c) (TensorProduct.map f (exteriorPower.map b f) (includeWedge b x))
    (exteriorPower.map (c + 1) f y) = exteriorPower.map (b + c) f (mixedMap b c x y) at he
  rw [he, metric_map_invariant _ _ hf]
  rfl

theorem enlarged_wedge {c : ℕ} (R : Index c) (i : Axis) (hi : i ∉ R.val) :
    ∃ a : ℂ, a ≠ 0 ∧ basis (c + 1) (insertIndex R i hi) =
      a • wedgeLeftLinear c (e i) (basis c R) := by
  have hm : i ∈ (insertIndex R i hi).val := Finset.mem_insert_self _ _
  obtain ⟨a, ha, h⟩ := basis_eq_wedge_erase (insertIndex R i hi) i hm
  have he : eraseIndex (insertIndex R i hi) i hm = R := Subtype.ext (Finset.erase_insert hi)
  rw [he] at h
  exact ⟨a, ha, h⟩

private theorem two_wedge_ne_zero {c : ℕ} (R : Index c) (i j : Axis) (hij : i ≠ j)
    (hi : i ∉ R.val) (hj : j ∉ R.val) :
    wedgeLeftLinear (c + 1) (e i) (wedgeLeftLinear c (e j) (basis c R)) ≠ 0 := by
  let S := insertIndex R j hj
  have hiS : i ∉ S.val := by
    change i ∉ insert j R.val
    simp [hij, hi]
  obtain ⟨a, _, hA⟩ := enlarged_wedge R j hj
  obtain ⟨b, _, hB⟩ := enlarged_wedge S i hiS
  change basis (c + 1) S = _ at hA
  intro h
  rw [hA, map_smul, h, smul_zero, smul_zero] at hB
  exact (basis (c + 2)).ne_zero _ hB

private theorem mixedMap_ne_zero (c : ℕ) (hc : c ≤ 11) :
    ∃ (x : Ext 3) (y : Ext (c + 1)), mixedMap 2 c x y ≠ 0 := by
  let s : Finset Axis := ({0, 1, 2} : Finset Axis)ᶜ
  have hs : s.card = 11 := by decide
  obtain ⟨r, hr, hrc⟩ := Finset.exists_subset_card_eq (s := s) (by omega : c ≤ _)
  let R : Index c := ⟨r, hrc⟩
  have h0 : (0 : Axis) ∉ R.val := fun h => (Finset.mem_compl.mp (hr h)) (by simp)
  have h1 : (1 : Axis) ∉ R.val := fun h => (Finset.mem_compl.mp (hr h)) (by simp)
  have h2 : (2 : Axis) ∉ R.val := fun h => (Finset.mem_compl.mp (hr h)) (by simp)
  let v : Fin 3 → Space := ![e 0, e 1, e 2]
  let y := wedgeLeftLinear c (e 0) (basis c R)
  refine ⟨pure 3 v, y, ?_⟩
  have hy0 : contractLeft c (v 0) y = basis c R := contract_wedge_basis R 0 h0
  have hy1 : contractLeft c (v 1) y = 0 := contract_wedge_basis_of_ne R 1 0 (by decide) h1
  have hy2 : contractLeft c (v 2) y = 0 := contract_wedge_basis_of_ne R 2 0 (by decide) h2
  rw [mixedMap, LinearMap.comp_apply, includeWedge_pure, map_smul, map_sum, Fin.sum_univ_three]
  simp only [map_zsmul, TensorProduct.lift.tmul, LinearMap.smul_apply, LinearMap.add_apply,
    transfer_apply, hy0, hy1, hy2, map_zero, zsmul_zero, add_zero,
    Fin.val_zero, pow_zero, one_zsmul]
  apply smul_ne_zero (by norm_num : (((2 : ℕ) : ℂ) + 1)⁻¹ ≠ 0)
  have hv : (0 : Fin 3).removeNth v = ![e 1, e 2] := by
    funext i
    fin_cases i <;> rfl
  rw [hv]
  have he : (multiply 2 c (pure 2 ![e 1, e 2]) (basis c R)).val =
      (wedgeLeftLinear (c + 1) (e 1) (wedgeLeftLinear c (e 2) (basis c R))).val := by
    change (pure 2 ![e 1, e 2]).val * (basis c R).val =
      ExteriorAlgebra.ι ℂ (e 1) * (ExteriorAlgebra.ι ℂ (e 2) * (basis c R).val)
    rw [exteriorPower.ιMulti_apply_coe, ExteriorAlgebra.ιMulti_apply, List.ofFn_succ, List.ofFn_succ]
    simp only [List.ofFn_zero, List.prod_cons, List.prod_nil, mul_one]
    rw [mul_assoc]
    rfl
  intro hz
  have hv' := congrArg Subtype.val hz
  rw [he] at hv'
  exact two_wedge_ne_zero R 1 2 (by decide) h1 h2 (Subtype.ext hv')

private theorem mixedForm_ne_zero (c : ℕ) (hc : c ≤ 11) : mixedForm 2 c ≠ 0 := by
  obtain ⟨x, y, hxy⟩ := mixedMap_ne_zero c hc
  intro hz
  have h := DFunLike.congr_fun (DFunLike.congr_fun hz x) y
  change exteriorMetric (2 + c) (mixedMap 2 c x y) = 0 at h
  exact hxy (exteriorMetric_injective (2 + c) (h.trans (map_zero _).symm))

private theorem mixedForm_one_ne_zero (c : ℕ) (hc : c ≤ 12) : mixedForm 1 c ≠ 0 := by
  let s : Finset Axis := ({0, 1} : Finset Axis)ᶜ
  have hs : s.card = 12 := by decide
  obtain ⟨r, hr, hrc⟩ := Finset.exists_subset_card_eq (s := s) (by omega : c ≤ _)
  let R : Index c := ⟨r, hrc⟩
  have h0 : (0 : Axis) ∉ R.val := fun h => (Finset.mem_compl.mp (hr h)) (by simp)
  have h1 : (1 : Axis) ∉ R.val := fun h => (Finset.mem_compl.mp (hr h)) (by simp)
  let v : Fin 2 → Space := ![e 0, e 1]
  let y := wedgeLeftLinear c (e 0) (basis c R)
  have hy0 : contractLeft c (v 0) y = basis c R := contract_wedge_basis R 0 h0
  have hy1 : contractLeft c (v 1) y = 0 := contract_wedge_basis_of_ne R 1 0 (by decide) h1
  have hx : mixedMap 1 c (pure 2 v) y ≠ 0 := by
    rw [mixedMap, LinearMap.comp_apply, includeWedge_pure, map_smul, map_sum, Fin.sum_univ_two]
    simp only [map_zsmul, TensorProduct.lift.tmul, LinearMap.smul_apply, LinearMap.add_apply,
      transfer_apply, hy0, hy1, map_zero, zsmul_zero, add_zero, Fin.val_zero, pow_zero, one_zsmul]
    apply smul_ne_zero (by norm_num : (((1 : ℕ) : ℂ) + 1)⁻¹ ≠ 0)
    have hv : (0 : Fin 2).removeNth v = fun _ => e 1 := by
      funext j
      fin_cases j
      rfl
    rw [hv]
    have he : (multiply 1 c (pure 1 (fun _ => e 1)) (basis c R)).val =
        (wedgeLeftLinear c (e 1) (basis c R)).val := by
      change (pure 1 (fun _ => e 1)).val * (basis c R).val = _
      rw [exteriorPower.ιMulti_apply_coe, ExteriorAlgebra.ιMulti_apply, List.ofFn_succ]
      simp only [List.ofFn_zero, List.prod_cons, List.prod_nil, mul_one]
      rfl
    intro h
    have he' := congrArg (fun w : Ext (1 + c) => w.val) h
    rw [he] at he'
    obtain ⟨a, _, ha⟩ := enlarged_wedge R 1 h1
    have hb : wedgeLeftLinear c (e 1) (basis c R) = 0 := Subtype.ext he'
    rw [hb, smul_zero] at ha
    exact (basis (c + 1)).ne_zero _ ha
  intro hz
  have h := DFunLike.congr_fun (DFunLike.congr_fun hz (pure 2 v)) y
  change exteriorMetric (1 + c) (mixedMap 1 c (pure 2 v) y) = 0 at h
  exact hx (exteriorMetric_injective (1 + c) (h.trans (map_zero _).symm))

private def swapLast {r k l : ℕ} (F : Form r k l) : Form r l k where
  toFun x := (F x).flip
  map_add' x y := by
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    simp only [LinearMap.flip_apply, map_add, LinearMap.add_apply]
  map_smul' c x := by
    apply LinearMap.ext
    intro z
    apply LinearMap.ext
    intro w
    simp only [LinearMap.flip_apply, map_smul, LinearMap.smul_apply, RingHom.id_apply]

private theorem swapLast_invariant {r k l : ℕ} {F : Form r k l} (h : orthInvariant F) :
    orthInvariant (swapLast F) := fun f hf x y z => h f hf x z y

private theorem swapLast_ne_zero {r k l : ℕ} {F : Form r k l} (h : F ≠ 0) : swapLast F ≠ 0 := by
  intro hz
  apply h
  apply LinearMap.ext
  intro x
  apply LinearMap.ext
  intro y
  apply LinearMap.ext
  intro z
  exact DFunLike.congr_fun (DFunLike.congr_fun (DFunLike.congr_fun hz x) z) y

theorem even_exists {r k l : ℕ} (hr : r = 1 ∨ r = 3) (h : feasible r k l) :
    ∃ F : Form r k l, orthInvariant F ∧ F ≠ 0 := by
  obtain ⟨d, hdr, hdk, he, hN⟩ := h
  by_cases h0 : d.val = 0
  · have hl : l = r + k := by omega
    subst l
    exact ⟨wedgeForm r k, wedgeForm_invariant r k, wedgeForm_ne_zero r k (by omega)⟩
  by_cases hR : d.val = r
  · have hk : k = r + l := by omega
    subst k
    exact ⟨swapLast (wedgeForm r l), swapLast_invariant (wedgeForm_invariant r l),
      swapLast_ne_zero (wedgeForm_ne_zero r l (by omega))⟩
  have h3 : r = 3 := by omega
  subst r
  by_cases h1 : d.val = 1
  · let c := k - 1
    have hk : k = c + 1 := by dsimp [c]; omega
    have hl : l = 2 + c := by dsimp [c]; omega
    have hc : c ≤ 11 := by dsimp [c]; omega
    rw [hk, hl]
    exact ⟨mixedForm 2 c, mixedForm_invariant 2 c, mixedForm_ne_zero c hc⟩
  · have h2 : d.val = 2 := by omega
    let c := l - 1
    have hl : l = c + 1 := by dsimp [c]; omega
    have hk : k = 2 + c := by dsimp [c]; omega
    have hc : c ≤ 11 := by dsimp [c]; omega
    rw [hk, hl]
    exact ⟨swapLast (mixedForm 2 c), swapLast_invariant (mixedForm_invariant 2 c),
      swapLast_ne_zero (mixedForm_ne_zero c hc)⟩

theorem even_exists_two {k l : ℕ} (h : feasible 2 k l) :
    ∃ F : Form 2 k l, orthInvariant F ∧ F ≠ 0 := by
  obtain ⟨d, hd, hk, he, hN⟩ := h
  by_cases h0 : d.val = 0
  · have hl : l = 2 + k := by omega
    subst l
    exact ⟨wedgeForm 2 k, wedgeForm_invariant 2 k, wedgeForm_ne_zero 2 k (by omega)⟩
  by_cases h2 : d.val = 2
  · have hk' : k = 2 + l := by omega
    subst k
    exact ⟨swapLast (wedgeForm 2 l), swapLast_invariant (wedgeForm_invariant 2 l),
      swapLast_ne_zero (wedgeForm_ne_zero 2 l (by omega))⟩
  have h1 : d.val = 1 := by omega
  let c := k - 1
  have hk' : k = c + 1 := by dsimp [c]; omega
  have hl : l = 1 + c := by dsimp [c]; omega
  have hc : c ≤ 12 := by dsimp [c]; omega
  rw [hk', hl]
  exact ⟨mixedForm 1 c, mixedForm_invariant 1 c, mixedForm_one_ne_zero c hc⟩

theorem reflect_basis {k : ℕ} (s : Index k) :
    exteriorPower.map k vectorReflection (basis k s) = subsetFlip s.val 0 • basis k s := by
  rw [vectorReflection, orthDiagonal_exterior]
  congr 1
  unfold subsetFlip
  by_cases h : (0 : Axis) ∈ s.val
  · rw [if_pos h, Finset.prod_eq_single 0]
    · simp
    · intro j _ hj; simp [hj]
    · exact fun h' => (h' h).elim
  · rw [if_neg h]
    apply Finset.prod_eq_one
    intro j hj
    have h' : j ≠ 0 := fun he => h (he ▸ hj)
    simp [h']

private theorem even_vanishes_on_full {r k l : ℕ} {F : Form r k l}
    (h : orthInvariant F) (q : Triple r k l) (hq : parity q = Finset.univ) : value F q = 0 := by
  have hx := h vectorReflection vectorReflection_isometry (basis r q.1) (basis k q.2.1) (basis l q.2.2)
  simp only [reflect_basis, map_smul, LinearMap.smul_apply, smul_eq_mul] at hx
  change subsetFlip q.2.2.val 0 * (subsetFlip q.2.1.val 0 * (subsetFlip q.1.val 0 * value F q)) =
    value F q at hx
  have hs : subsetFlip (parity q) 0 = -1 := by rw [hq]; simp [subsetFlip]
  rw [parity, subsetFlip_diff, subsetFlip_diff] at hs
  have hz : -value F q = value F q := by
    calc
      _ = (subsetFlip q.1.val 0 * subsetFlip q.2.1.val 0 * subsetFlip q.2.2.val 0) * value F q := by
        rw [hs, neg_one_mul]
      _ = _ := by exact (show _ = _ by ac_rfl).trans hx
  have htwo : (2 : ℂ) * value F q = 0 := by linear_combination -hz
  exact (mul_eq_zero.mp htwo).resolve_left (by norm_num)

private theorem as_invariant {r k l : ℕ} {F : Form r k l} (h : orthInvariant F) :
    F ∈ invariantForms r k l := fun g x y z => h g.val g.prop.2 x y z

private def twistLast {r k l m : ℕ} (h : l + m = 14) (F : Form r k m) : Form r k l where
  toFun x := (LinearMap.lcomp ℂ ℂ (starEquiv h).toLinearMap).comp (F x)
  map_add' x y := by simp only [map_add, LinearMap.comp_add]
  map_smul' c x := by simp only [map_smul, LinearMap.comp_smul, RingHom.id_apply]

private theorem twistLast_apply {r k l m : ℕ} (h : l + m = 14) (F : Form r k m)
    (x : Ext r) (y : Ext k) (z : Ext l) : twistLast h F x y z = F x y (starEquiv h z) := rfl

private theorem twistLast_invariant {r k l m : ℕ} (h : l + m = 14) {F : Form r k m}
    (hF : orthInvariant F) : twistLast h F ∈ invariantForms r k l := by
  intro g x y z
  rw [twistLast_apply, twistLast_apply, starEquiv_equivariant]
  exact hF g.val g.prop.2 x y (starEquiv h z)

private theorem twistLast_ne_zero {r k l m : ℕ} (h : l + m = 14) {F : Form r k m}
    (hF : F ≠ 0) : twistLast h F ≠ 0 := by
  intro hz
  apply hF
  apply LinearMap.ext
  intro x
  apply LinearMap.ext
  intro y
  apply LinearMap.ext
  intro z
  obtain ⟨w, rfl⟩ := (starEquiv h).surjective z
  exact DFunLike.congr_fun (DFunLike.congr_fun (DFunLike.congr_fun hz x) y) w

private theorem odd_vanishes_on_empty {r k l m : ℕ} (h : l + m = 14) {F : Form r k m}
    (hF : orthInvariant F) (q : Triple r k l) (hq : parity q = ∅) : value (twistLast h F) q = 0 := by
  obtain ⟨u, hu, a, _, he⟩ := starEquiv_complement h q.2.2
  let p : Triple r k m := (q.1, q.2.1, u)
  have hqu := third_of_parity q false hq
  have hp : parity p = Finset.univ := by
    change (q.1.val ∆ q.2.1.val) ∆ u.val = Finset.univ
    rw [hu, show q.2.2.val = q.1.val ∆ q.2.1.val from hqu]
    ext i
    rw [Finset.mem_symmDiff]
    simp only [Finset.mem_compl, Finset.mem_univ, iff_true]
    tauto
  change twistLast h F (basis r q.1) (basis k q.2.1) (basis l q.2.2) = 0
  rw [twistLast_apply, he, map_smul]
  change a • value F p = 0
  rw [even_vanishes_on_full hF p hp, smul_zero]

private theorem exists_value_ne_zero {r k l : ℕ} {F : Form r k l} (h : F ≠ 0) :
    ∃ q : Triple r k l, value F q ≠ 0 := by
  by_contra! hn
  exact h (value_ext hn)

theorem even_nonzero_coordinate {r k l : ℕ} {F : Form r k l} (hF : orthInvariant F) (hF0 : F ≠ 0) :
    ∃ q : Triple r k l, parity q = ∅ ∧ value F q ≠ 0 := by
  obtain ⟨q, hq⟩ := exists_value_ne_zero hF0
  have h := support_parity ⟨F, as_invariant hF⟩ q hq
  exact ⟨q, h.resolve_right (fun hp => hq (even_vanishes_on_full hF q hp)), hq⟩

local instance (r k l : ℕ) : AddCommGroup ↥(invariantForms r k l) :=
  Submodule.addCommGroup (R := ℂ) (M := Form r k l) (invariantForms r k l)

private def evaluation {r k l : ℕ} (q : Triple r k l) : invariantForms r k l →ₗ[ℂ] ℂ where
  toFun F := value F.val q
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

private theorem two_le_finrank {r k l : ℕ} (A B : ↥(invariantForms r k l))
    (s t : Triple r k l)
    (hAs : value A.val s ≠ 0) (hBs : value B.val s = 0)
    (hAt : value A.val t = 0) (hBt : value B.val t ≠ 0) :
    2 ≤ Module.finrank ℂ (invariantForms r k l) := by
  let M : ℂ × ℂ →ₗ[ℂ] invariantForms r k l :=
    (LinearMap.fst ℂ ℂ ℂ).smulRight A + (LinearMap.snd ℂ ℂ ℂ).smulRight B
  have he (q : Triple r k l) (p : ℂ × ℂ) :
      evaluation q (M p) = p.1 * value A.val q + p.2 * value B.val q := by
    change evaluation q (p.1 • A + p.2 • B) = _
    rw [map_add, map_smul, map_smul]
    rfl
  have hi : Function.Injective M := by
    intro p q h
    have hs := congrArg (evaluation s) h
    have ht := congrArg (evaluation t) h
    rw [he, he, hBs, mul_zero, add_zero, mul_zero, add_zero] at hs
    rw [he, he, hAt, mul_zero, zero_add, mul_zero, zero_add] at ht
    exact Prod.ext (mul_right_cancel₀ hAs hs) (mul_right_cancel₀ hBt ht)
  simpa using LinearMap.finrank_le_finrank_of_injective hi

private theorem one_le_finrank {r k l : ℕ} (F : ↥(invariantForms r k l)) (hF : F.val ≠ 0) :
    1 ≤ Module.finrank ℂ (invariantForms r k l) := by
  have hex : ∃ x : ↥(invariantForms r k l), x ≠ 0 :=
    ⟨F, fun h => hF (congrArg (fun G : ↥(invariantForms r k l) => G.val) h)⟩
  have hpos : 0 < Module.finrank ℂ (invariantForms r k l) :=
    Module.finrank_pos_iff_exists_ne_zero.mpr hex
  omega

/-- In the vector and alternating channels, each feasible parity contributes
one independent intertwiner for every pair of exterior grades. -/
theorem finrank_exteriorIntertwiners (r k l : ℕ) (hr : r = 1 ∨ r = 3) (hl : l ≤ 14) :
    Module.finrank ℂ (ExteriorIntertwiners r k l) = parityBound r k l := by
  rw [(exteriorIntertwinerEquiv r k l).finrank_eq]
  apply le_antisymm (finrank_invariantForms_le r k l)
  have hsum : l + (14 - l) = 14 := by omega
  by_cases he : feasible r k l <;> by_cases ho : feasible r k (14 - l)
  · obtain ⟨A, hA, hA0⟩ := even_exists hr he
    obtain ⟨B, hB, hB0⟩ := even_exists hr ho
    let X : ↥(invariantForms r k l) := ⟨A, as_invariant hA⟩
    let Y : ↥(invariantForms r k l) := ⟨twistLast hsum B, twistLast_invariant hsum hB⟩
    obtain ⟨s, hs⟩ := exists_value_ne_zero hA0
    obtain ⟨t, ht⟩ := exists_value_ne_zero (twistLast_ne_zero hsum hB0)
    have hsP : parity s = ∅ := (support_parity X s hs).resolve_right (fun h => hs (even_vanishes_on_full hA s h))
    have htP : parity t = Finset.univ :=
      (support_parity Y t ht).resolve_left (fun h => ht (odd_vanishes_on_empty hsum hB t h))
    simp only [parityBound, if_pos he, if_pos ho]
    exact two_le_finrank X Y s t hs (odd_vanishes_on_empty hsum hB s hsP) (even_vanishes_on_full hA t htP) ht
  · obtain ⟨F, hF, hF0⟩ := even_exists hr he
    simpa [parityBound, he, ho] using one_le_finrank ⟨F, as_invariant hF⟩ hF0
  · obtain ⟨F, hF, hF0⟩ := even_exists hr ho
    simpa [parityBound, he, ho] using one_le_finrank
      ⟨twistLast hsum F, twistLast_invariant hsum hF⟩ (twistLast_ne_zero hsum hF0)
  · simp [parityBound, he, ho]

theorem alternating_multiplicities_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val)) =
      D7Counts.expectedRows.map (fun row => row.alternating.toNat) := by
  have h (k l : Fin 15) := finrank_exteriorIntertwiners 3 k.val l.val (Or.inr rfl) (by omega)
  simp_rw [h]
  exact alternating_bounds_by_grade

theorem vector_multiplicities_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) =
      D7Counts.expectedRows.map (fun row => row.vector.toNat) := by
  have h (k l : Fin 15) := finrank_exteriorIntertwiners 1 k.val l.val (Or.inl rfl) (by omega)
  simp_rw [h]
  exact vector_bounds_by_grade

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem vector_and_alternating_totals :
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) = 56 ∧
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val)) = 96 := by
  constructor
  · have h (k l : Fin 15) := finrank_exteriorIntertwiners 1 k.val l.val (Or.inl rfl) (by omega)
    simp_rw [h]
    decide +kernel
  · have h (k l : Fin 15) := finrank_exteriorIntertwiners 3 k.val l.val (Or.inr rfl) (by omega)
    simp_rw [h]
    decide +kernel

section Bundled

open CategoryTheory CategoryTheory.Limits

local instance : HasFiniteBiproducts (FDRep ℂ splitSpecialOrthogonal) :=
  HasFiniteBiproducts.of_hasFiniteProducts

def sourceGrade (r : ℕ) (k : Fin 15) : FDRep ℂ splitSpecialOrthogonal :=
  FDRep.of (V := Ext r ⊗[ℂ] Ext k.val) ((exteriorRepresentation r).tprod (exteriorRepresentation k.val))

def targetGrade (l : Fin 15) : FDRep ℂ splitSpecialOrthogonal :=
  FDRep.of (exteriorRepresentation l.val)

def summedSource (r : ℕ) : FDRep ℂ splitSpecialOrthogonal := ⨁ sourceGrade r

def summedTarget : FDRep ℂ splitSpecialOrthogonal := ⨁ targetGrade

def bundledHomEquiv {U W : Type} [AddCommGroup U] [Module ℂ U] [Module.Finite ℂ U]
    [AddCommGroup W] [Module ℂ W] [Module.Finite ℂ W]
    (ρ : Representation ℂ splitSpecialOrthogonal U) (σ : Representation ℂ splitSpecialOrthogonal W) :
    (FDRep.of ρ ⟶ FDRep.of σ) ≃ₗ[ℂ] ρ.IntertwiningMap σ where
  toFun f :=
    { toLinearMap := f.hom.hom.hom
      isIntertwining' g := congrArg
        (fun f : (FDRep.of ρ).V ⟶ (FDRep.of σ).V => f.hom.hom) (f.comm g) }
  invFun f :=
    { hom := FGModuleCat.ofHom f.toLinearMap
      comm g := FGModuleCat.hom_ext (f.isIntertwining' g) }
  left_inv _ := Action.hom_ext _ _ (FGModuleCat.hom_ext rfl)
  right_inv _ := Representation.IntertwiningMap.ext rfl
  map_add' _ _ := Representation.IntertwiningMap.ext rfl
  map_smul' _ _ := Representation.IntertwiningMap.ext rfl

set_option backward.isDefEq.respectTransparency false in
private def gradeHomEquiv (r : ℕ) (k l : Fin 15) :
    (sourceGrade r k ⟶ targetGrade l) ≃ₗ[ℂ] ExteriorIntertwiners r k.val l.val :=
  bundledHomEquiv (U := Ext r ⊗[ℂ] Ext k.val) (W := Ext l.val)
    ((exteriorRepresentation r).tprod (exteriorRepresentation k.val)) (exteriorRepresentation l.val)

private theorem summedHom_finrank (r : ℕ) : Module.finrank ℂ (summedSource r ⟶ summedTarget) =
    ∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners r k.val l.val) := by
  change Module.finrank ℂ (⨁ sourceGrade r ⟶ ⨁ targetGrade) = _
  rw [(D7Classification.blockHomEquiv ℂ (sourceGrade r) targetGrade).finrank_eq,
    Module.finrank_pi_fintype]
  apply Finset.sum_congr rfl
  intro k _
  rw [Module.finrank_pi_fintype]
  exact Finset.sum_congr rfl fun l _ => (gradeHomEquiv r k l).finrank_eq

/-- The complex Hom dimensions for the vector and Bianchi channels on the
biproduct of all exterior grades. -/
theorem vector_and_bianchi_hom_dimensions :
    Module.finrank ℂ (summedSource 1 ⟶ summedTarget) = 56 ∧
    Module.finrank ℂ (summedSource 3 ⟶ summedTarget) = 96 := by
  rw [summedHom_finrank, summedHom_finrank]
  exact vector_and_alternating_totals

end Bundled

end
end GeometricUnity.D7TripleMultiplicity
