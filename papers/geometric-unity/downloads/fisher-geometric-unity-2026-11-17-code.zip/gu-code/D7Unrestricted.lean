import D7QuadMultiplicity
import Mathlib.LinearAlgebra.Contraction

/-!
# The unrestricted complex exterior-grade Hom count

The product metric lowers the two output indices. The resulting invariant
four-linear forms have the multiplicities proved in D7QuadMultiplicity.
-/

namespace GeometricUnity.D7Unrestricted

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7TensorColumns
open D7ComplementaryGrades D7QuadInvariants D7TripleMultiplicity
open D7TripleInvariants (metricEquiv metricEquiv_toLinearMap)
open scoped BigOperators TensorProduct

noncomputable section

abbrev Source (k : ℕ) := Ext 2 ⊗[ℂ] Ext k
private abbrev e := orthBasis

def sourceAction (k : ℕ) : Representation ℂ splitSpecialOrthogonal (Source k) :=
  (exteriorRepresentation 2).tprod (exteriorRepresentation k)

abbrev Intertwiners (k l : ℕ) := Representation.IntertwiningMap (sourceAction k) (action l)

private theorem spaceMetric (x y : Space) : orthBasis.toDualEquiv x y = splitForm x y := by
  have h : orthBasis.toDualEquiv.toLinearMap = splitMetric := by
    apply orthBasis.ext
    intro i
    apply orthBasis.ext
    intro j
    change orthBasis.toDual (orthBasis i) (orthBasis j) = splitMetric (orthBasis i) (orthBasis j)
    rw [Module.Basis.toDual_apply, splitMetric_apply, orthBasis_pair]
  have hx := DFunLike.congr_fun (DFunLike.congr_fun h x) y
  exact hx.trans (splitMetric_apply x y)

/-- The product of the vector metric and the exterior coefficient metric. -/
def tensorMetric (l : ℕ) : Product l ≃ₗ[ℂ] (Product l →ₗ[ℂ] ℂ) :=
  (TensorProduct.congr orthBasis.toDualEquiv (metricEquiv l)).trans
    (TensorProduct.dualDistribEquivOfBasis orthBasis (basis l))

private theorem tensorMetric_tmul (l : ℕ) (x y : Space) (u v : Ext l) :
    tensorMetric l (x ⊗ₜ[ℂ] u) (y ⊗ₜ[ℂ] v) = splitForm x y * exteriorMetric l u v := by
  unfold tensorMetric
  rw [LinearEquiv.trans_apply, TensorProduct.congr_tmul]
  change TensorProduct.dualDistrib ℂ Space (Ext l) (orthBasis.toDualEquiv x ⊗ₜ[ℂ] metricEquiv l u)
    (y ⊗ₜ[ℂ] v) = _
  rw [TensorProduct.dualDistrib_apply, spaceMetric]
  have h := DFunLike.congr_fun (DFunLike.congr_fun (metricEquiv_toLinearMap l) u) v
  exact congrArg (fun t : ℂ => splitForm x y * t) h

private theorem tensorMetric_invariant (l : ℕ) (g : splitSpecialOrthogonal) (x y : Product l) :
    tensorMetric l (action l g x) (action l g y) = tensorMetric l x y := by
  let f := (tensorMetric l).toLinearMap
  let g' := action l g
  have h : ((f.comp g').flip.comp g').flip = f := by
    apply TensorProduct.ext'
    intro a u
    apply TensorProduct.ext'
    intro b v
    change tensorMetric l (action l g (a ⊗ₜ[ℂ] u)) (action l g (b ⊗ₜ[ℂ] v)) =
      tensorMetric l (a ⊗ₜ[ℂ] u) (b ⊗ₜ[ℂ] v)
    rw [action_tmul, action_tmul, tensorMetric_tmul, tensorMetric_tmul, g.prop.2]
    change splitForm a b * exteriorMetric l (exteriorRepresentation l g u) (exteriorRepresentation l g v) =
      splitForm a b * exteriorMetric l u v
    rw [metric_invariant]
  exact DFunLike.congr_fun (DFunLike.congr_fun h x) y

private def asForm {k l : ℕ} (G : Source k →ₗ[ℂ] Product l →ₗ[ℂ] ℂ) : Form k l where
  toFun x := TensorProduct.curry (((TensorProduct.mk ℂ Space (Ext l) x).dualMap).comp G)
  map_add' x y := by
    apply LinearMap.ext
    intro u
    apply LinearMap.ext
    intro v
    apply LinearMap.ext
    intro z
    change G (u ⊗ₜ[ℂ] v) ((x + y) ⊗ₜ[ℂ] z) = G (u ⊗ₜ[ℂ] v) (x ⊗ₜ[ℂ] z) + G (u ⊗ₜ[ℂ] v) (y ⊗ₜ[ℂ] z)
    rw [TensorProduct.add_tmul, map_add]
  map_smul' c x := by
    apply LinearMap.ext
    intro u
    apply LinearMap.ext
    intro v
    apply LinearMap.ext
    intro z
    change G (u ⊗ₜ[ℂ] v) ((c • x) ⊗ₜ[ℂ] z) = c • G (u ⊗ₜ[ℂ] v) (x ⊗ₜ[ℂ] z)
    rw [← TensorProduct.smul_tmul', map_smul]

private def asBilinear {k l : ℕ} (F : Form k l) :
    Ext 2 →ₗ[ℂ] Ext k →ₗ[ℂ] Space →ₗ[ℂ] Ext l →ₗ[ℂ] ℂ where
  toFun u := (F.flip u).flip
  map_add' u v := by
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    simp only [LinearMap.flip_apply, map_add, LinearMap.add_apply]
  map_smul' c u := by
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    simp only [LinearMap.flip_apply, map_smul, LinearMap.smul_apply, RingHom.id_apply]

private def asRaw {k l : ℕ} (F : Form k l) : Source k →ₗ[ℂ] Product l →ₗ[ℂ] ℂ :=
  TensorProduct.lift ((asBilinear F).compr₂ₛₗ (TensorProduct.uncurry (RingHom.id ℂ) Space (Ext l) ℂ))

private theorem asRaw_tmul {k l : ℕ} (F : Form k l) (x : Space) (u : Ext 2) (v : Ext k) (w : Ext l) :
    asRaw F (u ⊗ₜ[ℂ] v) (x ⊗ₜ[ℂ] w) = F x u v w := rfl

private theorem source_tmul (k : ℕ) (g : splitSpecialOrthogonal) (u : Ext 2) (v : Ext k) :
    sourceAction k g (u ⊗ₜ[ℂ] v) = exteriorRepresentation 2 g u ⊗ₜ[ℂ] exteriorRepresentation k g v :=
  TensorProduct.map_tmul _ _ _ _

private def lower {k l : ℕ} (T : Intertwiners k l) : Form k l :=
  asForm ((tensorMetric l).toLinearMap.comp T.toLinearMap)

private theorem lower_mem {k l : ℕ} (T : Intertwiners k l) : lower T ∈ invariantForms k l := by
  intro g x u v w
  have h := Representation.IntertwiningMap.isIntertwining (sourceAction k) (action l) T g (u ⊗ₜ[ℂ] v)
  rw [source_tmul] at h
  change tensorMetric l (T (exteriorRepresentation 2 g u ⊗ₜ[ℂ] exteriorRepresentation k g v))
    (g.val x ⊗ₜ[ℂ] exteriorRepresentation l g w) = tensorMetric l (T (u ⊗ₜ[ℂ] v)) (x ⊗ₜ[ℂ] w)
  have hw : action l g (x ⊗ₜ[ℂ] w) = g.val x ⊗ₜ[ℂ] exteriorRepresentation l g w :=
    action_tmul l g x w
  rw [h, ← hw, tensorMetric_invariant]

private def lowerLinear (k l : ℕ) : Intertwiners k l →ₗ[ℂ] invariantForms k l where
  toFun T := ⟨lower T, lower_mem T⟩
  map_add' T U := by
    apply Subtype.ext
    apply coefficient_ext
    intro q
    change tensorMetric l ((T + U) (basis 2 q.first ⊗ₜ[ℂ] basis k q.second))
      (e q.axis ⊗ₜ[ℂ] basis l q.third) = _
    simp only [Representation.IntertwiningMap.coe_add, Pi.add_apply, map_add, LinearMap.add_apply]
    rfl
  map_smul' a T := by
    apply Subtype.ext
    apply coefficient_ext
    intro q
    change tensorMetric l ((a • T) (basis 2 q.first ⊗ₜ[ℂ] basis k q.second))
      (e q.axis ⊗ₜ[ℂ] basis l q.third) = _
    simp only [Representation.IntertwiningMap.coe_smul, Pi.smul_apply, map_smul, LinearMap.smul_apply]
    rfl

private theorem lower_injective (k l : ℕ) : Function.Injective (lowerLinear k l) := by
  intro T U h
  apply Representation.IntertwiningMap.ext
  apply TensorProduct.ext'
  intro u v
  apply (tensorMetric l).injective
  apply TensorProduct.ext'
  intro x w
  have he := congrArg (fun F : ↥(invariantForms k l) => F.val x u v w) h
  exact he

private theorem vector_surjective (g : splitSpecialOrthogonal) : Function.Surjective g.val := by
  let e := LinearMap.equivOfIsUnitDet (g.prop.1 ▸ isUnit_one : IsUnit g.val.det)
  have he : e.toLinearMap = g.val := LinearMap.coe_equivOfIsUnitDet _
  rw [← he, LinearEquiv.coe_coe]
  exact e.surjective

private theorem lower_surjective (k l : ℕ) : Function.Surjective (lowerLinear k l) := by
  intro F
  let f := (tensorMetric l).symm.toLinearMap.comp (asRaw F.val)
  have hmetric (u : Source k) : tensorMetric l (f u) = asRaw F.val u :=
    (tensorMetric l).apply_symm_apply _
  let T : Intertwiners k l :=
    { toLinearMap := f
      isIntertwining' g := by
        apply TensorProduct.ext'
        intro u v
        simp only [LinearMap.comp_apply, source_tmul]
        apply (tensorMetric l).injective
        apply TensorProduct.ext'
        intro x w
        obtain ⟨x', rfl⟩ := vector_surjective g x
        obtain ⟨w', rfl⟩ := exterior_surjective l g w
        have hw : action l g (x' ⊗ₜ[ℂ] w') = g.val x' ⊗ₜ[ℂ] exteriorRepresentation l g w' :=
          action_tmul l g x' w'
        rw [← hw, tensorMetric_invariant, hmetric, hmetric, hw, asRaw_tmul, asRaw_tmul]
        exact F.prop g x' u v w' }
  refine ⟨T, Subtype.ext ?_⟩
  apply coefficient_ext
  intro q
  change tensorMetric l (f (basis 2 q.first ⊗ₜ[ℂ] basis k q.second))
    (e q.axis ⊗ₜ[ℂ] basis l q.third) = _
  rw [hmetric, asRaw_tmul]
  rfl

/-- Lowering the vector and exterior output indices identifies the
unrestricted intertwiners with the invariant four-linear forms. -/
def intertwinerEquiv (k l : ℕ) : Intertwiners k l ≃ₗ[ℂ] invariantForms k l :=
  LinearEquiv.ofBijective (lowerLinear k l) ⟨lower_injective k l, lower_surjective k l⟩

theorem intertwinerEquiv_apply {k l : ℕ} (T : Intertwiners k l)
    (a : Space) (u : Ext 2) (x : Ext k) (y : Ext l) :
    (intertwinerEquiv k l T).val a u x y =
      tensorMetric l (T (u ⊗ₜ[ℂ] x)) (a ⊗ₜ[ℂ] y) := rfl

private def sourceDuality {k m : ℕ} (h : k + m = 14) : (sourceAction k).Equiv (sourceAction m) :=
  Representation.Equiv.mk (TensorProduct.congr (LinearEquiv.refl ℂ (Ext 2)) (starEquiv h)) (by
    intro g
    apply TensorProduct.ext'
    intro u v
    simp only [LinearMap.comp_apply, source_tmul, LinearEquiv.coe_coe, TensorProduct.congr_tmul,
      LinearEquiv.refl_apply, starEquiv_equivariant])

private def precomposeDuality {k m : ℕ} (h : k + m = 14) (l : ℕ) :
    Intertwiners m l ≃ₗ[ℂ] Intertwiners k l where
  toFun T := T.comp (sourceDuality h).toIntertwiningMap
  invFun T := T.comp (sourceDuality h).symm.toIntertwiningMap
  left_inv T := by
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    change T ((sourceDuality h) ((sourceDuality h).symm x)) = T x
    rw [Representation.Equiv.apply_symm_apply]
  right_inv T := by
    apply Representation.IntertwiningMap.ext
    apply LinearMap.ext
    intro x
    change T ((sourceDuality h).symm ((sourceDuality h) x)) = T x
    rw [Representation.Equiv.symm_apply_apply]
  map_add' _ _ := Representation.IntertwiningMap.ext rfl
  map_smul' _ _ := Representation.IntertwiningMap.ext rfl

/-- The source grade can be replaced by its Hodge complement before
evaluating the partner and parity count. -/
theorem finrank_intertwiners (k l : Fin 15) :
    Module.finrank ℂ (Intertwiners k.val l.val) = quadMultiplicity (min k.val (14 - k.val)) l.val := by
  have hl : l.val ≤ 14 := by omega
  by_cases hk : k.val ≤ 7
  · have hle : k.val ≤ 14 - k.val := by omega
    rw [Nat.min_eq_left hle, (intertwinerEquiv k.val l.val).finrank_eq]
    exact D7QuadMultiplicity.finrank_invariantForms hk hl
  · have hsum : (14 - k.val) + k.val = 14 := by omega
    have hle : 14 - k.val ≤ k.val := by omega
    rw [Nat.min_eq_right hle, (precomposeDuality hsum l.val).finrank_eq,
      (intertwinerEquiv (14 - k.val) l.val).finrank_eq]
    exact D7QuadMultiplicity.finrank_invariantForms (by omega) hl

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem unrestricted_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val)) =
      D7Counts.expectedRows.map (fun row => row.unrestricted.toNat) := by
  simp_rw [finrank_intertwiners]
  decide +kernel

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem unrestricted_total :
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (Intertwiners k.val l.val)) = 200 := by
  simp_rw [finrank_intertwiners]
  decide +kernel

section Bundled

open CategoryTheory CategoryTheory.Limits

local instance : HasFiniteBiproducts (FDRep ℂ splitSpecialOrthogonal) :=
  HasFiniteBiproducts.of_hasFiniteProducts

def vectorTargetGrade (l : Fin 15) : FDRep ℂ splitSpecialOrthogonal :=
  FDRep.of (V := Product l.val) (action l.val)

def summedVectorTarget : FDRep ℂ splitSpecialOrthogonal := ⨁ vectorTargetGrade

set_option backward.isDefEq.respectTransparency false in
/-- Identify a bundled Hom block with the underlying intertwining maps. -/
def gradeHomEquiv (k l : Fin 15) :
    (sourceGrade 2 k ⟶ vectorTargetGrade l) ≃ₗ[ℂ] Intertwiners k.val l.val :=
  bundledHomEquiv (U := Source k.val) (W := Product l.val) (sourceAction k.val) (action l.val)

/-- The complex Hom dimension of the unrestricted symbol, on the
biproduct of all exterior grades. -/
theorem unrestricted_hom_dimension :
    Module.finrank ℂ (summedSource 2 ⟶ summedVectorTarget) = 200 := by
  change Module.finrank ℂ (⨁ sourceGrade 2 ⟶ ⨁ vectorTargetGrade) = _
  rw [(D7Classification.blockHomEquiv ℂ (sourceGrade 2) vectorTargetGrade).finrank_eq,
    Module.finrank_pi_fintype, ← unrestricted_total]
  apply Finset.sum_congr rfl
  intro k _
  rw [Module.finrank_pi_fintype]
  exact Finset.sum_congr rfl fun l _ => (gradeHomEquiv k l).finrank_eq

end Bundled

end
end GeometricUnity.D7Unrestricted
