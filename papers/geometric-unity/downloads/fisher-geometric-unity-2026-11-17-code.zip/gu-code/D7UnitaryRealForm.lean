import D7Classification
import Mathlib.LinearAlgebra.Matrix.ConjTranspose
import Mathlib.LinearAlgebra.TensorProduct.Tower

/-!
# The real coefficient space inside the complex matrix algebra

The real form is fixed by the negative adjoint for a Hermitian signature
matrix. Its scalar extension is the full complex matrix module. This
identification respects conjugation by units preserving the signature.
-/

namespace GeometricUnity.D7UnitaryRealForm

open D7Classification (Fixed mem_fixed finrank_fixed_of_conjugation)
open scoped Matrix TensorProduct

noncomputable section

variable {n : Type} [Fintype n]

/-- Conjugation for the skew-adjoint real form. -/
def realConjugation (J : Matrix n n ℂ) : Matrix n n ℂ →ₗ[ℝ] Matrix n n ℂ where
  toFun X := -(J * Xᴴ * J)
  map_add' X Y := by
    simp only [Matrix.conjTranspose_add, Matrix.mul_add, Matrix.add_mul, neg_add]
  map_smul' r X := by
    simp only [Matrix.conjTranspose_smul, star_trivial, Matrix.mul_smul, Matrix.smul_mul, smul_neg,
      RingHom.id_apply]

theorem realConjugation_apply (J X : Matrix n n ℂ) :
    realConjugation J X = -(J * Xᴴ * J) := rfl

/-- The real vector space of matrices skew-adjoint for the form with
signature matrix `J`. -/
def skewAdjoint (J : Matrix n n ℂ) : Submodule ℝ (Matrix n n ℂ) :=
  Fixed (realConjugation J)

theorem mem_skewAdjoint (J X : Matrix n n ℂ) :
    X ∈ skewAdjoint J ↔ X = -(J * Xᴴ * J) :=
  (mem_fixed (realConjugation J) X).trans eq_comm

private theorem realConjugation_anti (J : Matrix n n ℂ) (X : Matrix n n ℂ) :
    realConjugation J (Complex.I • X) = -(Complex.I • realConjugation J X) := by
  simp only [realConjugation_apply, Matrix.conjTranspose_smul, Complex.star_def, Complex.conj_I,
    Matrix.mul_neg, Matrix.neg_mul, Matrix.mul_smul, Matrix.smul_mul, neg_smul, neg_neg, smul_neg]

private theorem realConjugation_involutive [DecidableEq n] {J : Matrix n n ℂ}
    (hJ : Jᴴ = J) (hJJ : J * J = 1) : Function.Involutive (realConjugation J) := by
  intro X
  simp only [realConjugation_apply, Matrix.conjTranspose_neg, Matrix.conjTranspose_mul, hJ,
    Matrix.conjTranspose_conjTranspose, Matrix.mul_neg, Matrix.neg_mul, neg_neg]
  calc
    J * (J * (X * J)) * J = (J * J) * X * (J * J) := by simp only [Matrix.mul_assoc]
    _ = X := by rw [hJJ, Matrix.one_mul, Matrix.mul_one]

private def extendScalars (J : Matrix n n ℂ) :
    ℂ ⊗[ℝ] ↥(skewAdjoint J) →ₗ[ℂ] Matrix n n ℂ :=
  TensorProduct.AlgebraTensorModule.lift {
    toFun c := c • (skewAdjoint J).subtype
    map_add' c d := add_smul c d _
    map_smul' c d := smul_assoc c d _ }

@[simp] private theorem extendScalars_tmul (J : Matrix n n ℂ) (c : ℂ) (X : skewAdjoint J) :
    extendScalars J (c ⊗ₜ[ℝ] X) = c • X.val := rfl

variable [DecidableEq n]

private theorem extendScalars_surjective {J : Matrix n n ℂ}
    (hJ : Jᴴ = J) (hJJ : J * J = 1) : Function.Surjective (extendScalars J) := by
  let s := realConjugation J
  have hinv := realConjugation_involutive hJ hJJ
  intro X
  let A : skewAdjoint J := ⟨(1 / 2 : ℝ) • (X + s X), (mem_fixed s _).mpr (by
    rw [map_smul, map_add, hinv X, add_comm (s X) X])⟩
  let B : skewAdjoint J := ⟨(1 / 2 : ℝ) • (-(Complex.I • X) + Complex.I • s X),
    (mem_fixed s _).mpr (by
      rw [map_smul, map_add, map_neg, realConjugation_anti, realConjugation_anti, hinv X,
        neg_neg, add_comm])⟩
  refine ⟨(1 : ℂ) ⊗ₜ[ℝ] A + Complex.I ⊗ₜ[ℝ] B, ?_⟩
  rw [map_add, extendScalars_tmul, extendScalars_tmul, one_smul]
  change (1 / 2 : ℝ) • (X + s X) +
    Complex.I • ((1 / 2 : ℝ) • (-(Complex.I • X) + Complex.I • s X)) = X
  rw [smul_comm Complex.I (1 / 2 : ℝ)]
  simp only [smul_add, smul_neg, smul_smul, Complex.I_mul_I, neg_one_smul, neg_neg]
  module

/-- Scalar extension identifies the real coefficient space with the
whole complex matrix module. -/
def complexificationEquiv {J : Matrix n n ℂ} (hJ : Jᴴ = J) (hJJ : J * J = 1) :
    ℂ ⊗[ℝ] ↥(skewAdjoint J) ≃ₗ[ℂ] Matrix n n ℂ := by
  have h := finrank_fixed_of_conjugation (realConjugation J)
    (realConjugation_involutive hJ hJJ) (realConjugation_anti J)
  have hd : Module.finrank ℂ (ℂ ⊗[ℝ] ↥(skewAdjoint J)) =
      Module.finrank ℂ (Matrix n n ℂ) := Module.finrank_baseChange.trans h
  have hs := extendScalars_surjective hJ hJJ
  exact LinearEquiv.ofBijective (extendScalars J)
    ⟨(LinearMap.injective_iff_surjective_of_finrank_eq_finrank hd).mpr hs, hs⟩

@[simp] theorem complexificationEquiv_tmul {J : Matrix n n ℂ}
    (hJ : Jᴴ = J) (hJJ : J * J = 1) (c : ℂ) (X : skewAdjoint J) :
    complexificationEquiv hJ hJJ (c ⊗ₜ[ℝ] X) = c • X.val := rfl

local notation "SpinIndex" => Fin 64 ⊕ Fin 64

/-- The diagonal presentation of the signature `(64,64)`. -/
def signature : Matrix SpinIndex SpinIndex ℂ :=
  Matrix.diagonal (Sum.elim (fun _ => 1) (fun _ => -1))

theorem signature_hermitian : signatureᴴ = signature := by
  rw [signature, Matrix.diagonal_conjTranspose]
  congr 1
  funext i
  cases i <;> simp

theorem signature_sq : signature * signature = 1 := by
  rw [signature, Matrix.diagonal_mul_diagonal, ← Matrix.diagonal_one]
  congr 1
  funext i
  cases i <;> simp

/-- Conjugation on the complex coefficient matrices. -/
def matrixConjugation (U : (Matrix n n ℂ)ˣ) : Matrix n n ℂ →ₗ[ℂ] Matrix n n ℂ :=
  LinearMap.mulLeftRight ℂ (↑U, ↑U⁻¹)

theorem realConjugation_commutes {J : Matrix n n ℂ}
    (hJJ : J * J = 1) (U : (Matrix n n ℂ)ˣ) (hU : (U : Matrix n n ℂ)ᴴ * J * U = J)
    (X : Matrix n n ℂ) :
    realConjugation J (matrixConjugation U X) = matrixConjugation U (realConjugation J X) := by
  let u : Matrix n n ℂ := U
  let v : Matrix n n ℂ := ↑U⁻¹
  have hu : u * v = 1 := U.mul_inv
  change uᴴ * J * u = J at hU
  have hright : uᴴ * J = J * v := by
    have h := congrArg (fun X : Matrix n n ℂ => X * v) hU
    simpa only [Matrix.mul_assoc, hu, Matrix.mul_one] using h
  have ht : vᴴ * uᴴ = 1 := by rw [← Matrix.conjTranspose_mul, hu, Matrix.conjTranspose_one]
  have hleft : J * vᴴ = u * J := by
    have h0 : J * u = vᴴ * J := by
      have h : vᴴ * (uᴴ * J * u) = vᴴ * J := congrArg (fun X => vᴴ * X) hU
      simpa only [← Matrix.mul_assoc, ht, Matrix.one_mul] using h
    calc
      J * vᴴ = J * (vᴴ * J) * J := by simp only [Matrix.mul_assoc, hJJ, Matrix.mul_one]
      _ = u * J := by rw [← h0, ← Matrix.mul_assoc J J u, hJJ, Matrix.one_mul]
  change -(J * (u * X * v)ᴴ * J) = u * (-(J * Xᴴ * J)) * v
  calc
    _ = -(J * vᴴ * Xᴴ * (uᴴ * J)) := by simp only [Matrix.conjTranspose_mul, Matrix.mul_assoc]
    _ = -(u * J * Xᴴ * (J * v)) := by rw [hleft, hright]
    _ = _ := by simp only [Matrix.mul_neg, Matrix.neg_mul, Matrix.mul_assoc]

/-- A unit preserving the signature acts on the skew-adjoint real form. -/
def realMatrixConjugation {J : Matrix n n ℂ} (hJJ : J * J = 1)
    (U : (Matrix n n ℂ)ˣ) (hU : (U : Matrix n n ℂ)ᴴ * J * U = J) :
    ↥(skewAdjoint J) →ₗ[ℝ] ↥(skewAdjoint J) :=
  (((matrixConjugation U).restrictScalars ℝ).comp (skewAdjoint J).subtype).codRestrict
    (skewAdjoint J) (fun X => (mem_fixed (realConjugation J) _).mpr (by
      change realConjugation J (matrixConjugation U X.val) = matrixConjugation U X.val
      rw [realConjugation_commutes hJJ U hU, (mem_fixed (realConjugation J) _).mp X.prop]))

/-- The matrix real-form identification intertwines conjugation after
scalar extension. -/
theorem complexification_intertwines {J : Matrix n n ℂ} (hJ : Jᴴ = J) (hJJ : J * J = 1)
    (U : (Matrix n n ℂ)ˣ) (hU : (U : Matrix n n ℂ)ᴴ * J * U = J) :
    (complexificationEquiv hJ hJJ).toLinearMap.comp ((realMatrixConjugation hJJ U hU).baseChange ℂ) =
      (matrixConjugation U).comp (complexificationEquiv hJ hJJ).toLinearMap := by
  apply TensorProduct.AlgebraTensorModule.ext
  intro a X
  simp only [LinearMap.comp_apply, LinearMap.baseChange_tmul, LinearEquiv.coe_coe,
    complexificationEquiv_tmul, map_smul]
  rfl

end

end GeometricUnity.D7UnitaryRealForm
