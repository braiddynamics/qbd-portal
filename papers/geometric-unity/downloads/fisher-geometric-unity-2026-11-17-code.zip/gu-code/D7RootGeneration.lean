import D7RootInterpolation
import Mathlib.Analysis.Complex.Polynomial.Basic

/-!
# Generation of the split special orthogonal action

Root operations change two null coordinates at a time. The elimination
uses these operations to restore the two columns of a hyperbolic pair
while keeping every previously restored pair fixed.
-/

namespace GeometricUnity.D7RootGeneration

open D7Exterior D7SpinNullFrame D7RootInterpolation
open scoped BigOperators

noncomputable section

private abbrev End := Module.End ℂ Space
private abbrev e := axisBasis
local notation "mate" => pairedAxis
local notation "B" => D7Hodge.splitMetric

private theorem basis_apply (a j : Axis) : e a j = if j = a then 1 else 0 := by
  simp only [axisBasis, Pi.basisFun_apply, Pi.single_apply]

private theorem basis_coord (a : Axis) (x : Space) : e.coord a x = x a := by
  simp [axisBasis, Module.Basis.coord_apply, Pi.basisFun_repr]

private theorem split_apply (x y : Space) :
    B x y = ∑ i : Pair, (x (plusAxis i) * y (minusAxis i) + x (minusAxis i) * y (plusAxis i)) :=
  D7Hodge.splitMetric_apply x y

private theorem metric_symm (x y : Space) : B x y = B y x := by
  rw [split_apply, split_apply]
  apply Finset.sum_congr rfl
  intro i _
  ring

private theorem plus_ne_minus (i j : Pair) : plusAxis i ≠ minusAxis j := by
  intro h
  have he := congrArg Fin.val h
  change 2 * i.val = 2 * j.val + 1 at he
  omega

private theorem plus_eq (i j : Pair) : plusAxis i = plusAxis j ↔ i = j := by
  constructor
  · intro h
    simpa only [pairIndex_plus] using congrArg pairIndex h
  · exact congrArg plusAxis

private theorem minus_eq (i j : Pair) : minusAxis i = minusAxis j ↔ i = j := by
  constructor
  · intro h
    simpa only [pairIndex_minus] using congrArg pairIndex h
  · exact congrArg minusAxis

@[simp] private theorem metric_basis (a : Axis) (x : Space) : B (e a) x = x (mate a) := by
  rcases null_axis_cases a with h | h
  · rw [h, pairedAxis_plus, split_apply]
    simp only [basis_apply, plus_eq, Ne.symm (plus_ne_minus _ _), if_false, zero_mul, add_zero,
      ite_mul, one_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  · rw [h, pairedAxis_minus, split_apply]
    simp only [basis_apply, minus_eq, plus_ne_minus, if_false, zero_mul, zero_add,
      ite_mul, one_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true]

@[simp] private theorem metric_basis_right (a : Axis) (x : Space) : B x (e a) = x (mate a) := by
  rw [metric_symm x, metric_basis]

private def root (a b : Axis) (t : ℂ) : End := rootGroup t a (mate b) b (mate a)

private theorem root_mem (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) :
    root a b t ∈ Submonoid.closure splitRootMaps :=
  Submonoid.subset_closure ⟨a, b, t, hab, rfl⟩

private theorem root_apply (a b : Axis) (t : ℂ) (x : Space) :
    root a b t x = x + (t * x (mate b)) • e a - (t * x (mate a)) • e b := by
  change x + t • (e.coord (mate b) x • e a) - t • (e.coord (mate a) x • e b) = _
  rw [basis_coord, basis_coord, smul_smul, smul_smul]

private theorem root_coord (a b : Axis) (t : ℂ) (x : Space) (j : Axis) :
    root a b t x j = x j + (if j = a then t * x (mate b) else 0) -
      (if j = b then t * x (mate a) else 0) := by
  rw [root_apply]
  simp only [Pi.sub_apply, Pi.add_apply, Pi.smul_apply, smul_eq_mul, basis_apply, mul_ite,
    mul_one, mul_zero]

private theorem axis_ne_of_pair_ne {a b : Axis} (h : pairIndex a ≠ pairIndex b) : a ≠ b :=
  fun he => h (congrArg pairIndex he)

private theorem root_mate_left (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) (x : Space) :
    root a b t x (mate a) = x (mate a) := by
  have hn : mate a ≠ b := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab)
  simp only [root_coord, if_neg (pairedAxis_ne a), if_neg hn, add_zero, sub_zero]

private theorem root_mate_right (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) (x : Space) :
    root a b t x (mate b) = x (mate b) := by
  have hn : mate b ≠ a := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab.symm)
  simp only [root_coord, if_neg (pairedAxis_ne b), if_neg hn, add_zero, sub_zero]

private theorem root_inv_mul (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) :
    root a b (-t) * root a b t = 1 := by
  apply LinearMap.ext
  intro x
  funext j
  change root a b (-t) (root a b t x) j = x j
  rw [root_coord, root_mate_left a b hab, root_mate_right a b hab, root_coord]
  have hn := axis_ne_of_pair_ne hab
  by_cases ha : j = a <;> by_cases hb : j = b <;> simp [ha, hb, hn, hn.symm]

private def rootUnit (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) : Endˣ :=
  ⟨root a b t, root a b (-t), by simpa only [neg_neg] using root_inv_mul a b hab (-t),
    root_inv_mul a b hab t⟩

private theorem root_preserves (a b : Axis) (hab : pairIndex a ≠ pairIndex b)
    (t : ℂ) (x y : Space) : B (root a b t x) (root a b t y) = B x y := by
  have hm : mate a ≠ b := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab)
  have hn : mate b ≠ a := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab.symm)
  simp only [root_apply, map_add, map_sub, map_smul, LinearMap.add_apply, LinearMap.sub_apply,
    LinearMap.smul_apply, metric_basis, metric_basis_right, basis_apply, if_neg (pairedAxis_ne a),
    if_neg (pairedAxis_ne b), if_neg hm, if_neg hn, smul_eq_mul]
  ring

private theorem root_det (a b : Axis) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) :
    (root a b t).det = 1 := by
  have hm : mate a ≠ b := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab)
  have hn : mate b ≠ a := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hab.symm)
  let T := LinearMap.transvection (e.coord (mate b)) (t • e a)
  let U := LinearMap.transvection (e.coord (mate a)) ((-t) • e b)
  have he : T * U = root a b t := by
    apply LinearMap.ext
    intro x
    funext j
    have hU : U x = x + e.coord (mate a) x • ((-t) • e b) := rfl
    change (T (U x)) j = root a b t x j
    change ((U x) + e.coord (mate b) (U x) • (t • e a)) j = _
    rw [hU, basis_coord, basis_coord, root_coord]
    simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, basis_apply, if_neg (pairedAxis_ne b),
      mul_zero, add_zero, mul_ite, mul_one]
    simp only [mul_comm (x (mate b)) t]
    by_cases hb : j = b
    · simp only [if_pos hb, mul_neg, sub_eq_add_neg, mul_comm (x (mate a)) t]
      abel
    · simp only [if_neg hb, add_zero, sub_zero]
  rw [← he, map_mul]
  simp [T, U, hm, hn]

private abbrev Words := Submonoid.closure splitRootMaps

private theorem words_special : Words ≤ splitSpecialOrthogonal := by
  apply Submonoid.closure_le.mpr
  rintro _ ⟨a, b, t, hab, rfl⟩
  refine ⟨root_det a b hab t, fun x y => ?_⟩
  exact (D7Hodge.splitMetric_apply _ _).symm.trans
    ((root_preserves a b hab t x y).trans (D7Hodge.splitMetric_apply _ _))

private def fixesOutside (S : Finset Pair) (f : End) : Prop :=
  ∀ a, pairIndex a ∉ S → f (e a) = e a

private def localWords (S : Finset Pair) : Subgroup Endˣ where
  carrier := {u | (u : End) ∈ Words ∧ (↑u⁻¹ : End) ∈ Words ∧ fixesOutside S u}
  one_mem' := ⟨Words.one_mem, by rw [inv_one]; exact Words.one_mem, fun _ _ => rfl⟩
  mul_mem' {u v} hu hv := by
    refine ⟨Words.mul_mem hu.1 hv.1, ?_, fun a ha => ?_⟩
    · rw [mul_inv_rev, Units.val_mul]
      exact Words.mul_mem hv.2.1 hu.2.1
    · change (u : End) ((v : End) (e a)) = e a
      rw [hv.2.2 a ha, hu.2.2 a ha]
  inv_mem' {u} hu := by
    refine ⟨hu.2.1, by rw [inv_inv]; exact hu.1, fun a ha => ?_⟩
    have h := congrArg (fun x => (↑u⁻¹ : End) x) (hu.2.2 a ha)
    change (↑u⁻¹ : End) ((u : End) (e a)) = _ at h
    change ((↑u⁻¹ : End) * (u : End)) (e a) = _ at h
    rw [u.inv_mul] at h
    exact h.symm

private theorem rootUnit_mem_local (S : Finset Pair) (a b : Axis)
    (ha : pairIndex a ∈ S) (hb : pairIndex b ∈ S) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) :
    rootUnit a b hab t ∈ localWords S := by
  refine ⟨root_mem a b hab t, root_mem a b hab (-t), fun j hj => ?_⟩
  change root a b t (e j) = e j
  have h₁ : mate a ≠ j := fun h => hj (by simpa only [← h, pairedAxis_pairIndex] using ha)
  have h₂ : mate b ≠ j := fun h => hj (by simpa only [← h, pairedAxis_pairIndex] using hb)
  simp only [root_apply, basis_apply, if_neg h₁, if_neg h₂, mul_zero, zero_smul, add_zero, sub_zero]

private theorem local_preserves {S : Finset Pair} (u : localWords S) (x y : Space) :
    B (u.val.val x) (u.val.val y) = B x y := by
  have hu := words_special u.prop.1
  exact (D7Hodge.splitMetric_apply _ _).trans (hu.2 x y |>.trans
    (D7Hodge.splitMetric_apply _ _).symm)

private abbrev act {S : Finset Pair} (u : localWords S) : End := u.val.val

private def localRoot {S : Finset Pair} (a b : Axis) (ha : pairIndex a ∈ S)
    (hb : pairIndex b ∈ S) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) : localWords S :=
  ⟨rootUnit a b hab t, rootUnit_mem_local S a b ha hb hab t⟩

private theorem act_root {S : Finset Pair} (a b : Axis) (ha : pairIndex a ∈ S)
    (hb : pairIndex b ∈ S) (hab : pairIndex a ≠ pairIndex b) (t : ℂ) :
    act (localRoot a b ha hb hab t) = root a b t := rfl

private theorem act_mul {S : Finset Pair} (u v : localWords S) (x : Space) :
    act (u * v) x = act u (act v x) := rfl

private def supported (S : Finset Pair) (x : Space) : Prop :=
  ∀ j, pairIndex j ∉ S → x j = 0

private theorem supported_map {S : Finset Pair} {f : End}
    (hf : ∀ x y, B (f x) (f y) = B x y) (hfix : fixesOutside S f)
    {x : Space} (hx : supported S x) : supported S (f x) := by
  intro j hj
  have h := hf (e (mate j)) x
  rw [hfix (mate j) (by simpa only [pairedAxis_pairIndex] using hj),
    metric_basis, metric_basis, pairedAxis_pairedAxis, hx j hj] at h
  exact h

private theorem local_supported {S : Finset Pair} (u : localWords S)
    {x : Space} (hx : supported S x) : supported S (act u x) :=
  supported_map (local_preserves u) u.prop.2.2 hx

private theorem basis_supported {S : Finset Pair} {a : Axis} (ha : pairIndex a ∈ S) :
    supported S (e a) := by
  intro j hj
  rw [basis_apply, if_neg]
  exact fun he => hj (he ▸ ha)

private theorem axis_cases {p j : Axis} (h : pairIndex j = pairIndex p) :
    j = p ∨ j = mate p := by
  rcases null_axis_cases p with hp | hp <;> rcases null_axis_cases j with hj | hj
  · left
    rw [hj, h, ← hp]
  · right
    rw [hj, h, hp, pairedAxis_plus, pairIndex_plus]
  · right
    rw [hj, h, hp, pairedAxis_minus, pairIndex_minus]
  · left
    rw [hj, h, ← hp]

private theorem eq_two_axes {x : Space} (p : Axis)
    (h : ∀ j, pairIndex j ≠ pairIndex p → x j = 0) :
    x = x p • e p + x (mate p) • e (mate p) := by
  funext j
  by_cases hj : pairIndex j = pairIndex p
  · rcases axis_cases hj with h | h
    · simp [h, basis_apply, (pairedAxis_ne p).symm]
    · simp [h, basis_apply, pairedAxis_ne p]
  · rw [h j hj]
    have hp := axis_ne_of_pair_ne hj
    have hm : j ≠ mate p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using hj)
    simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul, basis_apply, if_neg hp, if_neg hm,
      mul_zero, add_zero]

private theorem metric_two_axes (p : Axis) (a b c d : ℂ) :
    B (a • e p + b • e (mate p)) (c • e p + d • e (mate p)) = a * d + b * c := by
  simp [basis_apply, pairedAxis_ne p, (pairedAxis_ne p).symm]
private theorem isotropic_axis {x : Space} {p : Axis} (hx : B x x = 0) (hp : x p ≠ 0)
    (hzero : ∀ j, pairIndex j ≠ pairIndex p → x j = 0) : x = x p • e p := by
  have h := eq_two_axes p hzero
  have hh : B (x p • e p + x (mate p) • e (mate p))
      (x p • e p + x (mate p) • e (mate p)) = 0 := by rw [← h, hx]
  rw [metric_two_axes] at hh
  have hz : (2 : ℂ) * x p * x (mate p) = 0 := by linear_combination hh
  exact h.trans (by simp [(mul_eq_zero.mp hz).resolve_left (mul_ne_zero (by norm_num) hp)])

private theorem clear_coordinates {S : Finset Pair} {d : Axis} (hd : pairIndex d ∈ S)
    (x : Space) (hx : x d ≠ 0) (T : Finset Axis)
    (hT : ∀ q ∈ T, pairIndex q ∈ S ∧ pairIndex q ≠ pairIndex d) :
    ∃ u : localWords S, act u x d = x d ∧ act u (e (mate d)) = e (mate d) ∧
      ∀ q ∈ T, act u x q = 0 := by
  induction T using Finset.induction_on with
  | empty => exact ⟨1, rfl, rfl, by simp⟩
  | @insert q T hq ih =>
    have h := hT q (Finset.mem_insert_self q T)
    obtain ⟨u, hu, hfix, hz⟩ := ih (fun j hj => hT j (Finset.mem_insert_of_mem hj))
    let t := -(act u x q) / act u x d
    let v := localRoot q (mate d) h.1 (by simpa only [pairedAxis_pairIndex] using hd)
      (by simpa only [pairedAxis_pairIndex] using h.2) t
    have hv : act v = root q (mate d) t := rfl
    have hm : mate d ≠ q :=
      axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.2.symm)
    refine ⟨v * u, ?_, ?_, ?_⟩
    · rw [act_mul, hv, root_coord, if_neg (axis_ne_of_pair_ne h.2.symm),
        if_neg (pairedAxis_ne d).symm, add_zero, sub_zero, hu]
    · rw [act_mul, hfix, hv, root_apply, pairedAxis_pairedAxis]
      have hmq : mate q ≠ mate d := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.2)
      simp only [basis_apply, if_neg (Ne.symm (pairedAxis_ne d)), if_neg hmq, mul_zero,
        zero_smul, add_zero, sub_zero]
    · intro j hj
      rw [act_mul, hv, root_coord]
      rcases Finset.mem_insert.mp hj with rfl | hj
      · simp [hm.symm, t, hu, hx]
      · have hjq : j ≠ q := fun he => hq (he ▸ hj)
        have hjm : j ≠ mate d := axis_ne_of_pair_ne (by
          simpa only [pairedAxis_pairIndex] using (hT j (Finset.mem_insert_of_mem hj)).2)
        simp only [if_neg hjq, if_neg hjm, add_zero, sub_zero, hz j hj]

private theorem clear_pair_complement {S : Finset Pair} {d : Axis} (hd : pairIndex d ∈ S)
    {x : Space} (hs : supported S x) (hi : B x x = 0) (hx : x d ≠ 0) :
    ∃ u : localWords S, act u x = x d • e d ∧ act u (e (mate d)) = e (mate d) := by
  let T := Finset.univ.filter fun q : Axis => pairIndex q ∈ S ∧ pairIndex q ≠ pairIndex d
  obtain ⟨u, hd', hf, hz⟩ := clear_coordinates hd x hx T (fun q hq => (Finset.mem_filter.mp hq).2)
  refine ⟨u, ?_, hf⟩
  rw [← hd']
  apply isotropic_axis (p := d) ((local_preserves u x x).trans hi) (fun h => hx (hd'.symm.trans h))
  intro j hj
  by_cases h : pairIndex j ∈ S
  · exact hz j (Finset.mem_filter.mpr ⟨Finset.mem_univ j, h, hj⟩)
  · exact local_supported u hs j h

private theorem obtain_pivot {S : Finset Pair} {p r : Axis}
    (hp : pairIndex p ∈ S) (hr : pairIndex r ∈ S) (hpr : pairIndex p ≠ pairIndex r)
    {x : Space} (hs : supported S x) (hx : x ≠ 0) :
    ∃ u : localWords S, act u x p ≠ 0 := by
  by_cases hxp : x p = 0
  · have use_other : ∀ y : Space, ∀ q : Axis, pairIndex q ∈ S → pairIndex p ≠ pairIndex q →
        y p = 0 → y q ≠ 0 → ∃ u : localWords S, act u y p ≠ 0 := by
      intro y q hq hpq hy hyq
      have hm : pairIndex (mate q) ∈ S := by rwa [pairedAxis_pairIndex]
      have hpm : pairIndex p ≠ pairIndex (mate q) := by rwa [pairedAxis_pairIndex]
      refine ⟨localRoot p (mate q) hp hm hpm 1, ?_⟩
      simp [act_root, root_coord, axis_ne_of_pair_ne hpm, hy, hyq]
    by_cases h : ∃ q, pairIndex p ≠ pairIndex q ∧ x q ≠ 0
    · obtain ⟨q, hpq, hq⟩ := h
      exact use_other x q (by by_contra hn; exact hq (hs q hn)) hpq hxp hq
    · have hz : ∀ q, pairIndex p ≠ pairIndex q → x q = 0 := by
        intro q hpq
        by_contra hn
        exact h ⟨q, hpq, hn⟩
      have hxm : x (mate p) ≠ 0 := by
        intro he
        apply hx
        rw [eq_two_axes p (fun j hj => hz j hj.symm), hxp, he, zero_smul, zero_smul, add_zero]
      let v := localRoot r p hr hp hpr.symm 1
      have hvr : act v x r = x (mate p) := by
        change root r p 1 x r = _
        simp [root_coord, axis_ne_of_pair_ne hpr.symm, hz r hpr]
      have hvp : act v x p = 0 := by
        change root r p 1 x p = _
        have hrm : pairIndex p ≠ pairIndex (mate r) := by rwa [pairedAxis_pairIndex]
        simp [root_coord, axis_ne_of_pair_ne hpr, hxp, hz (mate r) hrm]
      obtain ⟨u, hu⟩ := use_other (act v x) r hr hpr hvp (by rwa [hvr])
      exact ⟨u * v, hu⟩
  · exact ⟨1, hxp⟩

private theorem normalize_pivot {S : Finset Pair} {p r : Axis}
    (hp : pairIndex p ∈ S) (hr : pairIndex r ∈ S) (hpr : pairIndex p ≠ pairIndex r)
    {c : ℂ} (hc : c ≠ 0) : ∃ u : localWords S, act u (c • e p) = e p := by
  have hpm : pairIndex (mate p) ∈ S := by rwa [pairedAxis_pairIndex]
  have hrm : pairIndex (mate r) ∈ S := by rwa [pairedAxis_pairIndex]
  have h₁ : pairIndex r ≠ pairIndex (mate p) := by
    simpa only [pairedAxis_pairIndex] using hpr.symm
  have h₂ : pairIndex p ≠ pairIndex (mate r) := by rwa [pairedAxis_pairIndex]
  have hne := axis_ne_of_pair_ne hpr
  let u := localRoot r (mate p) hr hpm h₁ c⁻¹
  let v := localRoot p (mate r) hp hrm h₂ (1 - c)
  let w := localRoot r (mate p) hr hpm h₁ (-1)
  have hu : act u (c • e p) = c • e p + e r := by
    change root r (mate p) c⁻¹ (c • e p) = _
    simp [root_apply, basis_apply, (axis_ne_of_pair_ne h₂).symm, hc]
  have hv : act v (c • e p + e r) = e p + e r := by
    change root p (mate r) (1 - c) (c • e p + e r) = _
    simp [root_apply, basis_apply, hne.symm, pairedAxis_ne p, (axis_ne_of_pair_ne h₁).symm]
    rw [add_right_comm, ← add_smul, add_sub_cancel, one_smul]
  have hw : act w (e p + e r) = e p := by
    change root r (mate p) (-1) (e p + e r) = _
    simp [root_apply, basis_apply, hne, pairedAxis_ne r, (axis_ne_of_pair_ne h₂).symm]
  exact ⟨w * (v * u), by rw [act_mul, act_mul, hu, hv, hw]⟩

private theorem restore_pair {S : Finset Pair} {f : End} (hf : f ∈ splitSpecialOrthogonal)
    (hfix : fixesOutside S f) {p r : Axis}
    (hp : pairIndex p ∈ S) (hr : pairIndex r ∈ S) (hpr : pairIndex p ≠ pairIndex r) :
    ∃ u : localWords S, act u (f (e p)) = e p ∧ act u (f (e (mate p))) = e (mate p) := by
  have hB : ∀ x y, B (f x) (f y) = B x y := fun x y =>
    (D7Hodge.splitMetric_apply _ _).trans ((hf.2 x y).trans (D7Hodge.splitMetric_apply _ _).symm)
  have hpm : pairIndex (mate p) ∈ S := by rwa [pairedAxis_pairIndex]
  have hbp : B (e p) (e p) = 0 := by rw [metric_basis, basis_apply, if_neg (pairedAxis_ne p)]
  have hbm : B (e (mate p)) (e (mate p)) = 0 := by
    rw [metric_basis, basis_apply, pairedAxis_pairedAxis, if_neg (pairedAxis_ne p).symm]
  have hb : B (e p) (e (mate p)) = 1 := by rw [metric_basis, basis_apply, if_pos rfl]
  have hx : f (e p) ≠ 0 := by
    intro h
    have he := (hB (e p) (e (mate p))).trans hb
    simp only [h, map_zero, LinearMap.zero_apply, zero_ne_one] at he
  have hs := supported_map hB hfix (basis_supported hp)
  obtain ⟨u, hu⟩ := obtain_pivot hp hr hpr hs hx
  obtain ⟨v, hv, _⟩ := clear_pair_complement hp (local_supported u hs)
    ((local_preserves u _ _).trans ((hB _ _).trans hbp)) hu
  obtain ⟨w, hw⟩ := normalize_pivot hp hr hpr hu
  let g := w * (v * u)
  have hg : act g (f (e p)) = e p := by
    change act (w * (v * u)) (f (e p)) = _
    rw [act_mul, act_mul, hv, hw]
  let y := act g (f (e (mate p)))
  have hsy : supported S y := local_supported g (supported_map hB hfix (basis_supported hpm))
  have hy : B y y = 0 := (local_preserves g _ _).trans ((hB _ _).trans hbm)
  have hym : y (mate p) = 1 := by
    rw [← metric_basis p y, ← hg]
    exact (local_preserves g _ _).trans ((hB _ _).trans hb)
  obtain ⟨z, hz, hzp⟩ := clear_pair_complement hpm hsy hy (by rw [hym]; exact one_ne_zero)
  exact ⟨z * g, by rw [act_mul, hg]; simpa only [pairedAxis_pairedAxis] using hzp,
    by rw [act_mul]; change act z y = _; rw [hz, hym, one_smul]⟩

/-! Products of three roots exchange two disjoint null axes. Composing with
the exchange at parameter `-1` gives a diagonal map on the two pairs. -/

private def exchange (p r : Axis) (t : ℂ) : End :=
  root p (mate r) t * root r (mate p) (-t⁻¹) * root p (mate r) t

private theorem exchange_mem (p r : Axis) (h : pairIndex p ≠ pairIndex r) (t : ℂ) :
    exchange p r t ∈ Words :=
  Words.mul_mem (Words.mul_mem (root_mem _ _ (by simpa only [pairedAxis_pairIndex] using h) _)
    (root_mem _ _ (by simpa only [pairedAxis_pairIndex] using h.symm) _))
    (root_mem _ _ (by simpa only [pairedAxis_pairIndex] using h) _)

private theorem exchange_coord {p r : Axis} (h : pairIndex p ≠ pairIndex r)
    {t : ℂ} (ht : t ≠ 0) (x : Space) (j : Axis) :
    exchange p r t x j =
      if j = p then t * x r else
      if j = r then -t⁻¹ * x p else
      if j = mate p then t⁻¹ * x (mate r) else
      if j = mate r then -t * x (mate p) else x j := by
  change root p (mate r) t (root r (mate p) (-t⁻¹) (root p (mate r) t x)) j = _
  have hpr := axis_ne_of_pair_ne h
  have hpmr : p ≠ mate r := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h)
  have hmpr : mate p ≠ r := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h)
  have hm : mate p ≠ mate r := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h)
  have h₁ := hpr.symm
  have h₂ := hpmr.symm
  have h₃ := hmpr.symm
  have h₄ := hm.symm
  have h₅ := pairedAxis_ne p
  have h₆ := pairedAxis_ne r
  have h₇ := h₅.symm
  have h₈ := h₆.symm
  rcases eq_or_ne j p with rfl | hp
  · simp_all [root_coord]
    field_simp
    ring
  rcases eq_or_ne j r with rfl | hr
  · simp_all [root_coord]
    field_simp
    ring
  rcases eq_or_ne j (mate p) with rfl | hp'
  · simp_all [root_coord]
    field_simp
    ring
  rcases eq_or_ne j (mate r) with rfl | hr'
  · simp_all [root_coord]
    field_simp
    ring
  · simp_all [root_coord]

private def diagonal (p r : Axis) (t : ℂ) : End :=
  exchange p r t * exchange p r (-1)

private theorem diagonal_mem (p r : Axis) (h : pairIndex p ≠ pairIndex r) (t : ℂ) :
    diagonal p r t ∈ Words :=
  Words.mul_mem (exchange_mem p r h t) (exchange_mem p r h (-1))

private theorem diagonal_coord {p r : Axis} (h : pairIndex p ≠ pairIndex r)
    {t : ℂ} (ht : t ≠ 0) (x : Space) (j : Axis) :
    diagonal p r t x j =
      (if j = p then t else
      if j = r then t⁻¹ else
      if j = mate p then t⁻¹ else
      if j = mate r then t else 1) * x j := by
  change exchange p r t (exchange p r (-1) x) j = _
  have hpr := axis_ne_of_pair_ne h
  have hrmp : r ≠ mate p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.symm)
  have hmrp : mate r ≠ p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.symm)
  have hm : mate r ≠ mate p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.symm)
  simp only [exchange_coord h ht, exchange_coord h (neg_ne_zero.mpr one_ne_zero)]
  by_cases hp : j = p
  · simp [hp, hpr.symm]
  by_cases hr : j = r
  · simp [hr, hpr.symm]
  by_cases hp' : j = mate p
  · simp [hp', hmrp, hm, pairedAxis_ne r, pairedAxis_ne p, hrmp.symm]
  by_cases hr' : j = mate r
  · simp [hr', pairedAxis_ne p, hrmp.symm, hmrp, hm, pairedAxis_ne r]
  · simp [hp, hr, hp', hr']

private def singleTorus (i : Pair) (c : ℂˣ) : End :=
  torus fun j => if j = i then c else 1

private theorem singleTorus_coord (i : Pair) (c : ℂˣ) (x : Space) (j : Axis) :
    singleTorus i c x j =
      (if j = plusAxis i then (c : ℂ) else if j = minusAxis i then (c : ℂ)⁻¹ else 1) * x j := by
  change ((scale (fun k => if k = i then c else 1) j : ℂˣ) : ℂ) * x j = _
  by_cases hj : pairIndex j = i
  · have h : pairIndex j = pairIndex (plusAxis i) := hj.trans (pairIndex_plus i).symm
    rcases axis_cases h with rfl | h'
    · have hs : axisSign (plusAxis i) = 1 := by
        unfold axisSign
        change (if 2 * i.val % 2 = 0 then (1 : ℤ) else -1) = 1
        rw [if_pos (by omega)]
      simp [scale, pairIndex_plus, hs]
    · rw [h', pairedAxis_plus]
      have hs : axisSign (minusAxis i) = -1 := by
        unfold axisSign
        change (if (2 * i.val + 1) % 2 = 0 then (1 : ℤ) else -1) = -1
        rw [if_neg (by omega)]
      simp [scale, pairIndex_minus, hs, (plus_ne_minus i i).symm]
  · simp [scale, hj,
      show j ≠ plusAxis i from fun h => hj (by rw [h, pairIndex_plus]),
      show j ≠ minusAxis i from fun h => hj (by rw [h, pairIndex_minus])]

private theorem diagonal_cancel_aux {p r : Axis} (h : pairIndex p ≠ pairIndex r)
    {a : ℂ} (ha : a ≠ 0) (x : Space) (j : Axis) :
    diagonal p r a (diagonal p (mate r) a x) j =
      (if j = p then a * a else if j = mate p then a⁻¹ * a⁻¹ else 1) * x j := by
  have h' : pairIndex p ≠ pairIndex (mate r) := by rwa [pairedAxis_pairIndex]
  rw [diagonal_coord h ha, diagonal_coord h' ha, pairedAxis_pairedAxis]
  have hpr := (axis_ne_of_pair_ne h).symm
  have hpmr := (axis_ne_of_pair_ne h').symm
  have hrmp : r ≠ mate p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.symm)
  have hm : mate r ≠ mate p := axis_ne_of_pair_ne (by simpa only [pairedAxis_pairIndex] using h.symm)
  by_cases hp : j = p
  · simp [hp, mul_assoc]
  by_cases hp' : j = mate p
  · simp [hp', pairedAxis_ne p, hrmp.symm, hm.symm, mul_assoc]
  by_cases hr : j = r
  · simp [hr, hpr, hrmp, (pairedAxis_ne r).symm, ha]
  by_cases hr' : j = mate r
  · simp [hr', hpmr, hm, pairedAxis_ne r, ha]
  · simp [hp, hp', hr, hr']

private theorem singleTorus_mem (i : Pair) (c : ℂˣ) : singleTorus i c ∈ Words := by
  obtain ⟨a, ha⟩ := IsAlgClosed.exists_pow_nat_eq (c : ℂ) (by decide : 0 < 2)
  rw [pow_two] at ha
  have han : a ≠ 0 := fun h => Units.ne_zero c (ha ▸ (h ▸ mul_zero (0 : ℂ)))
  have hai : a⁻¹ * a⁻¹ = (c : ℂ)⁻¹ := by rw [← ha, mul_inv_rev]
  obtain ⟨k, hk⟩ := exists_ne i
  have h : pairIndex (plusAxis i) ≠ pairIndex (plusAxis k) := by
    simpa only [pairIndex_plus] using hk.symm
  have h' : pairIndex (plusAxis i) ≠ pairIndex (mate (plusAxis k)) := by
    rwa [pairedAxis_pairIndex]
  have he : diagonal (plusAxis i) (plusAxis k) a *
      diagonal (plusAxis i) (mate (plusAxis k)) a = singleTorus i c := by
    apply LinearMap.ext
    intro x
    funext j
    rw [Module.End.mul_apply, diagonal_cancel_aux h han, singleTorus_coord,
      pairedAxis_plus, ha, hai]
  rw [← he]
  exact Words.mul_mem (diagonal_mem _ _ h a) (diagonal_mem _ _ h' a)

private theorem singleTorus_basis (i : Pair) (c : ℂˣ) (j : Axis) :
    singleTorus i c (e j) =
      (if j = plusAxis i then (c : ℂ) else if j = minusAxis i then (c : ℂ)⁻¹ else 1) • e j := by
  funext k
  rw [singleTorus_coord]
  by_cases h : k = j <;> simp [h, basis_apply]

private def swapAxes (p r : Axis) : End :=
  LinearMap.transvection (e.coord p - e.coord r) (e r - e p)

private theorem swap_det {p r : Axis} (h : p ≠ r) : (swapAxes p r).det = -1 := by
  rw [swapAxes, LinearMap.transvection.det]
  simp [h, h.symm]

private theorem swap_basis (p r j : Axis) (h : p ≠ r) :
    swapAxes p r (e j) = if j = p then e r else if j = r then e p else e j := by
  rw [swapAxes, LinearMap.transvection.apply]
  rcases eq_or_ne j p with rfl | hp
  · simp [h.symm]
  rcases eq_or_ne j r with rfl | hr
  · simp [hp, h]
  · simp [hp, hp.symm, hr, hr.symm]

private theorem singleton_generation (i : Pair) {f : End} (hf : f ∈ splitSpecialOrthogonal)
    (hfix : fixesOutside {i} f) : f ∈ Words := by
  let p := plusAxis i
  let q := mate p
  have hpi : pairIndex p = i := pairIndex_plus i
  have hqi : pairIndex q = i := (pairedAxis_pairIndex p).trans hpi
  have hpq : p ≠ q := (pairedAxis_ne p).symm
  have hq' : q = minusAxis i := pairedAxis_plus i
  have hB : ∀ x y, B (f x) (f y) = B x y := fun x y =>
    (D7Hodge.splitMetric_apply _ _).trans ((hf.2 x y).trans (D7Hodge.splitMetric_apply _ _).symm)
  let a := f (e p) p
  let b := f (e p) q
  let c := f (e q) p
  let d := f (e q) q
  have hs : ∀ k, pairIndex k = i → ∀ j, pairIndex j ≠ i → f (e k) j = 0 := by
    intro k hk j hj
    exact supported_map hB hfix (basis_supported (by simp [hk])) j (by simpa using hj)
  have hp : f (e p) = a • e p + b • e q :=
    eq_two_axes p (fun j hj => hs p hpi j (by simpa only [hpi] using hj))
  have hq : f (e q) = c • e p + d • e q :=
    eq_two_axes p (fun j hj => hs q hqi j (by simpa only [hpi] using hj))
  have hpp : B (e p) (e p) = 0 := by simp [basis_apply, pairedAxis_ne p]
  have hqq : B (e q) (e q) = 0 := by simp [basis_apply, q, hpq]
  have hpq' : B (e p) (e q) = 1 := by simp [basis_apply, q]
  have hab : a * b = 0 := by
    have h := (hB (e p) (e p)).trans hpp
    rw [hp, metric_two_axes] at h
    linear_combination h / 2
  have hcd : c * d = 0 := by
    have h := (hB (e q) (e q)).trans hqq
    rw [hq, metric_two_axes] at h
    linear_combination h / 2
  have hadbc : a * d + b * c = 1 := by
    have h := (hB (e p) (e q)).trans hpq'
    rwa [hp, hq, metric_two_axes] at h
  by_cases ha : a = 0
  · have hbc : b * c = 1 := by simpa [ha] using hadbc
    have hb : b ≠ 0 := left_ne_zero_of_mul_eq_one hbc
    have hc : c ≠ 0 := right_ne_zero_of_mul_eq_one hbc
    have hd : d = 0 := (mul_eq_zero.mp hcd).resolve_left hc
    have hcb : c = b⁻¹ := eq_inv_of_mul_eq_one_right hbc
    let u := Units.mk0 b hb
    have he : f = swapAxes p q * singleTorus i u := by
      apply e.ext
      intro j
      change f (e j) = swapAxes p q (singleTorus i u (e j))
      rw [singleTorus_basis, map_smul, swap_basis p q j hpq, ← hq']
      rcases eq_or_ne j p with rfl | hjp
      · simp [hp, ha, p, u]
      rcases eq_or_ne j q with rfl | hjq
      · simp [hq, hd, hcb, hjp, show q ≠ plusAxis i from hpq.symm, u]
      · have hj : pairIndex j ∉ ({i} : Finset Pair) := by
          intro hm
          have hm' : pairIndex j = pairIndex p := (Finset.mem_singleton.mp hm).trans hpi.symm
          exact (axis_cases hm').elim hjp hjq
        rw [hfix j hj]
        simp [show j ≠ plusAxis i from hjp, hjq, hjp]
    have hdet : f.det = 1 := hf.1
    rw [he, map_mul, swap_det hpq, singleTorus, torus_det, mul_one] at hdet
    norm_num at hdet
  · have hb : b = 0 := (mul_eq_zero.mp hab).resolve_left ha
    have had : a * d = 1 := by simpa [hb] using hadbc
    have hd : d ≠ 0 := right_ne_zero_of_mul_eq_one had
    have hc : c = 0 := (mul_eq_zero.mp hcd).resolve_right hd
    have hda : d = a⁻¹ := eq_inv_of_mul_eq_one_right had
    let u := Units.mk0 a ha
    have he : f = singleTorus i u := by
      apply e.ext
      intro j
      rw [singleTorus_basis, ← hq']
      rcases eq_or_ne j p with rfl | hjp
      · simp [hp, hb, p, u]
      rcases eq_or_ne j q with rfl | hjq
      · simp [hq, hc, hda, show q ≠ plusAxis i from hpq.symm, u]
      · have hj : pairIndex j ∉ ({i} : Finset Pair) := by
          intro hm
          have hm' : pairIndex j = pairIndex p := (Finset.mem_singleton.mp hm).trans hpi.symm
          exact (axis_cases hm').elim hjp hjq
        rw [hfix j hj]
        simp [show j ≠ plusAxis i from hjp, hjq]
    rw [he]
    exact singleTorus_mem i u

private theorem generation_supported (S : Finset Pair) (f : End)
    (hf : f ∈ splitSpecialOrthogonal) (hfix : fixesOutside S f) : f ∈ Words := by
  induction S using Finset.induction_on generalizing f with
  | empty =>
    have he : f = 1 := e.ext fun j => hfix j (Finset.notMem_empty _)
    rw [he]
    exact Words.one_mem
  | @insert i T hi ih =>
    by_cases hT : T.Nonempty
    · obtain ⟨k, hk⟩ := hT
      have hik : i ≠ k := fun h => hi (h ▸ hk)
      let p := plusAxis i
      let r := plusAxis k
      have hpi : pairIndex p = i := pairIndex_plus i
      have hri : pairIndex r = k := pairIndex_plus k
      obtain ⟨u, hp, hm⟩ := restore_pair hf hfix (p := p) (r := r)
        (hpi ▸ Finset.mem_insert_self i T) (hri ▸ Finset.mem_insert_of_mem hk)
        (by simpa only [hpi, hri] using hik)
      let g := act u * f
      have hg : g ∈ splitSpecialOrthogonal := splitSpecialOrthogonal.mul_mem (words_special u.prop.1) hf
      have hgf : fixesOutside T g := by
        intro j hj
        change act u (f (e j)) = e j
        by_cases hji : pairIndex j = i
        · rcases axis_cases (hji.trans hpi.symm) with he | he
          · rwa [he]
          · rwa [he]
        · have hnt : pairIndex j ∉ insert i T := by simp [hji, hj]
          rw [hfix j hnt]
          exact u.prop.2.2 j hnt
      have hmem := ih g hg hgf
      have he : (↑u.val⁻¹ : End) * g = f := by
        change (↑u.val⁻¹ : End) * ((u.val : End) * f) = f
        rw [← mul_assoc, u.val.inv_mul, one_mul]
      rw [← he]
      exact Words.mul_mem u.prop.2.1 hmem
    · rw [Finset.not_nonempty_iff_eq_empty.mp hT] at hfix
      exact singleton_generation i hf hfix

/-- The complex determinant-one split orthogonal group is generated by the
complex split root maps. -/
theorem splitSpecialOrthogonal_eq_rootClosure :
    splitSpecialOrthogonal = Submonoid.closure splitRootMaps :=
  le_antisymm (fun f hf => generation_supported Finset.univ f hf (by simp [fixesOutside]))
    words_special

/-- The action of every complex split special orthogonal transformation on a
pair of exterior tensors belongs to the complex linear span of real spin actions. -/
theorem splitSO_tensorActions_mem_spin_span (k l m n : ℕ) (f : splitSpecialOrthogonal) :
    (exteriorTensorMap k l f.val, exteriorTensorMap m n f.val) ∈
      Submodule.span ℂ (Set.range fun g : D7SpinAction.Spin =>
        (exteriorTensorMap k l (complexNullAction g),
          exteriorTensorMap m n (complexNullAction g))) :=
  rootClosure_tensorActions_mem_spin_span k l m n
    (splitSpecialOrthogonal_eq_rootClosure ▸ f.prop)

end

end GeometricUnity.D7RootGeneration
