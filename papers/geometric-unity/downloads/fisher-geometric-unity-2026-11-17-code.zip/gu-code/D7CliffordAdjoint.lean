import D7CliffordMatrix
import D7UnitaryRealForm
import Mathlib.Analysis.Matrix.Spectrum

/-!
# Transpose on the split Clifford matrix generators

In the exterior basis, creation inserts an index with its exterior sign.
Contraction removes the same index with the same sign. Consequently
transpose fixes the positive Clifford generators and negates the negative
ones.
-/

namespace GeometricUnity.D7CliffordAdjoint

open D7CliffordMatrix
open WitnessW1 (Index Cl splitForm gamma metricSign)
open scoped BigOperators Matrix TensorProduct

noncomputable section

private abbrev basisVector := Pi.basisFun ℝ (Fin 7)
private abbrev creator (i : Fin 7) := creation (basisVector i)
private abbrev annihilator (i : Fin 7) := contraction (basisVector.coord i)

private def singletonIndex (i : Fin 7) : Set.powersetCard (Fin 7) 1 :=
  Set.powersetCard.ofCard (by simp : ({i} : SpinorIndex).card = 1)

private theorem basis_singleton (i : Fin 7) :
    spinorBasis {i} = ExteriorAlgebra.ι ℝ (basisVector i) := by
  let s := singletonIndex i
  change basisVector.ExteriorAlgebra s.val = _
  rw [ExteriorAlgebra.basis_apply_powersetCard]
  let order := s.val.orderIsoOfFin s.prop
  have h : (order 0).val = i := Finset.mem_singleton.mp (order 0).prop
  change ExteriorAlgebra.ιMulti ℝ 1 (fun k => basisVector (order k).val) = _
  rw [ExteriorAlgebra.ιMulti_apply, List.ofFn_succ, List.ofFn_zero, List.prod_cons, List.prod_nil,
    mul_one, h]

private theorem creator_zero (i : Fin 7) (S : SpinorIndex) (hi : i ∈ S) :
    creator i (spinorBasis S) = 0 := by
  change ExteriorAlgebra.ι ℝ (basisVector i) * spinorBasis S = 0
  rw [← basis_singleton]
  let s := singletonIndex i
  let t := Set.powersetCard.ofCard (rfl : S.card = S.card)
  have hn : ¬ Disjoint s.val t.val := fun h => Finset.disjoint_left.mp h (by simp [s, singletonIndex]) hi
  exact ExteriorAlgebra.basis_mul_of_not_disjoint basisVector s t hn

private theorem creator_insert (i : Fin 7) (S : SpinorIndex) (hi : i ∉ S) :
    ∃ c : ℝ, (c = 1 ∨ c = -1) ∧ creator i (spinorBasis S) = c • spinorBasis (insert i S) := by
  change ∃ c : ℝ, _ ∧ ExteriorAlgebra.ι ℝ (basisVector i) * spinorBasis S = _
  rw [← basis_singleton]
  let s := singletonIndex i
  let t := Set.powersetCard.ofCard (rfl : S.card = S.card)
  have hd : Disjoint s.val t.val := Finset.disjoint_singleton_left.mpr hi
  have h := ExteriorAlgebra.basis_mul_of_disjoint basisVector s t hd
  have he : (Set.powersetCard.disjUnion hd).val = insert i S := by
    rw [Set.powersetCard.coe_disjUnion, Finset.disjUnion_eq_union]
    exact Finset.singleton_union _ _
  rw [he] at h
  change spinorBasis {i} * spinorBasis S =
    (Set.powersetCard.permOfDisjoint hd).sign • spinorBasis (insert i S) at h
  rcases Int.units_eq_one_or (Set.powersetCard.permOfDisjoint hd).sign with hp | hp
  · exact ⟨1, Or.inl rfl, by simpa only [hp, one_smul] using h⟩
  · refine ⟨-1, Or.inr rfl, ?_⟩
    rw [hp] at h
    change spinorBasis {i} * spinorBasis S = (-1 : ℤ) • spinorBasis (insert i S) at h
    simpa only [neg_one_smul, neg_one_zsmul] using h

private theorem annihilator_zero (i : Fin 7) (S : SpinorIndex) (hi : i ∉ S) :
    annihilator i (spinorBasis S) = 0 := by
  have hproduct (L : List (Fin 7)) (hL : i ∉ L) :
      annihilator i ((L.map fun j => ExteriorAlgebra.ι ℝ (basisVector j)).prod) = 0 := by
    induction L with
    | nil =>
      exact CliffordAlgebra.contractLeft_one (Q := (0 : QuadraticForm ℝ Half)) (basisVector.coord i)
    | cons j L ih =>
      have hij : i ≠ j := fun hij => hL (List.mem_cons.mpr (Or.inl hij))
      have hnot : i ∉ L := fun hm => hL (List.mem_cons.mpr (Or.inr hm))
      have hcoord : basisVector.coord i (basisVector j) = 0 := by
        simp [Module.Basis.coord_apply, hij]
      rw [List.map_cons, List.prod_cons]
      change CliffordAlgebra.contractLeft (Q := (0 : QuadraticForm ℝ Half)) (basisVector.coord i)
        (CliffordAlgebra.ι 0 (basisVector j) *
          (L.map fun k => ExteriorAlgebra.ι ℝ (basisVector k)).prod) = 0
      rw [CliffordAlgebra.contractLeft_ι_mul, hcoord, zero_smul]
      change 0 - ExteriorAlgebra.ι ℝ (basisVector j) *
        annihilator i ((L.map fun k => ExteriorAlgebra.ι ℝ (basisVector k)).prod) = 0
      rw [ih hnot, mul_zero, sub_zero]
  let s := Set.powersetCard.ofCard (rfl : S.card = S.card)
  let order := s.val.orderIsoOfFin s.prop
  let L := List.ofFn (fun j => (order j).val)
  have hL : i ∉ L := by
    intro h
    obtain ⟨j, hj⟩ := List.mem_ofFn.mp h
    exact hi (hj ▸ (order j).prop)
  change annihilator i (basisVector.ExteriorAlgebra s.val) = 0
  rw [ExteriorAlgebra.basis_apply_powersetCard]
  change annihilator i (ExteriorAlgebra.ιMulti ℝ S.card (fun j => basisVector (order j).val)) = 0
  rw [ExteriorAlgebra.ιMulti_apply]
  have h := hproduct L hL
  rw [show L.map (fun j => ExteriorAlgebra.ι ℝ (basisVector j)) =
    List.ofFn (fun j => ExteriorAlgebra.ι ℝ (basisVector (order j).val)) from List.map_ofFn] at h
  exact h

private theorem annihilator_insert (i : Fin 7) (S : SpinorIndex) (hi : i ∉ S) {c : ℝ}
    (hc : c = 1 ∨ c = -1) (h : creator i (spinorBasis S) = c • spinorBasis (insert i S)) :
    annihilator i (spinorBasis (insert i S)) = c • spinorBasis S := by
  have hu := CliffordAlgebra.contractLeft_ι_mul (Q := (0 : QuadraticForm ℝ Half))
    (basisVector.coord i) (basisVector i) (spinorBasis S)
  change annihilator i (creator i (spinorBasis S)) =
    basisVector.coord i (basisVector i) • spinorBasis S -
      ExteriorAlgebra.ι ℝ (basisVector i) * annihilator i (spinorBasis S) at hu
  rw [h, map_smul, annihilator_zero i S hi, mul_zero, sub_zero] at hu
  have hcoord : basisVector.coord i (basisVector i) = 1 := by simp [Module.Basis.coord_apply]
  rw [hcoord, one_smul] at hu
  rcases hc with rfl | rfl
  · simpa only [one_smul] using hu
  · simpa only [neg_one_smul, neg_neg] using congrArg Neg.neg hu

private theorem creator_repr_zero (i : Fin 7) (S T : SpinorIndex) (h : T ≠ insert i S) :
    spinorBasis.repr (creator i (spinorBasis S)) T = 0 := by
  by_cases hi : i ∈ S
  · rw [creator_zero i S hi]
    simp
  · obtain ⟨c, _, hc⟩ := creator_insert i S hi
    rw [hc, map_smul, Module.Basis.repr_self]
    simp [h]

private theorem creator_transpose (i : Fin 7) :
    (LinearMap.toMatrix spinorBasis spinorBasis (creator i))ᵀ =
      LinearMap.toMatrix spinorBasis spinorBasis (annihilator i) := by
  ext S T
  rw [Matrix.transpose_apply, LinearMap.toMatrix_apply, LinearMap.toMatrix_apply]
  by_cases hi : i ∈ T
  · let U := T.erase i
    have he : insert i U = T := Finset.insert_erase hi
    obtain ⟨c, hc, hcreate⟩ := creator_insert i U (Finset.notMem_erase i T)
    have hcontract := annihilator_insert i U (Finset.notMem_erase i T) hc hcreate
    rw [he] at hcreate hcontract
    by_cases hSU : S = U
    · rw [hSU, hcreate, hcontract]
      simp
    · have hzero : spinorBasis.repr (creator i (spinorBasis S)) T = 0 := by
        by_cases his : i ∈ S
        · rw [creator_zero i S his]
          simp
        · apply creator_repr_zero i S T
          intro hTI
          apply hSU
          change S = T.erase i
          rw [hTI, Finset.erase_insert his]
      rw [hzero, hcontract, map_smul, Module.Basis.repr_self]
      simp [hSU]
  · rw [annihilator_zero i T hi]
    have hTI : T ≠ insert i S := fun h => hi (h.symm ▸ Finset.mem_insert_self i S)
    rw [creator_repr_zero i S T hTI]
    simp

theorem gamma_pos_transpose (i : Fin 7) :
    (matrixEquiv (gamma (Fin.castAdd 7 i)))ᵀ = matrixEquiv (gamma (Fin.castAdd 7 i)) := by
  change (LinearMap.toMatrix spinorBasis spinorBasis
    (endRepresentation (gamma (Fin.castAdd 7 i))))ᵀ = _
  rw [matrixEquiv_apply]
  change _ = LinearMap.toMatrix spinorBasis spinorBasis (endRepresentation (gamma (Fin.castAdd 7 i)))
  rw [endRepresentation_gamma_pos, map_add, Matrix.transpose_add, creator_transpose]
  have h := congrArg Matrix.transpose (creator_transpose i)
  rw [Matrix.transpose_transpose] at h
  rw [← h, add_comm]

theorem gamma_neg_transpose (i : Fin 7) :
    (matrixEquiv (gamma (Fin.natAdd 7 i)))ᵀ = -matrixEquiv (gamma (Fin.natAdd 7 i)) := by
  change (LinearMap.toMatrix spinorBasis spinorBasis
    (endRepresentation (gamma (Fin.natAdd 7 i))))ᵀ = _
  rw [matrixEquiv_apply]
  change _ = -LinearMap.toMatrix spinorBasis spinorBasis (endRepresentation (gamma (Fin.natAdd 7 i)))
  rw [endRepresentation_gamma_neg, map_sub, Matrix.transpose_sub, creator_transpose]
  have h := congrArg Matrix.transpose (creator_transpose i)
  rw [Matrix.transpose_transpose] at h
  rw [← h, neg_sub]

theorem gamma_transpose (i : Index) :
    (matrixEquiv (gamma i))ᵀ = metricSign i • matrixEquiv (gamma i) := by
  refine Fin.addCases (m := 7) (n := 7) ?_ ?_ i
  · intro j
    rw [show metricSign (Fin.castAdd 7 j) = 1 from if_pos j.isLt, one_smul]
    exact gamma_pos_transpose j
  · intro j
    have h : metricSign (Fin.natAdd 7 j) = -1 := if_neg (by
      change ¬ 7 + j.val < 7
      omega)
    rw [h, neg_one_smul]
    exact gamma_neg_transpose j

/-- The product of the seven negative Clifford generators, in increasing
order. Its spinor matrix is the signature operator. -/
def negativeVolume : Cl := gamma 7 * gamma 8 * gamma 9 * gamma 10 * gamma 11 * gamma 12 * gamma 13

private theorem swapDescending (i j : Index) (h : j < i) (x : Cl) :
    gamma i * (gamma j * x) = -(gamma j * (gamma i * x)) := by
  rw [← mul_assoc, WitnessW1.gamma_anticommute i j (ne_of_gt h), neg_mul, mul_assoc]

private theorem cancelNegative (i : Index) (h : 7 ≤ i.val) (x : Cl) :
    gamma i * (gamma i * x) = -x := by
  rw [← mul_assoc, WitnessW1.gamma_square, metricSign, if_neg (by omega), map_neg,
    map_one, neg_mul, one_mul]

theorem negativeVolume_square : negativeVolume * negativeVolume = 1 := by
  rw [← mul_one (negativeVolume * negativeVolume)]
  simp (disch := decide) only [negativeVolume, mul_assoc, swapDescending, cancelNegative,
    neg_mul, mul_neg, neg_neg]

private theorem gamma_negativeVolume (i : Index) :
    gamma i * negativeVolume = (-metricSign i) • (negativeVolume * gamma i) := by
  fin_cases i <;> norm_num [metricSign]
  all_goals
    have h (i j : Index) (hji : j < i) : gamma i * gamma j = -(gamma j * gamma i) :=
      WitnessW1.gamma_anticommute i j (ne_of_gt hji)
    simp (disch := decide) only [negativeVolume, mul_assoc, swapDescending, h,
      mul_neg, neg_neg] <;> rfl

/-- The signature operator on the real spinor space. -/
def signatureMatrix : Mat := matrixEquiv negativeVolume

theorem signatureMatrix_square : signatureMatrix * signatureMatrix = 1 := by
  rw [signatureMatrix, ← map_mul, negativeVolume_square, map_one]

private theorem negative_gamma_orthogonal (i : Index) (h : 7 ≤ i.val) :
    (matrixEquiv (gamma i))ᵀ * matrixEquiv (gamma i) = 1 := by
  have hs : metricSign i = -1 := if_neg (by omega)
  rw [gamma_transpose, hs, neg_one_smul, Matrix.neg_mul, ← map_mul, WitnessW1.gamma_square,
    hs, map_neg, map_one, map_neg, map_one, neg_neg]

private theorem negative_gamma_orthogonal_mul (i : Index) (h : 7 ≤ i.val) (X : Mat) :
    (matrixEquiv (gamma i))ᵀ * (matrixEquiv (gamma i) * X) = X := by
  rw [← mul_assoc, negative_gamma_orthogonal i h, one_mul]

theorem signatureMatrix_transpose : signatureMatrixᵀ = signatureMatrix := by
  have h : signatureMatrixᵀ * signatureMatrix = 1 := by
    simp (disch := decide) only [signatureMatrix, negativeVolume, map_mul, Matrix.transpose_mul,
      mul_assoc, negative_gamma_orthogonal_mul, negative_gamma_orthogonal]
  calc
    signatureMatrixᵀ = signatureMatrixᵀ * (signatureMatrix * signatureMatrix) := by
      rw [signatureMatrix_square, mul_one]
    _ = signatureMatrix := by rw [← mul_assoc, h, one_mul]

private def signatureAdjoint : Mat →ₗ[ℝ] Mat :=
  (LinearMap.mulLeftRight ℝ (signatureMatrix, signatureMatrix)).comp
    (Matrix.transposeLinearEquiv SpinorIndex SpinorIndex ℝ ℝ).toLinearMap

private theorem signatureAdjoint_mul (X Y : Mat) :
    signatureAdjoint (X * Y) = signatureAdjoint Y * signatureAdjoint X := by
  change signatureMatrix * (X * Y)ᵀ * signatureMatrix =
    (signatureMatrix * Yᵀ * signatureMatrix) * (signatureMatrix * Xᵀ * signatureMatrix)
  simp only [Matrix.transpose_mul, mul_assoc]
  rw [← mul_assoc signatureMatrix signatureMatrix, signatureMatrix_square, one_mul]

private theorem signatureAdjoint_gamma (i : Index) :
    signatureAdjoint (matrixEquiv (gamma i)) = -matrixEquiv (gamma i) := by
  change signatureMatrix * (matrixEquiv (gamma i))ᵀ * signatureMatrix =
    -matrixEquiv (gamma i)
  have hsign : metricSign i * -metricSign i = -1 := by unfold metricSign; split <;> norm_num
  have h := congrArg matrixEquiv (gamma_negativeVolume i)
  simp only [map_mul, map_smul] at h
  change matrixEquiv (gamma i) * signatureMatrix =
    (-metricSign i) • (signatureMatrix * matrixEquiv (gamma i)) at h
  rw [gamma_transpose, Matrix.mul_smul, Matrix.smul_mul, mul_assoc, h, Matrix.mul_smul,
    smul_smul, hsign, neg_one_smul, ← mul_assoc, signatureMatrix_square, one_mul]

private theorem signatureAdjoint_generator (v : Index → ℝ) :
    signatureAdjoint (matrixEquiv (CliffordAlgebra.ι splitForm v)) =
      -matrixEquiv (CliffordAlgebra.ι splitForm v) := by
  let f := matrixEquiv.toLinearMap.comp (CliffordAlgebra.ι splitForm)
  have h : signatureAdjoint.comp f = -f := by
    apply (Pi.basisFun ℝ Index).ext
    intro i
    have hBasis : Pi.basisFun ℝ Index i = WitnessW1.basisVector i := by
      simp [Pi.basisFun_apply, WitnessW1.basisVector]
    rw [hBasis]
    simpa only [f, LinearMap.comp_apply, LinearMap.neg_apply, AlgEquiv.toLinearMap_apply,
      gamma] using signatureAdjoint_gamma i
  exact DFunLike.congr_fun h v

/-- Clifford conjugation is the transpose adjoint for the signature
matrix of the spinor realization. -/
theorem matrixEquiv_star (x : Cl) :
    matrixEquiv (star x) = signatureMatrix * (matrixEquiv x)ᵀ * signatureMatrix := by
  change matrixEquiv (star x) = signatureAdjoint (matrixEquiv x)
  induction x using CliffordAlgebra.left_induction with
  | algebraMap r =>
    change matrixEquiv (star (algebraMap ℝ Cl r)) = signatureAdjoint (matrixEquiv (algebraMap ℝ Cl r))
    rw [CliffordAlgebra.star_algebraMap, AlgEquiv.commutes, Algebra.algebraMap_eq_smul_one, map_smul]
    have h : signatureAdjoint 1 = 1 := by
      change signatureMatrix * (1 : Mat)ᵀ * signatureMatrix = 1
      rw [Matrix.transpose_one, mul_one, signatureMatrix_square]
    rw [h]
  | add x y hx hy =>
    simp only [star_add, map_add, hx, hy]
  | ι_mul x v hx =>
    rw [star_mul, CliffordAlgebra.star_ι, map_mul, map_neg, map_mul,
      signatureAdjoint_mul, signatureAdjoint_generator v, hx]

/-- The Hermitian signature matrix in the complex spinor space. -/
def complexSignature : ComplexMat := complexEmbedding signatureMatrix

private theorem complexEmbedding_transpose (X : Mat) :
    complexEmbedding Xᵀ = (complexEmbedding X)ᴴ := by
  ext i j
  change ((X j i : ℝ) : ℂ) = star ((X j i : ℝ) : ℂ)
  simp

theorem complexSignature_hermitian : complexSignatureᴴ = complexSignature := by
  rw [complexSignature, ← complexEmbedding_transpose, signatureMatrix_transpose]

theorem complexSignature_square : complexSignature * complexSignature = 1 := by
  rw [complexSignature, ← map_mul, signatureMatrix_square, map_one]

private theorem complexSignature_trace : Matrix.trace complexSignature = 0 := by
  let a := complexEmbedding (matrixEquiv (gamma 0))
  have ha : a * a = 1 := by
    change complexEmbedding (matrixEquiv (gamma 0)) * complexEmbedding (matrixEquiv (gamma 0)) = 1
    rw [← map_mul, ← map_mul, WitnessW1.gamma_square, show metricSign 0 = 1 from rfl,
      map_one, map_one, map_one]
  have hanti : a * complexSignature = -(complexSignature * a) := by
    have h := congrArg (complexEmbedding.comp matrixEquiv.toAlgHom) (gamma_negativeVolume 0)
    simpa only [AlgHom.comp_apply, AlgEquiv.coe_toAlgHom, map_mul, map_smul, map_neg,
      show metricSign 0 = 1 from rfl, neg_one_smul, complexSignature, signatureMatrix, a] using h
  have htrace : Matrix.trace complexSignature = -Matrix.trace complexSignature := by
    calc
      _ = Matrix.trace (a * (a * complexSignature)) := by rw [← mul_assoc, ha, one_mul]
      _ = Matrix.trace (a * complexSignature * a) := Matrix.trace_mul_comm _ _
      _ = _ := by rw [hanti, Matrix.neg_mul, mul_assoc, ha, mul_one, Matrix.trace_neg]
  have hzero : (2 : ℂ) * Matrix.trace complexSignature = 0 := by
    rw [two_mul, ← eq_neg_iff_add_eq_zero]
    exact htrace
  exact (mul_eq_zero.mp hzero).resolve_left (by norm_num)

private theorem signature_isHermitian : complexSignature.IsHermitian :=
  complexSignature_hermitian

/-- The real eigenvalues of the Hermitian signature matrix. -/
def signatureEigenvalue : SpinorIndex → ℝ := signature_isHermitian.eigenvalues

theorem signatureEigenvalue_sign (i : SpinorIndex) :
    signatureEigenvalue i = 1 ∨ signatureEigenvalue i = -1 := by
  let D : ComplexMat := Matrix.diagonal (fun j => (signatureEigenvalue j : ℂ))
  let U := Unitary.conjStarAlgAut ℂ ComplexMat signature_isHermitian.eigenvectorUnitary
  have hn : complexSignature = U D := signature_isHermitian.spectral_theorem
  have hd : D * D = 1 := by
    apply U.injective
    calc
      U (D * D) = U D * U D := map_mul U D D
      _ = 1 := by rw [← hn, complexSignature_square]
      _ = U 1 := (map_one U).symm
  have hm := congrArg (fun M : ComplexMat => M i i) hd
  change (D * D) i i = (1 : ComplexMat) i i at hm
  have hmul : signatureEigenvalue i * signatureEigenvalue i = 1 := by
    apply Complex.ofReal_injective
    simpa only [D, Matrix.diagonal_mul_diagonal, Matrix.diagonal_apply_eq, Pi.mul_apply,
      Matrix.one_apply_eq, Complex.ofReal_mul, Complex.ofReal_one] using hm
  exact mul_self_eq_one_iff.mp hmul

/-- The Hermitian form has 64 positive and 64 negative eigenvalues. -/
theorem signature_eigenvalue_counts :
    (Finset.univ.filter fun i => signatureEigenvalue i = 1).card = 64 ∧
      (Finset.univ.filter fun i => signatureEigenvalue i = -1).card = 64 := by
  classical
  let positive := Finset.univ.filter fun i => signatureEigenvalue i = 1
  let negative := Finset.univ.filter fun i => signatureEigenvalue i = -1
  have hcover : positive ∪ negative = Finset.univ := by
    ext i
    simp [positive, negative, signatureEigenvalue_sign i]
  have hdisjoint : Disjoint positive negative := Finset.disjoint_left.mpr fun i hp hn => by
    have hP := (Finset.mem_filter.mp hp).2
    have hN := (Finset.mem_filter.mp hn).2
    rw [hP] at hN
    norm_num at hN
  have hsumC : (∑ i : SpinorIndex, (signatureEigenvalue i : ℂ)) = 0 :=
    signature_isHermitian.trace_eq_sum_eigenvalues.symm.trans complexSignature_trace
  have hsum : (∑ i : SpinorIndex, signatureEigenvalue i) = 0 := by exact_mod_cast hsumC
  have hp : (∑ i ∈ positive, signatureEigenvalue i) = (positive.card : ℝ) := by
    rw [Finset.sum_congr rfl (fun _ hi => (Finset.mem_filter.mp hi).2), Finset.sum_const, nsmul_one]
  have hn : (∑ i ∈ negative, signatureEigenvalue i) = -(negative.card : ℝ) := by
    rw [Finset.sum_congr rfl (fun _ hi => (Finset.mem_filter.mp hi).2), Finset.sum_const]
    simp [negative, nsmul_eq_mul]
  rw [← hcover, Finset.sum_union hdisjoint, hp, hn, ← sub_eq_add_neg] at hsum
  have hcards : positive.card + negative.card = 128 := by
    rw [← Finset.card_union_of_disjoint hdisjoint, hcover, Finset.card_univ,
      Fintype.card_finset, Fintype.card_fin]
    rfl
  have heq : positive.card = negative.card := by exact_mod_cast sub_eq_zero.mp hsum
  change positive.card = 64 ∧ negative.card = 64
  omega

/-- The actual Spin matrices preserve the Hermitian signature form. -/
theorem spinorUnits_preserve_signature (g : D7SpinAction.Spin) :
    (spinorUnits g : ComplexMat)ᴴ * complexSignature * (spinorUnits g : ComplexMat) =
      complexSignature := by
  have hg : star (g.val : Cl) * g.val = 1 :=
    Unitary.star_mul_self_of_mem (pinGroup.mem_unitary (spinGroup.mem_pin g.prop))
  have h := congrArg (complexEmbedding.comp matrixEquiv.toAlgHom) hg
  simp only [AlgHom.comp_apply, AlgEquiv.coe_toAlgHom, map_mul, map_one, matrixEquiv_star,
    complexEmbedding_transpose, ← spinorUnits_val g] at h
  have h' := congrArg (fun X : ComplexMat => complexSignature * X) h
  change complexSignature *
      ((complexSignature * (spinorUnits g : ComplexMat)ᴴ * complexSignature) *
        (spinorUnits g : ComplexMat)) = complexSignature * 1 at h'
  simpa only [← mul_assoc, complexSignature_square, one_mul, mul_one] using h'

/-- Spin conjugation on the skew-adjoint real coefficient matrices of
the spinor model. -/
def coefficientConjugation (g : D7SpinAction.Spin) :
    ↥(D7UnitaryRealForm.skewAdjoint complexSignature) →ₗ[ℝ]
      ↥(D7UnitaryRealForm.skewAdjoint complexSignature) :=
  D7UnitaryRealForm.realMatrixConjugation complexSignature_square
    (spinorUnits g) (spinorUnits_preserve_signature g)

/-- Identify the complexification of the actual skew-adjoint coefficient
space with the complexified split Clifford algebra. -/
def cliffordCoefficientEquiv :
    ℂ ⊗[ℝ] ↥(D7UnitaryRealForm.skewAdjoint complexSignature) ≃ₗ[ℂ] ℂ ⊗[ℝ] Cl :=
  (D7UnitaryRealForm.complexificationEquiv complexSignature_hermitian
    complexSignature_square).trans complexMatrixEquiv.toLinearEquiv.symm

/-- The coefficient identification intertwines the actual Spin actions. -/
theorem cliffordCoefficientEquiv_intertwines (g : D7SpinAction.Spin) :
    cliffordCoefficientEquiv.toLinearMap.comp ((coefficientConjugation g).baseChange ℂ) =
      ((D7SpinAction.cliffordConjugation g).toLinearMap.baseChange ℂ).comp
        cliffordCoefficientEquiv.toLinearMap := by
  let e := D7UnitaryRealForm.complexificationEquiv complexSignature_hermitian
    complexSignature_square
  have he z : complexMatrixEquiv (cliffordCoefficientEquiv z) = e z :=
    complexMatrixEquiv.apply_symm_apply (e z)
  apply LinearMap.ext
  intro z
  apply complexMatrixEquiv.injective
  change complexMatrixEquiv (cliffordCoefficientEquiv ((coefficientConjugation g).baseChange ℂ z)) =
    complexMatrixEquiv ((D7SpinAction.cliffordConjugation g).toLinearMap.baseChange ℂ
      (cliffordCoefficientEquiv z))
  rw [he]
  have hspin := DFunLike.congr_fun (complexMatrixEquiv_intertwines g) (cliffordCoefficientEquiv z)
  change complexMatrixEquiv ((D7SpinAction.cliffordConjugation g).toLinearMap.baseChange ℂ
      (cliffordCoefficientEquiv z)) =
    D7UnitaryRealForm.matrixConjugation (spinorUnits g)
      (complexMatrixEquiv (cliffordCoefficientEquiv z)) at hspin
  rw [hspin, he]
  exact DFunLike.congr_fun (D7UnitaryRealForm.complexification_intertwines
    complexSignature_hermitian complexSignature_square (spinorUnits g)
    (spinorUnits_preserve_signature g)) z

end

end GeometricUnity.D7CliffordAdjoint
