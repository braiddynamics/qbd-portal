import D7Irreducible
import D7VectorTensor

/-!
# Irreducibility of the traceless hook

Double sign changes separate the tensor basis by the indices appearing an
odd number of times. A transposition within one such block extracts a
difference. Plane rotations connect differences from the two block types.
-/

namespace GeometricUnity.D7Hook

open D7Exterior D7Hodge D7Irreducible D7VectorTensor TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

private abbrev e := orthBasis
private def blade (a i j : Axis) : VTwo := e a ⊗ₜ[ℂ] wedgeTwo (e i) (e j)
private def repeated (i k : Axis) : VTwo := blade i i k
private def diffRepeated (i j k : Axis) : VTwo := repeated i k - repeated j k
private def diffDistinct (i j k : Axis) : VTwo := blade i j k + blade j i k
private def Distinct (i j k : Axis) : Prop := i ≠ j ∧ i ≠ k ∧ j ≠ k

private theorem blade_swap (a i j : Axis) : blade a j i = -blade a i j := by
  rw [blade, blade, wedgeTwo_swap, tmul_neg]

private theorem repeated_self (i : Axis) : repeated i i = 0 := by
  simp [repeated, blade, wedgeTwo_self]

private def column (s : Index 2) (j : Fin 2) : Axis := Set.powersetCard.ofFinEmbEquiv.symm s j

private theorem column_ne (s : Index 2) : column s 0 ≠ column s 1 := by
  intro h
  have h' : (0 : Fin 2) = 1 := (Set.powersetCard.ofFinEmbEquiv.symm s).injective h
  exact (by decide : (0 : Fin 2) ≠ 1) h'

private theorem columns (s : Index 2) : s.val = {column s 0, column s 1} := by
  ext a
  change a ∈ s ↔ a ∈ ({column s 0, column s 1} : Finset Axis)
  rw [← Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem s a]
  constructor
  · rintro ⟨j, rfl⟩
    fin_cases j
    · exact Finset.mem_insert_self _ _
    · exact Finset.mem_insert.mpr (Or.inr (Finset.mem_singleton_self _))
  · intro h
    rcases (Finset.mem_insert.mp h) with h | h
    · exact ⟨0, h.symm⟩
    · exact ⟨1, (Finset.mem_singleton.mp h).symm⟩

def tensorExteriorBasis (k : ℕ) : Module.Basis (Axis × Index k) ℂ (Space ⊗[ℂ] Exterior k) :=
  e.tensorProduct (basis k)

private abbrev tensorBasis := tensorExteriorBasis 2

private theorem tensorBasis_blade (t : Axis × Index 2) :
    tensorBasis t = blade t.1 (column t.2 0) (column t.2 1) := by
  rw [tensorBasis, tensorExteriorBasis, Module.Basis.tensorProduct_apply', exteriorPower.basis_apply]
  congr 1

def parity {k : ℕ} (t : Axis × Index k) : Finset Axis :=
  if t.1 ∈ t.2.val then t.2.val.erase t.1 else insert t.1 t.2.val

private theorem parity_card (t : Axis × Index 2) : (parity t).card = 1 ∨ (parity t).card = 3 := by
  by_cases h : t.1 ∈ t.2.val
  · left; rw [parity, if_pos h, Finset.card_erase_of_mem h, t.2.prop]
  · right; rw [parity, if_neg h, Finset.card_insert_of_notMem h, t.2.prop]

private theorem parity_not_complement (t s : Axis × Index 2) : parity t ≠ (parity s)ᶜ := by
  intro h
  have hc := congrArg Finset.card h
  rw [Finset.card_compl, Fintype.card_fin] at hc
  rcases parity_card s with hs | hs <;> rcases parity_card t with ht | ht <;> omega

private theorem parity_sign {k : ℕ} (t : Axis × Index k) (i : Axis) :
    subsetFlip (parity t) i = axisFlip i t.1 * subsetFlip t.2.val i := by
  by_cases ha : t.1 ∈ t.2.val <;> by_cases he : t.1 = i <;> by_cases hm : i ∈ t.2.val <;>
    simp_all [parity, subsetFlip, axisFlip, Finset.mem_erase, eq_comm]

theorem tensorExterior_doubleFlip {k : ℕ} (i j : Axis) (t : Axis × Index k) :
    (vectorAction.tprod (exteriorRepresentation k)) (doubleFlip i j) (tensorExteriorBasis k t) =
      character (parity t) i j • tensorExteriorBasis k t := by
  rw [tensorExteriorBasis, Module.Basis.tensorProduct_apply']
  change TensorProduct.map (doubleFlip i j).val (exteriorRepresentation k (doubleFlip i j))
    (e t.1 ⊗ₜ[ℂ] basis k t.2) = _
  rw [map_tmul, doubleFlip_basis, doubleFlip_exterior, smul_tmul_smul]
  congr 1
  simp only [character, parity_sign]
  ring

private theorem tensor_doubleFlip (i j : Axis) (t : Axis × Index 2) :
    tensorAction (doubleFlip i j) (tensorBasis t) = character (parity t) i j • tensorBasis t :=
  tensorExterior_doubleFlip i j t

private def Stable (W : Submodule ℂ VTwo) : Prop :=
  ∀ g : splitSpecialOrthogonal, ∀ x ∈ W, tensorAction g x ∈ W

private theorem block_in_submodule (W : Submodule ℂ VTwo) (hW : Stable W) (hne : W ≠ ⊥) :
    ∃ x : VTwo, ∃ s : Axis × Index 2, x ∈ W ∧ x ≠ 0 ∧
      ∀ t, tensorBasis.repr x t ≠ 0 → parity t = parity s := by
  obtain ⟨x, s, hx, hs, hw⟩ := support_sign_block tensorBasis parity
    (fun i j => tensorAction (doubleFlip i j)) tensor_doubleFlip W (fun i j => hW (doubleFlip i j)) hne
  exact ⟨x, s, hx, fun h => hs (by simp [h]), fun t ht => (hw t ht).resolve_right (parity_not_complement t s)⟩

private theorem basis_span_block (x : VTwo) (s : Finset Axis) (U : Submodule ℂ VTwo)
    (hs : ∀ t, tensorBasis.repr x t ≠ 0 → parity t = s)
    (hU : ∀ t, parity t = s → tensorBasis t ∈ U) : x ∈ U := by
  rw [← tensorBasis.sum_repr x]
  apply U.sum_mem
  intro t _
  by_cases h : tensorBasis.repr x t = 0
  · rw [h, zero_smul]; exact U.zero_mem
  · exact U.smul_mem _ (hU t (hs t h))

private theorem parity_singleton {t : Axis × Index 2} {k : Axis} (h : parity t = {k}) :
    ∃ i : {i : Axis // i ≠ k}, tensorBasis t = repeated i.val k ∨ tensorBasis t = -repeated i.val k := by
  have ht : t.1 ∈ t.2.val := by
    by_contra hn
    have hc := congrArg Finset.card h
    rw [parity, if_neg hn, Finset.card_insert_of_notMem hn, t.2.prop, Finset.card_singleton] at hc
    omega
  have he : t.2.val.erase t.1 = {k} := by simpa only [parity, if_pos ht] using h
  have hk : k ∈ t.2.val.erase t.1 := by rw [he]; exact Finset.mem_singleton_self _
  have hne : t.1 ≠ k := Ne.symm (Finset.mem_erase.mp hk).1
  have hcols := columns t.2
  have hleft : t.1 = column t.2 0 ∨ t.1 = column t.2 1 := by simpa only [hcols, Finset.mem_insert, Finset.mem_singleton] using ht
  have hright : k = column t.2 0 ∨ k = column t.2 1 := by
    simpa only [hcols, Finset.mem_insert, Finset.mem_singleton] using (Finset.mem_erase.mp hk).2
  refine ⟨⟨t.1, hne⟩, ?_⟩
  rw [tensorBasis_blade]
  rcases hleft with hl | hl <;> rcases hright with hr | hr
  · exact (hne (hl.trans hr.symm)).elim
  · left; rw [← hl, ← hr]; rfl
  · right; rw [← hl, ← hr, blade_swap]; rfl
  · exact (hne (hl.trans hr.symm)).elim

private def triple (i j k : Axis) : Fin 3 → VTwo := ![blade i j k, blade j k i, blade k i j]

private theorem parity_triple {t : Axis × Index 2} {i j k : Axis} (d : Distinct i j k)
    (h : parity t = {i, j, k}) :
    ∃ a : Fin 3, tensorBasis t = triple i j k a ∨ tensorBasis t = -triple i j k a := by
  have hc : ({i, j, k} : Finset Axis).card = 3 := by
    rw [Finset.card_insert_of_notMem (by simp [d.1, d.2.1]), Finset.card_pair d.2.2]
  have ht : t.1 ∉ t.2.val := by
    intro hm
    have hs := congrArg Finset.card h
    rw [parity, if_pos hm, Finset.card_erase_of_mem hm, t.2.prop, hc] at hs
    omega
  have hcols : ({t.1, column t.2 0, column t.2 1} : Finset Axis) = {i, j, k} := by
    rw [parity, if_neg ht, columns] at h
    exact h
  have hmem (a : Axis) (ha : a ∈ ({t.1, column t.2 0, column t.2 1} : Finset Axis)) :
      a = i ∨ a = j ∨ a = k := by
    rwa [hcols, Finset.mem_insert, Finset.mem_insert, Finset.mem_singleton] at ha
  let a := t.1
  let b := column t.2 0
  let c := column t.2 1
  have hab : a ≠ b := fun he => ht (by rw [columns, show t.1 = column t.2 0 from he]; simp)
  have hac : a ≠ c := fun he => ht (by rw [columns, show t.1 = column t.2 1 from he]; simp)
  have hbc : b ≠ c := column_ne t.2
  have ha := hmem a (by simp [a])
  have hb := hmem b (by simp [b])
  have hd := hmem c (by simp [c])
  change ∃ n : Fin 3, tensorBasis t = triple i j k n ∨ tensorBasis t = -triple i j k n
  rw [tensorBasis_blade]
  change ∃ n : Fin 3, blade a b c = triple i j k n ∨ blade a b c = -triple i j k n
  rcases ha with ha | ha | ha <;> rcases hb with hb | hb | hb <;> rcases hd with hd | hd | hd <;>
    try solve | exact (hab (ha.trans hb.symm)).elim | exact (hac (ha.trans hd.symm)).elim | exact (hbc (hb.trans hd.symm)).elim
  · exact ⟨0, Or.inl (by rw [ha, hb, hd]; rfl)⟩
  · exact ⟨0, Or.inr (by rw [ha, hb, hd]; exact blade_swap i j k)⟩
  · exact ⟨1, Or.inr (by rw [ha, hb, hd]; exact blade_swap j k i)⟩
  · exact ⟨1, Or.inl (by rw [ha, hb, hd]; rfl)⟩
  · exact ⟨2, Or.inl (by rw [ha, hb, hd]; rfl)⟩
  · exact ⟨2, Or.inr (by rw [ha, hb, hd]; exact blade_swap k i j)⟩

private theorem exists_pivot (i j k : Axis) (d : Distinct i j k) : ∃ p : Axis, p ≠ i ∧ p ≠ j ∧ p ≠ k := by
  by_contra! h
  have he : ({i, j, k} : Finset Axis) = Finset.univ := by
    apply Finset.eq_univ_of_forall
    intro p
    rw [Finset.mem_insert, Finset.mem_insert, Finset.mem_singleton]
    by_contra! he
    exact he.2.2 (h p he.1 he.2.1)
  have hc := congrArg Finset.card he
  rw [Finset.card_insert_of_notMem (by simp [d.1, d.2.1]), Finset.card_pair d.2.2,
    Finset.card_univ, Fintype.card_fin] at hc
  omega

private theorem action_blade_scaled (g : splitSpecialOrthogonal) (σ : Axis → Axis) (c : Axis → ℂ)
    (h : ∀ a, g.val (e a) = c a • e (σ a)) (a i j : Axis) :
    tensorAction g (blade a i j) = (c a * (c i * c j)) • blade (σ a) (σ i) (σ j) := by
  simp only [blade, action_pure, h, wedgeTwo_smul_left, wedgeTwo_smul_right, smul_smul, smul_tmul_smul]
  rw [mul_comm (c j) (c i)]

private theorem action_oriented_blade (σ : Equiv.Perm Axis) (p a i j : Axis)
    (ha : a ≠ p) (hi : i ≠ p) (hj : j ≠ p) :
    tensorAction (orientedPermAt σ p) (blade a i j) = blade (σ a) (σ i) (σ j) := by
  rw [action_blade_scaled _ σ (orientationCorrection σ p) (orientedPermAt_basis σ p)]
  simp [orientationCorrection, ha, hi, hj]

private theorem action_oriented_repeated (σ : Equiv.Perm Axis) (p i k : Axis) (hk : k ≠ p) :
    tensorAction (orientedPermAt σ p) (repeated i k) = repeated (σ i) (σ k) := by
  rw [repeated, repeated, action_blade_scaled _ σ (orientationCorrection σ p) (orientedPermAt_basis σ p)]
  have h : orientationCorrection σ p k = 1 := if_neg hk
  rw [h, mul_one, correction_sq, one_smul]

private theorem trace_repeated (i k : Axis) (h : i ≠ k) : trace (repeated i k) = e k := by
  unfold repeated blade
  rw [trace_pure, orthBasis_pair, orthBasis_pair, if_pos rfl, if_neg h]
  simp

private theorem trace_distinct (i j k : Axis) (d : Distinct i j k) : trace (blade i j k) = 0 := by
  unfold blade
  rw [trace_pure, orthBasis_pair, orthBasis_pair, if_neg d.1, if_neg d.2.1]
  simp

private theorem axes_triple_injective (i j k : Axis) (d : Distinct i j k) :
    Function.Injective (![i, j, k] : Fin 3 → Axis) := by
  intro a b h
  fin_cases a <;> fin_cases b
  · rfl
  · exact (d.1 h).elim
  · exact (d.2.1 h).elim
  · exact (d.1 h.symm).elim
  · rfl
  · exact (d.2.2 h).elim
  · exact (d.2.1 h.symm).elim
  · exact (d.2.2 h.symm).elim
  · rfl

private theorem wedge_three_ne_zero (i j k : Axis) (d : Distinct i j k) : wedgeThree (e i) (e j) (e k) ≠ 0 := by
  let a : Fin 3 → Axis := ![i, j, k]
  let f : Fin 3 → Module.Dual ℂ Space := fun j => e.coord (a j)
  let v : Fin 3 → Space := e ∘ a
  have hv : exteriorPower.ιMulti ℂ 3 v = wedgeThree (e i) (e j) (e k) := by
    congr 1
    funext j
    fin_cases j <;> rfl
  intro h
  have hm : Matrix.of (fun i j : Fin 3 => f j (v i)) = 1 := by
    ext i j
    have h : Function.Injective a := axes_triple_injective _ _ _ d
    simp only [f, v, Matrix.of_apply, Function.comp_apply, Module.Basis.coord_apply, Module.Basis.repr_self,
      Finsupp.single_apply, Matrix.one_apply, h.eq_iff]
  have he := exteriorPower.pairingDual_ιMulti_ιMulti (R := ℂ) f v
  rw [hv, h, map_zero, hm, Matrix.det_one] at he
  exact zero_ne_one he

private theorem triple_alternation (i j k : Axis) (a : Fin 3) :
    alternation (triple i j k a) = wedgeThree (e i) (e j) (e k) := by
  fin_cases a
  · exact alternation_pure _ _ _
  · exact (alternation_pure _ _ _).trans (wedgeThree_rotate _ _ _)
  · exact (alternation_pure _ _ _).trans ((wedgeThree_rotate (e j) (e k) (e i)).trans (wedgeThree_rotate _ _ _))

theorem swap_sum_difference {ι E : Type*} [Fintype ι] [DecidableEq ι] [AddCommGroup E] [Module ℂ E]
    (c : ι → ℂ) (v : ι → E)
    (a b : ι) (h : a ≠ b) :
    (∑ t, c t • v t) - (∑ t, c t • v (Equiv.swap a b t)) = (c a - c b) • (v a - v b) := by
  rw [← Finset.sum_sub_distrib, ← Finset.sum_subset (s₁ := {a, b}) (s₂ := Finset.univ) (Finset.subset_univ _)]
  · rw [Finset.sum_pair h, Equiv.swap_apply_left, Equiv.swap_apply_right]
    module
  · intro t _ ht
    simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at ht
    rw [Equiv.swap_apply_of_ne_of_ne ht.1 ht.2, sub_self]

theorem coefficients_differ {ι E : Type*} [Fintype ι] [AddCommGroup E] [Module ℂ E] (c : ι → ℂ) (v : ι → E)
    (hc : ∑ t, c t = 0) (hv : (∑ t, c t • v t) ≠ 0) : ∃ a b, c a ≠ c b := by
  classical
  by_contra! he
  cases isEmpty_or_nonempty ι with
  | inl h => exact hv (Finset.sum_of_isEmpty _)
  | inr h =>
    let : Nonempty ι := h
    obtain ⟨i⟩ := h
    have hn : (Fintype.card ι : ℂ) ≠ 0 := Nat.cast_ne_zero.mpr Fintype.card_ne_zero
    have hi : c i = 0 := by
      have h := hc
      simp_rw [he _ i] at h
      rw [Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at h
      exact (mul_eq_zero.mp h).resolve_left hn
    exact hv (Finset.sum_eq_zero fun j _ => by rw [he j i, hi, zero_smul])

private theorem singleton_extract (W : Submodule ℂ VTwo) (hW : Stable W) (hsub : W ≤ hook) (k : Axis)
    (x : VTwo) (hx : x ∈ W) (hx0 : x ≠ 0)
    (hs : ∀ t, tensorBasis.repr x t ≠ 0 → parity t = {k}) :
    ∃ i j, Distinct i j k ∧ diffRepeated i j k ∈ W := by
  classical
  let v (i : {i : Axis // i ≠ k}) := repeated i.val k
  have hspan : x ∈ Submodule.span ℂ (Set.range v) := by
    apply basis_span_block x {k} _ hs
    intro t ht
    obtain ⟨i, hi | hi⟩ := parity_singleton ht
    · rw [hi]; exact Submodule.subset_span (Set.mem_range_self i)
    · rw [hi]; exact Submodule.neg_mem _ (Submodule.subset_span (Set.mem_range_self i))
  obtain ⟨c, rfl⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp hspan
  have htrace := ((mem_hook _).mp (hsub hx)).2
  have hc : ∑ i, c i = 0 := by
    have h (a : {i : Axis // i ≠ k}) : trace (v a) = e k := trace_repeated _ _ a.prop
    simp only [map_sum, map_smul, h, ← Finset.sum_smul] at htrace
    exact (smul_eq_zero.mp htrace).resolve_right (e.ne_zero k)
  obtain ⟨a, b, hne⟩ := coefficients_differ c v hc hx0
  have hab : a.val ≠ b.val := fun h => hne (congrArg c (Subtype.ext h))
  have d : Distinct a.val b.val k := ⟨hab, a.prop, b.prop⟩
  obtain ⟨p, _, _, hpk⟩ := exists_pivot _ _ _ d
  let σ := Equiv.swap a.val b.val
  let g := orientedPermAt σ p
  have hfix : σ k = k := Equiv.swap_apply_of_ne_of_ne (Ne.symm a.prop) (Ne.symm b.prop)
  have he (i : {i : Axis // i ≠ k}) : tensorAction g (v i) = v (Equiv.swap a b i) := by
    rw [show tensorAction g (v i) = repeated (σ i.val) (σ k) from
      action_oriented_repeated σ p _ _ (Ne.symm hpk), hfix]
    congr 1
    by_cases ha : i = a
    · subst i; simp [σ]
    · by_cases hb : i = b
      · subst i; simp [σ]
      · rw [Equiv.swap_apply_of_ne_of_ne ha hb]
        exact Equiv.swap_apply_of_ne_of_ne (fun h => ha (Subtype.ext h)) (fun h => hb (Subtype.ext h))
  have hm := W.sub_mem hx (hW g _ hx)
  simp only [map_sum, map_smul, he] at hm
  rw [swap_sum_difference c v a b (fun h => hne (congrArg c h))] at hm
  exact ⟨a.val, b.val, d, basis_mem_of_scaled W _ _ (sub_ne_zero.mpr hne) hm⟩

private theorem triple_swap_extract (W : Submodule ℂ VTwo) (hW : Stable W) (i j k : Axis) (d : Distinct i j k)
    (a b c : ℂ) (hab : a ≠ b)
    (hmem : a • blade i j k + b • blade j k i + c • blade k i j ∈ W) : diffDistinct i j k ∈ W := by
  obtain ⟨p, hpi, hpj, hpk⟩ := exists_pivot i j k d
  let σ := Equiv.swap i j
  let g := orientedPermAt σ p
  have hi : σ i = j := Equiv.swap_apply_left _ _
  have hj : σ j = i := Equiv.swap_apply_right _ _
  have hk : σ k = k := Equiv.swap_apply_of_ne_of_ne (Ne.symm d.2.1) (Ne.symm d.2.2)
  have hb₁ : tensorAction g (blade i j k) = -blade j k i := by
    rw [action_oriented_blade _ _ _ _ _ (Ne.symm hpi) (Ne.symm hpj) (Ne.symm hpk), hi, hj, hk, blade_swap j k i]
  have hb₂ : tensorAction g (blade j k i) = -blade i j k := by
    rw [action_oriented_blade _ _ _ _ _ (Ne.symm hpj) (Ne.symm hpk) (Ne.symm hpi), hi, hj, hk, blade_swap i j k]
  have hb₃ : tensorAction g (blade k i j) = -blade k i j := by
    rw [action_oriented_blade _ _ _ _ _ (Ne.symm hpk) (Ne.symm hpi) (Ne.symm hpj), hi, hj, hk, blade_swap k i j]
  have h := W.add_mem hmem (hW g _ hmem)
  simp only [map_add, map_smul, hb₁, hb₂, hb₃] at h
  apply basis_mem_of_scaled W _ _ (sub_ne_zero.mpr hab)
  have hd : (a - b) • diffDistinct i j k =
      (a • blade i j k + b • blade j k i + c • blade k i j) +
        (a • -blade j k i + b • -blade i j k + c • -blade k i j) := by
    rw [diffDistinct, blade_swap j k i]
    module
  rwa [hd]

private theorem triple_extract (W : Submodule ℂ VTwo) (hW : Stable W) (hsub : W ≤ hook)
    (i j k : Axis) (d : Distinct i j k) (x : VTwo) (hx : x ∈ W) (hx0 : x ≠ 0)
    (hs : ∀ t, tensorBasis.repr x t ≠ 0 → parity t = {i, j, k}) :
    ∃ i j k, Distinct i j k ∧ diffDistinct i j k ∈ W := by
  classical
  have hspan : x ∈ Submodule.span ℂ (Set.range (triple i j k)) := by
    apply basis_span_block x {i, j, k} _ hs
    intro t ht
    obtain ⟨a, ha | ha⟩ := parity_triple d ht
    · rw [ha]; exact Submodule.subset_span (Set.mem_range_self a)
    · rw [ha]; exact Submodule.neg_mem _ (Submodule.subset_span (Set.mem_range_self a))
  obtain ⟨c, rfl⟩ := (Submodule.mem_span_range_iff_exists_fun ℂ).mp hspan
  have halt := ((mem_hook _).mp (hsub hx)).1
  simp only [map_sum, map_smul, triple_alternation, ← Finset.sum_smul] at halt
  have hc : ∑ a, c a = 0 := (smul_eq_zero.mp halt).resolve_right (wedge_three_ne_zero i j k d)
  have hsum : (∑ a, c a • triple i j k a) =
      c 0 • blade i j k + c 1 • blade j k i + c 2 • blade k i j := by
    rw [Fin.sum_univ_three]; rfl
  rw [hsum] at hx hx0
  by_cases h₁ : c 0 = c 1
  · have h₂ : c 1 ≠ c 2 := by
      intro h₂
      have hz : c 2 = 0 := by
        rw [Fin.sum_univ_three, h₁, h₂] at hc
        linear_combination (1 / 3 : ℂ) * hc
      exact hx0 (by simp [h₁, h₂, hz])
    have d' : Distinct j k i := ⟨d.2.2, Ne.symm d.1, Ne.symm d.2.1⟩
    refine ⟨j, k, i, d', triple_swap_extract W hW j k i d' (c 1) (c 2) (c 0) h₂ ?_⟩
    convert hx using 1
    abel
  · exact ⟨i, j, k, d, triple_swap_extract W hW i j k d _ _ _ h₁ hx⟩

private def reflect (n : Space) : Space →ₗ[ℂ] Space :=
  LinearMap.transvection (splitMetric n) ((-2 : ℂ) • n)

private theorem reflect_apply (n x : Space) : reflect n x = x + (-2 * splitForm n x) • n := by
  change x + splitMetric n x • ((-2 : ℂ) • n) = _
  rw [splitMetric_apply, smul_smul, mul_comm]

private theorem reflect_det (n : Space) (hn : splitForm n n = 1) : (reflect n).det = -1 := by
  rw [reflect, LinearMap.transvection.det, map_smul, splitMetric_apply, hn, smul_eq_mul]
  norm_num

private theorem symmetric_metric (x y : Space) : splitMetric x y = splitMetric y x := by
  rw [splitMetric_apply, splitMetric_apply]
  apply Finset.sum_congr rfl
  intro i _
  change x (plusAxis i) * y (minusAxis i) + x (minusAxis i) * y (plusAxis i) =
    y (plusAxis i) * x (minusAxis i) + y (minusAxis i) * x (plusAxis i)
  ring

private theorem reflect_isometry (n : Space) (hn : splitForm n n = 1) (x y : Space) :
    splitForm (reflect n x) (reflect n y) = splitForm x y := by
  rw [reflect_apply, reflect_apply]
  simp only [← splitMetric_apply, LinearMap.map_add, LinearMap.map_smul, LinearMap.add_apply,
    LinearMap.smul_apply, smul_eq_mul]
  rw [symmetric_metric x n, show splitMetric n n = 1 by rw [splitMetric_apply, hn]]
  ring

private def normal (i j : Axis) : Space := (3 / 5 : ℂ) • e i + (4 / 5 : ℂ) • e j

private theorem normal_pair (i j k : Axis) : splitForm (normal i j) (e k) =
    (3 / 5 : ℂ) * (if i = k then 1 else 0) + (4 / 5 : ℂ) * (if j = k then 1 else 0) := by
  simp only [normal, ← splitMetric_apply, LinearMap.map_add, LinearMap.map_smul, LinearMap.add_apply,
    LinearMap.smul_apply, smul_eq_mul]
  rw [splitMetric_apply, splitMetric_apply, orthBasis_pair, orthBasis_pair]

private theorem normal_norm (i j : Axis) (h : i ≠ j) : splitForm (normal i j) (normal i j) = 1 := by
  conv_lhs => rw [← splitMetric_apply]
  conv_lhs => arg 2; unfold normal
  simp only [LinearMap.map_add, LinearMap.map_smul, smul_eq_mul, splitMetric_apply, normal_pair,
    if_neg h, if_neg (Ne.symm h)]
  norm_num

def rotation (i j : Axis) (h : i ≠ j) : splitSpecialOrthogonal :=
  ⟨(reflect (normal i j)).comp (reflect (e i)), by
    rw [LinearMap.det_comp, reflect_det _ (normal_norm i j h), reflect_det _ (by simp [orthBasis_pair])]
    norm_num,
   fun x y => (reflect_isometry _ (normal_norm i j h) _ _).trans
      (reflect_isometry _ (by simp [orthBasis_pair]) x y)⟩

theorem rotation_on_plane (i j : Axis) (h : i ≠ j) :
    (rotation i j h).val (e i) = (-7 / 25 : ℂ) • e i + (24 / 25 : ℂ) • e j ∧
    (rotation i j h).val (e j) = (-24 / 25 : ℂ) • e i + (-7 / 25 : ℂ) • e j := by
  have h₁ : reflect (e i) (e i) = -e i := by rw [reflect_apply, orthBasis_pair, if_pos rfl]; module
  have h₂ : reflect (e i) (e j) = e j := by simp [reflect_apply, orthBasis_pair, h]
  constructor
  · change reflect (normal i j) (reflect (e i) (e i)) = _
    rw [h₁, map_neg, reflect_apply, normal_pair, if_pos rfl, if_neg h.symm, normal]
    module
  · change reflect (normal i j) (reflect (e i) (e j)) = _
    rw [h₂, reflect_apply, normal_pair, if_neg h, if_pos rfl, normal]
    module

theorem rotation_off_plane (i j k : Axis) (h : i ≠ j) (hi : k ≠ i) (hj : k ≠ j) :
    (rotation i j h).val (e k) = e k := by
  have hk : reflect (e i) (e k) = e k := by simp [reflect_apply, orthBasis_pair, hi.symm]
  change reflect (normal i j) (reflect (e i) (e k)) = _
  rw [hk, reflect_apply, normal_pair, if_neg hi.symm, if_neg hj.symm]
  simp

private theorem rotation_basis (i j k : Axis) (d : Distinct i j k) :
    (rotation i j d.1).val (e i) = (-7 / 25 : ℂ) • e i + (24 / 25 : ℂ) • e j ∧
    (rotation i j d.1).val (e j) = (-24 / 25 : ℂ) • e i + (-7 / 25 : ℂ) • e j ∧
    (rotation i j d.1).val (e k) = e k :=
  ⟨(rotation_on_plane i j d.1).1, (rotation_on_plane i j d.1).2,
    rotation_off_plane i j k d.1 d.2.1.symm d.2.2.symm⟩

private theorem rotation_repeated (i j k : Axis) (d : Distinct i j k) :
    tensorAction (rotation i j d.1) (diffRepeated i j k) =
      (-527 / 625 : ℂ) • diffRepeated i j k + (-336 / 625 : ℂ) • diffDistinct i j k := by
  obtain ⟨hi, hj, hk⟩ := rotation_basis i j k d
  simp only [diffRepeated, diffDistinct, repeated, blade, map_sub, action_pure, hi, hj, hk,
    wedgeTwo_add_left, wedgeTwo_smul_left, add_tmul, tmul_add, ← smul_tmul', tmul_smul]
  module

private theorem rotation_distinct (i j k : Axis) (d : Distinct i j k) :
    tensorAction (rotation i j d.1) (diffDistinct i j k) =
      (336 / 625 : ℂ) • diffRepeated i j k + (-527 / 625 : ℂ) • diffDistinct i j k := by
  obtain ⟨hi, hj, hk⟩ := rotation_basis i j k d
  simp only [diffRepeated, diffDistinct, repeated, blade, map_add, action_pure, hi, hj, hk,
    wedgeTwo_add_left, wedgeTwo_smul_left, add_tmul, tmul_add, ← smul_tmul', tmul_smul]
  module

private theorem flip_differences (i j k p : Axis) (d : Distinct i j k) (hpi : p ≠ i) (hpj : p ≠ j) (hpk : p ≠ k) :
    tensorAction (doubleFlip i p) (diffRepeated i j k) = diffRepeated i j k ∧
      tensorAction (doubleFlip i p) (diffDistinct i j k) = -diffDistinct i j k := by
  let c := fun a => axisFlip i a * axisFlip p a
  have h (a : Axis) : (doubleFlip i p).val (e a) = c a • e (id a) := doubleFlip_basis _ _ _
  have hi : c i = -1 := by simp [c, axisFlip, Ne.symm hpi]
  have hj : c j = 1 := by simp [c, axisFlip, Ne.symm d.1, Ne.symm hpj]
  have hk : c k = 1 := by simp [c, axisFlip, Ne.symm d.2.1, Ne.symm hpk]
  simp only [diffRepeated, diffDistinct, repeated, map_sub, map_add, action_blade_scaled _ id c h,
    id_eq, hi, hj, hk]
  constructor <;> module

private theorem mix_differences (W : Submodule ℂ VTwo) (hW : Stable W) (i j k : Axis) (d : Distinct i j k) :
    diffRepeated i j k ∈ W ↔ diffDistinct i j k ∈ W := by
  obtain ⟨p, hpi, hpj, hpk⟩ := exists_pivot i j k d
  obtain ⟨hD, hT⟩ := flip_differences i j k p d hpi hpj hpk
  let g := rotation i j d.1
  let f := doubleFlip i p
  constructor
  · intro hx
    have hw := W.sub_mem (hW g _ hx) (hW f _ (hW g _ hx))
    change tensorAction (rotation i j d.1) (diffRepeated i j k) -
      tensorAction (doubleFlip i p) (tensorAction (rotation i j d.1) (diffRepeated i j k)) ∈ W at hw
    rw [rotation_repeated i j k d, map_add, map_smul, map_smul, hD, hT] at hw
    apply basis_mem_of_scaled W _ (-672 / 625 : ℂ) (by norm_num)
    convert hw using 1
    module
  · intro hx
    have hw := W.add_mem (hW g _ hx) (hW f _ (hW g _ hx))
    change tensorAction (rotation i j d.1) (diffDistinct i j k) +
      tensorAction (doubleFlip i p) (tensorAction (rotation i j d.1) (diffDistinct i j k)) ∈ W at hw
    rw [rotation_distinct i j k d, map_add, map_smul, map_smul, hD, hT] at hw
    apply basis_mem_of_scaled W _ (672 / 625 : ℂ) (by norm_num)
    convert hw using 1
    module

private theorem move_repeated (W : Submodule ℂ VTwo) (hW : Stable W) {i j k a b c : Axis}
    (d : Distinct i j k) (d' : Distinct a b c) (h : diffRepeated i j k ∈ W) : diffRepeated a b c ∈ W := by
  obtain ⟨σ, hσ⟩ := Equiv.Perm.exists_extending_pair ![i, j, k] ![a, b, c]
    (axes_triple_injective _ _ _ d) (axes_triple_injective _ _ _ d')
  obtain ⟨p, _, _, hpk⟩ := exists_pivot i j k d
  have hi : σ i = a := hσ 0
  have hj : σ j = b := hσ 1
  have hk : σ k = c := hσ 2
  have hw := hW (orientedPermAt σ p) _ h
  rwa [diffRepeated, map_sub, action_oriented_repeated _ _ _ _ (Ne.symm hpk),
    action_oriented_repeated _ _ _ _ (Ne.symm hpk), hi, hj, hk] at hw

private theorem some_difference (W : Submodule ℂ VTwo) (hW : Stable W) (hle : W ≤ hook) (hne : W ≠ ⊥) :
    ∃ i j k, Distinct i j k ∧ diffRepeated i j k ∈ W := by
  obtain ⟨x, s, hx, hx0, hs⟩ := block_in_submodule W hW hne
  let i := column s.2 0
  let j := column s.2 1
  by_cases hi : s.1 = i
  · have h : parity s = {j} := by
      rw [parity, columns, hi]
      simp [i, j, column_ne s.2]
    obtain ⟨a, b, hab, hw⟩ := singleton_extract W hW hle j x hx hx0 (fun t ht => (hs t ht).trans h)
    exact ⟨a, b, j, hab, hw⟩
  · by_cases hj : s.1 = j
    · have h : parity s = {i} := by
        rw [parity, columns, hj]
        change (if j ∈ ({i, j} : Finset Axis) then ({i, j} : Finset Axis).erase j else insert j {i, j}) = {i}
        rw [show ({i, j} : Finset Axis) = {j, i} from Finset.pair_comm i j]
        simp
        exact Ne.symm (column_ne s.2)
      obtain ⟨a, b, hab, hw⟩ := singleton_extract W hW hle i x hx hx0 (fun t ht => (hs t ht).trans h)
      exact ⟨a, b, i, hab, hw⟩
    · have h : parity s = {s.1, i, j} := by
        rw [parity, columns]
        simp [hi, hj, i, j]
      obtain ⟨a, b, c, d, hw⟩ := triple_extract W hW hle s.1 i j
        ⟨hi, hj, column_ne s.2⟩ x hx hx0 (fun t ht => (hs t ht).trans h)
      exact ⟨a, b, c, d, (mix_differences W hW a b c d).mpr hw⟩

private theorem residual_repeated_mem (W : Submodule ℂ VTwo)
    (hD : ∀ i j k, Distinct i j k → diffRepeated i j k ∈ W) (i k : Axis) (hik : i ≠ k) :
    residual (repeated i k) ∈ W := by
  classical
  let s := (Finset.univ : Finset Axis).erase k
  have hsum : (∑ j ∈ s, diffRepeated i j k) ∈ W := by
    apply W.sum_mem
    intro j hj
    have hjk : j ≠ k := (Finset.mem_erase.mp hj).1
    by_cases hij : i = j
    · subst j; simp [diffRepeated]
    · exact hD _ _ _ ⟨hij, hik, hjk⟩
  have hN : s.card = 13 := by
    change ((Finset.univ : Finset Axis).erase k).card = 13
    rw [Finset.card_erase_of_mem (Finset.mem_univ k), Finset.card_univ, Fintype.card_fin]
  have hS : (∑ j ∈ s, repeated j k) = ∑ j, repeated j k := by
    have he := Finset.sum_erase_add (Finset.univ : Finset Axis) (fun j => repeated j k) (Finset.mem_univ k)
    rwa [repeated_self, add_zero] at he
  have ha : alternation (repeated i k) = 0 := (alternation_pure _ _ _).trans (wedgeThree_repeat _ _)
  have hformula : residual (repeated i k) = (13 : ℂ)⁻¹ • ∑ j ∈ s, diffRepeated i j k := by
    simp only [residual, LinearMap.sub_apply, LinearMap.id_apply, LinearMap.comp_apply, ha, map_zero, sub_zero,
      trace_repeated i k hik, includeVector_apply, diffRepeated, Finset.sum_sub_distrib, Finset.sum_const, hN, hS]
    change repeated i k - (13 : ℂ)⁻¹ • (∑ j, repeated j k) = _
    rw [← Nat.cast_smul_eq_nsmul ℂ]
    module
  rw [hformula]
  exact W.smul_mem _ hsum

private theorem residual_distinct_mem (W : Submodule ℂ VTwo)
    (hT : ∀ i j k, Distinct i j k → diffDistinct i j k ∈ W) (i j k : Axis) (d : Distinct i j k) :
    residual (blade i j k) ∈ W := by
  have hformula : residual (blade i j k) = (3 : ℂ)⁻¹ • (diffDistinct i j k - diffDistinct i k j) := by
    have ha : alternation (blade i j k) = wedgeThree (e i) (e j) (e k) := alternation_pure _ _ _
    simp only [residual, LinearMap.sub_apply, LinearMap.id_apply, LinearMap.comp_apply, ha,
      trace_distinct i j k d, map_zero, sub_zero, includeThree_pure, cyclicTensor, diffDistinct]
    change blade i j k - (3 : ℂ)⁻¹ • (blade i j k + blade j k i + blade k i j) = _
    rw [blade_swap j k i, blade_swap i j k]
    module
  rw [hformula]
  exact W.smul_mem _ (W.sub_mem (hT i j k d) (hT i k j ⟨d.2.1, d.1, Ne.symm d.2.2⟩))

private theorem hook_invariant_subspace (W : Submodule ℂ VTwo) (hW : Stable W) (hle : W ≤ hook) :
    W = ⊥ ∨ W = hook := by
  by_cases hne : W = ⊥
  · exact Or.inl hne
  right
  obtain ⟨i, j, k, d, h⟩ := some_difference W hW hle hne
  have hD (a b c : Axis) (d' : Distinct a b c) : diffRepeated a b c ∈ W := move_repeated W hW d d' h
  have hT (a b c : Axis) (d' : Distinct a b c) : diffDistinct a b c ∈ W :=
    (mix_differences W hW a b c d').mp (hD a b c d')
  have hb (s : Axis × Index 2) : residual (tensorBasis s) ∈ W := by
    rw [tensorBasis_blade]
    let i := column s.2 0
    let j := column s.2 1
    have hij : i ≠ j := column_ne s.2
    change residual (blade s.1 i j) ∈ W
    by_cases hi : s.1 = i
    · rw [hi]
      exact residual_repeated_mem W hD i j hij
    · by_cases hj : s.1 = j
      · rw [hj, blade_swap j j i, map_neg]
        exact W.neg_mem (residual_repeated_mem W hD j i (Ne.symm hij))
      · exact residual_distinct_mem W hT _ _ _ ⟨hi, hj, hij⟩
  apply le_antisymm hle
  intro x hx
  have hres : residual x = x := by
    have hk := (mem_hook x).mp hx
    simp [residual, hk.1, hk.2]
  rw [← hres, ← tensorBasis.sum_repr x, map_sum]
  exact W.sum_mem fun s _ => by rw [map_smul]; exact W.smul_mem _ (hb s)

/-- The 896-dimensional joint kernel of alternation and trace is irreducible
under the complex split special orthogonal group. -/
theorem hook_isIrreducible : Representation.IsIrreducible (k := ℂ) (V := ↥hook) hookAction := by
  have : Nontrivial (↥hook) := ⟨⟨⟨hookHighest, hookHighest_mem⟩, 0, fun h =>
    hookHighest_ne_zero (congrArg Subtype.val h)⟩⟩
  apply irreducible_of_subrepresentations
  intro U
  let W : Submodule ℂ VTwo := U.toSubmodule.map hook.subtype
  have hW : Stable W := by
    intro g x hx
    obtain ⟨y, hy, rfl⟩ := Submodule.mem_map.mp hx
    exact Submodule.mem_map.mpr ⟨hookAction g y, U.apply_mem_toSubmodule g hy, rfl⟩
  have hle : W ≤ hook := by
    intro x hx
    obtain ⟨y, _, rfl⟩ := Submodule.mem_map.mp hx
    exact y.prop
  rcases hook_invariant_subspace W hW hle with h | h
  · left
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective hook.subtype_injective
    change W = (⊥ : Submodule ℂ (↥hook)).map hook.subtype
    rw [Submodule.map_bot, h]
  · right
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.map_injective_of_injective hook.subtype_injective
    change W = (⊤ : Submodule ℂ (↥hook)).map hook.subtype
    rw [Submodule.map_top, Submodule.range_subtype, h]

/-- The highest-weight candidate generates the whole traceless hook. -/
theorem hookHighest_generates :
    Submodule.span ℂ (Set.range fun g => tensorAction g hookHighest) = hook := by
  let W := Submodule.span ℂ (Set.range fun g => tensorAction g hookHighest)
  have hW : Stable W := by
    intro g x hx
    have hle : W ≤ W.comap (tensorAction g) := by
      apply Submodule.span_le.mpr
      rintro _ ⟨h, rfl⟩
      exact Submodule.subset_span ⟨g * h, by
        change tensorAction (g * h) hookHighest = tensorAction g (tensorAction h hookHighest)
        rw [map_mul]
        rfl⟩
    exact hle hx
  have hle : W ≤ hook := by
    apply Submodule.span_le.mpr
    rintro _ ⟨g, rfl⟩
    exact hook_invariant g _ hookHighest_mem
  have hne : W ≠ ⊥ := by
    intro h
    have hv : hookHighest ∈ W := Submodule.subset_span ⟨1, by
      change tensorAction 1 hookHighest = hookHighest
      rw [map_one]
      rfl⟩
    rw [h, Submodule.mem_bot] at hv
    exact hookHighest_ne_zero hv
  exact (hook_invariant_subspace W hW hle).resolve_left hne

/-- The vector summand uses the same action as the first exterior power. -/
theorem vector_isIrreducible : vectorAction.IsIrreducible := by
  have : Nontrivial Space := ⟨⟨e 0, 0, e.ne_zero 0⟩⟩
  apply irreducible_of_subrepresentations
  intro U
  let f := exteriorPower.oneEquiv ℂ Space
  let W := U.toSubmodule.comap f.toLinearMap
  have hW : D7Irreducible.Stable W := by
    intro g x hx
    change f (exteriorRepresentation 1 g x) ∈ U.toSubmodule
    have h := LinearMap.congr_fun (exteriorPower.oneEquiv_naturality g.val) x
    change f (exteriorRepresentation 1 g x) = vectorAction g (f x) at h
    rw [h]
    exact U.apply_mem_toSubmodule g hx
  rcases exterior_irreducible 1 (by decide) W hW with h | h
  · left
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.comap_injective_of_surjective f.surjective
    change W = (⊥ : Submodule ℂ Space).comap f.toLinearMap
    rw [h, Submodule.comap_bot, LinearMap.ker_eq_bot.mpr f.injective]
  · right
    apply Subrepresentation.toSubmodule_injective
    apply Submodule.comap_injective_of_surjective f.surjective
    change W = (⊤ : Submodule ℂ Space).comap f.toLinearMap
    rw [h, Submodule.comap_top]

end
end GeometricUnity.D7Hook
