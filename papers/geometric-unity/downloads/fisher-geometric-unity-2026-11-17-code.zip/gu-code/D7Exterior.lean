import D7Counts
import Mathlib.Data.Complex.Basic
import Mathlib.Data.Rat.Defs
import Mathlib.LinearAlgebra.ExteriorPower.Basis
import Mathlib.LinearAlgebra.Basis.VectorSpace
import Mathlib.LinearAlgebra.Transvection.Basic
import Mathlib.RepresentationTheory.FDRep
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-!
# Weights of the exterior powers of the D₇ vector representation

The split basis is ordered `+e₁, -e₁, …, +e₇, -e₇`. The exterior basis
realizes the weight multisets used by `D7Counts`. In each degree, the
listed highest-weight candidates are nonzero torus weight vectors fixed
by the positive-root unipotents. The final checks evaluate the Weyl
products for these labels and compare them with the exterior dimensions.
-/

namespace GeometricUnity.D7Exterior

open scoped BigOperators

abbrev Axis := Fin 14
abbrev Pair := Fin 7
abbrev Space := Axis → ℂ
abbrev Index (k : ℕ) := Set.powersetCard Axis k

def pairIndex (j : Axis) : Pair := ⟨j.val / 2, by omega⟩

def axisSign (j : Axis) : ℤ := if j.val % 2 = 0 then 1 else -1

def axisWeight (j : Axis) (i : Pair) : ℤ :=
  if pairIndex j = i then axisSign j else 0

def subsetWeight (s : Finset Axis) (i : Pair) : ℤ := ∑ j ∈ s, axisWeight j i

def scale (t : Pair → ℂˣ) (j : Axis) : ℂˣ := t (pairIndex j) ^ axisSign j

def torus (t : Pair → ℂˣ) : Space →ₗ[ℂ] Space where
  toFun v j := (scale t j : ℂ) * v j
  map_add' v w := by ext j; exact mul_add _ _ _
  map_smul' c v := by ext j; exact mul_left_comm _ _ _

noncomputable def axisBasis : Module.Basis Axis ℂ Space := Pi.basisFun ℂ Axis

theorem torus_axis (t : Pair → ℂˣ) (j : Axis) :
    torus t (axisBasis j) = (scale t j : ℂ) • axisBasis j := by
  ext l
  change (scale t l : ℂ) * (axisBasis j) l = (scale t j : ℂ) * (axisBasis j) l
  by_cases h : l = j
  · subst l; rfl
  · simp [axisBasis, Pi.basisFun_apply, h]

private theorem scale_product (t : Pair → ℂˣ) (j : Axis) :
    (∏ i : Pair, t i ^ axisWeight j i) = scale t j := by
  rw [Finset.prod_eq_single (pairIndex j)]
  · simp [axisWeight, scale]
  · intro i _ hi
    simp [axisWeight, Ne.symm hi]
  · simp

private theorem pow_sum (t : ℂˣ) (s : Finset Axis) (w : Axis → ℤ) :
    t ^ (∑ j ∈ s, w j) = ∏ j ∈ s, t ^ w j := by
  induction s using Finset.induction_on with
  | empty => simp
  | @insert j s hj ih => simp [hj, zpow_add, ih]

theorem subset_character (t : Pair → ℂˣ) (s : Finset Axis) :
    (∏ j ∈ s, scale t j) = ∏ i : Pair, t i ^ subsetWeight s i := by
  simp only [← scale_product t, subsetWeight, pow_sum]
  exact Finset.prod_comm

/-- Every exterior basis vector is a weight vector for the diagonal torus. -/
theorem torus_exterior (t : Pair → ℂˣ) (k : ℕ) (s : Index k) :
    exteriorPower.map k (torus t) (axisBasis.exteriorPower k s) =
      ((∏ i : Pair, t i ^ subsetWeight s.val i : ℂˣ) : ℂ) • axisBasis.exteriorPower k s := by
  rw [← subset_character, exteriorPower.basis_apply, exteriorPower.map_apply_ιMulti_family]
  let e := s.val.orderIsoOfFin s.prop
  change exteriorPower.ιMulti ℂ k (fun j => torus t (axisBasis (e j).val)) =
    ((∏ j ∈ s.val, scale t j : ℂˣ) : ℂ) •
      exteriorPower.ιMulti ℂ k (fun j => axisBasis (e j).val)
  simp only [torus_axis]
  rw [AlternatingMap.map_smul_univ]
  congr 1
  rw [Units.coe_prod]
  trans ∏ j : s.val, (scale t j.val : ℂ)
  · exact Fintype.prod_equiv e.toEquiv (fun j => (scale t (e j).val : ℂ))
      (fun j => (scale t j.val : ℂ)) fun _ ↦ rfl
  · exact Finset.prod_coe_sort s.val (fun j => (scale t j : ℂ))

def axisLabel (j : Axis) : D7Counts.Weight := List.ofFn (axisWeight j)

theorem vector_weights_eq : (List.ofFn axisLabel) = D7Counts.vectorWeights := by
  decide +kernel

private theorem add_labels (u v : Pair → ℤ) :
    D7Counts.addWeight (List.ofFn u) (List.ofFn v) = List.ofFn fun i => u i + v i := by
  simp only [D7Counts.addWeight]
  apply List.ext_getElem
  · simp
  · intro n h₁ h₂
    simp

private theorem selected_label (l : List Axis) (v : Pair → ℤ) :
    (l.map axisLabel).foldl D7Counts.addWeight (List.ofFn v) =
      List.ofFn fun i => v i + (l.map fun j => axisWeight j i).sum := by
  induction l generalizing v with
  | nil => simp
  | cons a l ih =>
    simp only [List.map_cons, List.foldl_cons, axisLabel, add_labels, ih, List.sum_cons, add_assoc]

private theorem choosePositions_map {α β : Type} (f : α → β) (k : ℕ) (l : List α) :
    D7Counts.choosePositions k (l.map f) = (D7Counts.choosePositions k l).map (List.map f) := by
  induction l generalizing k with
  | nil => cases k <;> rfl
  | cons a l ih =>
    cases k with
    | zero => rfl
    | succ k => simp [D7Counts.choosePositions, ih, List.map_map, Function.comp_def]

private theorem choosePositions_perm {α : Type} (k : ℕ) (l : List α) :
    (D7Counts.choosePositions k l).Perm (l.sublistsLen k) := by
  induction l generalizing k with
  | nil => cases k <;> exact List.Perm.refl _
  | cons a l ih =>
    cases k with
    | zero => simp [D7Counts.choosePositions]
    | succ k =>
      rw [D7Counts.choosePositions, List.sublistsLen_succ_cons]
      exact List.perm_append_comm.trans ((ih (k + 1)).append ((ih k).map (a :: ·)))

private theorem chosen_subsets {α : Type} (k : ℕ) (l : List α) :
    (((D7Counts.choosePositions k l).map ((↑) : List α → Multiset α)) : Multiset (Multiset α)) =
      Multiset.powersetCard k (l : Multiset α) := by
  rw [Multiset.powersetCard_coe]
  exact Quot.sound ((choosePositions_perm k l).map ((↑) : List α → Multiset α))

def exteriorBasisLabels (k : ℕ) : Multiset D7Counts.Weight :=
  ((Finset.univ : Finset Axis).powersetCard k).val.map fun s => List.ofFn (subsetWeight s)

/-- The case computation uses the weights of the exterior basis, with their multiplicities. -/
theorem exterior_weights_eq (k : ℕ) :
    (D7Counts.exteriorWeights k : Multiset D7Counts.Weight) = exteriorBasisLabels k := by
  have haxes : ((List.ofFn (id : Axis → Axis) : List Axis) : Multiset Axis) = Finset.univ.val := by
    decide +kernel
  have hlabel : D7Counts.vectorWeights = (List.ofFn (id : Axis → Axis)).map axisLabel := by
    rw [← vector_weights_eq, List.map_ofFn]
    rfl
  let weight (s : Multiset Axis) : D7Counts.Weight :=
    List.ofFn fun i => (s.map fun j => axisWeight j i).sum
  calc
    _ = ((Multiset.powersetCard k ((List.ofFn (id : Axis → Axis) : List Axis) : Multiset Axis))).map weight := by
      rw [D7Counts.exteriorWeights, hlabel, choosePositions_map, ← chosen_subsets,
        List.map_map, Multiset.map_coe, List.map_map]
      congr 1
      apply List.map_congr_left
      intro l _
      change (l.map axisLabel).foldl D7Counts.addWeight D7Counts.zeroWeight = weight l
      rw [D7Counts.zeroWeight, ← List.ofFn_const, selected_label]
      simp [weight]
    _ = _ := by
      rw [haxes, ← Finset.map_val_val_powersetCard, Multiset.map_map]
      rfl

def lastMinus : Index 7 := ⟨{0, 2, 4, 6, 8, 10, 13}, by change Finset.card _ = 7; decide⟩

theorem lastMinus_weight : List.ofFn (subsetWeight lastMinus.val) = D7Counts.muMinus := by
  decide +kernel

def plusAxis (i : Pair) : Axis := ⟨2 * i.val, by omega⟩
def minusAxis (i : Pair) : Axis := ⟨2 * i.val + 1, by omega⟩

private def splitTerm (v w : Space) (i : Pair) : ℂ :=
  v (plusAxis i) * w (minusAxis i) + v (minusAxis i) * w (plusAxis i)

/-- The bilinear form in the null basis. -/
def splitForm (v w : Space) : ℂ := ∑ i : Pair, splitTerm v w i

private theorem plus_injective : Function.Injective plusAxis := by
  intro i j h
  have hn := congrArg Fin.val h
  change 2 * i.val = 2 * j.val at hn
  exact Fin.ext (by omega)

private theorem minus_injective : Function.Injective minusAxis := by
  intro i j h
  have hn := congrArg Fin.val h
  change 2 * i.val + 1 = 2 * j.val + 1 at hn
  exact Fin.ext (by omega)

private theorem plus_ne_minus (i j : Pair) : plusAxis i ≠ minusAxis j := by
  intro h
  have hn := congrArg Fin.val h
  change 2 * i.val = 2 * j.val + 1 at hn
  omega

private theorem minus_ne_plus (i j : Pair) : minusAxis i ≠ plusAxis j :=
  Ne.symm (plus_ne_minus j i)

theorem torus_preserves_splitForm (t : Pair → ℂˣ) (v w : Space) :
    splitForm (torus t v) (torus t w) = splitForm v w := by
  apply Finset.sum_congr rfl
  intro i _
  have hp : pairIndex (plusAxis i) = i := Fin.ext (by
    change (2 * i.val) / 2 = i.val
    omega)
  have hm : pairIndex (minusAxis i) = i := Fin.ext (by
    change (2 * i.val + 1) / 2 = i.val
    omega)
  have hsp : axisSign (plusAxis i) = 1 := if_pos (by change (2 * i.val) % 2 = 0; omega)
  have hsm : axisSign (minusAxis i) = -1 := if_neg (by change (2 * i.val + 1) % 2 ≠ 0; omega)
  change (scale t (plusAxis i) : ℂ) * v (plusAxis i) *
      ((scale t (minusAxis i) : ℂ) * w (minusAxis i)) +
    (scale t (minusAxis i) : ℂ) * v (minusAxis i) *
      ((scale t (plusAxis i) : ℂ) * w (plusAxis i)) =
    v (plusAxis i) * w (minusAxis i) + v (minusAxis i) * w (plusAxis i)
  have hc : (scale t (plusAxis i) : ℂ) * (scale t (minusAxis i) : ℂ) = 1 := by
    rw [← Units.val_mul]
    simp [scale, hp, hm, hsp, hsm]
  linear_combination (v (plusAxis i) * w (minusAxis i) +
    v (minusAxis i) * w (plusAxis i)) * hc

theorem torus_det (t : Pair → ℂˣ) : (torus t).det = 1 := by
  have hzero : ∀ i : Pair, subsetWeight Finset.univ i = 0 := by decide +kernel
  calc
    (torus t).det = axisBasis.det (torus t ∘ axisBasis) := by
      rw [Module.Basis.det_comp, Module.Basis.det_self, mul_one]
    _ = ∏ j : Axis, (scale t j : ℂ) := by
      simp only [Function.comp_def, torus_axis, AlternatingMap.map_smul_univ,
        Module.Basis.det_self, smul_eq_mul, mul_one]
    _ = 1 := by rw [← Units.coe_prod, subset_character]; simp [hzero]

private def highestAxes (k : Fin 15) : Finset Axis :=
  Finset.univ.filter fun a =>
    if k.val ≤ 7 then a.val % 2 = 0 ∧ a.val / 2 < k.val
    else a.val % 2 = 0 ∨ 14 - k.val ≤ a.val / 2

private theorem highestAxes_card : ∀ k : Fin 15, (highestAxes k).card = k.val := by
  decide +kernel

/-- In degrees above seven, keep all positive axes and include both axes of
the last `k - 7` pairs. -/
def highestPlus (k : Fin 15) : Index k.val := ⟨highestAxes k, highestAxes_card k⟩

private noncomputable def elementary (p q : Axis) : Space →ₗ[ℂ] Space :=
  (axisBasis.coord q).smulRight (axisBasis p)

private theorem elementary_axis (p q j : Axis) :
    elementary p q (axisBasis j) = if j = q then axisBasis p else 0 := by
  by_cases h : j = q
  · subst j; simp [elementary]
  · simp [elementary, h, Ne.symm h]

/-- The two signed elementary entries of a positive-root unipotent. -/
noncomputable def rootGroup (c : ℂ) (p q r u : Axis) : Space →ₗ[ℂ] Space :=
  LinearMap.id + c • elementary p q - c • elementary r u

noncomputable def rootMinus (c : ℂ) (i j : Pair) : Space →ₗ[ℂ] Space :=
  rootGroup c (plusAxis i) (plusAxis j) (minusAxis j) (minusAxis i)

noncomputable def rootPlus (c : ℂ) (i j : Pair) : Space →ₗ[ℂ] Space :=
  rootGroup c (plusAxis i) (minusAxis j) (plusAxis j) (minusAxis i)

private theorem rootGroup_factor (c : ℂ) (p q r u : Axis) (hqr : q ≠ r) :
    rootGroup c p q r u = (LinearMap.id + c • elementary p q).comp
      (LinearMap.id + (-c) • elementary r u) := by
  apply axisBasis.ext
  intro j
  by_cases hk : j = u <;>
    simp [rootGroup, LinearMap.comp_apply, elementary_axis, hk, Ne.symm hqr,
      sub_eq_add_neg, add_assoc, add_left_comm, add_comm]

private theorem elementary_transvection_det (c : ℂ) (p q : Axis) (hpq : p ≠ q) :
    (LinearMap.id + c • elementary p q).det = 1 := by
  have he : LinearMap.id + c • elementary p q =
      LinearMap.transvection (axisBasis.coord q) (c • axisBasis p) := by
    apply LinearMap.ext
    intro v
    change v + c • (axisBasis.coord q v • axisBasis p) =
      v + axisBasis.coord q v • (c • axisBasis p)
    rw [smul_comm]
  rw [he, LinearMap.transvection.det]
  simp [Ne.symm hpq]

private theorem rootGroup_det (c : ℂ) (p q r u : Axis) (hpq : p ≠ q) (hru : r ≠ u)
    (hqr : q ≠ r) : (rootGroup c p q r u).det = 1 := by
  rw [rootGroup_factor c p q r u hqr, LinearMap.det_comp,
    elementary_transvection_det _ _ _ hpq, elementary_transvection_det _ _ _ hru, mul_one]

theorem rootMinus_det (c : ℂ) (i j : Pair) (h : i < j) : (rootMinus c i j).det = 1 :=
  rootGroup_det _ _ _ _ _ (fun e => (ne_of_lt h) (plus_injective e))
    (fun e => (ne_of_gt h) (minus_injective e)) (plus_ne_minus j j)

theorem rootPlus_det (c : ℂ) (i j : Pair) : (rootPlus c i j).det = 1 :=
  rootGroup_det _ _ _ _ _ (plus_ne_minus i j) (plus_ne_minus j i) (minus_ne_plus j j)

private theorem rootGroup_coord (c : ℂ) (p q r u : Axis) (v : Space) (l : Axis) :
    rootGroup c p q r u v l = v l + (if l = p then c * v q else 0) -
      (if l = r then c * v u else 0) := by
  change v l + c * ((axisBasis.coord q v : ℂ) * axisBasis p l) -
    c * ((axisBasis.coord u v : ℂ) * axisBasis r l) = _
  simp [axisBasis, Module.Basis.coord_apply, Pi.basisFun_repr, Pi.basisFun_apply,
    Pi.single_apply, mul_ite]

private theorem sum_eq_of_pair (f g : Pair → ℂ) (i j : Pair) (h : i ≠ j)
    (hout : ∀ l, l ≠ i → l ≠ j → f l = g l) (hin : f i + f j = g i + g j) :
    ∑ l, f l = ∑ l, g l := by
  rw [← sub_eq_zero, ← Finset.sum_sub_distrib, ← Finset.sum_subset
    (s₁ := {i, j}) (s₂ := Finset.univ) (Finset.subset_univ _)]
  · rw [Finset.sum_pair h]
    linear_combination hin
  · intro l _ hl
    simp only [Finset.mem_insert, Finset.mem_singleton, not_or] at hl
    rw [hout l hl.1 hl.2, sub_self]

theorem rootMinus_preserves_splitForm (c : ℂ) (i j : Pair) (h : i < j) (v w : Space) :
    splitForm (rootMinus c i j v) (rootMinus c i j w) = splitForm v w := by
  apply sum_eq_of_pair _ _ i j (ne_of_lt h)
  · intro l hi hj
    simp [splitTerm, rootMinus, rootGroup_coord, plus_ne_minus, minus_ne_plus,
      plus_injective.eq_iff, minus_injective.eq_iff, hi, hj]
  · simp [splitTerm, rootMinus, rootGroup_coord, plus_ne_minus, minus_ne_plus,
      plus_injective.eq_iff, minus_injective.eq_iff, ne_of_lt h, ne_of_gt h]
    ring

theorem rootPlus_preserves_splitForm (c : ℂ) (i j : Pair) (h : i < j) (v w : Space) :
    splitForm (rootPlus c i j v) (rootPlus c i j w) = splitForm v w := by
  apply sum_eq_of_pair _ _ i j (ne_of_lt h)
  · intro l hi hj
    simp [splitTerm, rootPlus, rootGroup_coord, minus_ne_plus, plus_injective.eq_iff, hi, hj]
  · simp [splitTerm, rootPlus, rootGroup_coord, minus_ne_plus, plus_injective.eq_iff,
      ne_of_lt h, ne_of_gt h]
    ring

/-- The split special orthogonal elements, realized by their endomorphisms.
The determinant-one condition ensures invertibility. -/
noncomputable def splitSpecialOrthogonal : Submonoid (Module.End ℂ Space) where
  carrier := {f | f.det = 1 ∧ ∀ v w, splitForm (f v) (f w) = splitForm v w}
  one_mem' := ⟨map_one LinearMap.det, fun _ _ => rfl⟩
  mul_mem' := by
    rintro f g ⟨hf, hformf⟩ ⟨hg, hformg⟩
    exact ⟨by rw [map_mul, hf, hg, mul_one], fun v w => (hformf (g v) (g w)).trans (hformg v w)⟩

noncomputable def torusElement (t : Pair → ℂˣ) : splitSpecialOrthogonal :=
  ⟨torus t, torus_det t, torus_preserves_splitForm t⟩

noncomputable def rootMinusElement (c : ℂ) (i j : Pair) (h : i < j) : splitSpecialOrthogonal :=
  ⟨rootMinus c i j, rootMinus_det c i j h, rootMinus_preserves_splitForm c i j h⟩

noncomputable def rootPlusElement (c : ℂ) (i j : Pair) (h : i < j) : splitSpecialOrthogonal :=
  ⟨rootPlus c i j, rootPlus_det c i j, rootPlus_preserves_splitForm c i j h⟩

/-- The first positive axis is fixed by the positive-root maps of the vector action. -/
theorem firstAxis_root_fixed (c : ℂ) (i j : Pair) (h : i < j) :
    (rootMinusElement c i j h).val (axisBasis (plusAxis 0)) = axisBasis (plusAxis 0) ∧
    (rootPlusElement c i j h).val (axisBasis (plusAxis 0)) = axisBasis (plusAxis 0) := by
  have hj : (0 : Pair) ≠ j := (lt_of_le_of_lt (Fin.zero_le i) h).ne
  have haxis : plusAxis 0 ≠ plusAxis j := fun e => hj (plus_injective e)
  change rootMinus c i j (axisBasis (plusAxis 0)) = _ ∧ rootPlus c i j (axisBasis (plusAxis 0)) = _
  simp [rootMinus, rootPlus, rootGroup, elementary_axis, haxis, plus_ne_minus]

noncomputable def exteriorRepresentation (k : ℕ) :
    Representation ℂ splitSpecialOrthogonal (⋀[ℂ]^k Space) where
  toFun f := exteriorPower.map k f.val
  map_one' := exteriorPower.map_id
  map_mul' f g := exteriorPower.map_comp g.val f.val

noncomputable def exteriorFDRep (k : ℕ) : FDRep ℂ splitSpecialOrthogonal :=
  FDRep.of (exteriorRepresentation k)

theorem splitSpecialOrthogonal_isUnit (f : splitSpecialOrthogonal) : IsUnit f.val :=
  (LinearMap.isUnit_iff_isUnit_det f.val).mpr (f.property.1 ▸ isUnit_one)

private theorem wedge_fixed_by_single_addition (k : ℕ) (s : Index k) (f : Space →ₗ[ℂ] Space)
    (c : ℂ) (p q : Axis) (hpq : p ≠ q) (hmem : q ∈ s.val → p ∈ s.val)
    (hf : ∀ j ∈ s.val, f (axisBasis j) = axisBasis j + if j = q then c • axisBasis p else 0) :
    exteriorPower.map k f (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s := by
  let e := Set.powersetCard.ofFinEmbEquiv.symm s
  let v : Fin k → Space := axisBasis ∘ e
  rw [exteriorPower.basis_apply, exteriorPower.map_apply_ιMulti_family]
  change exteriorPower.ιMulti ℂ k (fun j => f (v j)) = exteriorPower.ιMulti ℂ k v
  have he (j : Fin k) : e j ∈ s.val :=
    Finset.orderEmbOfFin_mem s.val s.prop j
  by_cases hq : q ∈ s.val
  · obtain ⟨a, ha⟩ := (Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem s q).mpr hq
    obtain ⟨b, hb⟩ := (Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem s p).mpr (hmem hq)
    change e a = q at ha
    change e b = p at hb
    have hab : a ≠ b := fun h => hpq (hb.symm.trans (h ▸ ha))
    have hu : (fun j => f (v j)) = Function.update v a (v a + c • axisBasis p) := by
      funext j
      by_cases h : j = a
      · subst j
        have hfa := hf q hq
        simpa [v, ha] using hfa
      · have h' : e j ≠ q := fun hj => h (e.injective (hj.trans ha.symm))
        simp [v, hf _ (he j), Function.update_of_ne h, h']
    have hz : exteriorPower.ιMulti ℂ k (Function.update v a (axisBasis p)) = 0 := by
      apply (exteriorPower.ιMulti ℂ k).map_eq_zero_of_eq _ (i := a) (j := b) _ hab
      simp [v, Function.update_of_ne hab.symm, hb]
    rw [hu, AlternatingMap.map_update_add, AlternatingMap.map_update_smul, hz,
      smul_zero, add_zero]
    congr 1
    exact Function.update_eq_self a v
  · have hfix (j : Fin k) : f (v j) = v j := by
      have h : e j ≠ q := fun h => hq (h ▸ he j)
      simp [v, hf _ (he j), h]
    simp only [hfix]

private theorem wedge_fixed_by_root (k : ℕ) (s : Index k) (c : ℂ) (p q r u : Axis)
    (hpq : p ≠ q) (hru : r ≠ u) (hqr : q ≠ r)
    (hp : q ∈ s.val → p ∈ s.val) (hr : u ∈ s.val → r ∈ s.val) :
    exteriorPower.map k (rootGroup c p q r u) (axisBasis.exteriorPower k s) =
      axisBasis.exteriorPower k s := by
  let f : Space →ₗ[ℂ] Space := LinearMap.id + c • elementary p q
  let g : Space →ₗ[ℂ] Space := LinearMap.id + (-c) • elementary r u
  have hf : exteriorPower.map k f (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s := by
    apply wedge_fixed_by_single_addition k s f c p q hpq hp
    intro j _
    simp [f, elementary_axis, smul_ite]
  have hg : exteriorPower.map k g (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s := by
    apply wedge_fixed_by_single_addition k s g (-c) r u hru hr
    intro j _
    simp [g, elementary_axis, smul_ite]
  have hcomp : rootGroup c p q r u = f.comp g := rootGroup_factor c p q r u hqr
  rw [hcomp, exteriorPower.map_comp, LinearMap.comp_apply, hg, hf]

private def CanAdd (s : Finset Axis) (p q r u : Axis) : Prop :=
  p ≠ q ∧ r ≠ u ∧ q ≠ r ∧ (q ∈ s → p ∈ s) ∧ (u ∈ s → r ∈ s)

set_option maxRecDepth 4000 in
set_option maxHeartbeats 2000000 in
private theorem highestPlus_positions : ∀ (k : Fin 15) (i j : Pair), i < j →
    CanAdd (highestPlus k).val (plusAxis i) (plusAxis j) (minusAxis j) (minusAxis i) ∧
    CanAdd (highestPlus k).val (plusAxis i) (minusAxis j) (plusAxis j) (minusAxis i) := by
  unfold CanAdd
  decide +kernel

private theorem lastMinus_positions : ∀ i j : Pair, i < j →
    CanAdd lastMinus.val (plusAxis i) (plusAxis j) (minusAxis j) (minusAxis i) ∧
    CanAdd lastMinus.val (plusAxis i) (minusAxis j) (plusAxis j) (minusAxis i) := by
  unfold CanAdd
  decide +kernel

theorem highestPlus_weight : ∀ k : Fin 15,
    List.ofFn (subsetWeight (highestPlus k).val) = D7Counts.mu (min k.val (14 - k.val)) := by
  decide +kernel

private theorem fixed_of_positions (k : ℕ) (s : Index k) (c : ℂ)
    (i j : Pair)
    (h₁ : CanAdd s.val (plusAxis i) (plusAxis j) (minusAxis j) (minusAxis i))
    (h₂ : CanAdd s.val (plusAxis i) (minusAxis j) (plusAxis j) (minusAxis i)) :
    exteriorPower.map k (rootMinus c i j) (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s ∧
      exteriorPower.map k (rootPlus c i j) (axisBasis.exteriorPower k s) = axisBasis.exteriorPower k s := by
  rcases h₁ with ⟨hp₁, hr₁, hqu₁, hq₁, hu₁⟩
  rcases h₂ with ⟨hp₂, hr₂, hqu₂, hq₂, hu₂⟩
  exact ⟨wedge_fixed_by_root k s c _ _ _ _ hp₁ hr₁ hqu₁ hq₁ hu₁,
    wedge_fixed_by_root k s c _ _ _ _ hp₂ hr₂ hqu₂ hq₂ hu₂⟩

/-- In every degree the positive-label wedge is fixed by all positive-root maps. -/
theorem highestPlus_root_fixed (k : Fin 15) (c : ℂ) (i j : Pair) (h : i < j) :
    exteriorRepresentation k.val (rootMinusElement c i j h) (axisBasis.exteriorPower k.val (highestPlus k)) =
        axisBasis.exteriorPower k.val (highestPlus k) ∧
      exteriorRepresentation k.val (rootPlusElement c i j h) (axisBasis.exteriorPower k.val (highestPlus k)) =
        axisBasis.exteriorPower k.val (highestPlus k) :=
  fixed_of_positions _ _ c i j (highestPlus_positions k i j h).1 (highestPlus_positions k i j h).2

/-- The wedge with the seventh axis negative is also fixed by the positive roots. -/
theorem lastMinus_root_fixed (c : ℂ) (i j : Pair) (h : i < j) :
    exteriorRepresentation 7 (rootMinusElement c i j h) (axisBasis.exteriorPower 7 lastMinus) =
        axisBasis.exteriorPower 7 lastMinus ∧
      exteriorRepresentation 7 (rootPlusElement c i j h) (axisBasis.exteriorPower 7 lastMinus) =
        axisBasis.exteriorPower 7 lastMinus :=
  fixed_of_positions _ _ c i j (lastMinus_positions i j h).1 (lastMinus_positions i j h).2

/-- The list of candidate labels is the one used in every exterior grade table. -/
theorem grade_weights_eq : ∀ k : Fin 15,
    D7Counts.gradeWeights k.val = List.ofFn (subsetWeight (highestPlus k).val) ::
      (if k.val = 7 then [List.ofFn (subsetWeight lastMinus.val)] else []) := by
  decide +kernel

theorem highestPlus_ne_zero (k : Fin 15) : axisBasis.exteriorPower k.val (highestPlus k) ≠ 0 :=
  (axisBasis.exteriorPower k.val).ne_zero _

theorem lastMinus_ne_zero : axisBasis.exteriorPower 7 lastMinus ≠ 0 :=
  (axisBasis.exteriorPower 7).ne_zero _

/-- The two middle-grade candidates come from distinct exterior basis vectors. -/
theorem middle_candidates_independent :
    LinearIndependent ℂ (fun i : Fin 2 => axisBasis.exteriorPower 7
      (if i = 0 then highestPlus (7 : Fin 15) else lastMinus)) := by
  apply (axisBasis.exteriorPower 7).linearIndependent.comp
  have hne : highestPlus (7 : Fin 15) ≠ lastMinus := by
    intro h
    have hv := congrArg Subtype.val h
    have hvals : (highestPlus (7 : Fin 15)).val ≠ lastMinus.val := by decide +kernel
    exact hvals hv
  intro i j h
  fin_cases i <;> fin_cases j <;> simp_all

private def orderedPairs : Finset (Pair × Pair) :=
  Finset.univ.filter fun ij => ij.1 < ij.2

/-- The rational product obtained by inserting a label into the D₇ Weyl formula. -/
def weylProduct (w : D7Counts.Weight) : ℚ :=
  let shifted (i : Pair) : ℤ := (6 - (i.val : ℤ)) + w[i.val]?.getD 0
  ∏ ij ∈ orderedPairs,
    (((shifted ij.1)^2 - (shifted ij.2)^2 : ℤ) : ℚ) /
      (((6 - (ij.1.val : ℤ))^2 - (6 - (ij.2.val : ℤ))^2 : ℤ) : ℚ)

theorem weyl_product_values :
    (∀ k : Fin 7, weylProduct (D7Counts.mu k.val) = (Nat.choose 14 k.val : ℚ)) ∧
      weylProduct (D7Counts.mu 7) = 1716 ∧ weylProduct D7Counts.muMinus = 1716 := by
  decide +kernel

/-- The evaluated products exhaust the actual ambient exterior dimensions. -/
theorem grade_products_exhaust_finrank (k : Fin 15) :
    ((D7Counts.gradeWeights k.val).map weylProduct).sum =
      (Module.finrank ℂ (⋀[ℂ]^k.val Space) : ℚ) := by
  rw [exteriorPower.finrank_eq, Module.finrank_pi, Fintype.card_fin]
  have h : ∀ k : Fin 15, ((D7Counts.gradeWeights k.val).map weylProduct).sum =
      (Nat.choose 14 k.val : ℚ) := by decide +kernel
  exact h k

end GeometricUnity.D7Exterior
