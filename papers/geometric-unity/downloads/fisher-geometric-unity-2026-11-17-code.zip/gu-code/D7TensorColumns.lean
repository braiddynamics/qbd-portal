import D7Hook
import D7VectorGrades
import Mathlib.LinearAlgebra.Basis.SMul

/-!
# Coordinate columns of the vector–exterior tensor product

Repeated-index columns are normalized by contraction. Distinct-index columns
are normalized by exterior multiplication. In either family the corresponding
linear map takes every column in a block to the same exterior basis vector.
-/

namespace GeometricUnity.D7TensorColumns

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7Hook TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

private abbrev e := orthBasis

def eraseIndex {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) : Index n :=
  ⟨S.val.erase i, by change (S.val.erase i).card = n; rw [Finset.card_erase_of_mem hi, S.prop]; omega⟩

def insertIndex {n : ℕ} (R : Index n) (i : Axis) (hi : i ∉ R.val) : Index (n + 1) :=
  ⟨insert i R.val, by change (insert i R.val).card = n + 1; rw [Finset.card_insert_of_notMem hi, R.prop]⟩

theorem notMem_eraseIndex {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) :
    i ∉ (eraseIndex S i hi).val := Finset.notMem_erase _ _

set_option backward.isDefEq.respectTransparency false in
theorem basis_eq_wedge_erase {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) :
    ∃ z : ℂ, z ≠ 0 ∧ basis (n + 1) S = z • wedgeLeftLinear n (e i) (basis n (eraseIndex S i hi)) := by
  let R := eraseIndex S i hi
  let a := Set.powersetCard.ofFinEmbEquiv.symm S
  have hm : i ∈ S := hi
  obtain ⟨j, hj⟩ := (Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem S _).mpr hm
  change a j = i at hj
  let d := OrderEmbedding.ofStrictMono (fun k => a (j.succAbove k))
    (a.strictMono.comp (Fin.strictMono_succAbove j))
  have hd (k : Fin n) : d k ∈ R.val := by
    apply Finset.mem_erase.mpr
    refine ⟨?_, Finset.orderEmbOfFin_mem S.val S.prop (j.succAbove k)⟩
    exact fun h => Fin.succAbove_ne j k (a.injective (h.trans hj.symm))
  have he := Finset.orderEmbOfFin_unique' R.prop (f := d) hd
  have hor : j.removeNth (e ∘ a) = e ∘ Set.powersetCard.ofFinEmbEquiv.symm R := by
    funext k
    change e (d k) = e ((R.val.orderEmbOfFin R.prop) k)
    rw [he]
  let z := (-1 : ℤ) ^ j.val
  refine ⟨(z : ℂ), Int.cast_ne_zero.mpr (pow_ne_zero _ (by norm_num)), ?_⟩
  calc
    basis (n + 1) S = z • wedgeLeftLinear n (e i) (basis n R) := by
      rw [exteriorPower.basis_apply, exteriorPower.basis_apply, exteriorPower.ιMulti_family,
        exteriorPower.ιMulti_family, wedgeLeft_pure, ← hor, ← AlternatingMap.map_insertNth]
      have hval : (e ∘ a) j = e i := congrArg e hj
      rw [← hval, Fin.insertNth_self_removeNth]
    _ = (z : ℂ) • wedgeLeftLinear n (e i) (basis n R) := (Int.cast_smul_eq_zsmul ℂ z _).symm

theorem wedgeLeft_basis_zero {n : ℕ} (R : Index n) (i : Axis) (hi : i ∈ R.val) :
    wedgeLeftLinear n (e i) (basis n R) = 0 := by
  change i ∈ R at hi
  obtain ⟨j, hj⟩ := (Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem R i).mpr hi
  rw [exteriorPower.basis_apply, exteriorPower.ιMulti_family, wedgeLeft_pure]
  apply (exteriorPower.ιMulti ℂ (n + 1)).map_eq_zero_of_eq _ (i := 0) (j := j.succ)
  · change e i = e (Set.powersetCard.ofFinEmbEquiv.symm R j)
    rw [hj]
  · exact Ne.symm (Fin.succ_ne_zero j)

theorem contractLeft_basis_zero {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∉ S.val) :
    contractLeft n (e i) (basis (n + 1) S) = 0 := by
  rw [exteriorPower.basis_apply, exteriorPower.ιMulti_family, contractLeft_pure]
  apply Finset.sum_eq_zero
  intro j _
  let a := Set.powersetCard.ofFinEmbEquiv.symm S
  have hm : a j ∈ S.val := Finset.orderEmbOfFin_mem S.val S.prop j
  have he : i ≠ Set.powersetCard.ofFinEmbEquiv.symm S j := fun hc => hi (hc.symm ▸ hm)
  simp only [Function.comp_apply, orthBasis_pair, if_neg he, zero_smul, smul_zero]

theorem contract_wedge_basis {n : ℕ} (R : Index n) (i : Axis) (hi : i ∉ R.val) :
    contractLeft n (e i) (wedgeLeftLinear n (e i) (basis n R)) = basis n R := by
  cases n with
  | zero => rw [contract_wedgeLeft_zero, orthBasis_pair, if_pos rfl, one_smul]
  | succ n =>
    rw [contract_wedgeLeft, orthBasis_pair, if_pos rfl, one_smul, contractLeft_basis_zero R i hi,
      map_zero, sub_zero]

theorem wedgeLeft_sq {n : ℕ} (x : Space) (u : Ext n) :
    wedgeLeftLinear (n + 1) x (wedgeLeftLinear n x u) = 0 := by
  apply Subtype.ext
  change ExteriorAlgebra.ι ℂ x * (ExteriorAlgebra.ι ℂ x * u.val) = 0
  rw [← mul_assoc, ExteriorAlgebra.ι_sq_zero, zero_mul]

theorem wedgeLeft_swap {n : ℕ} (x y : Space) (u : Ext n) :
    wedgeLeftLinear (n + 1) x (wedgeLeftLinear n y u) =
      -wedgeLeftLinear (n + 1) y (wedgeLeftLinear n x u) := by
  apply Subtype.ext
  change ExteriorAlgebra.ι ℂ x * (ExteriorAlgebra.ι ℂ y * u.val) =
    -(ExteriorAlgebra.ι ℂ y * (ExteriorAlgebra.ι ℂ x * u.val))
  rw [← mul_assoc, ← mul_assoc, ← neg_mul]
  exact congrArg (fun z => z * u.val)
    (eq_neg_of_add_eq_zero_left (ExteriorAlgebra.ι_add_mul_swap (R := ℂ) x y))

/-- A repeated-index tensor normalized to have unit contraction in its block. -/
def repeated {n : ℕ} (R : Index n) (i : Axis) : Product (n + 1) :=
  e i ⊗ₜ[ℂ] wedgeLeftLinear n (e i) (basis n R)

/-- A distinct-index tensor normalized to have unit alternation in its block. -/
def distinct {n : ℕ} (S : Index (n + 1)) (i : Axis) : Product n :=
  e i ⊗ₜ[ℂ] contractLeft n (e i) (basis (n + 1) S)

theorem repeated_zero {n : ℕ} (R : Index n) (i : Axis) (hi : i ∈ R.val) : repeated R i = 0 := by
  rw [repeated, wedgeLeft_basis_zero R i hi, tmul_zero]

theorem distinct_zero {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∉ S.val) : distinct S i = 0 := by
  rw [distinct, contractLeft_basis_zero S i hi, tmul_zero]

theorem trace_repeated {n : ℕ} (R : Index n) (i : Axis) (hi : i ∉ R.val) :
    contract n (repeated R i) = basis n R := by
  rw [repeated, contract, TensorProduct.lift.tmul, contract_wedge_basis R i hi]

theorem wedge_repeated {n : ℕ} (R : Index n) (i : Axis) : wedge (n + 1) (repeated R i) = 0 := by
  rw [repeated, wedge, TensorProduct.lift.tmul, wedgeLeft_sq]

theorem repeated_column {n : ℕ} (t : Axis × Index (n + 1)) (ht : t.1 ∈ t.2.val) :
    ∃ z : ℂ, z ≠ 0 ∧
      tensorExteriorBasis (n + 1) t = z • repeated (eraseIndex t.2 t.1 ht) t.1 := by
  obtain ⟨z, hz, h⟩ := basis_eq_wedge_erase t.2 t.1 ht
  refine ⟨z, hz, ?_⟩
  rw [tensorExteriorBasis, Module.Basis.tensorProduct_apply', h, tmul_smul, repeated]

theorem distinct_column {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) :
    ∃ z : ℂ, z ≠ 0 ∧ basis (n + 1) S = z • wedgeLeftLinear n (e i) (basis n (eraseIndex S i hi)) ∧
      distinct S i = z • tensorExteriorBasis n (i, eraseIndex S i hi) := by
  obtain ⟨z, hz, h⟩ := basis_eq_wedge_erase S i hi
  refine ⟨z, hz, h, ?_⟩
  rw [distinct, h, map_smul, contract_wedge_basis _ _ (notMem_eraseIndex S i hi),
    tmul_smul, tensorExteriorBasis, Module.Basis.tensorProduct_apply']

theorem wedge_distinct {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) :
    wedge n (distinct S i) = basis (n + 1) S := by
  obtain ⟨z, _, h, hD⟩ := distinct_column S i hi
  rw [hD, map_smul, tensorExteriorBasis, Module.Basis.tensorProduct_apply', wedge, TensorProduct.lift.tmul, ← h]

theorem trace_distinct {n : ℕ} (S : Index (n + 2)) (i : Axis) : contract n (distinct S i) = 0 := by
  by_cases hi : i ∈ S.val
  · obtain ⟨z, _, _, hz⟩ := distinct_column S i hi
    rw [hz, map_smul, tensorExteriorBasis, Module.Basis.tensorProduct_apply', contract, TensorProduct.lift.tmul,
      contractLeft_basis_zero _ _ (notMem_eraseIndex S i hi), smul_zero]
  · rw [distinct_zero S i hi, map_zero]

theorem column_of_distinct {n : ℕ} (t : Axis × Index n) (ht : t.1 ∉ t.2.val) :
    ∃ z : ℂ, z ≠ 0 ∧ tensorExteriorBasis n t = z • distinct (insertIndex t.2 t.1 ht) t.1 := by
  let S := insertIndex t.2 t.1 ht
  have hi : t.1 ∈ S.val := Finset.mem_insert_self _ _
  have hS : eraseIndex S t.1 hi = t.2 := Subtype.ext (Finset.erase_insert ht)
  obtain ⟨z, hz, _, h⟩ := distinct_column S t.1 hi
  rw [hS] at h
  refine ⟨z⁻¹, inv_ne_zero hz, ?_⟩
  rw [h, smul_smul, inv_mul_cancel₀ hz, one_smul]

theorem includeWedge_basis {n : ℕ} (S : Index (n + 1)) :
    includeWedge n (basis (n + 1) S) = (n + 1 : ℂ)⁻¹ • ∑ i ∈ S.val, distinct S i := by
  let a := Set.powersetCard.ofFinEmbEquiv.symm S
  let v : Fin (n + 1) → Space := e ∘ a
  have hb : basis (n + 1) S = exteriorPower.ιMulti ℂ (n + 1) v := by
    rw [exteriorPower.basis_apply, exteriorPower.ιMulti_family]
  have himage : Finset.univ.map a.toEmbedding = S.val := by
    ext i
    rw [Finset.mem_map]
    change (∃ j : Fin (n + 1), j ∈ Finset.univ ∧ a j = i) ↔ i ∈ S
    simp only [Finset.mem_univ, true_and]
    exact Set.powersetCard.mem_range_ofFinEmbEquiv_symm_iff_mem S i
  have hterm (j : Fin (n + 1)) : distinct S (a j) =
      (-1 : ℤ) ^ j.val • (v j ⊗ₜ[ℂ] exteriorPower.ιMulti ℂ n (j.removeNth v)) := by
    rw [distinct, hb, contractLeft_pure, Finset.sum_eq_single j]
    · have hp : splitForm (e (a j)) (v j) = 1 := by
        change splitForm (e (a j)) (e (a j)) = 1
        simp [orthBasis_pair]
      rw [hp, one_smul]
      simp only [← Int.cast_smul_eq_zsmul ℂ, tmul_smul]
      rfl
    · intro k _ hk
      have he : a j ≠ a k := fun h => hk (a.injective h).symm
      change (-1 : ℤ) ^ k.val • ((splitForm (e (a j)) (e (a k))) • _) = _
      simp [orthBasis_pair, he]
    · simp
  rw [hb, includeWedge_pure, ← himage, Finset.sum_map]
  congr 1
  exact Finset.sum_congr rfl fun j _ => (hterm j).symm

private theorem sub_average {E ι : Type*} [AddCommGroup E] [Module ℂ E]
    (s : Finset ι) (hs : s.card ≠ 0) (v : ι → E) (i : ι) :
    v i - (s.card : ℂ)⁻¹ • ∑ j ∈ s, v j =
      (s.card : ℂ)⁻¹ • ∑ j ∈ s, (v i - v j) := by
  rw [Finset.sum_sub_distrib, Finset.sum_const, smul_sub, ← Nat.cast_smul_eq_nsmul ℂ,
    smul_smul, inv_mul_cancel₀ (Nat.cast_ne_zero.mpr hs), one_smul]

theorem repeated_sub_metric {n : ℕ} (hn : n < 14) (R : Index n) (i : Axis) :
    repeated R i - includeMetric n (basis n R) =
      (14 - (n : ℂ))⁻¹ • ∑ j ∈ R.valᶜ, (repeated R i - repeated R j) := by
  have hcard : R.valᶜ.card = 14 - n := by rw [Finset.card_compl, Fintype.card_fin, R.prop]
  have hsum : ∑ j ∈ R.valᶜ, repeated R j = ∑ j : Axis, repeated R j := by
    apply Finset.sum_subset (Finset.subset_univ _)
    intro j _ hj
    exact repeated_zero R j (by simpa using hj)
  rw [includeMetric_apply]
  change repeated R i - (14 - (n : ℂ))⁻¹ • (∑ j, repeated R j) = _
  rw [← hsum]
  have hcast : (R.valᶜ.card : ℂ) = 14 - (n : ℂ) := by
    rw [hcard, Nat.cast_sub hn.le]
    norm_num
  rw [← hcast]
  exact sub_average R.valᶜ (by rw [hcard]; omega) (repeated R) i

theorem distinct_sub_wedge {n : ℕ} (S : Index (n + 1)) (i : Axis) :
    distinct S i - includeWedge n (basis (n + 1) S) =
      (n + 1 : ℂ)⁻¹ • ∑ j ∈ S.val, (distinct S i - distinct S j) := by
  rw [includeWedge_basis]
  have hcard : S.val.card = n + 1 := S.prop
  have hcast : (S.val.card : ℂ) = (n + 1 : ℂ) := by rw [hcard, Nat.cast_add, Nat.cast_one]
  rw [← hcast]
  exact sub_average S.val (by rw [hcard]; omega) (distinct S) i

/-- Repeated and distinct differences span the simultaneous kernel of
exterior multiplication and contraction in every supported input degree. -/
theorem jointKernel_le_of_differences (n : ℕ) (hn : n < 14) (W : Submodule ℂ (Product (n + 1)))
    (hR : ∀ (R : Index n) i j, i ∉ R.val → j ∉ R.val → repeated R i - repeated R j ∈ W)
    (hS : ∀ (S : Index (n + 2)) i j, i ∈ S.val → j ∈ S.val → distinct S i - distinct S j ∈ W) :
    jointKernel n ≤ W := by
  let P : Product (n + 1) →ₗ[ℂ] Product (n + 1) :=
    LinearMap.id - (includeWedge (n + 1)).comp (wedge (n + 1)) - (includeMetric n).comp (contract n)
  have hP (y : Product (n + 1)) :
      P y = y - includeWedge (n + 1) (wedge (n + 1) y) - includeMetric n (contract n y) := rfl
  have hcolumn (t : Axis × Index (n + 1)) : P (tensorExteriorBasis (n + 1) t) ∈ W := by
    by_cases ht : t.1 ∈ t.2.val
    · obtain ⟨z, _, hz⟩ := repeated_column t ht
      let R := eraseIndex t.2 t.1 ht
      have hi : t.1 ∉ R.val := notMem_eraseIndex t.2 t.1 ht
      rw [hz, map_smul, hP, wedge_repeated, trace_repeated R t.1 hi, map_zero, sub_zero,
        repeated_sub_metric hn]
      exact W.smul_mem _ (W.smul_mem _ (W.sum_mem fun j hj => hR R t.1 j hi (Finset.mem_compl.mp hj)))
    · obtain ⟨z, _, hz⟩ := column_of_distinct t ht
      let S := insertIndex t.2 t.1 ht
      have hi : t.1 ∈ S.val := Finset.mem_insert_self _ _
      rw [hz, map_smul, hP, wedge_distinct S t.1 hi, trace_distinct, map_zero, sub_zero, distinct_sub_wedge]
      exact W.smul_mem _ (W.smul_mem _ (W.sum_mem fun j hj => hS S t.1 j hi hj))
  intro x hx
  have ⟨hw, hc⟩ := (mem_jointKernel n x).mp hx
  have hxP : P x = x := by rw [hP, hw, hc, map_zero, map_zero, sub_zero, sub_zero]
  rw [← hxP, ← (tensorExteriorBasis (n + 1)).sum_repr x, map_sum]
  exact W.sum_mem fun t _ => by rw [map_smul]; exact W.smul_mem _ (hcolumn t)

abbrev RepeatedIndex (n : ℕ) := Σ R : Index n, {i : Axis // i ∉ R.val}
abbrev DistinctIndex (n : ℕ) := Σ S : Index (n + 2), ↥S.val
abbrev NormalizedIndex (n : ℕ) := RepeatedIndex n ⊕ DistinctIndex n

private def toColumn {n : ℕ} : NormalizedIndex n → Axis × Index (n + 1)
  | .inl ⟨R, i⟩ => (i.val, insertIndex R i.val i.prop)
  | .inr ⟨S, i⟩ => (i.val, eraseIndex S i.val i.prop)

private def fromColumn {n : ℕ} (t : Axis × Index (n + 1)) : NormalizedIndex n :=
  if h : t.1 ∈ t.2.val then .inl ⟨eraseIndex t.2 t.1 h, ⟨t.1, notMem_eraseIndex t.2 t.1 h⟩⟩
  else .inr ⟨insertIndex t.2 t.1 h, ⟨t.1, Finset.mem_insert_self _ _⟩⟩

private theorem erase_insertIndex {n : ℕ} (R : Index n) (i : Axis) (hi : i ∉ R.val) :
    eraseIndex (insertIndex R i hi) i (Finset.mem_insert_self _ _) = R :=
  Subtype.ext (Finset.erase_insert hi)

private theorem insert_eraseIndex {n : ℕ} (S : Index (n + 1)) (i : Axis) (hi : i ∈ S.val) :
    insertIndex (eraseIndex S i hi) i (notMem_eraseIndex S i hi) = S :=
  Subtype.ext (Finset.insert_erase hi)

private def columnEquiv (n : ℕ) : NormalizedIndex n ≃ Axis × Index (n + 1) where
  toFun := toColumn
  invFun := fromColumn
  left_inv := by
    rintro (⟨R, i⟩ | ⟨S, i⟩)
    · have h : i.val ∈ (insertIndex R i.val i.prop).val := Finset.mem_insert_self _ _
      change fromColumn (i.val, insertIndex R i.val i.prop) = .inl ⟨R, i⟩
      rw [fromColumn, dif_pos h]
      congr 1
      apply Sigma.subtype_ext
      · exact erase_insertIndex R i.val i.prop
      · rfl
    · have h := notMem_eraseIndex S i.val i.prop
      change fromColumn (i.val, eraseIndex S i.val i.prop) = .inr ⟨S, i⟩
      rw [fromColumn, dif_neg h]
      congr 1
      apply Sigma.subtype_ext
      · exact insert_eraseIndex S i.val i.prop
      · rfl
  right_inv := by
    rintro ⟨i, S⟩
    by_cases h : i ∈ S.val
    · simp only [fromColumn, toColumn, dif_pos h, insert_eraseIndex]
    · simp only [fromColumn, toColumn, dif_neg h, erase_insertIndex]

private def columnVector {n : ℕ} : NormalizedIndex n → Product (n + 1)
  | .inl ⟨R, i⟩ => repeated R i.val
  | .inr ⟨S, i⟩ => distinct S i.val

private theorem columnVector_scaled {n : ℕ} (q : NormalizedIndex n) :
    ∃ z : ℂ, z ≠ 0 ∧ columnVector q = z • tensorExteriorBasis (n + 1) (columnEquiv n q) := by
  rcases q with ⟨R, i⟩ | ⟨S, i⟩
  · let t := (i.val, insertIndex R i.val i.prop)
    have ht : t.1 ∈ t.2.val := Finset.mem_insert_self _ _
    obtain ⟨z, hz, h⟩ := repeated_column t ht
    change tensorExteriorBasis (n + 1) t =
      z • repeated (eraseIndex (insertIndex R i.val i.prop) i.val ht) i.val at h
    rw [erase_insertIndex] at h
    refine ⟨z⁻¹, inv_ne_zero hz, ?_⟩
    change repeated R i.val = z⁻¹ • tensorExteriorBasis (n + 1) t
    rw [h, smul_smul, inv_mul_cancel₀ hz, one_smul]
  · obtain ⟨z, hz, _, h⟩ := distinct_column S i.val i.prop
    exact ⟨z, hz, h⟩

/-- The orthogonal tensor basis, grouped by normalized contraction and wedge blocks. -/
def normalizedBasis (n : ℕ) : Module.Basis (NormalizedIndex n) ℂ (Product (n + 1)) :=
  ((tensorExteriorBasis (n + 1)).reindex (columnEquiv n).symm).unitsSMul fun q =>
    Units.mk0 (columnVector_scaled q).choose (columnVector_scaled q).choose_spec.1

private theorem normalizedBasis_apply {n : ℕ} (q : NormalizedIndex n) :
    normalizedBasis n q = columnVector q := by
  rw [normalizedBasis, Module.Basis.unitsSMul_apply, Module.Basis.reindex_apply, Units.smul_def]
  exact (columnVector_scaled q).choose_spec.2.symm

@[simp] theorem normalizedBasis_repeated {n : ℕ} (R : Index n) (i : {i : Axis // i ∉ R.val}) :
    normalizedBasis n (.inl ⟨R, i⟩) = repeated R i.val := normalizedBasis_apply _

@[simp] theorem normalizedBasis_distinct {n : ℕ} (S : Index (n + 2)) (i : ↥S.val) :
    normalizedBasis n (.inr ⟨S, i⟩) = distinct S i.val := normalizedBasis_apply _

def block {n : ℕ} : NormalizedIndex n → Finset Axis
  | .inl ⟨R, _⟩ => R.val
  | .inr ⟨S, _⟩ => S.val

private theorem parity_column {n : ℕ} (q : NormalizedIndex n) : parity (columnEquiv n q) = block q := by
  rcases q with ⟨R, i⟩ | ⟨S, i⟩
  · change parity (i.val, insertIndex R i.val i.prop) = R.val
    have h : i.val ∈ (insertIndex R i.val i.prop).val := Finset.mem_insert_self _ _
    rw [parity, if_pos h]
    exact Finset.erase_insert i.prop
  · change parity (i.val, eraseIndex S i.val i.prop) = S.val
    rw [parity, if_neg (notMem_eraseIndex S i.val i.prop)]
    exact Finset.insert_erase i.prop

theorem normalizedBasis_doubleFlip {n : ℕ} (i j : Axis) (q : NormalizedIndex n) :
    action (n + 1) (doubleFlip i j) (normalizedBasis n q) =
      character (block q) i j • normalizedBasis n q := by
  obtain ⟨z, _, hz⟩ := columnVector_scaled q
  have h := tensorExterior_doubleFlip i j (columnEquiv n q)
  change action (n + 1) (doubleFlip i j) (tensorExteriorBasis (n + 1) (columnEquiv n q)) = _ at h
  rw [normalizedBasis_apply, hz, map_smul, h, parity_column, smul_comm z]

end
end GeometricUnity.D7TensorColumns
