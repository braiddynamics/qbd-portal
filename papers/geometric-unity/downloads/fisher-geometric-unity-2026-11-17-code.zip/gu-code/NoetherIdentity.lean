import Theorem52
import Mathlib.Algebra.TrivSqZeroExt.Basic
import Mathlib.Algebra.Group.Action.Opposite
import Mathlib.Analysis.Calculus.Deriv.Linear

/-!
# Geometric Unity: the coupled Noether identity

The coordinate model uses commuting coefficient derivations, a real
associative algebra, and an integrated cyclic trace. The finite gauge
transformations act on units and on local connection coefficients.
The dressing differential is the tangent coefficient in the algebra
of dual numbers. The connection differential agrees with the real
directional derivative of Theorem 5.2. The final identity uses the
integrated boundary identity and separation by admissible gauge tests.
-/

namespace GeometricUnity.NoetherIdentity

open GeometricUnity.Theorem52
open scoped BigOperators

noncomputable section

variable {ι A C : Type*} [Ring A] [Algebra ℝ A] [Ring C] [Algebra ℝ C]

private def mapOne (f : A →ₐ[ℝ] C) (X : OneForm ι A) : OneForm ι C := fun a => f (X a)
private def mapTwo (f : A →ₐ[ℝ] C) (F : TwoForm ι A) : TwoForm ι C := fun a b => f (F a b)
private def mapInsertion (f : A →ₐ[ℝ] C) (P : Insertion ι A) : Insertion ι C :=
  fun a b c => f (P a b c)

private theorem map_dB (f : A →ₐ[ℝ] C) (d : ι → A →ₗ[ℝ] A) (δ : ι → C →ₗ[ℝ] C)
    (hf : ∀ a x, δ a (f x) = f (d a x)) (X : OneForm ι A) :
    dB δ (mapOne f X) = mapTwo f (dB d X) := by
  funext a b
  simp [dB, mapOne, mapTwo, hf]

private theorem map_wedgeSquare (f : A →ₐ[ℝ] C) (X : OneForm ι A) :
    wedgeSquare (mapOne f X) = mapTwo f (wedgeSquare X) := by
  funext a b
  simp [wedgeSquare, mapOne, mapTwo, comm_apply]

private theorem map_comm (f : A →ₐ[ℝ] C) (x y : A) :
    comm (f x) (f y) = f (comm x y) := by simp [comm_apply]

private theorem map_anti (f : A →ₐ[ℝ] C) (x y : A) :
    anti (f x) (f y) = f (anti x y) := by simp [anti_apply]

private theorem map_covariant (f : A →ₐ[ℝ] C) (d : ι → A →ₗ[ℝ] A)
    (δ : ι → C →ₗ[ℝ] C) (hf : ∀ a x, δ a (f x) = f (d a x)) (B : OneForm ι A)
    (a : ι) (x : A) :
    covariant δ (mapOne f B) a (f x) = f (covariant d B a x) := by
  simp [covariant, mapOne, hf, map_comm]

private theorem map_curvature (f : A →ₐ[ℝ] C) (d : ι → A →ₗ[ℝ] A)
    (δ : ι → C →ₗ[ℝ] C) (hf : ∀ a x, δ a (f x) = f (d a x)) (B : OneForm ι A) :
    curvature δ (mapOne f B) = mapTwo f (curvature d B) := by
  rw [curvature, map_dB f d δ hf, map_wedgeSquare]
  funext a b
  simp [curvature, mapTwo]

private theorem covariant_leibniz (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (B : OneForm ι A) :
    Leibniz (covariant d B) := by
  intro a x y
  simp only [covariant, LinearMap.add_apply, comm_apply, hd a]
  noncomm_ring

private theorem derivation_one (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (a : ι) :
    d a 1 = 0 := by
  have h := hd a 1 1
  simp only [one_mul, mul_one] at h
  exact left_eq_add.mp h

section Gauge

/-- Conjugation in the direction used in the note, `x ↦ h⁻¹ x h`. -/
def conjugate (h : Aˣ) : A →ₐ[ℝ] A where
  toFun x := ↑h⁻¹ * x * (h : A)
  map_zero' := by simp
  map_one' := by simp
  map_add' x y := by simp [mul_add, add_mul]
  map_mul' x y := by simp [mul_assoc, Units.mul_inv_cancel_left]
  commutes' r := by
    simp [Algebra.algebraMap_eq_smul_one]

theorem conjugate_apply (h : Aˣ) (x : A) :
    conjugate h x = ↑h⁻¹ * x * (h : A) := rfl

private theorem conjugate_comp (h k : Aˣ) (x : A) :
    conjugate k (conjugate h x) = conjugate (h * k) x := by
  simp [conjugate_apply, mul_inv_rev, mul_assoc]

private theorem conjugate_trace (trace : A →ₗ[ℝ] ℝ) (htrace : Cyclic trace) (h : Aˣ) :
    trace.comp (conjugate h).toLinearMap = trace := by
  apply LinearMap.ext
  intro x
  change trace (↑h⁻¹ * x * (h : A)) = trace x
  rw [htrace _ (h : A), ← mul_assoc, h.mul_inv, one_mul]

def gaugeTerm (d : ι → A →ₗ[ℝ] A) (h : Aˣ) : OneForm ι A :=
  fun a => ↑h⁻¹ * d a (h : A)

/-- Component transform of a connection, including its inhomogeneous term. -/
def gaugeConnection (d : ι → A →ₗ[ℝ] A) (h : Aˣ) (B : OneForm ι A) : OneForm ι A :=
  mapOne (conjugate h) B + gaugeTerm d h

theorem gaugeConnection_comp (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (h k : Aˣ) (B : OneForm ι A) :
    gaugeConnection d k (gaugeConnection d h B) = gaugeConnection d (h * k) B := by
  have log_comp (a : ι) :
      gaugeTerm d (h * k) a = conjugate k (gaugeTerm d h a) + gaugeTerm d k a := by
    simp [gaugeTerm, conjugate_apply, mul_inv_rev, hd a, mul_add,
      mul_assoc, Units.inv_mul_cancel_left]
  funext a
  simp [gaugeConnection, mapOne, conjugate_comp, log_comp, add_assoc]

theorem gaugeConnection_one (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (B : OneForm ι A) :
    gaugeConnection d 1 B = B := by
  funext a
  simp [gaugeConnection, gaugeTerm, mapOne, conjugate_apply, derivation_one d hd]

private theorem derivative_inv (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (h : Aˣ) (a : ι) :
    d a (↑h⁻¹ : A) = -(↑h⁻¹ * d a (h : A) * ↑h⁻¹) := by
  have hz : d a (↑h⁻¹ : A) * ↑h + ↑h⁻¹ * d a (h : A) = 0 := by
    rw [← hd a, h.inv_mul, derivation_one d hd]
  have he := congrArg (fun x : A => x * (↑h⁻¹ : A)) hz
  rw [add_mul, h.mul_inv_cancel_right, zero_mul] at he
  exact eq_neg_of_add_eq_zero_left he

private theorem derivative_conjugate (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (h : Aˣ) (a : ι) (x : A) :
    d a (conjugate h x) = conjugate h (d a x) +
      conjugate h x * gaugeTerm d h a - gaugeTerm d h a * conjugate h x := by
  simp only [conjugate_apply, gaugeTerm, hd a, derivative_inv d hd h a, add_mul, neg_mul]
  rw [show (↑h⁻¹ * x * (h : A)) * (↑h⁻¹ * d a (h : A)) =
    ↑h⁻¹ * x * d a (h : A) by simp [mul_assoc, Units.mul_inv_cancel_left]]
  noncomm_ring

/-- The conjugating derivative terms cancel the inhomogeneous connection term. -/
theorem covariant_gauge (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (h : Aˣ) (B : OneForm ι A) (a : ι) (x : A) :
    covariant d (gaugeConnection d h B) a (conjugate h x) =
      conjugate h (covariant d B a x) := by
  simp only [covariant, LinearMap.add_apply, gaugeConnection, Pi.add_apply, mapOne,
    derivative_conjugate d hd h, map_add]
  rw [← map_comm (conjugate h) (B a) x]
  simp only [comm_apply]
  abel

def Commuting (d : ι → A →ₗ[ℝ] A) : Prop :=
  ∀ a b x, d a (d b x) = d b (d a x)

private theorem gaugeTerm_flat (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (hc : Commuting d) (h : Aˣ) : curvature d (gaugeTerm d h) = 0 := by
  funext a b
  simp only [curvature, Pi.add_apply, Pi.zero_apply, dB, wedgeSquare, gaugeTerm, hd a, hd b,
    derivative_inv d hd h, comm_apply, neg_mul, hc a b (h : A)]
  noncomm_ring

theorem curvature_gauge (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (hc : Commuting d) (h : Aˣ) (B : OneForm ι A) :
    curvature d (gaugeConnection d h B) = mapTwo (conjugate h) (curvature d B) := by
  have hcov (a : ι) (x : A) :
      covariant d (gaugeTerm d h) a (conjugate h x) = conjugate h (d a x) := by
    simpa [gaugeConnection, mapOne, covariant] using covariant_gauge d hd h 0 a x
  rw [gaugeConnection, add_comm, curvature_shift, gaugeTerm_flat d hd hc h, zero_add,
    map_dB (conjugate h) d (covariant d (gaugeTerm d h)) hcov, map_wedgeSquare]
  funext a b
  simp [curvature, mapTwo]

end Gauge

variable [Fintype ι]

section Action

private theorem map_theta (f : A →ₐ[ℝ] C)
    (B : Bracket A) (B' : Bracket C) (hf : ∀ x y, B' (f x) (f y) = f (B x y))
    (P : Insertion ι A) (F : TwoForm ι A) :
    theta B' (mapInsertion f P) (mapTwo f F) = mapOne f (theta B P F) := by
  funext a
  simp [theta, mapInsertion, mapTwo, mapOne, hf, map_sum]

private theorem pair_map (f : A →ₐ[ℝ] C) (trace : C →ₗ[ℝ] ℝ) (X Y : OneForm ι A) :
    pair trace (mapOne f X) (mapOne f Y) = pair (trace.comp f.toLinearMap) X Y := by
  simp [pair, mapOne]

private theorem action_map (f : A →ₐ[ℝ] C) (trace : C →ₗ[ℝ] ℝ)
    (d : ι → A →ₗ[ℝ] A) (δ : ι → C →ₗ[ℝ] C) (hf : ∀ a x, δ a (f x) = f (d a x))
    (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A) (lam m : ℝ) (X : OneForm ι A) :
    action trace δ g (mapInsertion f P) (mapInsertion f Q) (mapTwo f F) lam m (mapOne f X) =
      action (trace.comp f.toLinearMap) d g P Q F lam m X := by
  simp only [action, map_dB f d δ hf, map_wedgeSquare]
  have hin :
      mapTwo f F + (1 / 2 : ℝ) • mapTwo f (dB d X) + lam • mapTwo f (wedgeSquare X) =
        mapTwo f (F + (1 / 2 : ℝ) • dB d X + lam • wedgeSquare X) := by
    funext a b
    simp [mapTwo]
  rw [hin, map_theta f anti anti (map_anti f), map_theta f comm comm (map_comm f)]
  have hadd (U V : OneForm ι A) : mapOne f U + mapOne f V = mapOne f (U + V) := by
    funext a
    simp [mapOne]
  have hg : raise g (mapOne f X) = mapOne f (raise g X) := by
    funext a
    simp [raise, mapOne]
  rw [hadd, hg, pair_map, pair_map]

/-- The reference connection and Clifford insertions are dressed by the
same invertible coefficient. The connection `U` varies independently. -/
def dressedAction (trace : A →ₗ[ℝ] ℝ) (d : ι → A →ₗ[ℝ] A) (g : ι → ℝ)
    (P₀ Q₀ : Insertion ι A) (B₀ : OneForm ι A) (lam m : ℝ) (U : OneForm ι A) (ε : Aˣ) : ℝ :=
  let B := gaugeConnection d ε B₀
  action trace (covariant d B) g (mapInsertion (conjugate ε) P₀) (mapInsertion (conjugate ε) Q₀)
    (curvature d B) lam m (U - B)

/-- Finite simultaneous gauge invariance of the action of Theorem 5.2. -/
theorem dressedAction_gauge (trace : A →ₗ[ℝ] ℝ) (htrace : Cyclic trace)
    (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (hc : Commuting d) (g : ι → ℝ)
    (P₀ Q₀ : Insertion ι A) (B₀ U : OneForm ι A) (lam m : ℝ) (ε h : Aˣ) :
    dressedAction trace d g P₀ Q₀ B₀ lam m (gaugeConnection d h U) (ε * h) =
      dressedAction trace d g P₀ Q₀ B₀ lam m U ε := by
  let B := gaugeConnection d ε B₀
  have hB : gaugeConnection d (ε * h) B₀ = gaugeConnection d h B :=
    (gaugeConnection_comp d hd ε h B₀).symm
  have ht : gaugeConnection d h U - gaugeConnection d h B = mapOne (conjugate h) (U - B) := by
    funext a
    simp only [gaugeConnection, Pi.sub_apply, Pi.add_apply, mapOne, map_sub]
    abel
  have hins (R : Insertion ι A) :
      mapInsertion (conjugate (ε * h)) R = mapInsertion (conjugate h) (mapInsertion (conjugate ε) R) := by
    funext a b c
    exact (conjugate_comp ε h (R a b c)).symm
  simp only [dressedAction, hB, ht, hins, curvature_gauge d hd hc h]
  rw [action_map (conjugate h) trace (covariant d B) (covariant d (gaugeConnection d h B))
    (covariant_gauge d hd h B), conjugate_trace trace htrace h]

private theorem dressedAction_compensate (trace : A →ₗ[ℝ] ℝ) (htrace : Cyclic trace)
    (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d) (hc : Commuting d) (g : ι → ℝ)
    (P₀ Q₀ : Insertion ι A) (B₀ U : OneForm ι A) (lam m : ℝ) (ε h : Aˣ) :
    dressedAction trace d g P₀ Q₀ B₀ lam m U (ε * h) =
      dressedAction trace d g P₀ Q₀ B₀ lam m (gaugeConnection d h⁻¹ U) ε := by
  have hh := dressedAction_gauge trace htrace d hd hc g P₀ Q₀ B₀
    (gaugeConnection d h⁻¹ U) lam m ε h
  rwa [gaugeConnection_comp d hd h⁻¹ h U, inv_mul_cancel, gaugeConnection_one d hd] at hh

end Action

section Dual

open TrivSqZeroExt

private abbrev Dual (A : Type*) := TrivSqZeroExt A A

private abbrev constant : A →ₐ[ℝ] Dual A := TrivSqZeroExt.inlAlgHom ℝ A A

private def tangentOne (X : OneForm ι A) : OneForm ι (Dual A) := fun a => inr (X a)

omit [Algebra ℝ A] in
private theorem dual_product (x y : Dual A) : (x * y).snd = x.fst * y.snd + x.snd * y.fst := rfl

private def liftLinear (D : A →ₗ[ℝ] A) : Dual A →ₗ[ℝ] Dual A where
  toFun x := ⟨D x.fst, D x.snd⟩
  map_add' x y := by
    apply TrivSqZeroExt.ext
    · exact D.map_add x.fst y.fst
    · exact D.map_add x.snd y.snd
  map_smul' r x := by
    apply TrivSqZeroExt.ext
    · exact map_smul D r x.fst
    · exact map_smul D r x.snd

@[simp] private theorem lift_fst (D : A →ₗ[ℝ] A) (x : Dual A) :
    (liftLinear D x).fst = D x.fst := rfl

@[simp] private theorem lift_snd (D : A →ₗ[ℝ] A) (x : Dual A) :
    (liftLinear D x).snd = D x.snd := rfl

private theorem lift_constant (D : A →ₗ[ℝ] A) (x : A) :
    liftLinear D (constant x) = constant (D x) := by
  apply TrivSqZeroExt.ext <;> simp

omit [Fintype ι] in
private theorem liftLeibniz (D : ι → A →ₗ[ℝ] A) (hD : Leibniz D) :
    Leibniz (fun a => liftLinear (D a)) := by
  intro a x y
  apply TrivSqZeroExt.ext
  · simp only [lift_fst, fst_mul, fst_add, hD a]
  · simp only [dual_product, lift_fst, lift_snd, snd_add, map_add, hD a]
    abel

omit [Fintype ι] in
private theorem liftCommuting (D : ι → A →ₗ[ℝ] A) (hD : Commuting D) :
    Commuting (fun a => liftLinear (D a)) := by
  intro a b x
  apply TrivSqZeroExt.ext
  · exact hD a b x.fst
  · exact hD a b x.snd

private def tangentTrace (trace : A →ₗ[ℝ] ℝ) : Dual A →ₗ[ℝ] ℝ where
  toFun x := trace x.snd
  map_add' _ _ := by simp
  map_smul' _ _ := by simp

@[simp] private theorem tangentTrace_apply (trace : A →ₗ[ℝ] ℝ) (x : Dual A) :
    tangentTrace trace x = trace x.snd := rfl

private theorem tangentTrace_cyclic (trace : A →ₗ[ℝ] ℝ) (h : Cyclic trace) :
    Cyclic (tangentTrace trace) := by
  intro x y
  change trace (x * y).snd = trace (y * x).snd
  simp only [dual_product, map_add]
  rw [h x.fst y.snd, h x.snd y.fst, add_comm]

private def scaleTangent (r : ℝ) : Dual A →ₐ[ℝ] Dual A where
  toFun x := ⟨x.fst, r • x.snd⟩
  map_zero' := by ext <;> simp
  map_one' := by ext <;> simp
  map_add' x y := by
    apply TrivSqZeroExt.ext
    · rfl
    · exact smul_add r x.snd y.snd
  map_mul' x y := by
    apply TrivSqZeroExt.ext
    · rfl
    · change r • (x.fst * y.snd + x.snd * y.fst) = x.fst * (r • y.snd) + (r • x.snd) * y.fst
      simp [smul_add]
  commutes' _ := by
    ext <;> simp [algebraMap_eq_inl']

@[simp] private theorem scale_fst (r : ℝ) (x : Dual A) :
    (scaleTangent r x).fst = x.fst := rfl

@[simp] private theorem scale_snd (r : ℝ) (x : Dual A) :
    (scaleTangent r x).snd = r • x.snd := rfl

private theorem lift_scale (r : ℝ) (D : A →ₗ[ℝ] A) (x : Dual A) :
    liftLinear D (scaleTangent r x) = scaleTangent r (liftLinear D x) := by
  apply TrivSqZeroExt.ext
  · rfl
  · exact map_smul D r x.snd

private theorem scale_trace (r : ℝ) (trace : A →ₗ[ℝ] ℝ) :
    (tangentTrace trace).comp (scaleTangent r).toLinearMap = r • tangentTrace trace := by
  apply LinearMap.ext
  intro x
  exact map_smul trace r x.snd

private theorem action_trace_smul (r : ℝ) (trace : A →ₗ[ℝ] ℝ)
    (D : ι → A →ₗ[ℝ] A) (g : ι → ℝ) (P Q : Insertion ι A) (F : TwoForm ι A)
    (lam m : ℝ) (X : OneForm ι A) :
    action (r • trace) D g P Q F lam m X = r * action trace D g P Q F lam m X := by
  simp only [action, pair, LinearMap.smul_apply, smul_eq_mul, ← Finset.mul_sum]
  ring

private theorem euler_primal (D : ι → A →ₗ[ℝ] A) (g : ι → ℝ) (P Q : Insertion ι A)
    (F : TwoForm ι A) (lam m : ℝ) (X : OneForm ι A) (a : ι) :
    (euler (fun b => liftLinear (D b)) g (mapInsertion constant P) (mapInsertion constant Q)
      (mapTwo constant F) lam m (mapOne constant X) a).fst =
      euler D g P Q F lam m X a := by
  simp [euler, theta, correction, raise, dB, wedgeSquare, comm_apply, anti_apply,
    mapOne, mapTwo, mapInsertion, fst_sum]

private theorem action_tangent (trace : A →ₗ[ℝ] ℝ) (htrace : Cyclic trace)
    (D : ι → A →ₗ[ℝ] A) (D_leibniz : Leibniz D) (g : ι → ℝ) (P Q : Insertion ι A)
    (F : TwoForm ι A) (hp : Alternating P) (hq : Alternating Q)
    (hP : Parallel D P) (hQ : Parallel D Q) (lam m : ℝ) (X α : OneForm ι A)
    (hbP : BoundaryZero trace D anti P X α) (hbQ : BoundaryZero trace D comm Q X α) :
    action (tangentTrace trace) (fun a => liftLinear (D a)) g
        (mapInsertion constant P) (mapInsertion constant Q) (mapTwo constant F) lam m
        (mapOne constant X + tangentOne α) =
      pair trace α (euler D g P Q F lam m X) := by
  let D' a := liftLinear (D a)
  let P' := mapInsertion constant P
  let Q' := mapInsertion constant Q
  let F' := mapTwo constant F
  let X' := mapOne constant X
  let α' := tangentOne α
  let tr' := tangentTrace trace
  let I := action tr' D' g P' Q' F' lam m
  have hAlt (R : Insertion ι A) (hR : Alternating R) : Alternating (mapInsertion constant R) := by
    constructor
    · intro a b c; simp [mapInsertion, hR.swapBC a b c]
    · intro a b c; simp [mapInsertion, hR.swapAC a b c]
  have hPar (R : Insertion ι A) (hR : Parallel D R) : Parallel D' (mapInsertion constant R) := by
    intro a b c
    change liftLinear (D b) (constant (R a b c)) = 0
    rw [lift_constant, hR a b c, map_zero]
  have hbP' : BoundaryZero tr' D' anti P' X' α' := by
    simpa [BoundaryZero, sum3, tr', D', P', X', α', tangentTrace, mapInsertion,
      mapOne, tangentOne, anti_apply] using hbP
  have hbQ' : BoundaryZero tr' D' comm Q' X' α' := by
    simpa [BoundaryZero, sum3, tr', D', Q', X', α', tangentTrace, mapInsertion,
      mapOne, tangentOne, comm_apply] using hbQ
  have hd := theorem_5_2 tr' D' g P' Q' F' (hAlt P hp) (hAlt Q hq)
    (tangentTrace_cyclic trace htrace) (liftLeibniz D D_leibniz)
    (hPar P hP) (hPar Q hQ) lam m X' α' hbP' hbQ'
  have hline (t : ℝ) : I (X' + t • α') = t * I (X' + α') := by
    have h := action_map (scaleTangent t) tr' D' D' (fun a => lift_scale t (D a))
      g P' Q' F' lam m (X' + α')
    have hP' : mapInsertion (scaleTangent t) P' = P' := by
      funext a b c; apply TrivSqZeroExt.ext <;> simp [P', mapInsertion]
    have hQ' : mapInsertion (scaleTangent t) Q' = Q' := by
      funext a b c; apply TrivSqZeroExt.ext <;> simp [Q', mapInsertion]
    have hF' : mapTwo (scaleTangent t) F' = F' := by
      funext a b; apply TrivSqZeroExt.ext <;> simp [F', mapTwo]
    have hX' : mapOne (scaleTangent t) (X' + α') = X' + t • α' := by
      funext a; apply TrivSqZeroExt.ext <;> simp [X', α', mapOne, tangentOne]
    rw [hP', hQ', hF', hX', scale_trace, action_trace_smul] at h
    exact h
  have hpoly : (fun t : ℝ => I (X' + t • α')) = fun t => t * I (X' + α') := funext hline
  change HasDerivAt (fun t : ℝ => I (X' + t • α'))
    (pair tr' α' (euler D' g P' Q' F' lam m X')) 0 at hd
  rw [hpoly] at hd
  have hlinear : HasDerivAt (fun t : ℝ => t * I (X' + α')) (I (X' + α')) 0 := by
    simpa only [one_mul] using (hasDerivAt_id' (x := (0 : ℝ))).mul_const (I (X' + α'))
  change I (X' + α') = _
  rw [← hlinear.deriv, hd.deriv]
  simp only [pair, tr', α', tangentTrace_apply, tangentOne, dual_product,
    fst_inr, snd_inr, zero_mul, zero_add, D', P', Q', F', X', euler_primal D g P Q F lam m X]

end Dual

section DressingDifferential

open TrivSqZeroExt

omit [Fintype ι] in
private theorem map_gaugeConnection (f : A →ₐ[ℝ] C) (d : ι → A →ₗ[ℝ] A)
    (δ : ι → C →ₗ[ℝ] C) (hf : ∀ a x, δ a (f x) = f (d a x)) (ε : Aˣ) (B : OneForm ι A) :
    gaugeConnection δ (Units.map f.toMonoidHom ε) (mapOne f B) =
      mapOne f (gaugeConnection d ε B) := by
  funext a
  simp [gaugeConnection, gaugeTerm, conjugate_apply, mapOne, hf]

private def infinitesimalGauge (ζ : A) : (Dual A)ˣ where
  val := ⟨1, ζ⟩
  inv := ⟨1, -ζ⟩
  val_inv := by
    apply TrivSqZeroExt.ext
    · change (1 : A) * 1 = 1; simp
    · change (1 : A) * (-ζ) + ζ * 1 = 0; simp
  inv_val := by
    apply TrivSqZeroExt.ext
    · change (1 : A) * 1 = 1; simp
    · change (1 : A) * ζ + (-ζ) * 1 = 0; simp

omit [Algebra ℝ A] in
private theorem infinitesimalGauge_inv (ζ : A) :
    (infinitesimalGauge ζ)⁻¹ = infinitesimalGauge (-ζ) := by
  apply Units.ext
  rfl

omit [Algebra ℝ A] in
@[simp] private theorem infinitesimal_fst (ζ : A) :
    (↑(infinitesimalGauge ζ) : Dual A).fst = 1 := rfl

omit [Algebra ℝ A] in
@[simp] private theorem infinitesimal_snd (ζ : A) :
    (↑(infinitesimalGauge ζ) : Dual A).snd = ζ := rfl

omit [Fintype ι] in
/-- The coefficient of the infinitesimal connection transform is `D_U ζ`. -/
private theorem gaugeConnection_infinitesimal (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (U : OneForm ι A) (ζ : A) :
    gaugeConnection (fun a => liftLinear (d a)) (infinitesimalGauge ζ) (mapOne constant U) =
      mapOne constant U + tangentOne (fun a => covariant d U a ζ) := by
  funext a
  apply TrivSqZeroExt.ext
  · simp [gaugeConnection, mapOne, gaugeTerm, conjugate_apply, infinitesimalGauge_inv,
      tangentOne, derivation_one d hd]
  · simp only [gaugeConnection, mapOne, gaugeTerm, conjugate_apply, infinitesimalGauge_inv,
      tangentOne, Pi.add_apply, snd_add, dual_product, fst_mul, infinitesimal_fst, infinitesimal_snd,
      inlAlgHom_apply, fst_inl, snd_inl, snd_inr, lift_fst, lift_snd, derivation_one d hd,
      covariant, LinearMap.add_apply, comm_apply, mul_one, one_mul, mul_zero,
      add_zero, zero_add, neg_mul]
    abel

omit [Fintype ι] in
private theorem lift_covariant (d : ι → A →ₗ[ℝ] A) (B : OneForm ι A) :
    covariant (fun a => liftLinear (d a)) (mapOne constant B) =
      fun a => liftLinear (covariant d B a) := by
  funext a
  apply LinearMap.ext
  intro x
  apply TrivSqZeroExt.ext <;> simp [covariant, mapOne, comm_apply]

/-- Right multiplication of the dressing by the infinitesimal gauge unit. -/
def dressingJet (ε : Aˣ) (ζ : A) : (TrivSqZeroExt A A)ˣ :=
  Units.map constant.toMonoidHom ε * infinitesimalGauge ζ

theorem dressingJet_snd (ε : Aˣ) (ζ : A) :
    (↑(dressingJet ε ζ) : TrivSqZeroExt A A).snd = (ε : A) * ζ := by
  change (ε : A) * ζ + 0 * 1 = (ε : A) * ζ
  rw [zero_mul, add_zero]

variable (trace : A →ₗ[ℝ] ℝ) (d : ι → A →ₗ[ℝ] A) (g : ι → ℝ)
variable (P₀ Q₀ : Insertion ι A) (B₀ : OneForm ι A) (lam m : ℝ)
variable (U : OneForm ι A) (ε : Aˣ)

/-- The raised connection Euler expression of Theorem 5.2 for the dressed action. -/
def dressedEuler : OneForm ι A :=
  let B := gaugeConnection d ε B₀
  euler (covariant d B) g (mapInsertion (conjugate ε) P₀) (mapInsertion (conjugate ε) Q₀)
    (curvature d B) lam m (U - B)

/-- First-order variation of the dressing at fixed connection. The lifted
dressing has constant coefficient `ε` and tangent coefficient `ε * ζ`. -/
def dressingDerivative (ζ : A) : ℝ :=
  dressedAction (tangentTrace trace) (fun a => liftLinear (d a)) g
    (mapInsertion constant P₀) (mapInsertion constant Q₀) (mapOne constant B₀) lam m
    (mapOne constant U) (dressingJet ε ζ)

/-- The two integrated boundary conditions needed to apply Theorem 5.2 in
the infinitesimal gauge direction. -/
def ConnectionBoundary (ζ : A) : Prop :=
  let B := gaugeConnection d ε B₀
  let α := fun a => covariant d U a ζ
  BoundaryZero trace (covariant d B) anti (mapInsertion (conjugate ε) P₀) (U - B) α ∧
    BoundaryZero trace (covariant d B) comm (mapInsertion (conjugate ε) Q₀) (U - B) α

private theorem lifted_dressedAction (α : OneForm ι A) :
    let B := gaugeConnection d ε B₀
    let P := mapInsertion (conjugate ε) P₀
    let Q := mapInsertion (conjugate ε) Q₀
    dressedAction (tangentTrace trace) (fun a => liftLinear (d a)) g
      (mapInsertion constant P₀) (mapInsertion constant Q₀) (mapOne constant B₀) lam m
      (mapOne constant U + tangentOne α) (Units.map constant.toMonoidHom ε) =
    action (tangentTrace trace) (fun a => liftLinear (covariant d B a)) g
      (mapInsertion constant P) (mapInsertion constant Q)
      (mapTwo constant (curvature d B)) lam m (mapOne constant (U - B) + tangentOne α) := by
  let B := gaugeConnection d ε B₀
  let f : A →ₐ[ℝ] Dual A := constant
  let d' : ι → Dual A →ₗ[ℝ] Dual A := fun a => liftLinear (d a)
  let ε' : (Dual A)ˣ := Units.map f.toMonoidHom ε
  have hD (a : ι) (x : A) : d' a (f x) = f (d a x) := lift_constant (d a) x
  have hB : gaugeConnection d' ε' (mapOne f B₀) = mapOne f B :=
    map_gaugeConnection f d d' hD ε B₀
  have hins (R : Insertion ι A) :
      mapInsertion (conjugate ε') (mapInsertion constant R) =
        mapInsertion constant (mapInsertion (conjugate ε) R) := by
    funext a b c
    simp [ε', f, mapInsertion, conjugate_apply]
  have hT : mapOne constant U + tangentOne α - mapOne constant B =
      mapOne constant (U - B) + tangentOne α := by
    funext a
    simp only [Pi.sub_apply, Pi.add_apply, mapOne, map_sub]
    abel
  change dressedAction (tangentTrace trace) d' g (mapInsertion constant P₀)
    (mapInsertion constant Q₀) (mapOne constant B₀) lam m (mapOne constant U + tangentOne α) ε' = _
  rw [dressedAction, hB, hins P₀, hins Q₀, hT, lift_covariant d B,
    map_curvature f d d' hD B]

/-- Finite invariance in the dual algebra moves the dressing variation
to a connection variation in the opposite gauge direction. -/
theorem dressingDerivative_eq_neg_pair (htrace : Cyclic trace) (hd : Leibniz d) (hc : Commuting d)
    (hp : Alternating P₀) (hq : Alternating Q₀)
    (hP : Parallel (covariant d B₀) P₀) (hQ : Parallel (covariant d B₀) Q₀)
    (ζ : A) (hb : ConnectionBoundary trace d P₀ Q₀ B₀ U ε ζ) :
    dressingDerivative trace d g P₀ Q₀ B₀ lam m U ε ζ =
      -pair trace (fun a => covariant d U a ζ) (dressedEuler d g P₀ Q₀ B₀ lam m U ε) := by
  let B := gaugeConnection d ε B₀
  let P := mapInsertion (conjugate ε) P₀
  let Q := mapInsertion (conjugate ε) Q₀
  let α := fun a => covariant d U a ζ
  let d' a := liftLinear (d a)
  have hdir : gaugeConnection d' (infinitesimalGauge ζ)⁻¹ (mapOne constant U) =
      mapOne constant U + tangentOne (-α) := by
    rw [infinitesimalGauge_inv, gaugeConnection_infinitesimal d hd U (-ζ)]
    have ha : (fun a => covariant d U a (-ζ)) = -α := by
      funext a
      exact map_neg (covariant d U a) ζ
    rw [ha]
  have hAlt (R : Insertion ι A) (hR : Alternating R) :
      Alternating (mapInsertion (conjugate ε) R) := by
    constructor
    · intro a b c; simp [mapInsertion, hR.swapBC a b c]
    · intro a b c; simp [mapInsertion, hR.swapAC a b c]
  have hPar (R : Insertion ι A) (hR : Parallel (covariant d B₀) R) :
      Parallel (covariant d B) (mapInsertion (conjugate ε) R) := by
    intro a b c
    simp [B, mapInsertion, covariant_gauge d hd, hR a b c]
  have hbP : BoundaryZero trace (covariant d B) anti P (U - B) (-α) := by
    simpa [BoundaryZero, sum3, Finset.sum_neg_distrib] using hb.1
  have hbQ : BoundaryZero trace (covariant d B) comm Q (U - B) (-α) := by
    simpa [BoundaryZero, sum3, Finset.sum_neg_distrib] using hb.2
  calc
    _ = dressedAction (tangentTrace trace) d' g (mapInsertion constant P₀)
        (mapInsertion constant Q₀) (mapOne constant B₀) lam m
        (gaugeConnection d' (infinitesimalGauge ζ)⁻¹ (mapOne constant U))
        (Units.map constant.toMonoidHom ε) :=
      dressedAction_compensate (tangentTrace trace) (tangentTrace_cyclic trace htrace)
        d' (liftLeibniz d hd) (liftCommuting d hc) g (mapInsertion constant P₀)
        (mapInsertion constant Q₀) (mapOne constant B₀) (mapOne constant U) lam m
        (Units.map constant.toMonoidHom ε) (infinitesimalGauge ζ)
    _ = dressedAction (tangentTrace trace) d' g (mapInsertion constant P₀)
        (mapInsertion constant Q₀) (mapOne constant B₀) lam m
        (mapOne constant U + tangentOne (-α)) (Units.map constant.toMonoidHom ε) :=
      congrArg (fun V => dressedAction (tangentTrace trace) d' g (mapInsertion constant P₀)
        (mapInsertion constant Q₀) (mapOne constant B₀) lam m V
        (Units.map constant.toMonoidHom ε)) hdir
    _ = action (tangentTrace trace) (fun a => liftLinear (covariant d B a)) g
        (mapInsertion constant P) (mapInsertion constant Q) (mapTwo constant (curvature d B)) lam m
        (mapOne constant (U - B) + tangentOne (-α)) :=
      lifted_dressedAction trace d g P₀ Q₀ B₀ lam m U ε (-α)
    _ = pair trace (-α) (dressedEuler d g P₀ Q₀ B₀ lam m U ε) :=
      action_tangent trace htrace (covariant d B) (covariant_leibniz d hd B) g P Q
        (curvature d B) (hAlt P₀ hp) (hAlt Q₀ hq) (hPar P₀ hP) (hPar Q₀ hQ)
        lam m (U - B) (-α) hbP hbQ
    _ = _ := by simp [pair, α, Finset.sum_neg_distrib]

end DressingDifferential

section Noether

def divergence (d : ι → A →ₗ[ℝ] A) (U E : OneForm ι A) : A :=
  ∑ a, covariant d U a (E a)

/-- The integrated divergence of the traced product is zero for
the admissible gauge test. -/
def GaugeBoundary (trace : A →ₗ[ℝ] ℝ) (d : ι → A →ₗ[ℝ] A) (U E : OneForm ι A) (ζ : A) : Prop :=
  (∑ a, trace (covariant d U a (ζ * E a))) = 0

/-- Cyclicity removes the connection commutator from the boundary term. -/
theorem gaugeBoundary_iff_ordinary (trace : A →ₗ[ℝ] ℝ) (htrace : Cyclic trace)
    (d : ι → A →ₗ[ℝ] A) (U E : OneForm ι A) (ζ : A) :
    GaugeBoundary trace d U E ζ ↔ (∑ a, trace (d a (ζ * E a))) = 0 := by
  have h : (∑ a, trace (covariant d U a (ζ * E a))) = ∑ a, trace (d a (ζ * E a)) := by
    apply Finset.sum_congr rfl
    intro a _
    simp only [covariant, LinearMap.add_apply, comm_apply, map_add, map_sub,
      htrace (U a) (ζ * E a), sub_self, add_zero]
  unfold GaugeBoundary
  rw [h]

theorem integrated_gauge_product (trace : A →ₗ[ℝ] ℝ) (d : ι → A →ₗ[ℝ] A) (hd : Leibniz d)
    (U E : OneForm ι A) (ζ : A) (hb : GaugeBoundary trace d U E ζ) :
    -pair trace (fun a => covariant d U a ζ) E = trace (ζ * divergence d U E) := by
  have h := covariant_leibniz d hd U
  unfold Leibniz at h
  unfold GaugeBoundary at hb
  simp only [h, map_add, Finset.sum_add_distrib] at hb
  simp only [pair, divergence, Finset.mul_sum, map_sum]
  linarith

variable (trace : A →ₗ[ℝ] ℝ) (d : ι → A →ₗ[ℝ] A) (g : ι → ℝ)
variable (P₀ Q₀ : Insertion ι A) (B₀ : OneForm ι A) (lam m : ℝ)
variable (U : OneForm ι A) (ε : Aˣ)

/-- The dressing differential is represented by the covariant divergence
of the full connection Euler expression. -/
theorem dressingDerivative_eq_divergence (htrace : Cyclic trace) (hd : Leibniz d) (hc : Commuting d)
    (hp : Alternating P₀) (hq : Alternating Q₀)
    (hP : Parallel (covariant d B₀) P₀) (hQ : Parallel (covariant d B₀) Q₀)
    (ζ : A) (hb : ConnectionBoundary trace d P₀ Q₀ B₀ U ε ζ)
    (hg : GaugeBoundary trace d U (dressedEuler d g P₀ Q₀ B₀ lam m U ε) ζ) :
    dressingDerivative trace d g P₀ Q₀ B₀ lam m U ε ζ =
      trace (ζ * divergence d U (dressedEuler d g P₀ Q₀ B₀ lam m U ε)) := by
  rw [dressingDerivative_eq_neg_pair trace d g P₀ Q₀ B₀ lam m U ε htrace hd hc hp hq hP hQ ζ hb]
  exact integrated_gauge_product trace d hd U _ ζ hg

/-- Theorem 6.1 in the coordinate model. Separation of the two Euler
representatives by admissible tests turns the paired identity into
the off-shell identity `Eε = D_U,a E_U^a`. -/
theorem theorem_6_1 (htrace : Cyclic trace) (hd : Leibniz d) (hc : Commuting d)
    (hp : Alternating P₀) (hq : Alternating Q₀)
    (hP : Parallel (covariant d B₀) P₀) (hQ : Parallel (covariant d B₀) Q₀)
    (admissible : A → Prop)
    (hb : ∀ ζ, admissible ζ → ConnectionBoundary trace d P₀ Q₀ B₀ U ε ζ)
    (hg : ∀ ζ, admissible ζ →
      GaugeBoundary trace d U (dressedEuler d g P₀ Q₀ B₀ lam m U ε) ζ)
    (separates : ∀ Z : A, (∀ ζ, admissible ζ → trace (ζ * Z) = 0) → Z = 0)
    (Eε : A) (hE : ∀ ζ, admissible ζ →
      dressingDerivative trace d g P₀ Q₀ B₀ lam m U ε ζ = trace (ζ * Eε)) :
    Eε = divergence d U (dressedEuler d g P₀ Q₀ B₀ lam m U ε) := by
  apply sub_eq_zero.mp
  apply separates
  intro ζ hζ
  rw [mul_sub, map_sub, ← hE ζ hζ,
    dressingDerivative_eq_divergence trace d g P₀ Q₀ B₀ lam m U ε htrace hd hc hp hq hP hQ
      ζ (hb ζ hζ) (hg ζ hζ), sub_self]

end Noether

end

end GeometricUnity.NoetherIdentity
