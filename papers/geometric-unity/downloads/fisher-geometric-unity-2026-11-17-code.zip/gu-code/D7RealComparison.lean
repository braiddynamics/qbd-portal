import D7CliffordAdjoint
import D7SpinNullFrame
import D7VectorTensor
import Mathlib.LinearAlgebra.BilinearForm.Properties
import Mathlib.LinearAlgebra.DirectSum.TensorProduct
import Mathlib.LinearAlgebra.QuadraticForm.Radical
import Mathlib.LinearAlgebra.TensorProduct.Pi

/-!
# Complexification of the real Spin coefficient representations

The real split quadratic space is complexified in the same null frame
used for the complex orthogonal action. The Clifford-to-exterior
identification then transports the conjugation action on the skew-adjoint
spinor matrices to the exterior grades.
-/

namespace GeometricUnity.D7RealComparison

open D7Exterior D7SpinAction D7SpinNullFrame D7CliffordAdjoint
open D7CliffordMatrix (spinorUnits ComplexMat)
open scoped TensorProduct DirectSum

noncomputable section

abbrev Coefficients := ↥(D7UnitaryRealForm.skewAdjoint complexSignature)
abbrev RealExterior (k : ℕ) := ⋀[ℝ]^k Vector
abbrev ComplexExterior (k : ℕ) := ⋀[ℂ]^k Space

/-- The complexification of the real vector space in the split null frame. -/
def vectorComplexEquiv : ℂ ⊗[ℝ] Vector ≃ₗ[ℂ] Space :=
  (nullFrame.baseChange ℝ ℂ).trans (TensorProduct.piScalarRight ℝ ℂ ℂ Axis)

private def vectorInclusion : Vector →ₗ[ℝ] Space :=
  (vectorComplexEquiv.toLinearMap.restrictScalars ℝ).comp (TensorProduct.mk ℝ ℂ Vector 1)

private theorem vectorComplexEquiv_tmul (z : ℂ) (v : Vector) :
    vectorComplexEquiv (z ⊗ₜ[ℝ] v) = z • vectorInclusion v := by
  change vectorComplexEquiv (z ⊗ₜ[ℝ] v) = z • vectorComplexEquiv (1 ⊗ₜ[ℝ] v)
  rw [← map_smul, TensorProduct.smul_tmul', smul_eq_mul, mul_one]

private theorem vectorInclusion_apply (v : Vector) :
    vectorInclusion v = fun j => (nullFrame v j : ℂ) := by
  funext j
  change vectorComplexEquiv (1 ⊗ₜ[ℝ] v) j = _
  simp [vectorComplexEquiv, Complex.real_smul]

private theorem vectorInclusion_intertwines (g : Spin) (v : Vector) :
    vectorInclusion (vectorRepresentation g v) = complexNullAction g (vectorInclusion v) := by
  rw [vectorInclusion_apply, vectorInclusion_apply]
  have h := complexNullAction_ofReal g (nullFrame v)
  change complexNullAction g (fun j => (nullFrame v j : ℂ)) =
    fun j => (realNullAction g (nullFrame v) j : ℂ) at h
  rw [h, realNullAction_apply, nullFrame.symm_apply_apply]

theorem vectorComplexEquiv_intertwines (g : Spin) :
    vectorComplexEquiv.toLinearMap.comp ((vectorRepresentation g).baseChange ℂ) =
      (complexNullAction g).comp vectorComplexEquiv.toLinearMap := by
  apply TensorProduct.AlgebraTensorModule.ext
  intro z v
  simp only [LinearMap.comp_apply, LinearMap.baseChange_tmul, LinearEquiv.coe_coe,
    vectorComplexEquiv_tmul, map_smul, vectorInclusion_intertwines]

private def realBasis : Module.Basis Axis ℝ Vector :=
  (Pi.basisFun ℝ Axis).map nullFrame.symm

private theorem vectorInclusion_basis (i : Axis) : vectorInclusion (realBasis i) = axisBasis i := by
  funext j
  simp only [vectorInclusion_apply, realBasis, Module.Basis.map_apply, nullFrame.apply_symm_apply,
    axisBasis, Pi.basisFun_apply, Pi.single_apply]
  split_ifs <;> simp

private def realExteriorInclusion : ExteriorAlgebra ℝ Vector →ₐ[ℝ] ExteriorAlgebra ℂ Space :=
  ExteriorAlgebra.lift ℝ
    ⟨((ExteriorAlgebra.ι ℂ).restrictScalars ℝ).comp vectorInclusion, fun v =>
      ExteriorAlgebra.ι_sq_zero (vectorInclusion v)⟩

private theorem realExteriorInclusion_ι (v : Vector) :
    realExteriorInclusion (ExteriorAlgebra.ι ℝ v) = ExteriorAlgebra.ι ℂ (vectorInclusion v) := by
  exact ExteriorAlgebra.lift_ι_apply (R := ℝ)
    (((ExteriorAlgebra.ι ℂ).restrictScalars ℝ).comp vectorInclusion)
    (fun x => ExteriorAlgebra.ι_sq_zero (vectorInclusion x)) v

private theorem realExteriorInclusion_ιMulti (k : ℕ) (v : Fin k → Vector) :
    realExteriorInclusion (ExteriorAlgebra.ιMulti ℝ k v) =
      ExteriorAlgebra.ιMulti ℂ k (vectorInclusion ∘ v) := by
  simp only [ExteriorAlgebra.ιMulti_apply, map_list_prod, List.map_ofFn, Function.comp_def,
    realExteriorInclusion_ι]

private def exteriorComplexMap :
    ℂ ⊗[ℝ] ExteriorAlgebra ℝ Vector →ₗ[ℂ] ExteriorAlgebra ℂ Space :=
  realExteriorInclusion.toLinearMap.liftBaseChange ℂ

private def exteriorComplexEquiv :
    ℂ ⊗[ℝ] ExteriorAlgebra ℝ Vector ≃ₗ[ℂ] ExteriorAlgebra ℂ Space :=
  (realBasis.ExteriorAlgebra.baseChange ℂ).equiv axisBasis.ExteriorAlgebra (Equiv.refl _)

private theorem exteriorComplexEquiv_toLinearMap :
    exteriorComplexEquiv.toLinearMap = exteriorComplexMap := by
  apply (realBasis.ExteriorAlgebra.baseChange ℂ).ext
  intro s
  change exteriorComplexEquiv ((realBasis.ExteriorAlgebra.baseChange ℂ) s) = _
  rw [show exteriorComplexEquiv ((realBasis.ExteriorAlgebra.baseChange ℂ) s) =
      axisBasis.ExteriorAlgebra s from Module.Basis.equiv_apply _ _ _ _]
  simp only [Module.Basis.baseChange_apply, exteriorComplexMap, LinearMap.liftBaseChange_tmul,
    AlgHom.toLinearMap_apply, one_smul, ExteriorAlgebra.basis_apply, ExteriorAlgebra.ιMulti_family,
    realExteriorInclusion_ιMulti, Function.comp_def, vectorInclusion_basis]

private theorem realExteriorInclusion_intertwines (g : Spin) (x : ExteriorAlgebra ℝ Vector) :
    realExteriorInclusion (ExteriorAlgebra.map (vectorRepresentation g) x) =
      ExteriorAlgebra.map (complexNullAction g) (realExteriorInclusion x) := by
  have h : realExteriorInclusion.comp (ExteriorAlgebra.map (vectorRepresentation g)) =
      ((ExteriorAlgebra.map (complexNullAction g)).restrictScalars ℝ).comp realExteriorInclusion := by
    apply ExteriorAlgebra.hom_ext
    ext v
    simp only [LinearMap.comp_apply, AlgHom.toLinearMap_apply, AlgHom.comp_apply,
      ExteriorAlgebra.map_apply_ι, realExteriorInclusion_ι, AlgHom.restrictScalars_apply,
      vectorInclusion_intertwines]
  exact DFunLike.congr_fun h x

private theorem exteriorComplexEquiv_intertwines (g : Spin) :
    exteriorComplexEquiv.toLinearMap.comp
        ((ExteriorAlgebra.map (vectorRepresentation g)).toLinearMap.baseChange ℂ) =
      (ExteriorAlgebra.map (complexNullAction g)).toLinearMap.comp exteriorComplexEquiv.toLinearMap := by
  rw [exteriorComplexEquiv_toLinearMap]
  apply TensorProduct.AlgebraTensorModule.ext
  intro z x
  simp only [LinearMap.comp_apply, LinearMap.baseChange_tmul, exteriorComplexMap,
    LinearMap.liftBaseChange_tmul, AlgHom.toLinearMap_apply, map_smul,
    realExteriorInclusion_intertwines]

/-- Complexification commutes with taking each exterior power. -/
def gradeComplexEquiv (k : ℕ) : ℂ ⊗[ℝ] RealExterior k ≃ₗ[ℂ] ComplexExterior k :=
  ((realBasis.exteriorPower k).baseChange ℂ).equiv (axisBasis.exteriorPower k) (Equiv.refl _)

private theorem gradeComplexEquiv_subtype (k : ℕ) :
    (Submodule.subtype (ComplexExterior k)).comp (gradeComplexEquiv k).toLinearMap =
      exteriorComplexEquiv.toLinearMap.comp ((Submodule.subtype (RealExterior k)).baseChange ℂ) := by
  apply ((realBasis.exteriorPower k).baseChange ℂ).ext
  intro s
  rw [LinearMap.comp_apply, LinearMap.comp_apply]
  change ((gradeComplexEquiv k (((realBasis.exteriorPower k).baseChange ℂ) s) :
    ComplexExterior k) : ExteriorAlgebra ℂ Space) = exteriorComplexEquiv _
  rw [show gradeComplexEquiv k (((realBasis.exteriorPower k).baseChange ℂ) s) =
      axisBasis.exteriorPower k s from Module.Basis.equiv_apply _ _ _ _,
    Module.Basis.baseChange_apply, LinearMap.baseChange_tmul, Submodule.subtype_apply,
    ← ExteriorAlgebra.basis_eq_coe_basis axisBasis s, ← ExteriorAlgebra.basis_eq_coe_basis realBasis s]
  symm
  simpa only [exteriorComplexEquiv, Module.Basis.baseChange_apply, Equiv.refl_apply] using
    Module.Basis.equiv_apply (realBasis.ExteriorAlgebra.baseChange ℂ) s.val
      axisBasis.ExteriorAlgebra (Equiv.refl _)

private theorem exteriorMap_subtype {K M N : Type} [Field K]
    [AddCommGroup M] [AddCommGroup N] [Module K M] [Module K N] (k : ℕ) (f : M →ₗ[K] N) :
    (Submodule.subtype (⋀[K]^k N)).comp (exteriorPower.map k f) =
      (ExteriorAlgebra.map f).toLinearMap.comp (Submodule.subtype (⋀[K]^k M)) := by
  apply exteriorPower.linearMap_ext
  apply AlternatingMap.ext
  intro v
  simp only [LinearMap.compAlternatingMap_apply, LinearMap.comp_apply, Submodule.subtype_apply,
    exteriorPower.map_apply_ιMulti, exteriorPower.ιMulti_apply_coe, AlgHom.toLinearMap_apply,
    ExteriorAlgebra.map_apply_ιMulti]

theorem gradeComplexEquiv_intertwines (g : Spin) (k : ℕ) :
    (gradeComplexEquiv k).toLinearMap.comp ((exteriorPower.map k (vectorRepresentation g)).baseChange ℂ) =
      (exteriorRepresentation k (spinToSO g)).comp (gradeComplexEquiv k).toLinearMap := by
  apply LinearMap.ext
  intro x
  apply Subtype.ext
  have hR := exteriorMap_subtype k (vectorRepresentation g)
  have hC := exteriorMap_subtype k (complexNullAction g)
  have h := DFunLike.congr_fun (gradeComplexEquiv_subtype k)
  have he := DFunLike.congr_fun (exteriorComplexEquiv_intertwines g)
  have hRb := congrArg (LinearMap.baseChange ℂ) hR
  rw [LinearMap.baseChange_comp, LinearMap.baseChange_comp] at hRb
  change ((gradeComplexEquiv k ((exteriorPower.map k (vectorRepresentation g)).baseChange ℂ x) :
      ComplexExterior k) : ExteriorAlgebra ℂ Space) =
    ((exteriorPower.map k (complexNullAction g) (gradeComplexEquiv k x) :
      ComplexExterior k) : ExteriorAlgebra ℂ Space)
  calc
    _ = exteriorComplexEquiv
          (((Submodule.subtype (RealExterior k)).baseChange ℂ)
            ((exteriorPower.map k (vectorRepresentation g)).baseChange ℂ x)) :=
      h _
    _ = exteriorComplexEquiv
          (((ExteriorAlgebra.map (vectorRepresentation g)).toLinearMap.baseChange ℂ)
            (((Submodule.subtype (RealExterior k)).baseChange ℂ) x)) :=
      congrArg exteriorComplexEquiv (DFunLike.congr_fun hRb x)
    _ = (ExteriorAlgebra.map (complexNullAction g))
          (exteriorComplexEquiv (((Submodule.subtype (RealExterior k)).baseChange ℂ) x)) :=
      he _
    _ = _ := by
      have hs := h x
      change ((gradeComplexEquiv k x : ComplexExterior k) : ExteriorAlgebra ℂ Space) =
        exteriorComplexEquiv (((Submodule.subtype (RealExterior k)).baseChange ℂ) x) at hs
      rw [← hs]
      exact (DFunLike.congr_fun hC (gradeComplexEquiv k x)).symm

abbrev CoefficientGrades := ⨁ k : Fin 15, ComplexExterior k.val

private def assembleGrades : CoefficientGrades →ₗ[ℂ] ExteriorAlgebra ℂ Space :=
  DirectSum.toModule ℂ (Fin 15) _ fun k => Submodule.subtype (ComplexExterior k.val)

private def restrictGrades : (⨁ k : ℕ, ComplexExterior k) →ₗ[ℂ] CoefficientGrades :=
  DirectSum.toModule ℂ ℕ _ fun k =>
    if h : k < 15 then DirectSum.lof ℂ (Fin 15) (fun i => ComplexExterior i.val) ⟨k, h⟩ else 0

private abbrev exteriorDecomposition :=
  DirectSum.decomposeLinearEquiv (fun k : ℕ => ComplexExterior k)

private theorem assembleGrades_injective : Function.Injective assembleGrades := by
  have h : restrictGrades.comp (exteriorDecomposition.toLinearMap.comp assembleGrades) =
      LinearMap.id := by
    apply DirectSum.linearMap_ext
    intro k
    apply LinearMap.ext
    intro x
    simp only [LinearMap.comp_apply, assembleGrades, DirectSum.toModule_lof,
      Submodule.subtype_apply, LinearEquiv.coe_coe, DirectSum.decomposeLinearEquiv_apply_coe,
      restrictGrades, dif_pos k.isLt, LinearMap.id_apply, Fin.eta]
  intro x y he
  have he' := congrArg (fun z => restrictGrades (exteriorDecomposition z)) he
  change (restrictGrades.comp (exteriorDecomposition.toLinearMap.comp assembleGrades)) x =
    (restrictGrades.comp (exteriorDecomposition.toLinearMap.comp assembleGrades)) y at he'
  rw [h] at he'
  exact he'

private theorem assembleGrades_surjective : Function.Surjective assembleGrades := by
  rw [← LinearMap.range_eq_top]
  apply top_unique
  rw [← axisBasis.ExteriorAlgebra.span_eq]
  apply Submodule.span_le.mpr
  rintro _ ⟨s, rfl⟩
  have hs := Finset.card_le_univ s
  rw [Fintype.card_fin] at hs
  let k : Fin 15 := ⟨s.card, Nat.lt_succ_of_le hs⟩
  let s' : D7Exterior.Index k.val := ⟨s, rfl⟩
  refine ⟨DirectSum.lof ℂ _ _ k (axisBasis.exteriorPower k.val s'), ?_⟩
  rw [assembleGrades, DirectSum.toModule_lof, Submodule.subtype_apply]
  exact (ExteriorAlgebra.basis_eq_coe_basis axisBasis s').symm

private def assembleGradesEquiv : CoefficientGrades ≃ₗ[ℂ] ExteriorAlgebra ℂ Space :=
  LinearEquiv.ofBijective assembleGrades ⟨assembleGrades_injective, assembleGrades_surjective⟩

/-- The actual conjugation action is a representation on the real coefficient space. -/
def coefficientAction : Representation ℝ Spin Coefficients where
  toFun := coefficientConjugation
  map_one' := by
    apply LinearMap.ext
    intro x
    apply Subtype.ext
    change (↑(spinorUnits 1) : ComplexMat) * x.val *
      (↑(spinorUnits 1)⁻¹ : ComplexMat) = x.val
    simp
  map_mul' g h := by
    apply LinearMap.ext
    intro x
    apply Subtype.ext
    change (↑(spinorUnits (g * h)) : ComplexMat) * x.val *
      (↑(spinorUnits (g * h))⁻¹ : ComplexMat) =
      (↑(spinorUnits g) : ComplexMat) *
        ((↑(spinorUnits h) : ComplexMat) * x.val * (↑(spinorUnits h)⁻¹ : ComplexMat)) *
        (↑(spinorUnits g)⁻¹ : ComplexMat)
    simp only [map_mul, Units.val_mul, mul_inv_rev, mul_assoc]

/-- The ambient action on all fifteen coefficient grades. -/
def coefficientGradeAction : Representation ℂ splitSpecialOrthogonal CoefficientGrades :=
  Representation.directSum fun k => exteriorRepresentation k.val

private theorem assembleGrades_intertwines (f : splitSpecialOrthogonal) :
    assembleGrades.comp (coefficientGradeAction f) =
      (ExteriorAlgebra.map f.val).toLinearMap.comp assembleGrades := by
  apply DirectSum.linearMap_ext
  intro k
  apply LinearMap.ext
  intro x
  have h := DFunLike.congr_fun (exteriorMap_subtype k.val f.val) x
  simpa [coefficientGradeAction, Representation.directSum_apply, assembleGrades,
    exteriorRepresentation] using h

private def coefficientExteriorEquiv :
    ℂ ⊗[ℝ] Coefficients ≃ₗ[ℂ] ExteriorAlgebra ℂ Space :=
  cliffordCoefficientEquiv.trans
    (((CliffordAlgebra.equivExterior WitnessW1.splitForm).baseChange ℝ ℂ).trans exteriorComplexEquiv)

private theorem coefficientExteriorEquiv_intertwines (g : Spin) :
    coefficientExteriorEquiv.toLinearMap.comp ((coefficientAction g).baseChange ℂ) =
      (ExteriorAlgebra.map (complexNullAction g)).toLinearMap.comp coefficientExteriorEquiv.toLinearMap := by
  let e := CliffordAlgebra.equivExterior WitnessW1.splitForm
  have h : e.toLinearMap.comp (cliffordConjugation g).toLinearMap =
      (ExteriorAlgebra.map (vectorRepresentation g)).toLinearMap.comp e.toLinearMap :=
    LinearMap.ext (equivExterior_intertwines g)
  have h' := congrArg (LinearMap.baseChange ℂ) h
  rw [LinearMap.baseChange_comp, LinearMap.baseChange_comp] at h'
  apply LinearMap.ext
  intro x
  have h₁ := DFunLike.congr_fun (cliffordCoefficientEquiv_intertwines g) x
  have h₂ := DFunLike.congr_fun h' (cliffordCoefficientEquiv x)
  have h₃ := DFunLike.congr_fun (exteriorComplexEquiv_intertwines g)
    ((e.toLinearMap.baseChange ℂ) (cliffordCoefficientEquiv x))
  simp only [LinearMap.comp_apply, LinearEquiv.coe_coe, AlgHom.toLinearMap_apply] at h₁ h₂ h₃
  change exteriorComplexEquiv
      ((e.toLinearMap.baseChange ℂ) (cliffordCoefficientEquiv ((coefficientConjugation g).baseChange ℂ x))) =
    ExteriorAlgebra.map (complexNullAction g)
      (exteriorComplexEquiv ((e.toLinearMap.baseChange ℂ) (cliffordCoefficientEquiv x)))
  rw [h₁, h₂, h₃]

/-- The complexified real unitary coefficient space, decomposed into exterior grades. -/
def coefficientComplexEquiv : ℂ ⊗[ℝ] Coefficients ≃ₗ[ℂ] CoefficientGrades :=
  coefficientExteriorEquiv.trans assembleGradesEquiv.symm

theorem coefficientComplexEquiv_intertwines (g : Spin) :
    coefficientComplexEquiv.toLinearMap.comp ((coefficientAction g).baseChange ℂ) =
      (coefficientGradeAction (spinToSO g)).comp coefficientComplexEquiv.toLinearMap := by
  apply LinearMap.ext
  intro x
  apply assembleGrades_injective
  have h (z : ℂ ⊗[ℝ] Coefficients) :
      assembleGrades (coefficientComplexEquiv z) = coefficientExteriorEquiv z :=
    assembleGradesEquiv.apply_symm_apply (coefficientExteriorEquiv z)
  change assembleGrades (coefficientComplexEquiv ((coefficientAction g).baseChange ℂ x)) =
    assembleGrades (coefficientGradeAction (spinToSO g) (coefficientComplexEquiv x))
  rw [h]
  have ha := DFunLike.congr_fun (assembleGrades_intertwines (spinToSO g)) (coefficientComplexEquiv x)
  change assembleGrades (coefficientGradeAction (spinToSO g) (coefficientComplexEquiv x)) =
    ExteriorAlgebra.map (complexNullAction g) (assembleGrades (coefficientComplexEquiv x)) at ha
  rw [ha, h]
  exact DFunLike.congr_fun (coefficientExteriorEquiv_intertwines g) x

/-- Scalar extension of a real representation to a complex representation. -/
def complexify {M : Type*} [AddCommGroup M] [Module ℝ M]
    (ρ : Representation ℝ Spin M) : Representation ℂ Spin (ℂ ⊗[ℝ] M) :=
  (Module.End.baseChangeHom ℝ ℂ M).toMonoidHom.comp ρ

@[simp] theorem complexify_apply {M : Type*} [AddCommGroup M] [Module ℝ M]
    (ρ : Representation ℝ Spin M) (g : Spin) :
    complexify ρ g = (ρ g).baseChange ℂ := rfl

private def exteriorAction {M : Type*} [AddCommGroup M] [Module ℝ M]
    (ρ : Representation ℝ Spin M) (k : ℕ) : Representation ℝ Spin (⋀[ℝ]^k M) where
  toFun g := exteriorPower.map k (ρ g)
  map_one' := by rw [map_one, Module.End.one_eq_id, exteriorPower.map_id]; rfl
  map_mul' g h := by rw [map_mul, Module.End.mul_eq_comp, exteriorPower.map_comp]; rfl

/-- The action on real exterior powers induced by the real Spin vector action. -/
def realExteriorAction (k : ℕ) : Representation ℝ Spin (RealExterior k) :=
  exteriorAction vectorRepresentation k

private abbrev splitMetric : LinearMap.BilinForm ℝ Vector := WitnessW1.splitForm.associated

private theorem splitAssociated_nondegenerate : splitMetric.Nondegenerate := by
  apply QuadraticMap.nondegenerate_associated_iff.mpr
  apply QuadraticMap.nondegenerate_iff_radical_eq_bot.mpr
  rw [WitnessW1.splitForm, QuadraticForm.radical_weightedSumSquares]
  apply (Submodule.eq_bot_iff _).mpr
  intro x hx
  funext i
  apply Pi.mem_spanSubset_iff.mp hx i
  change WitnessW1.metricSign i ≠ 0
  unfold WitnessW1.metricSign
  split_ifs <;> norm_num

/-- The real split metric identifies the vector and covector Spin representations. -/
def metricDualEquiv : vectorRepresentation.Equiv vectorRepresentation.dual := by
  let e := LinearMap.BilinForm.toDual splitMetric splitAssociated_nondegenerate
  refine Representation.Equiv.mk e fun g => ?_
  apply LinearMap.ext
  intro v
  apply LinearMap.ext
  intro w
  change e (vectorRepresentation g v) w = e v (vectorRepresentation g⁻¹ w)
  simp only [e, LinearMap.BilinForm.toDual_def]
  have h := associated_preserves g v (vectorRepresentation g⁻¹ w)
  have hw : vectorRepresentation g (vectorRepresentation g⁻¹ w) = w := by
    change (vectorRepresentation g * vectorRepresentation g⁻¹) w = w
    rw [← map_mul, mul_inv_cancel, map_one]
    rfl
  rwa [hw] at h

abbrev Covector := Module.Dual ℝ Vector

/-- The action on real differential form factors. -/
def formAction (k : ℕ) : Representation ℝ Spin (⋀[ℝ]^k Covector) :=
  exteriorAction vectorRepresentation.dual k

/-- Raising indices with the split metric identifies the covariant and contravariant exterior actions. -/
def formMetricEquiv (k : ℕ) : (formAction k).Equiv (realExteriorAction k) := by
  let e := metricDualEquiv.symm
  let E : (⋀[ℝ]^k Covector) ≃ₗ[ℝ] RealExterior k := LinearEquiv.ofLinearMap
    (exteriorPower.map k e.toLinearEquiv.toLinearMap)
    (exteriorPower.map k e.toLinearEquiv.symm.toLinearMap)
    (by rw [← exteriorPower.map_comp, LinearEquiv.comp_symm, exteriorPower.map_id])
    (by rw [← exteriorPower.map_comp, LinearEquiv.symm_comp, exteriorPower.map_id])
  refine Representation.Equiv.mk E fun g => ?_
  change exteriorPower.map k e.toLinearEquiv.toLinearMap ∘ₗ
      exteriorPower.map k (vectorRepresentation.dual g) =
    exteriorPower.map k (vectorRepresentation g) ∘ₗ exteriorPower.map k e.toLinearEquiv.toLinearMap
  rw [← exteriorPower.map_comp, ← exteriorPower.map_comp]
  exact congrArg (exteriorPower.map k) (e.isIntertwining' g)

private def complexifyEquiv {M N : Type*} [AddCommGroup M] [AddCommGroup N]
    [Module ℝ M] [Module ℝ N] {ρ : Representation ℝ Spin M} {σ : Representation ℝ Spin N}
    (e : ρ.Equiv σ) : (complexify ρ).Equiv (complexify σ) :=
  Representation.Equiv.mk (e.toLinearEquiv.baseChange ℝ ℂ) fun g => by
    simpa only [LinearEquiv.coe_baseChange, complexify_apply, LinearMap.baseChange_comp] using
      congrArg (LinearMap.baseChange ℂ) (e.isIntertwining' g)

/-- The complex ambient action with the same tensor factor attached to each coefficient grade. -/
def tensorGradeAction {U : Type*} [AddCommGroup U] [Module ℂ U]
    (σ : Representation ℂ splitSpecialOrthogonal U) :
    Representation ℂ splitSpecialOrthogonal (⨁ k : Fin 15, U ⊗[ℂ] ComplexExterior k.val) :=
  Representation.directSum fun k => σ.tprod (exteriorRepresentation k.val)

private def distributeGrades {U : Type*} [AddCommGroup U] [Module ℂ U]
    (σ : Representation ℂ splitSpecialOrthogonal U) :
    (σ.tprod coefficientGradeAction).Equiv (tensorGradeAction σ) := by
  let e := TensorProduct.directSumRight ℂ ℂ U (fun k : Fin 15 => ComplexExterior k.val)
  refine Representation.Equiv.mk e fun f => ?_
  apply TensorProduct.ext'
  intro u z
  let j := TensorProduct.mk ℂ U CoefficientGrades u
  suffices h : (e.toLinearMap.comp ((σ.tprod coefficientGradeAction) f)).comp j =
      ((tensorGradeAction σ f).comp e.toLinearMap).comp j from DFunLike.congr_fun h z
  apply DirectSum.linearMap_ext
  intro k
  apply LinearMap.ext
  intro x
  simp [j, e, Representation.tprod_apply, coefficientGradeAction, tensorGradeAction,
    Representation.directSum_apply]

private def tensorComplexEquiv {M U : Type*} [AddCommGroup M] [Module ℝ M]
    [AddCommGroup U] [Module ℂ U]
    (ρ : Representation ℝ Spin M) (σ : Representation ℂ splitSpecialOrthogonal U)
    (e : (complexify ρ).Equiv (σ.comp spinToSO)) :
    (complexify (ρ.tprod coefficientAction)).Equiv
      ((σ.tprod coefficientGradeAction).comp spinToSO) := by
  let E := (TensorProduct.AlgebraTensorModule.distribBaseChange ℝ ℂ M Coefficients).trans
    (TensorProduct.congr e.toLinearEquiv coefficientComplexEquiv)
  refine Representation.Equiv.mk E fun g => ?_
  apply TensorProduct.AlgebraTensorModule.ext
  intro c t
  let j := TensorProduct.mk ℝ ℂ (M ⊗[ℝ] Coefficients) c
  suffices h : (((E.toLinearMap.comp (complexify (ρ.tprod coefficientAction) g)).restrictScalars ℝ).comp j) =
      (((((σ.tprod coefficientGradeAction).comp spinToSO) g).comp E.toLinearMap).restrictScalars ℝ).comp j
      from DFunLike.congr_fun h t
  apply TensorProduct.ext'
  intro m x
  have hv := DFunLike.congr_fun (e.isIntertwining' g) (c ⊗ₜ[ℝ] m)
  change e.toLinearEquiv (complexify ρ g (c ⊗ₜ[ℝ] m)) =
    σ (spinToSO g) (e.toLinearEquiv (c ⊗ₜ[ℝ] m)) at hv
  have hx := DFunLike.congr_fun (coefficientComplexEquiv_intertwines g) (1 ⊗ₜ[ℝ] x)
  simp only [LinearMap.comp_apply, LinearEquiv.coe_coe, complexify_apply, LinearMap.baseChange_tmul] at hv hx
  simp only [LinearMap.comp_apply, LinearMap.restrictScalars_apply, j, TensorProduct.mk_apply,
    LinearEquiv.coe_coe, E, LinearEquiv.trans_apply, complexify_apply, LinearMap.baseChange_tmul,
    Representation.tprod_apply, MonoidHom.comp_apply, TensorProduct.map_tmul,
    TensorProduct.AlgebraTensorModule.distribBaseChange_tmul, TensorProduct.congr_tmul,
    hv, hx]

/-- Compare a tensor of a real Spin factor with the actual coefficient action to
the direct sum of the corresponding complex tensor grades. -/
def tensorComparison {M U : Type*} [AddCommGroup M] [Module ℝ M] [AddCommGroup U] [Module ℂ U]
    (ρ : Representation ℝ Spin M) (σ : Representation ℂ splitSpecialOrthogonal U)
    (e : (complexify ρ).Equiv (σ.comp spinToSO)) :
    (complexify (ρ.tprod coefficientAction)).Equiv ((tensorGradeAction σ).comp spinToSO) :=
  (tensorComplexEquiv ρ σ e).trans <|
    Representation.Equiv.mk (distributeGrades σ).toLinearEquiv
      (fun g => (distributeGrades σ).isIntertwining' (spinToSO g))

/-- The exterior-factor comparison, including the two-form source and the alternating channel. -/
def exteriorCoefficientComparison (k : ℕ) :
    (complexify (M := RealExterior k ⊗[ℝ] Coefficients)
      ((realExteriorAction k).tprod coefficientAction)).Equiv
      ((tensorGradeAction (exteriorRepresentation k)).comp spinToSO) :=
  tensorComparison (realExteriorAction k) (exteriorRepresentation k) <|
    Representation.Equiv.mk (gradeComplexEquiv k) (gradeComplexEquiv_intertwines · k)

/-- The vector-factor comparison for the target of the unrestricted contractions. -/
def vectorCoefficientComparison :
    (complexify (vectorRepresentation.tprod coefficientAction)).Equiv
      ((tensorGradeAction D7VectorTensor.vectorAction).comp spinToSO) :=
  tensorComparison vectorRepresentation D7VectorTensor.vectorAction <|
    Representation.Equiv.mk vectorComplexEquiv vectorComplexEquiv_intertwines

/-- The form-factor comparison on the real covariant source and alternating channel. -/
def formCoefficientComparison (k : ℕ) :
    (complexify (M := (⋀[ℝ]^k Covector) ⊗[ℝ] Coefficients)
      ((formAction k).tprod coefficientAction)).Equiv
      ((tensorGradeAction (exteriorRepresentation k)).comp spinToSO) :=
  tensorComparison (formAction k) (exteriorRepresentation k) <|
    (complexifyEquiv (formMetricEquiv k)).trans
      (Representation.Equiv.mk (gradeComplexEquiv k) (gradeComplexEquiv_intertwines · k))

/-- The one-form factor in the real codomain of Theorem 3.4. -/
def covectorCoefficientComparison :
    (complexify (M := Covector ⊗[ℝ] Coefficients)
      (vectorRepresentation.dual.tprod coefficientAction)).Equiv
      ((tensorGradeAction D7VectorTensor.vectorAction).comp spinToSO) :=
  tensorComparison vectorRepresentation.dual D7VectorTensor.vectorAction <|
    (complexifyEquiv metricDualEquiv.symm).trans
      (Representation.Equiv.mk vectorComplexEquiv vectorComplexEquiv_intertwines)

end

end GeometricUnity.D7RealComparison
