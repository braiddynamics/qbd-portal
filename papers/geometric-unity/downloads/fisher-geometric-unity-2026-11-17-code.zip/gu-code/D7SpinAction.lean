import WitnessW1
import Mathlib.LinearAlgebra.CliffordAlgebra.SpinGroup
import Mathlib.LinearAlgebra.ExteriorPower.Basic
import Mathlib.RepresentationTheory.Basic

/-!
# The real Spin action on the split quadratic space

Clifford conjugation gives a linear action on the embedded vectors.
The Clifford square relation proves that this action preserves the
quadratic form of signature `(7,7)`.
-/

namespace GeometricUnity.D7SpinAction

open WitnessW1 (Index splitForm Cl)

noncomputable section

abbrev Vector := Index → ℝ
abbrev Spin := ↥(spinGroup splitForm)

private abbrev iota := CliffordAlgebra.ι splitForm

theorem iota_injective : Function.Injective (CliffordAlgebra.ι splitForm) := by
  intro x y h
  have h' := congrArg (CliffordAlgebra.equivExterior splitForm) h
  apply (ExteriorAlgebra.ι_inj ℝ x y).mp
  simpa only [CliffordAlgebra.equivExterior, CliffordAlgebra.changeFormEquiv_apply,
    CliffordAlgebra.changeForm_ι] using h'

private abbrev units : Spin →* Clˣ := spinGroup.toUnits

private def vectorAction (g : Spin) : Vector →ₗ[ℝ] Vector :=
  (((LinearMap.mulLeftRight ℝ ((units g : Cl), (↑(units g)⁻¹ : Cl)) : Cl →ₗ[ℝ] Cl).comp
    iota).codRestrictOfInjective iota iota_injective (by
      intro x
      simpa only [LinearMap.comp_apply, LinearMap.mulLeftRight_apply, ConjAct.units_smul_def,
        ConjAct.ofConjAct_toConjAct] using
        spinGroup.conjAct_smul_ι_mem_range_ι (x := units g) g.prop x))

private theorem iota_vectorAction (g : Spin) (x : Vector) :
    iota (vectorAction g x) = (units g : Cl) * iota x * (↑(units g)⁻¹ : Cl) :=
  LinearMap.codRestrictOfInjective_comp_apply _ _ _ _ x

/-- The vector representation of the real Clifford Spin group. -/
def vectorRepresentation : Representation ℝ Spin Vector where
  toFun := vectorAction
  map_one' := by
    apply LinearMap.ext
    intro x
    apply iota_injective
    change iota (vectorAction 1 x) = iota x
    simp only [iota_vectorAction, map_one, inv_one, Units.val_one, one_mul, mul_one]
  map_mul' g h := by
    apply LinearMap.ext
    intro x
    apply iota_injective
    change iota (vectorAction (g * h) x) = iota (vectorAction g (vectorAction h x))
    simp only [iota_vectorAction, map_mul, Units.val_mul, mul_inv_rev, mul_assoc]

theorem iota_vectorRepresentation (g : Spin) (x : Vector) :
    iota (vectorRepresentation g x) = (units g : Cl) * iota x * (↑(units g)⁻¹ : Cl) :=
  iota_vectorAction g x

/-- The real Spin vector action is orthogonal for the split quadratic form. -/
theorem vectorRepresentation_preserves (g : Spin) (x : Vector) :
    splitForm (vectorRepresentation g x) = splitForm x := by
  apply (algebraMap ℝ Cl).injective
  rw [← CliffordAlgebra.ι_sq_scalar splitForm (vectorRepresentation g x),
    iota_vectorRepresentation]
  let u : Cl := units g
  let v : Cl := ↑(units g)⁻¹
  have h : v * u = 1 := (units g).inv_mul
  have h' : u * v = 1 := (units g).mul_inv
  change (u * iota x * v) * (u * iota x * v) = algebraMap ℝ Cl (splitForm x)
  calc
    _ = (u * iota x) * (v * u) * iota x * v := by simp only [mul_assoc]
    _ = u * (iota x * iota x) * v := by rw [h, mul_one, mul_assoc u (iota x) (iota x)]
    _ = _ := by rw [CliffordAlgebra.ι_sq_scalar, ← Algebra.commutes, mul_assoc, h', mul_one]

/-- Spin conjugation on the entire real Clifford algebra. -/
def cliffordConjugation (g : Spin) : Cl ≃ₐ[ℝ] Cl :=
  MulSemiringAction.toAlgEquiv ℝ Cl (ConjAct.toConjAct (units g))

private theorem cliffordConjugation_iota (g : Spin) (x : Vector) :
    cliffordConjugation g (iota x) = iota (vectorRepresentation g x) :=
  (iota_vectorRepresentation g x).symm

theorem associated_preserves (g : Spin) (x y : Vector) :
    splitForm.associated (vectorRepresentation g x) (vectorRepresentation g y) =
      splitForm.associated x y := by
  rw [QuadraticMap.associated_apply, QuadraticMap.associated_apply, ← map_add,
    vectorRepresentation_preserves, vectorRepresentation_preserves, vectorRepresentation_preserves]

private theorem exteriorMap_contract
    (v : Vector →ₗ[ℝ] Vector) (d : Module.Dual ℝ Vector) (x : ExteriorAlgebra ℝ Vector) :
    ExteriorAlgebra.map v (CliffordAlgebra.contractLeft (d.comp v) x) =
      CliffordAlgebra.contractLeft d (ExteriorAlgebra.map v x) := by
  induction x using CliffordAlgebra.left_induction with
  | algebraMap r =>
    simp only [CliffordAlgebra.contractLeft_algebraMap, map_zero, AlgHom.commutes]
  | add x y hx hy =>
    simp only [map_add, hx, hy]
  | ι_mul z a hz =>
    change ExteriorAlgebra.map v
        (CliffordAlgebra.contractLeft (d.comp v) (ExteriorAlgebra.ι ℝ a * z)) =
      CliffordAlgebra.contractLeft d (ExteriorAlgebra.map v (ExteriorAlgebra.ι ℝ a * z))
    simp only [map_mul, ExteriorAlgebra.map_apply_ι]
    rw [CliffordAlgebra.contractLeft_ι_mul, CliffordAlgebra.contractLeft_ι_mul]
    simp only [map_sub, map_smul, LinearMap.comp_apply, map_mul, ExteriorAlgebra.map_apply_ι, hz]

/-- The canonical Clifford-to-exterior linear equivalence intertwines
real Spin conjugation with the induced action on the exterior algebra. -/
theorem equivExterior_intertwines (g : Spin) (x : Cl) :
    CliffordAlgebra.equivExterior splitForm (cliffordConjugation g x) =
      ExteriorAlgebra.map (vectorRepresentation g) (CliffordAlgebra.equivExterior splitForm x) := by
  let q := splitForm
  let v := vectorRepresentation g
  let B := QuadraticMap.associated (-q)
  let hB : B.toQuadraticMap = 0 - q := CliffordAlgebra.changeForm.associated_neg_proof
  change CliffordAlgebra.changeForm hB (cliffordConjugation g x) =
    ExteriorAlgebra.map v (CliffordAlgebra.changeForm hB x)
  induction x using CliffordAlgebra.left_induction with
  | algebraMap r =>
    change CliffordAlgebra.changeForm hB
        (cliffordConjugation g (algebraMap ℝ (CliffordAlgebra q) r)) =
      ExteriorAlgebra.map v (CliffordAlgebra.changeForm hB (algebraMap ℝ (CliffordAlgebra q) r))
    have hr := CliffordAlgebra.changeForm_algebraMap hB r
    have hconj : cliffordConjugation g (algebraMap ℝ (CliffordAlgebra q) r) =
        algebraMap ℝ (CliffordAlgebra q) r := AlgEquiv.commutes _ _
    rw [hconj, hr]
    exact (AlgHom.commutes (ExteriorAlgebra.map v) r).symm
  | add x y hx hy =>
    simp only [map_add, hx, hy]
  | ι_mul z a hz =>
    rw [map_mul, cliffordConjugation_iota, CliffordAlgebra.changeForm_ι_mul,
      CliffordAlgebra.changeForm_ι_mul, map_sub, map_mul, hz]
    have he : (B (v a)).comp v = B a := by
      apply LinearMap.ext
      intro b
      change QuadraticMap.associated (-splitForm) (v a) (v b) =
        QuadraticMap.associated (-splitForm) a b
      simp only [map_neg, LinearMap.neg_apply, v, associated_preserves]
    have ha : ExteriorAlgebra.map v (CliffordAlgebra.ι (0 : QuadraticForm ℝ Vector) a) =
        CliffordAlgebra.ι 0 (v a) := ExteriorAlgebra.map_apply_ι v a
    rw [← he, exteriorMap_contract, ha]

/-- Under the Clifford-to-exterior equivalence, each grade transforms by
the corresponding exterior power of the vector representation. -/
theorem equivExterior_grade_action (g : Spin) {k : ℕ} (x : ⋀[ℝ]^k Vector) :
    CliffordAlgebra.equivExterior splitForm
        (cliffordConjugation g ((CliffordAlgebra.equivExterior splitForm).symm x.val)) =
      (exteriorPower.map k (vectorRepresentation g) x).val := by
  rw [equivExterior_intertwines, LinearEquiv.apply_symm_apply]
  let v := vectorRepresentation g
  have h :
      (ExteriorAlgebra.map v).toLinearMap.comp (Submodule.subtype (⋀[ℝ]^k Vector)) =
        (Submodule.subtype (⋀[ℝ]^k Vector)).comp (exteriorPower.map k v) := by
    apply exteriorPower.linearMap_ext
    apply AlternatingMap.ext
    intro m
    simp only [LinearMap.compAlternatingMap_apply, LinearMap.comp_apply, Submodule.subtype_apply,
      exteriorPower.map_apply_ιMulti, exteriorPower.ιMulti_apply_coe, AlgHom.toLinearMap_apply,
      ExteriorAlgebra.map_apply_ιMulti]
  exact DFunLike.congr_fun h x

end

end GeometricUnity.D7SpinAction
