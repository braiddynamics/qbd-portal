import D7TensorColumns

/-!
# Plane rotations on vector–exterior coordinates

A quarter-turn permutes the normalized coefficients in either block family.
An ordinary plane rotation converts a repeated difference into a distinct
difference and conversely.
-/

namespace GeometricUnity.D7TensorRotations

open D7Exterior D7Hodge D7Irreducible D7VectorTensor D7VectorGrades D7Hook D7TensorColumns TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

private abbrev e := orthBasis

theorem map_basis_fixed {n : ℕ} (g : splitSpecialOrthogonal) (R : Index n)
    (h : ∀ k ∈ R.val, g.val (e k) = e k) :
    exteriorPower.map n g.val (basis n R) = basis n R := by
  rw [exteriorPower.basis_apply, exteriorPower.ιMulti_family, exteriorPower.map_apply_ιMulti]
  congr 1
  funext k
  exact h _ (Finset.orderEmbOfFin_mem R.val R.prop k)

private theorem wedge_plane {n : ℕ} (x y : Space) (u : Ext n) (c s : ℂ)
    (h : c * c + s * s = 1) :
    wedgeLeftLinear (n + 1) (c • x + s • y) (wedgeLeftLinear n ((-s) • x + c • y) u) =
      wedgeLeftLinear (n + 1) x (wedgeLeftLinear n y u) := by
  calc
    _ = (c * c + s * s) • wedgeLeftLinear (n + 1) x (wedgeLeftLinear n y u) := by
      simp only [map_add, LinearMap.add_apply, map_smul, LinearMap.smul_apply, wedgeLeft_sq,
        smul_zero, zero_add, add_zero, wedgeLeft_swap y x u]
      module
    _ = _ := by rw [h, one_smul]

/-- A plane rotation fixes the coordinate wedge when the block contains both
rotated axes or when it contains neither. -/
theorem map_basis_plane {n : ℕ} (g : splitSpecialOrthogonal) (i j : Axis) (hij : i ≠ j) (c s : ℂ)
    (hc : c * c + s * s = 1)
    (hi : g.val (e i) = c • e i + s • e j) (hj : g.val (e j) = (-s) • e i + c • e j)
    (hoff : ∀ k, k ≠ i → k ≠ j → g.val (e k) = e k)
    (R : Index n) (hR : i ∈ R.val ↔ j ∈ R.val) : exteriorPower.map n g.val (basis n R) = basis n R := by
  by_cases hRi : i ∈ R.val
  · have hRj := hR.mp hRi
    cases n with
    | zero =>
      have hempty : R.val = ∅ := Finset.card_eq_zero.mp R.prop
      simp [hempty] at hRi
    | succ n =>
      let S := eraseIndex R i hRi
      have hSj : j ∈ S.val := Finset.mem_erase.mpr ⟨hij.symm, hRj⟩
      cases n with
      | zero =>
        have hempty : S.val = ∅ := Finset.card_eq_zero.mp S.prop
        simp [hempty] at hSj
      | succ n =>
        let T := eraseIndex S j hSj
        have hT := map_basis_fixed g T (fun k hk => hoff k
          (Finset.mem_erase.mp (Finset.mem_erase.mp hk).2).1 (Finset.mem_erase.mp hk).1)
        change exteriorPower.map n g.val (basis n (eraseIndex S j hSj)) = _ at hT
        obtain ⟨d, _, hd⟩ := basis_eq_wedge_erase R i hRi
        obtain ⟨z, _, hz⟩ := basis_eq_wedge_erase S j hSj
        rw [hd]
        change exteriorPower.map (n + 2) g.val (d • wedgeLeftLinear (n + 1) (e i) (basis (n + 1) S)) = _
        rw [hz]
        simp only [map_smul, wedgeLeft_naturality, hT, hi, hj, wedge_plane _ _ _ _ _ hc]
        rfl
  · have hRj : j ∉ R.val := fun h => hRi (hR.mpr h)
    exact map_basis_fixed g R fun k hk => hoff k (fun h => hRi (h ▸ hk)) (fun h => hRj (h ▸ hk))

def quarterTurn (i j : Axis) : splitSpecialOrthogonal := orientedPermAt (Equiv.swap i j) i

theorem quarterTurn_basis (i j : Axis) (hij : i ≠ j) :
    (quarterTurn i j).val (e i) = -e j ∧ (quarterTurn i j).val (e j) = e i := by
  constructor
  · simp [quarterTurn, orientedPermAt_basis, orientationCorrection, signScalar, Equiv.Perm.sign_swap hij]
  · simp [quarterTurn, orientedPermAt_basis, orientationCorrection, hij.symm]

theorem quarterTurn_off_plane (i j k : Axis) (hi : k ≠ i) (hj : k ≠ j) :
    (quarterTurn i j).val (e k) = e k := by
  simp [quarterTurn, orientedPermAt_basis, orientationCorrection, Equiv.swap_apply_of_ne_of_ne hi hj, hi]

theorem quarterTurn_exterior {n : ℕ} (i j : Axis) (hij : i ≠ j) (R : Index n)
    (hR : i ∈ R.val ↔ j ∈ R.val) :
    exteriorPower.map n (quarterTurn i j).val (basis n R) = basis n R := by
  obtain ⟨hi, hj⟩ := quarterTurn_basis i j hij
  apply map_basis_plane _ i j hij 0 (-1) (by norm_num) _ _ (quarterTurn_off_plane i j) R hR
  · simpa using hi
  · simpa using hj

theorem quarterTurn_repeated {n : ℕ} (i j : Axis) (hij : i ≠ j) (R : Index n)
    (hR : i ∈ R.val ↔ j ∈ R.val) (k : Axis) :
    action (n + 1) (quarterTurn i j) (repeated R k) = repeated R (Equiv.swap i j k) := by
  rw [repeated, action_tmul, wedgeLeft_naturality, quarterTurn_exterior i j hij R hR,
    quarterTurn, orientedPermAt_basis]
  simp only [map_smul, LinearMap.smul_apply, smul_tmul_smul, correction_sq, one_smul, repeated]

theorem quarterTurn_distinct {n : ℕ} (i j : Axis) (hij : i ≠ j) (S : Index (n + 2))
    (hS : i ∈ S.val ↔ j ∈ S.val) (k : Axis) :
    action (n + 1) (quarterTurn i j) (distinct S k) = distinct S (Equiv.swap i j k) := by
  rw [distinct, action_tmul, contractLeft_naturality, quarterTurn_exterior i j hij S hS,
    quarterTurn, orientedPermAt_basis]
  simp only [map_smul, LinearMap.smul_apply, smul_tmul_smul, correction_sq, one_smul, distinct]

theorem perm_repeated {n : ℕ} (σ : Equiv.Perm Axis) (p : Axis) (R : Index n) :
    ∃ d : ℂ, d ≠ 0 ∧ ∀ i,
      action (n + 1) (orientedPermAt σ p) (repeated R i) = d • repeated (permIndex σ R) (σ i) := by
  let g := orientedPermAt σ p
  obtain ⟨d, hd, he⟩ := orientedPerm_exterior σ p R
  change exteriorPower.map n g.val (basis n R) = _ at he
  refine ⟨d, hd, fun i => ?_⟩
  rw [repeated, action_tmul, wedgeLeft_naturality n g, he, orientedPermAt_basis]
  simp only [map_smul, LinearMap.smul_apply, smul_smul, smul_tmul_smul, repeated]
  rw [mul_comm d (orientationCorrection σ p i), ← mul_assoc, correction_sq, one_mul]

private def markedCoordinates {n : ℕ} (R : Index n) (i j : Axis) : Bool ⊕ ↥R.val → Axis :=
  Sum.elim (fun q => if q then i else j) Subtype.val

private theorem markedCoordinates_injective {n : ℕ} (R : Index n) (i j : Axis)
    (hi : i ∉ R.val) (hj : j ∉ R.val) (hij : i ≠ j) :
    Function.Injective (markedCoordinates R i j) := by
  intro x y h
  cases x with
  | inl x =>
    cases y with
    | inl y => cases x <;> cases y <;> simp_all [markedCoordinates]
    | inr y =>
      cases x
      · change j = y.val at h
        exact (hj (h ▸ y.prop)).elim
      · change i = y.val at h
        exact (hi (h ▸ y.prop)).elim
  | inr x =>
    cases y with
    | inl y =>
      cases y
      · change x.val = j at h
        exact (hj (h ▸ x.prop)).elim
      · change x.val = i at h
        exact (hi (h ▸ x.prop)).elim
    | inr y => exact congrArg Sum.inr (Subtype.ext h)

theorem perm_marked {n : ℕ} (R S : Index n) (i j k l : Axis)
    (hi : i ∉ R.val) (hj : j ∉ R.val) (hij : i ≠ j)
    (hk : k ∉ S.val) (hl : l ∉ S.val) (hkl : k ≠ l) :
    ∃ σ : Equiv.Perm Axis, permIndex σ R = S ∧ σ i = k ∧ σ j = l := by
  let q := Equiv.sumCongr (Equiv.refl Bool) (R.val.equivOfCardEq (R.prop.trans S.prop.symm))
  obtain ⟨σ, hσ⟩ := Equiv.Perm.exists_extending_pair (markedCoordinates R i j)
    (markedCoordinates S k l ∘ q) (markedCoordinates_injective R i j hi hj hij)
    ((markedCoordinates_injective S k l hk hl hkl).comp q.injective)
  refine ⟨σ, ?_, hσ (.inl true), hσ (.inl false)⟩
  apply Subtype.ext
  apply Finset.eq_of_subset_of_card_le
  · intro a ha
    obtain ⟨b, hb, rfl⟩ := Finset.mem_map.mp ha
    let y := R.val.equivOfCardEq (R.prop.trans S.prop.symm) ⟨b, hb⟩
    have h : σ b = y.val := hσ (.inr ⟨b, hb⟩)
    exact h.symm ▸ y.prop
  · simp [permIndex]

private abbrev bridgeTerm {n : ℕ} (R : Index n) (i j : Axis) : Product (n + 1) :=
  e i ⊗ₜ[ℂ] wedgeLeftLinear n (e j) (basis n R)

theorem contract_wedge_basis_of_ne {n : ℕ} (R : Index n) (i j : Axis) (hij : i ≠ j) (hi : i ∉ R.val) :
    contractLeft n (e i) (wedgeLeftLinear n (e j) (basis n R)) = 0 := by
  cases n with
  | zero => rw [contract_wedgeLeft_zero, orthBasis_pair, if_neg hij, zero_smul]
  | succ n =>
    rw [contract_wedgeLeft, orthBasis_pair, if_neg hij, zero_smul, contractLeft_basis_zero R i hi, map_zero, sub_zero]

private theorem contract_pair {n : ℕ} (R : Index n) (i j : Axis) (hij : i ≠ j) (hi : i ∉ R.val) :
    contractLeft (n + 1) (e i) (wedgeLeftLinear (n + 1) (e i) (wedgeLeftLinear n (e j) (basis n R))) =
      wedgeLeftLinear n (e j) (basis n R) := by
  rw [contract_wedgeLeft, orthBasis_pair, if_pos rfl, one_smul,
    contract_wedge_basis_of_ne R i j hij hi, map_zero, sub_zero]

private theorem basis_pair {n : ℕ} (R : Index n) (S : Index (n + 2)) (i j : Axis)
    (hij : i ≠ j) (hiR : i ∉ R.val) (hjR : j ∉ R.val) (hS : S.val = insert i (insert j R.val)) :
    ∃ d : ℂ, d ≠ 0 ∧ basis (n + 2) S =
      d • wedgeLeftLinear (n + 1) (e i) (wedgeLeftLinear n (e j) (basis n R)) := by
  have hi : i ∈ S.val := by rw [hS]; exact Finset.mem_insert_self _ _
  let T := eraseIndex S i hi
  have hT : T.val = insert j R.val := by
    change S.val.erase i = _
    rw [hS, Finset.erase_insert (by simp [hij, hiR])]
  have hj : j ∈ T.val := by rw [hT]; exact Finset.mem_insert_self _ _
  have hR : eraseIndex T j hj = R := by
    apply Subtype.ext
    change T.val.erase j = _
    rw [hT, Finset.erase_insert hjR]
  obtain ⟨a, ha, hA⟩ := basis_eq_wedge_erase S i hi
  obtain ⟨b, hb, hB⟩ := basis_eq_wedge_erase T j hj
  rw [hR] at hB
  refine ⟨a * b, mul_ne_zero ha hb, ?_⟩
  rw [hA]
  change a • wedgeLeftLinear (n + 1) (e i) (basis (n + 1) T) = _
  rw [hB, map_smul, smul_smul]

private theorem bridge_coord {n : ℕ} (R : Index n) (S : Index (n + 2)) (i j : Axis)
    (hij : i ≠ j) (hi : i ∉ R.val) (hj : j ∉ R.val) (hS : S.val = insert i (insert j R.val)) :
    ∃ d : ℂ, d ≠ 0 ∧ distinct S i - distinct S j = d • (bridgeTerm R i j + bridgeTerm R j i) := by
  obtain ⟨d, hd, h⟩ := basis_pair R S i j hij hi hj hS
  have h₁ : distinct S i = d • bridgeTerm R i j := by
    rw [distinct, h, map_smul, contract_pair R i j hij hi, tmul_smul]
  have h₂ : distinct S j = - (d • bridgeTerm R j i) := by
    rw [distinct, h, map_smul, wedgeLeft_swap (e i) (e j), map_neg, contract_pair R j i hij.symm hj,
      smul_neg, tmul_neg, tmul_smul]
  refine ⟨d, hd, ?_⟩
  rw [h₁, h₂, sub_neg_eq_add, smul_add]

private theorem plane_mix {n : ℕ} (R : Index n) (i j : Axis) (hij : i ≠ j)
    (hi : i ∉ R.val) (hj : j ∉ R.val) :
    let A := repeated R i - repeated R j
    let B := bridgeTerm R i j + bridgeTerm R j i
    let g := rotation i j hij
    action (n + 1) g A = (-527 / 625 : ℂ) • A + (-336 / 625 : ℂ) • B ∧
    action (n + 1) g B = (336 / 625 : ℂ) • A + (-527 / 625 : ℂ) • B := by
  let g := rotation i j hij
  obtain ⟨hi', hj'⟩ := rotation_on_plane i j hij
  have hR := map_basis_fixed g R (fun k hk => rotation_off_plane i j k hij
    (fun h => hi (h ▸ hk)) (fun h => hj (h ▸ hk)))
  change exteriorPower.map n (rotation i j hij).val (basis n R) = basis n R at hR
  dsimp only
  simp only [repeated, map_sub, map_add, action_tmul, wedgeLeft_naturality, hR, hi', hj',
    LinearMap.add_apply, map_smul, LinearMap.smul_apply, add_tmul, tmul_add, ← smul_tmul', tmul_smul]
  constructor <;> module

theorem rotation_bridge {n : ℕ} (W : Submodule ℂ (Product (n + 1)))
    (hW : ∀ g : splitSpecialOrthogonal, ∀ x ∈ W, action (n + 1) g x ∈ W)
    (R : Index n) (S : Index (n + 2)) (i j : Axis)
    (hij : i ≠ j) (hi : i ∉ R.val) (hj : j ∉ R.val) (hS : S.val = insert i (insert j R.val)) :
    repeated R i - repeated R j ∈ W ↔ distinct S i - distinct S j ∈ W := by
  obtain ⟨d, hd, hD⟩ := bridge_coord R S i j hij hi hj hS
  obtain ⟨hA, hB⟩ := plane_mix R i j hij hi hj
  let A := repeated R i - repeated R j
  let B := bridgeTerm R i j + bridgeTerm R j i
  let g := rotation i j hij
  rw [hD]
  change A ∈ W ↔ d • B ∈ W
  constructor
  · intro hx
    have hm := W.sub_mem (hW g A hx) (W.smul_mem (-527 / 625 : ℂ) hx)
    change action (n + 1) g A - (-527 / 625 : ℂ) • A ∈ W at hm
    rw [hA, add_sub_cancel_left] at hm
    exact W.smul_mem d (basis_mem_of_scaled W B _ (by norm_num) hm)
  · intro hx
    have hb := basis_mem_of_scaled W B d hd hx
    have hm := W.sub_mem (hW g B hb) (W.smul_mem (-527 / 625 : ℂ) hb)
    change action (n + 1) g B - (-527 / 625 : ℂ) • B ∈ W at hm
    rw [hB, add_sub_cancel_right] at hm
    exact basis_mem_of_scaled W A _ (by norm_num) hm

end
end GeometricUnity.D7TensorRotations
