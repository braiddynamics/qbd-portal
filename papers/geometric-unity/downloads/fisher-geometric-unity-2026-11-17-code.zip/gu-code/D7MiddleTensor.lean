import D7VectorGrades

/-!
# The two signed residual summands in degree seven

The middle Hodge involution exchanges the wedge and contraction constraints.
The exchange uses the adjointness of wedge and contraction for the determinant
metric and the vanishing of a fifteen-fold alternating form in dimension fourteen.
-/

namespace GeometricUnity.D7MiddleTensor

open D7Exterior D7Hodge D7VectorGrades TensorProduct
open scoped BigOperators TensorProduct

noncomputable section

private abbrev pureWedge (n : ℕ) (v : Fin n → Space) : Ext n := exteriorPower.ιMulti ℂ n v

private theorem exteriorMetric_symm (n : ℕ) (u v : Ext n) : exteriorMetric n u v = exteriorMetric n v u := by
  have h : exteriorMetric n = (exteriorMetric n).flip := by
    apply ext_on_wedges
    intro a
    apply ext_on_wedges
    intro b
    simp only [LinearMap.flip_apply, exteriorMetric_pure]
    rw [← Matrix.det_transpose]
    congr 1
    ext i j
    exact D7VectorTensor.splitForm_symm _ _
  exact DFunLike.congr_fun (DFunLike.congr_fun h u) v

/-- With the determinant metric, left wedging by a vector is adjoint to
contraction by that vector. The expansion is along the first column. -/
theorem wedge_contract_adjoint (n : ℕ) (x : Space) (u : Ext n) (v : Ext (n + 1)) :
    exteriorMetric (n + 1) (D7VectorTensor.wedgeLeftLinear n x u) v =
      exteriorMetric n u (contractLeft n x v) := by
  have h : (exteriorMetric (n + 1)).comp (D7VectorTensor.wedgeLeftLinear n x) =
      (((exteriorMetric n).flip.comp (contractLeft n x)).flip) := by
    apply ext_on_wedges
    intro a
    apply ext_on_wedges
    intro b
    simp only [LinearMap.comp_apply, LinearMap.flip_apply, wedgeLeft_pure, exteriorMetric_pure,
      contractLeft_pure, map_sum, map_zsmul, map_smul, LinearMap.sum_apply, LinearMap.smul_apply]
    rw [Matrix.det_succ_column_zero]
    apply Finset.sum_congr rfl
    intro i _
    simp only [← Int.cast_smul_eq_zsmul ℂ, Int.cast_pow, Int.cast_neg, Int.cast_one, smul_eq_mul]
    rw [mul_assoc]
    rfl
  exact DFunLike.congr_fun (DFunLike.congr_fun h u) v

private def multiplyValue (m n : ℕ) (u : Ext m) (v : Ext n) : Ext (m + n) :=
  ⟨u.val * v.val, by
    change u.val * v.val ∈ (LinearMap.range (ExteriorAlgebra.ι ℂ : Space →ₗ[ℂ] _)) ^ (m + n)
    rw [pow_add]
    exact Submodule.mul_mem_mul u.prop v.prop⟩

def multiply (m n : ℕ) : Ext m →ₗ[ℂ] Ext n →ₗ[ℂ] Ext (m + n) :=
  LinearMap.mk₂ ℂ (multiplyValue m n)
    (fun _ _ _ => Subtype.ext (add_mul _ _ _))
    (fun _ _ _ => Subtype.ext (smul_mul_assoc _ _ _))
    (fun _ _ _ => Subtype.ext (mul_add _ _ _))
    (fun _ _ _ => Subtype.ext (mul_smul_comm _ _ _))

theorem multiply_pure (m n : ℕ) (u : Fin m → Space) (v : Fin n → Space) :
    multiply m n (pureWedge m u) (pureWedge n v) = pureWedge (m + n) (Fin.append u v) :=
  Subtype.ext (ExteriorAlgebra.ιMulti_mul_ιMulti _ _)

private def volume68 : Ext 6 →ₗ[ℂ] Ext 8 →ₗ[ℂ] ℂ := (multiply 6 8).compr₂ₛₗ volume
private def volume86 : Ext 8 →ₗ[ℂ] Ext 6 →ₗ[ℂ] ℂ := (multiply 8 6).compr₂ₛₗ volume

private theorem volume68_pure (u : Fin 6 → Space) (v : Fin 8 → Space) :
    volume68 (pureWedge 6 u) (pureWedge 8 v) = orthBasis.det (Fin.append u v) := by
  simp only [volume68, LinearMap.compr₂ₛₗ_apply, multiply_pure, volume,
    exteriorPower.alternatingMapLinearEquiv_apply_ιMulti]

private theorem volume86_pure (u : Fin 8 → Space) (v : Fin 6 → Space) :
    volume86 (pureWedge 8 u) (pureWedge 6 v) = orthBasis.det (Fin.append u v) := by
  simp only [volume86, LinearMap.compr₂ₛₗ_apply, multiply_pure, volume,
    exteriorPower.alternatingMapLinearEquiv_apply_ιMulti]

private theorem remove_append_left (u : Fin 7 → Space) (v : Fin 8 → Space) (i : Fin 7) :
    (i.castAdd 8).removeNth (Fin.append (m := 7) (n := 8) u v) =
      Fin.append (m := 6) (n := 8) (i.removeNth u) v := by
  have hl : ∀ (i : Fin 7) (j : Fin 6), (i.castAdd 8).succAbove (j.castAdd 8) = (i.succAbove j).castAdd 8 := by
    decide +kernel
  have hr : ∀ (i : Fin 7) (j : Fin 8), (i.castAdd 8).succAbove (Fin.natAdd 6 j) = Fin.natAdd 7 j := by
    decide +kernel
  funext j
  refine Fin.addCases (m := 6) (n := 8) ?_ ?_ j
  · intro a; rw [Fin.removeNth_apply, hl, Fin.append_left, Fin.append_left, Fin.removeNth_apply]
  · intro a; rw [Fin.removeNth_apply, hr, Fin.append_right, Fin.append_right]

private theorem remove_append_right (u : Fin 7 → Space) (v : Fin 8 → Space) (i : Fin 8) :
    (Fin.natAdd 7 i).removeNth (Fin.append (m := 7) (n := 8) u v) =
      Fin.append (m := 7) (n := 7) u (i.removeNth v) := by
  have hl : ∀ (i : Fin 8) (j : Fin 7), (Fin.natAdd 7 i).succAbove (j.castAdd 7) = j.castAdd 8 := by
    decide +kernel
  have hr : ∀ (i : Fin 8) (j : Fin 7), (Fin.natAdd 7 i).succAbove (Fin.natAdd 7 j) = Fin.natAdd 7 (i.succAbove j) := by
    decide +kernel
  funext j
  refine Fin.addCases (m := 7) (n := 7) ?_ ?_ j
  · intro a; rw [Fin.removeNth_apply, hl, Fin.append_left, Fin.append_left]
  · intro a; rw [Fin.removeNth_apply, hr, Fin.append_right, Fin.append_right, Fin.removeNth_apply]

/-- Contracting a fifteen-fold pure wedge gives zero in the oriented top
degree. Splitting the fifteen terms at the seventh slot gives this identity. -/
private theorem volume_contract_right (x : Space) (u : Fin 7 → Space) (v : Ext 8) :
    volumePair (pureWedge 7 u) (contractLeft 7 x v) = volume68 (contractLeft 6 x (pureWedge 7 u)) v := by
  have hb : (volumePair (pureWedge 7 u)).comp (contractLeft 7 x) = volume68 (contractLeft 6 x (pureWedge 7 u)) := by
    apply ext_on_wedges
    intro w
    let f : Space →ₗ[ℂ] (Space [⋀^Fin 14]→ₗ[ℂ] ℂ) := (splitMetric x).smulRight orthBasis.det
    let F := AlternatingMap.alternatizeUncurryFin f
    have hz : Module.finrank ℂ (Ext 15) = 0 := by
      rw [exteriorPower.finrank_eq, Module.finrank_pi, Fintype.card_fin]
      decide
    let : Subsingleton (Ext 15) := (Module.finrank_eq_zero_iff_of_free ℂ (Ext 15)).mp hz
    have hzero : pureWedge 15 (Fin.append u w) = 0 := Subsingleton.elim _ _
    have he := congrArg (exteriorPower.alternatingMapLinearEquiv F) hzero
    rw [exteriorPower.alternatingMapLinearEquiv_apply_ιMulti, map_zero] at he
    simp only [F, AlternatingMap.alternatizeUncurryFin_apply, f, LinearMap.smulRight_apply,
      AlternatingMap.smul_apply, splitMetric_apply] at he
    rw [Fin.sum_univ_add (a := 7) (b := 8)] at he
    simp only [Fin.val_castAdd, Fin.val_natAdd, Fin.append_left, Fin.append_right, remove_append_left,
      remove_append_right, pow_add, show (-1 : ℤ) ^ 7 = -1 by decide, neg_one_mul, neg_zsmul,
      Finset.sum_neg_distrib, ← sub_eq_add_neg] at he
    have h := sub_eq_zero.mp he
    simp only [LinearMap.comp_apply, contractLeft_pure, map_sum, map_zsmul, map_smul, volumePair_pure,
      LinearMap.sum_apply, LinearMap.smul_apply]
    have h68 (a : Fin 6 → Space) : volume68 (pureWedge 6 a) (pureWedge (7 + 1) w) =
        orthBasis.det (Fin.append a w) := volume68_pure a w
    simp only [h68]
    exact h.symm
  exact DFunLike.congr_fun hb v

private theorem insert_volume_slot (x : Space) (u : Fin 7 → Space) (v : Fin 6 → Space) :
    (Fin.natAdd 7 (0 : Fin 7)).insertNth x (Fin.append u v) = Fin.append u (Matrix.vecCons x v) := by
  let p := Fin.natAdd 7 (0 : Fin 7)
  have hl : ∀ j : Fin 7, p.succAbove (j.castAdd 6) = j.castAdd 7 := by decide +kernel
  have hr : ∀ j : Fin 6, p.succAbove (Fin.natAdd 7 j) = Fin.natAdd 7 j.succ := by decide +kernel
  apply Fin.insertNth_eq_iff.mpr
  constructor
  · change x = Fin.append u (Matrix.vecCons x v) (Fin.natAdd 7 (0 : Fin 7))
    rw [Fin.append_right]
    rfl
  · symm
    funext j
    refine Fin.addCases (m := 7) (n := 6) ?_ ?_ j
    · intro a; rw [Fin.removeNth_apply, hl, Fin.append_left, Fin.append_left]
    · intro a; rw [Fin.removeNth_apply, hr, Fin.append_right, Fin.append_right]; rfl

private theorem volume_wedge_right (x : Space) (u : Fin 7 → Space) (v : Ext 6) :
    volumePair (pureWedge 7 u) (D7VectorTensor.wedgeLeftLinear 6 x v) =
      -volume86 (D7VectorTensor.wedgeLeftLinear 7 x (pureWedge 7 u)) v := by
  have hb : (volumePair (pureWedge 7 u)).comp (D7VectorTensor.wedgeLeftLinear 6 x) =
      -volume86 (D7VectorTensor.wedgeLeftLinear 7 x (pureWedge 7 u)) := by
    apply ext_on_wedges
    intro w
    simp only [LinearMap.comp_apply, LinearMap.neg_apply, wedgeLeft_pure]
    change volumePair (pureWedge 7 u) (pureWedge 7 (Matrix.vecCons x w)) =
      -volume86 (pureWedge 8 (Matrix.vecCons x u)) (pureWedge 6 w)
    rw [volumePair_pure, volume86_pure]
    rw [← insert_volume_slot, AlternatingMap.map_insertNth]
    have h : Fin.append (Matrix.vecCons x u) w = Matrix.vecCons x (Fin.append u w) := by
      rw [Matrix.vecCons, Matrix.vecCons, Fin.append_cons]
      rfl
    rw [h]
    change (-1 : ℤ) ^ 7 • orthBasis.det (Matrix.vecCons x (Fin.append u w)) = _
    rw [show (-1 : ℤ) ^ 7 = -1 by decide, neg_one_zsmul]
  exact DFunLike.congr_fun hb v

def tensorInvolution : Product 7 →ₗ[ℂ] Product 7 := TensorProduct.map LinearMap.id involution

private theorem metric_involution (x y : Mid) : exteriorMetric 7 (involution x) y = Complex.I * volumePair x y := by
  change metricPair (Complex.I • star x) y = _
  rw [map_smul, LinearMap.smul_apply, metric_star, smul_eq_mul]

private theorem wedge_involution_pair (t : Product 7) (v : Ext 8) :
    exteriorMetric 8 (wedge 7 (tensorInvolution t)) v = Complex.I * volume68 (contract 6 t) v := by
  have h : ((exteriorMetric 8).flip v).comp ((wedge 7).comp tensorInvolution) =
      Complex.I • ((volume68.flip v).comp (contract 6)) := by
    apply ext_on_tensor_wedges
    intro x u
    simp only [LinearMap.comp_apply, LinearMap.flip_apply, tensorInvolution, TensorProduct.map_tmul,
      LinearMap.id_apply, LinearMap.smul_apply, smul_eq_mul, wedge, contract, TensorProduct.lift.tmul]
    rw [wedge_contract_adjoint, metric_involution, volume_contract_right]
  exact DFunLike.congr_fun h t

private theorem contract_involution_pair (t : Product 7) (v : Ext 6) :
    exteriorMetric 6 (contract 6 (tensorInvolution t)) v = -Complex.I * volume86 (wedge 7 t) v := by
  have h : ((exteriorMetric 6).flip v).comp ((contract 6).comp tensorInvolution) =
      (-Complex.I) • ((volume86.flip v).comp (wedge 7)) := by
    apply ext_on_tensor_wedges
    intro x u
    simp only [LinearMap.comp_apply, LinearMap.flip_apply, tensorInvolution, TensorProduct.map_tmul,
      LinearMap.id_apply, LinearMap.smul_apply, smul_eq_mul, wedge, contract, TensorProduct.lift.tmul]
    rw [exteriorMetric_symm 6, ← wedge_contract_adjoint 6, exteriorMetric_symm 7,
      metric_involution, volume_wedge_right, mul_neg, neg_mul]
  exact DFunLike.congr_fun h t

private theorem wedge_involution_zero (t : Product 7) (ht : contract 6 t = 0) :
    wedge 7 (tensorInvolution t) = 0 := by
  apply exteriorMetric_injective 8
  apply LinearMap.ext
  intro v
  rw [wedge_involution_pair, ht, map_zero, LinearMap.zero_apply, mul_zero, map_zero, LinearMap.zero_apply]

private theorem contract_involution_zero (t : Product 7) (ht : wedge 7 t = 0) :
    contract 6 (tensorInvolution t) = 0 := by
  apply exteriorMetric_injective 6
  apply LinearMap.ext
  intro v
  rw [contract_involution_pair, ht, map_zero, LinearMap.zero_apply, mul_zero, map_zero, LinearMap.zero_apply]

/-- The two kernel conditions are preserved by the Hodge action on the tensor factor. -/
theorem jointKernel_tensorInvolution (t : Product 7) (ht : t ∈ jointKernel 6) :
    tensorInvolution t ∈ jointKernel 6 := by
  rw [mem_jointKernel] at ht ⊢
  exact ⟨wedge_involution_zero t ht.2, contract_involution_zero t ht.1⟩

theorem tensorInvolution_square (t : Product 7) : tensorInvolution (tensorInvolution t) = t := by
  have h : tensorInvolution.comp tensorInvolution = LinearMap.id := by
    apply TensorProduct.ext'
    intro x u
    simp only [tensorInvolution, LinearMap.comp_apply, TensorProduct.map_tmul, LinearMap.id_apply, involution_square]
  exact DFunLike.congr_fun h t

theorem wedge_involution_zero_iff (t : Product 7) : wedge 7 (tensorInvolution t) = 0 ↔ contract 6 t = 0 := by
  refine ⟨fun h => ?_, wedge_involution_zero t⟩
  simpa only [tensorInvolution_square] using contract_involution_zero (tensorInvolution t) h

theorem contract_involution_zero_iff (t : Product 7) : contract 6 (tensorInvolution t) = 0 ↔ wedge 7 t = 0 := by
  refine ⟨fun h => ?_, contract_involution_zero t⟩
  simpa only [tensorInvolution_square] using wedge_involution_zero (tensorInvolution t) h

/-- Within a Hodge eigenspace, either constraint suffices to define the residual kernel. -/
theorem wedge_zero_iff_contract_zero_on_eigenspace (t : Product 7) (a : ℂ) (ha : a ≠ 0)
    (ht : tensorInvolution t = a • t) : wedge 7 t = 0 ↔ contract 6 t = 0 := by
  have h := wedge_involution_zero_iff t
  rw [ht, map_smul] at h
  exact (show a • wedge 7 t = 0 ↔ wedge 7 t = 0 from
    ⟨fun hz => (smul_eq_zero.mp hz).resolve_left ha, fun hz => by rw [hz, smul_zero]⟩).symm.trans h

theorem tensorInvolution_equivariant (g : splitSpecialOrthogonal) (t : Product 7) :
    tensorInvolution (action 7 g t) = action 7 g (tensorInvolution t) := by
  have h : tensorInvolution.comp (action 7 g) = (action 7 g).comp tensorInvolution := by
    apply TensorProduct.ext'
    intro x u
    simp only [tensorInvolution, action, Representation.tprod_apply, LinearMap.comp_apply, TensorProduct.map_tmul,
      LinearMap.id_apply, involution_equivariant]
  exact DFunLike.congr_fun h t

private def tensorReflection : Product 7 →ₗ[ℂ] Product 7 := TensorProduct.map vectorReflection reflection

private theorem jointKernel_reflection (t : Product 7) (ht : t ∈ jointKernel 6) :
    tensorReflection t ∈ jointKernel 6 := by
  rw [mem_jointKernel] at ht ⊢
  have hw := DFunLike.congr_fun (wedge_natural 7 vectorReflection) t
  have hc := DFunLike.congr_fun (contract_natural 6 vectorReflection vectorReflection_isometry) t
  simp only [LinearMap.comp_apply, ht.1, ht.2, map_zero] at hw hc
  exact ⟨hw, hc⟩

private theorem tensorReflection_square (t : Product 7) : tensorReflection (tensorReflection t) = t := by
  have h : tensorReflection.comp tensorReflection = LinearMap.id := by
    apply TensorProduct.ext'
    intro x u
    simp only [tensorReflection, LinearMap.comp_apply, TensorProduct.map_tmul, LinearMap.id_apply,
      vectorReflection_square, reflection_square]
  exact DFunLike.congr_fun h t

private theorem tensorInvolution_reflection (t : Product 7) :
    tensorInvolution (tensorReflection t) = -tensorReflection (tensorInvolution t) := by
  have h : tensorInvolution.comp tensorReflection = -(tensorReflection.comp tensorInvolution) := by
    apply TensorProduct.ext'
    intro x u
    simp only [tensorInvolution, tensorReflection, LinearMap.comp_apply, LinearMap.neg_apply,
      TensorProduct.map_tmul, LinearMap.id_apply]
    have he : involution (reflection u) = -reflection (involution u) := by
      simp [involution, star_reflection]
    rw [he, tmul_neg]
  exact DFunLike.congr_fun h t

/-- Hodge involution restricted to the entire middle residual representation. -/
def residualInvolution : (↥(jointKernel 6)) →ₗ[ℂ] (↥(jointKernel 6)) :=
  tensorInvolution.restrict (fun _ ht => jointKernel_tensorInvolution _ ht)

set_option backward.isDefEq.respectTransparency false in
def residualSector (a : ℂ) : Submodule ℂ (jointKernel 6) :=
  involutionEigenspace (E := ↥(jointKernel 6)) residualInvolution a

set_option backward.isDefEq.respectTransparency false in
theorem tensorInvolution_of_mem_residualSector (a : ℂ) (x : ↥(jointKernel 6))
    (hx : x ∈ residualSector a) : tensorInvolution x.val = a • x.val := by
  rw [residualSector, mem_involutionEigenspace] at hx
  exact congrArg (fun y : ↥(jointKernel 6) => y.val) hx

set_option backward.isDefEq.respectTransparency false in
set_option maxHeartbeats 500000 in
theorem residualSectors_isCompl : IsCompl (residualSector 1) (residualSector (-1)) := by
  have h (x : ↥(jointKernel 6)) : residualInvolution (residualInvolution x) = x := by
    apply Subtype.ext
    exact tensorInvolution_square x.val
  exact involution_eigenspaces_isCompl (E := ↥(jointKernel 6)) residualInvolution h

theorem residualSector_invariant (a : ℂ) (g : splitSpecialOrthogonal) (x : ↥(jointKernel 6))
    (hx : x ∈ residualSector a) : jointKernelAction 6 g x ∈ residualSector a := by
  rw [residualSector, mem_involutionEigenspace] at hx ⊢
  apply Subtype.ext
  have h : tensorInvolution x.val = a • x.val := congrArg Subtype.val hx
  change tensorInvolution (action 7 g x.val) = a • action 7 g x.val
  rw [tensorInvolution_equivariant, h, map_smul]

def residualSectorAction (a : ℂ) : Representation ℂ splitSpecialOrthogonal (residualSector a) :=
  (jointKernelAction 6).subrepresentation (residualSector a) (fun g x hx => residualSector_invariant a g x hx)

set_option backward.isDefEq.respectTransparency false in
/-- The middle residual action is the direct sum of the two Hodge actions. -/
def residualSignedDecomposition : ((residualSectorAction 1).prod (residualSectorAction (-1))).Equiv
    (jointKernelAction 6) := by
  let f : (↥(residualSector 1) × ↥(residualSector (-1))) ≃ₗ[ℂ] ↥(jointKernel 6) :=
    Submodule.prodEquivOfIsCompl (R := ℂ) (E := ↥(jointKernel 6))
      (residualSector 1) (residualSector (-1)) residualSectors_isCompl
  refine Representation.Equiv.mk f fun g => ?_
  apply LinearMap.ext
  intro x
  change (jointKernelAction 6 g x.1.val) + (jointKernelAction 6 g x.2.val) = jointKernelAction 6 g (x.1.val + x.2.val)
  rw [map_add]

private def residualReflection : ↥(jointKernel 6) →ₗ[ℂ] ↥(jointKernel 6) :=
  tensorReflection.restrict (fun _ ht => jointKernel_reflection _ ht)

private theorem residualReflection_sector (a : ℂ) (x : ↥(jointKernel 6)) (hx : x ∈ residualSector a) :
    residualReflection x ∈ residualSector (-a) := by
  rw [residualSector, mem_involutionEigenspace] at hx ⊢
  apply Subtype.ext
  have h : tensorInvolution x.val = a • x.val := congrArg Subtype.val hx
  change tensorInvolution (tensorReflection x.val) = (-a) • tensorReflection x.val
  rw [tensorInvolution_reflection, h, map_smul]
  module

private def reflectionEquiv : residualSector 1 ≃ₗ[ℂ] residualSector (-1) where
  toFun x := ⟨residualReflection x.val, residualReflection_sector 1 x.val x.prop⟩
  invFun y := ⟨residualReflection y.val, by simpa using residualReflection_sector (-1) y.val y.prop⟩
  left_inv x := Subtype.ext (Subtype.ext (tensorReflection_square x.val.val))
  right_inv y := Subtype.ext (Subtype.ext (tensorReflection_square y.val.val))
  map_add' x y := Subtype.ext (residualReflection.map_add x.val y.val)
  map_smul' r x := Subtype.ext (residualReflection.map_smul r x.val)

set_option backward.isDefEq.respectTransparency false in
theorem residualSector_dimensions :
    Module.finrank ℂ (residualSector 1) = 21021 ∧ Module.finrank ℂ (residualSector (-1)) = 21021 := by
  have h : Module.finrank ℂ (residualSector 1) + Module.finrank ℂ (residualSector (-1)) =
      Module.finrank ℂ (jointKernel 6) :=
    Submodule.finrank_add_eq_of_isCompl (K := ℂ) (V := ↥(jointKernel 6)) residualSectors_isCompl
  have hk : Module.finrank ℂ (jointKernel 6) = 42042 := by
    rw [jointKernel_finrank 6 (by decide)]
    decide
  rw [hk] at h
  have he := reflectionEquiv.finrank_eq
  omega

def plusLabelCandidate : ↥(jointKernel 6) :=
  ⟨nullTensor (highestPlus (7 : Fin 15)), internalGrade_candidate (6 : Fin 13)⟩

def minusLabelCandidate : ↥(jointKernel 6) := ⟨nullTensor lastMinus, middleMinus_candidate⟩

/-- For the chosen orientation, the weight `ν₇⁺` occurs in the `-1` Hodge sector. -/
theorem plusLabelCandidate_sector : plusLabelCandidate ∈ residualSector (-1) := by
  rw [residualSector, mem_involutionEigenspace]
  apply Subtype.ext
  have h := (mem_sector (-1) _).mp highestPlus_mem_sector
  change tensorInvolution (nullTensor (highestPlus (7 : Fin 15))) = (-1 : ℂ) • nullTensor (highestPlus (7 : Fin 15))
  simp only [tensorInvolution, nullTensor, TensorProduct.map_tmul, LinearMap.id_apply, h, tmul_smul]
  rfl

/-- For the chosen orientation, the weight `ν₇⁻` occurs in the `+1` Hodge sector. -/
theorem minusLabelCandidate_sector : minusLabelCandidate ∈ residualSector 1 := by
  rw [residualSector, mem_involutionEigenspace]
  apply Subtype.ext
  have h := (mem_sector 1 _).mp lastMinus_mem_sector
  change tensorInvolution (nullTensor lastMinus) = (1 : ℂ) • nullTensor lastMinus
  simp only [tensorInvolution, nullTensor, TensorProduct.map_tmul, LinearMap.id_apply, h, tmul_smul]

end
end GeometricUnity.D7MiddleTensor
