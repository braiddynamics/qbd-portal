import D7SpinNullFrame
import D7VectorGrades
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.LinearAlgebra.Dual.Lemmas

/-!
# Interpolation of split root actions

Real Spin lifts give the paired tensor actions at real parameters.
Exterior powers and tensor products make these actions polynomial in the
parameter. A linear functional annihilating the real action span then
annihilates the action at every complex parameter.
-/

namespace GeometricUnity.D7RootInterpolation

open D7Exterior D7VectorGrades D7SpinNullFrame
open scoped BigOperators TensorProduct Polynomial

noncomputable section

private def polynomialCurves (E : Type*) [AddCommGroup E] [Module ℂ E] :
    Submodule ℂ (ℂ → E) :=
  Submodule.span ℂ {f | ∃ (p : ℂ[X]) (v : E), f = fun z => p.eval z • v}

section Curves

variable {E F G : Type*} [AddCommGroup E] [Module ℂ E]
variable [AddCommGroup F] [Module ℂ F] [AddCommGroup G] [Module ℂ G]

private theorem polynomialTerm (p : ℂ[X]) (v : E) :
    (fun z => p.eval z • v) ∈ polynomialCurves E :=
  Submodule.subset_span ⟨p, v, rfl⟩

private theorem curve_map (L : E →ₗ[ℂ] F) {f : ℂ → E} (hf : f ∈ polynomialCurves E) :
    (fun z => L (f z)) ∈ polynomialCurves F := by
  let T : (ℂ → E) →ₗ[ℂ] (ℂ → F) := LinearMap.pi fun z => L.comp (LinearMap.proj z)
  have h : polynomialCurves E ≤ (polynomialCurves F).comap T := by
    apply Submodule.span_le.mpr
    rintro _ ⟨p, v, rfl⟩
    change (fun z => L (p.eval z • v)) ∈ polynomialCurves F
    simpa only [map_smul] using polynomialTerm p (L v)
  exact h hf

private def pointwiseBilinear (L : E →ₗ[ℂ] F →ₗ[ℂ] G) :
    (ℂ → E) →ₗ[ℂ] (ℂ → F) →ₗ[ℂ] (ℂ → G) :=
  LinearMap.mk₂ ℂ (fun f g z => L (f z) (g z))
    (fun _ _ _ => funext fun _ => by simp)
    (fun _ _ _ => funext fun _ => by simp)
    (fun _ _ _ => funext fun _ => by simp)
    (fun _ _ _ => funext fun _ => by simp)

private theorem curve_bilinear (L : E →ₗ[ℂ] F →ₗ[ℂ] G) {f : ℂ → E} {g : ℂ → F}
    (hf : f ∈ polynomialCurves E) (hg : g ∈ polynomialCurves F) :
    (fun z => L (f z) (g z)) ∈ polynomialCurves G := by
  let T := pointwiseBilinear L
  change T f g ∈ polynomialCurves G
  refine Submodule.span_induction₂ (p := fun f g _ _ => T f g ∈ polynomialCurves G)
    ?_ ?_ ?_ ?_ ?_ ?_ ?_ hf hg
  · rintro _ _ ⟨p, x, rfl⟩ ⟨q, y, rfl⟩
    change (fun z => L (p.eval z • x) (q.eval z • y)) ∈ polynomialCurves G
    simpa only [map_smul, LinearMap.smul_apply, smul_smul, Polynomial.eval_mul]
      using polynomialTerm (q * p) (L x y)
  · intro g _
    rw [map_zero, LinearMap.zero_apply]
    exact (polynomialCurves G).zero_mem
  · intro f _
    rw [map_zero]
    exact (polynomialCurves G).zero_mem
  · intro f₁ f₂ g _ _ _ h₁ h₂
    rw [map_add, LinearMap.add_apply]
    exact (polynomialCurves G).add_mem h₁ h₂
  · intro f g₁ g₂ _ _ _ h₁ h₂
    rw [map_add]
    exact (polynomialCurves G).add_mem h₁ h₂
  · intro r f g _ _ h
    rw [map_smul, LinearMap.smul_apply]
    exact (polynomialCurves G).smul_mem r h
  · intro r f g _ _ h
    rw [map_smul]
    exact (polynomialCurves G).smul_mem r h

private theorem scalar_polynomial {f : ℂ → ℂ} (hf : f ∈ polynomialCurves ℂ) :
    ∃ p : ℂ[X], f = p.eval := by
  induction hf using Submodule.span_induction with
  | mem f h =>
    obtain ⟨p, v, rfl⟩ := h
    exact ⟨p * Polynomial.C v, funext fun z => by simp [smul_eq_mul]⟩
  | zero => exact ⟨0, funext fun z => by simp⟩
  | add f g _ _ hf hg =>
    obtain ⟨p, rfl⟩ := hf
    obtain ⟨q, rfl⟩ := hg
    exact ⟨p + q, funext fun z => by simp⟩
  | smul r f _ hf =>
    obtain ⟨p, rfl⟩ := hf
    exact ⟨Polynomial.C r * p, funext fun z => by simp [smul_eq_mul]⟩

private theorem curve_mem_of_real {f : ℂ → E} (hf : f ∈ polynomialCurves E)
    (S : Submodule ℂ E) (hr : ∀ r : ℝ, f (r : ℂ) ∈ S) (z : ℂ) : f z ∈ S := by
  apply (Subspace.forall_mem_dualAnnihilator_apply_eq_zero_iff S (f z)).mp
  intro L hL
  obtain ⟨p, hp⟩ := scalar_polynomial (curve_map L hf)
  have hroot : Set.range Complex.ofReal ⊆ {w | p.IsRoot w} := by
    rintro _ ⟨r, rfl⟩
    change p.eval (r : ℂ) = 0
    rw [← congrFun hp (r : ℂ)]
    exact (Submodule.mem_dualAnnihilator L).mp hL _ (hr r)
  have hp0 := p.eq_zero_of_infinite_isRoot
    ((Set.infinite_range_of_injective Complex.ofReal_injective).mono hroot)
  rw [congrFun hp z, hp0, Polynomial.eval_zero]

end Curves

private theorem exterior_curve_on_blade (N : Module.End ℂ Space) (k : ℕ)
    (v : Fin k → Space) :
    (fun z => exteriorPower.map k (LinearMap.id + z • N) (exteriorPower.ιMulti ℂ k v)) ∈
      polynomialCurves (Ext k) := by
  classical
  let blade := exteriorPower.ιMulti ℂ k (M := Space)
  let vN : Fin k → Space := fun i => N (v i)
  have h (z : ℂ) : exteriorPower.map k (LinearMap.id + z • N) (blade v) =
      ∑ s : Finset (Fin k), z ^ s.card • blade (s.piecewise vN v) := by
    rw [exteriorPower.map_apply_ιMulti]
    change blade (fun i => (LinearMap.id + z • N : Module.End ℂ Space) (v i)) = _
    have hv : (fun i => (LinearMap.id + z • N : Module.End ℂ Space) (v i)) =
        (fun i => z • vN i) + v := by
      funext i
      exact add_comm (v i) (z • N (v i))
    rw [hv]
    change blade ((fun i => z • vN i) + v) = _
    rw [AlternatingMap.map_add_univ]
    apply Finset.sum_congr rfl
    intro s _
    rw [show s.piecewise (fun i => z • vN i) v =
        s.piecewise (fun i => z • s.piecewise vN v i) (s.piecewise vN v) by
      funext i
      by_cases hi : i ∈ s <;> simp [Finset.piecewise, hi]]
    exact (blade.toMultilinearMap.map_piecewise_smul (fun _ => z) (s.piecewise vN v) s).trans
      (by rw [Finset.prod_const]; rfl)
  have hsum : (∑ s : Finset (Fin k), fun z : ℂ => z ^ s.card • blade (s.piecewise vN v)) ∈
      polynomialCurves (Ext k) :=
    Submodule.sum_mem _ fun s _ => by
      simpa only [Polynomial.eval_pow, Polynomial.eval_X] using
        polynomialTerm (Polynomial.X ^ s.card) (blade (s.piecewise vN v))
  have he : (fun z : ℂ => exteriorPower.map k (LinearMap.id + z • N) (blade v)) =
      ∑ s : Finset (Fin k), fun z => z ^ s.card • blade (s.piecewise vN v) := by
    funext z
    rw [Finset.sum_apply, h]
  change (fun z => exteriorPower.map k (LinearMap.id + z • N) (blade v)) ∈ _
  rw [he]
  exact hsum

private theorem exterior_curve (N : Module.End ℂ Space) (k : ℕ) :
    (fun z => exteriorPower.map k (LinearMap.id + z • N)) ∈
      polynomialCurves (Module.End ℂ (Ext k)) := by
  classical
  let b := axisBasis.exteriorPower k
  let F (z : ℂ) := exteriorPower.map k (LinearMap.id + z • N)
  have hx (i : Index k) : (fun z => F z (b i)) ∈ polynomialCurves (Ext k) := by
    change (fun z => F z ((axisBasis.exteriorPower k) i)) ∈ _
    rw [exteriorPower.basis_apply]
    exact exterior_curve_on_blade N k _
  have he : F = ∑ i : Index k, fun z => (b.coord i).smulRight (F z (b i)) := by
    funext z
    rw [Finset.sum_apply]
    apply b.ext
    intro j
    symm
    simp only [LinearMap.sum_apply, LinearMap.smulRight_apply, Module.Basis.coord_apply,
      Module.Basis.repr_self, Finsupp.single_apply, ite_smul, one_smul, zero_smul]
    simp
  change F ∈ _
  rw [he]
  exact Submodule.sum_mem _ fun i _ => curve_map (LinearMap.smulRightₗ (b.coord i)) (hx i)

local instance exteriorTensor_addCommGroup (k l : ℕ) : AddCommGroup (Ext k ⊗[ℂ] Ext l) :=
  @TensorProduct.addCommGroup ℂ _ (Ext k) (Ext l) (⋀[ℂ]^k Space).addCommGroup _ _ _

/-- The action on a tensor product of two exterior powers. -/
def exteriorTensorMap (k l : ℕ) (f : Module.End ℂ Space) : Module.End ℂ (Ext k ⊗[ℂ] Ext l) :=
  TensorProduct.map (exteriorPower.map k f) (exteriorPower.map l f)

private theorem exteriorTensor_curve (N : Module.End ℂ Space) (k l : ℕ) :
    (fun z => exteriorTensorMap k l (LinearMap.id + z • N)) ∈
      polynomialCurves (Module.End ℂ (Ext k ⊗[ℂ] Ext l)) :=
  curve_bilinear (TensorProduct.mapBilinear (R := ℂ) (RingHom.id ℂ) (Ext k) (Ext l) (Ext k) (Ext l))
    (exterior_curve N k) (exterior_curve N l)

private theorem root_affine (a b : Axis) (z : ℂ) :
    rootGroup z a (pairedAxis b) b (pairedAxis a) =
      LinearMap.id + z • (rootGroup 1 a (pairedAxis b) b (pairedAxis a) - LinearMap.id) := by
  unfold rootGroup
  module

/-- For the paired tensor actions needed in the dimension calculation,
every complex split root parameter lies in the complex linear span of
pairs of actual real Spin actions. -/
theorem rootGroup_tensorActions_mem_spin_span (a b : Axis) (hab : pairIndex a ≠ pairIndex b)
    (k l m n : ℕ) (z : ℂ) :
    (exteriorTensorMap k l (rootGroup z a (pairedAxis b) b (pairedAxis a)),
      exteriorTensorMap m n (rootGroup z a (pairedAxis b) b (pairedAxis a))) ∈
    Submodule.span ℂ (Set.range fun g : D7SpinAction.Spin =>
      (exteriorTensorMap k l (complexNullAction g), exteriorTensorMap m n (complexNullAction g))) := by
  let U := Module.End ℂ (Ext k ⊗[ℂ] Ext l)
  let W := Module.End ℂ (Ext m ⊗[ℂ] Ext n)
  let F (w : ℂ) : U × W :=
    (exteriorTensorMap k l (rootGroup w a (pairedAxis b) b (pairedAxis a)),
      exteriorTensorMap m n (rootGroup w a (pairedAxis b) b (pairedAxis a)))
  let S : Submodule ℂ (U × W) :=
    Submodule.span ℂ (Set.range fun g : D7SpinAction.Spin =>
      (exteriorTensorMap k l (complexNullAction g), exteriorTensorMap m n (complexNullAction g)))
  have hF : F ∈ polynomialCurves (U × W) := by
    let N := rootGroup 1 a (pairedAxis b) b (pairedAxis a) - LinearMap.id
    have h₁ := curve_map (LinearMap.inl ℂ U W) (exteriorTensor_curve N k l)
    have h₂ := curve_map (LinearMap.inr ℂ U W) (exteriorTensor_curve N m n)
    have he : F = (fun w => LinearMap.inl ℂ U W (exteriorTensorMap k l (LinearMap.id + w • N))) +
        (fun w => LinearMap.inr ℂ U W (exteriorTensorMap m n (LinearMap.id + w • N))) := by
      funext w
      change (exteriorTensorMap k l (rootGroup w a (pairedAxis b) b (pairedAxis a)),
        exteriorTensorMap m n (rootGroup w a (pairedAxis b) b (pairedAxis a))) = _
      rw [root_affine a b w]
      simp [N]
    rw [he]
    exact (polynomialCurves (U × W)).add_mem h₁ h₂
  refine curve_mem_of_real hF S ?_ z
  intro r
  obtain ⟨g, hg⟩ := exists_rootGroup_lift a b hab r
  exact Submodule.subset_span ⟨g, congrArg (fun f =>
    (exteriorTensorMap k l f, exteriorTensorMap m n f)) hg⟩

/-- All split root maps with arbitrary complex parameters. -/
def splitRootMaps : Set (Module.End ℂ Space) :=
  {f | ∃ (a b : Axis) (z : ℂ), pairIndex a ≠ pairIndex b ∧
    f = rootGroup z a (pairedAxis b) b (pairedAxis a)}

private def exteriorTensorHom (k l : ℕ) : Module.End ℂ Space →*
    Module.End ℂ (Ext k ⊗[ℂ] Ext l) where
  toFun := exteriorTensorMap k l
  map_one' := by simp only [exteriorTensorMap, Module.End.one_eq_id, exteriorPower.map_id,
    TensorProduct.map_id]
  map_mul' f g := by
    simp only [exteriorTensorMap, Module.End.mul_eq_comp, exteriorPower.map_comp]
    exact TensorProduct.map_comp (exteriorPower.map k f) (exteriorPower.map l f)
      (exteriorPower.map k g) (exteriorPower.map l g)

set_option maxHeartbeats 800000 in
/-- The paired action span also contains the action of every finite
product of complex split root maps. -/
theorem rootClosure_tensorActions_mem_spin_span (k l m n : ℕ) {f : Module.End ℂ Space}
    (hf : f ∈ Submonoid.closure splitRootMaps) :
    (exteriorTensorMap k l f, exteriorTensorMap m n f) ∈
      Submodule.span ℂ (Set.range fun g : D7SpinAction.Spin =>
        (exteriorTensorMap k l (complexNullAction g),
          exteriorTensorMap m n (complexNullAction g))) := by
  let X := Module.End ℂ (Ext k ⊗[ℂ] Ext l) × Module.End ℂ (Ext m ⊗[ℂ] Ext n)
  let paired : Module.End ℂ Space →* X := (exteriorTensorHom k l).prod (exteriorTensorHom m n)
  let spin : D7SpinAction.Spin →* X := paired.comp complexNullAction
  let A : Subalgebra ℂ X := Algebra.adjoin ℂ (Set.range spin)
  have hA : A.toSubmodule = Submodule.span ℂ (Set.range spin) := by
    let S := MonoidHom.mrange spin
    change (Algebra.adjoin ℂ (S : Set X)).toSubmodule = Submodule.span ℂ (S : Set X)
    rw [Algebra.adjoin_eq_span, S.closure_eq]
  have hroots : splitRootMaps ⊆ A.toSubmonoid.comap paired := by
    rintro _ ⟨a, b, z, hab, rfl⟩
    change paired (rootGroup z a (pairedAxis b) b (pairedAxis a)) ∈ A.toSubmodule
    rw [hA]
    exact rootGroup_tensorActions_mem_spin_span a b hab k l m n z
  change paired f ∈ Submodule.span ℂ (Set.range spin)
  rw [← hA]
  exact (Submonoid.closure_le.mpr hroots) hf

end

end GeometricUnity.D7RootInterpolation
