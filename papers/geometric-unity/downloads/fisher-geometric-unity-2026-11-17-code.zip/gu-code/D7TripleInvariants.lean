import D7ComplementaryGrades
import Mathlib.Data.Finset.SymmDiff
import Mathlib.LinearAlgebra.Dual.Basis

/-!
# Invariant forms on three exterior powers

The even coordinate sign changes force a nonzero coefficient of an invariant
form to have empty or full symmetric difference. Within each parity, the
three wedge degrees determine the orbit under signed coordinate permutations.
-/

namespace GeometricUnity.D7TripleInvariants

open D7Exterior D7Hodge D7Irreducible D7VectorGrades
open scoped symmDiff TensorProduct BigOperators

noncomputable section

abbrev Form (r k l : ℕ) := Ext r →ₗ[ℂ] Ext k →ₗ[ℂ] Ext l →ₗ[ℂ] ℂ
abbrev Triple (r k l : ℕ) := Index r × Index k × Index l

def invariantForms (r k l : ℕ) : Submodule ℂ (Form r k l) where
  carrier := {F | ∀ (g : splitSpecialOrthogonal) x y z,
    F (exteriorRepresentation r g x) (exteriorRepresentation k g y) (exteriorRepresentation l g z) = F x y z}
  add_mem' hF hG g x y z := by simp only [LinearMap.add_apply, hF g x y z, hG g x y z]
  zero_mem' := by
    change ∀ (g : splitSpecialOrthogonal) (x : Ext r) (y : Ext k) (z : Ext l), _ = _
    intros; rfl
  smul_mem' c F hF g x y z := by simp only [LinearMap.smul_apply, hF g x y z]

def value {r k l : ℕ} (F : Form r k l) (q : Triple r k l) : ℂ :=
  F (basis r q.1) (basis k q.2.1) (basis l q.2.2)

theorem value_ext {r k l : ℕ} {F G : Form r k l}
    (h : ∀ q : Triple r k l, value F q = value G q) : F = G := by
  apply (basis r).ext
  intro s
  apply (basis k).ext
  intro t
  apply (basis l).ext
  intro u
  exact h (s, t, u)

def parity {r k l : ℕ} (q : Triple r k l) : Finset Axis := (q.1.val ∆ q.2.1.val) ∆ q.2.2.val

theorem subsetFlip_diff (s t : Finset Axis) (i : Axis) :
    subsetFlip (s ∆ t) i = subsetFlip s i * subsetFlip t i := by
  by_cases hs : i ∈ s <;> by_cases ht : i ∈ t <;>
    simp [subsetFlip, Finset.mem_symmDiff, hs, ht]

theorem character_diff (s t : Finset Axis) (i j : Axis) :
    character (s ∆ t) i j = character s i j * character t i j := by
  simp only [character, subsetFlip_diff]
  ring

theorem support_parity {r k l : ℕ} (F : ↥(invariantForms r k l)) (q : Triple r k l)
    (h : value F.val q ≠ 0) : parity q = ∅ ∨ parity q = Finset.univ := by
  classical
  by_contra! hn
  obtain ⟨i, hi⟩ := hn.1
  have hex : ∃ j, j ∉ parity q := by
    by_contra! he
    exact hn.2 (Finset.eq_univ_of_forall he)
  obtain ⟨j, hj⟩ := hex
  have hchar : character (parity q) i j = -1 := by simp [character, subsetFlip, hi, hj]
  have hf := F.prop (doubleFlip i j) (basis r q.1) (basis k q.2.1) (basis l q.2.2)
  rw [doubleFlip_exterior, doubleFlip_exterior, doubleFlip_exterior] at hf
  change _ = value F.val q at hf
  simp only [map_smul, LinearMap.smul_apply, smul_eq_mul] at hf
  change character q.2.2.val i j * (character q.2.1.val i j *
    (character q.1.val i j * value F.val q)) = value F.val q at hf
  have he : character (parity q) i j * value F.val q = value F.val q := by
    rw [parity, character_diff, character_diff]
    calc
      _ = character q.2.2.val i j * (character q.2.1.val i j *
        (character q.1.val i j * value F.val q)) := by ac_rfl
      _ = _ := hf
  rw [hchar, neg_one_mul] at he
  have hz : (2 : ℂ) * value F.val q = 0 := by linear_combination -he
  exact h ((mul_eq_zero.mp hz).resolve_left (by norm_num))

theorem third_of_parity {r k l : ℕ} (q : Triple r k l) (b : Bool)
    (hq : parity q = if b then Finset.univ else ∅) :
    q.2.2.val = if b then (q.1.val ∆ q.2.1.val)ᶜ else q.1.val ∆ q.2.1.val := by
  ext i
  have h := congrArg (fun s : Finset Axis => i ∈ s) hq
  change (i ∈ (q.1.val ∆ q.2.1.val) ∆ q.2.2.val) =
    (i ∈ if b then Finset.univ else ∅) at h
  rw [Finset.mem_symmDiff] at h
  have hh := Iff.of_eq h
  cases b
  · change i ∈ q.2.2.val ↔ i ∈ q.1.val ∆ q.2.1.val
    change (_ ↔ i ∈ (∅ : Finset Axis)) at hh
    simp only [Finset.notMem_empty, iff_false] at hh
    tauto
  · change i ∈ q.2.2.val ↔ i ∈ (q.1.val ∆ q.2.1.val)ᶜ
    change (_ ↔ i ∈ (Finset.univ : Finset Axis)) at hh
    simp only [Finset.mem_univ, iff_true] at hh
    rw [Finset.mem_compl]
    tauto

theorem diff_card (s t : Finset Axis) :
    (s ∆ t).card + 2 * (s ∩ t).card = s.card + t.card := by
  rw [Finset.symmDiff_def, Finset.card_union_of_disjoint]
  · have hs := Finset.card_sdiff_add_card_inter s t
    have ht := Finset.card_sdiff_add_card_inter t s
    rw [Finset.inter_comm t s] at ht
    omega
  · exact Finset.disjoint_left.mpr fun i hi hj => (Finset.mem_sdiff.mp hi).2 (Finset.mem_sdiff.mp hj).1

private def pairCode (s t : Finset Axis) (i : Axis) : Bool × Bool :=
  (decide (i ∈ s), decide (i ∈ t))

private def cell (s t : Finset Axis) : Bool × Bool → Finset Axis
  | (true, true) => s ∩ t
  | (true, false) => s \ t
  | (false, true) => t \ s
  | (false, false) => (s ∪ t)ᶜ

private theorem mem_cell (s t : Finset Axis) (i : Axis) (c : Bool × Bool) :
    i ∈ cell s t c ↔ pairCode s t i = c := by
  obtain ⟨a, b⟩ := c
  cases a <;> cases b <;>
    simp [cell, pairCode, and_comm]

private theorem cell_cards {s t u v : Finset Axis} (hs : s.card = u.card) (ht : t.card = v.card)
    (hi : (s ∩ t).card = (u ∩ v).card) (c : Bool × Bool) :
    (cell s t c).card = (cell u v c).card := by
  obtain ⟨a, b⟩ := c
  cases a <;> cases b
  · simp only [cell, Finset.card_compl]
    have hst := Finset.card_union_add_card_inter s t
    have huv := Finset.card_union_add_card_inter u v
    omega
  · simp only [cell, Finset.card_sdiff, ht, hi]
  · simp only [cell, Finset.card_sdiff, hs, Finset.inter_comm t s, Finset.inter_comm v u, hi]
  · exact hi

private theorem perm_pair_of_code {s t u v : Finset Axis} (σ : Equiv.Perm Axis)
    (he : ∀ a, pairCode u v (σ a) = pairCode s t a) :
    s.map σ.toEmbedding = u ∧ t.map σ.toEmbedding = v := by
  constructor
  · ext i
    obtain ⟨a, rfl⟩ := σ.surjective i
    rw [show σ a ∈ s.map σ.toEmbedding ↔ a ∈ s from Finset.mem_map' σ.toEmbedding]
    have ha := congrArg Prod.fst (he a)
    change decide (σ a ∈ u) = decide (a ∈ s) at ha
    by_cases hu : σ a ∈ u <;> by_cases hs : a ∈ s <;> simp_all
  · ext i
    obtain ⟨a, rfl⟩ := σ.surjective i
    rw [show σ a ∈ t.map σ.toEmbedding ↔ a ∈ t from Finset.mem_map' σ.toEmbedding]
    have ha := congrArg Prod.snd (he a)
    change decide (σ a ∈ v) = decide (a ∈ t) at ha
    by_cases hv : σ a ∈ v <;> by_cases ht : a ∈ t <;> simp_all

private theorem perm_preserves_pairCode {s t u v : Finset Axis} (hs : s.card = u.card) (ht : t.card = v.card)
    (hi : (s ∩ t).card = (u ∩ v).card) :
    ∃ σ : Equiv.Perm Axis, ∀ a, pairCode u v (σ a) = pairCode s t a := by
  let e (c : Bool × Bool) : {a // pairCode s t a = c} ≃ {a // pairCode u v a = c} :=
    (Equiv.subtypeEquivRight (mem_cell s t · c)).symm.trans
      (((cell s t c).equivOfCardEq (cell_cards hs ht hi c)).trans
        (Equiv.subtypeEquivRight (mem_cell u v · c)))
  exact ⟨Equiv.ofFiberEquiv e, Equiv.ofFiberEquiv_map e⟩

private theorem perm_pair {s t u v : Finset Axis} (hs : s.card = u.card) (ht : t.card = v.card)
    (hi : (s ∩ t).card = (u ∩ v).card) :
    ∃ σ : Equiv.Perm Axis, s.map σ.toEmbedding = u ∧ t.map σ.toEmbedding = v := by
  obtain ⟨σ, hσ⟩ := perm_preserves_pairCode hs ht hi
  exact ⟨σ, perm_pair_of_code σ hσ⟩

theorem perm_pair_with_point {s t u v : Finset Axis} {a b : Axis}
    (hs : s.card = u.card) (ht : t.card = v.card)
    (hi : (s ∩ t).card = (u ∩ v).card) (ha : a ∈ s ↔ b ∈ u) (hb : a ∈ t ↔ b ∈ v) :
    ∃ σ : Equiv.Perm Axis, σ a = b ∧ s.map σ.toEmbedding = u ∧ t.map σ.toEmbedding = v := by
  obtain ⟨σ, hσ⟩ := perm_preserves_pairCode hs ht hi
  let τ := σ.trans (Equiv.swap (σ a) b)
  have hcode : pairCode u v (σ a) = pairCode u v b := by
    rw [hσ a]
    simp only [pairCode, propext ha, propext hb]
  have he (x : Axis) : pairCode u v (τ x) = pairCode s t x := by
    rw [← hσ x]
    change pairCode u v (Equiv.swap (σ a) b (σ x)) = pairCode u v (σ x)
    by_cases h₁ : σ x = σ a
    · rw [h₁, Equiv.swap_apply_left, hcode]
    by_cases h₂ : σ x = b
    · rw [h₂, Equiv.swap_apply_right, hcode]
    rw [Equiv.swap_apply_of_ne_of_ne h₁ h₂]
  exact ⟨τ, Equiv.swap_apply_left _ _, perm_pair_of_code τ he⟩

private theorem perm_triple {r k l : ℕ} (q q' : Triple r k l) (b : Bool)
    (h : parity q = if b then Finset.univ else ∅)
    (h' : parity q' = if b then Finset.univ else ∅) :
    ∃ σ : Equiv.Perm Axis,
      permIndex σ q.1 = q'.1 ∧ permIndex σ q.2.1 = q'.2.1 ∧ permIndex σ q.2.2 = q'.2.2 := by
  have hu := third_of_parity q b h
  have hv := third_of_parity q' b h'
  have hdiff : (q.1.val ∆ q.2.1.val).card = (q'.1.val ∆ q'.2.1.val).card := by
    have h₁ := q.2.2.prop
    have h₂ := q'.2.2.prop
    change q.2.2.val.card = l at h₁
    change q'.2.2.val.card = l at h₂
    cases b
    · simp only [Bool.false_eq_true, if_false] at hu hv
      rw [hu] at h₁
      rw [hv] at h₂
      exact h₁.trans h₂.symm
    · simp only [if_true] at hu hv
      rw [hu, Finset.card_compl, Fintype.card_fin] at h₁
      rw [hv, Finset.card_compl, Fintype.card_fin] at h₂
      have hr := Finset.card_le_univ (q.1.val ∆ q.2.1.val)
      have hs := Finset.card_le_univ (q'.1.val ∆ q'.2.1.val)
      rw [Fintype.card_fin] at hr hs
      omega
  have hs := q.1.prop.trans q'.1.prop.symm
  have ht := q.2.1.prop.trans q'.2.1.prop.symm
  have hi : (q.1.val ∩ q.2.1.val).card = (q'.1.val ∩ q'.2.1.val).card := by
    have h₁ := diff_card q.1.val q.2.1.val
    have h₂ := diff_card q'.1.val q'.2.1.val
    omega
  obtain ⟨σ, hs', ht'⟩ := perm_pair hs ht hi
  refine ⟨σ, Subtype.ext hs', Subtype.ext ht', ?_⟩
  apply Subtype.ext
  ext i
  obtain ⟨a, rfl⟩ := σ.surjective i
  change σ a ∈ q.2.2.val.map σ.toEmbedding ↔ σ a ∈ q'.2.2.val
  have hm (s : Finset Axis) : σ a ∈ s.map σ.toEmbedding ↔ a ∈ s := Finset.mem_map' σ.toEmbedding
  have hs₀ : σ a ∈ q'.1.val ↔ a ∈ q.1.val := hs' ▸ hm q.1.val
  have ht₀ : σ a ∈ q'.2.1.val ↔ a ∈ q.2.1.val := ht' ▸ hm q.2.1.val
  rw [hm, hu, hv]
  cases b <;> simp [Finset.mem_symmDiff, hs₀, ht₀]

private theorem same_orbit_zero {r k l : ℕ} (F : ↥(invariantForms r k l)) (q q' : Triple r k l)
    (b : Bool) (h : parity q = if b then Finset.univ else ∅)
    (h' : parity q' = if b then Finset.univ else ∅) (hz : value F.val q' = 0) :
    value F.val q = 0 := by
  obtain ⟨σ, hs, ht, hu⟩ := perm_triple q q' b h h'
  obtain ⟨a, _, ha⟩ := orientedPerm_exterior σ 0 q.1
  obtain ⟨c, _, hc⟩ := orientedPerm_exterior σ 0 q.2.1
  obtain ⟨d, _, hd⟩ := orientedPerm_exterior σ 0 q.2.2
  have he := F.prop (orientedPermAt σ 0) (basis r q.1) (basis k q.2.1) (basis l q.2.2)
  rw [ha, hc, hd, hs, ht, hu] at he
  change _ = value F.val q at he
  simp only [map_smul, LinearMap.smul_apply] at he
  change d • c • a • value F.val q' = value F.val q at he
  rw [hz, smul_zero, smul_zero, smul_zero] at he
  exact he.symm

private abbrev ParityClass (r k l : ℕ) :=
  {b : Bool // ∃ q : Triple r k l, parity q = if b then Finset.univ else ∅}

private def sample {r k l : ℕ} (b : ParityClass r k l) : Triple r k l := Classical.choose b.prop

private theorem sample_parity {r k l : ℕ} (b : ParityClass r k l) :
    parity (sample b) = if b.val then Finset.univ else ∅ := Classical.choose_spec b.prop

private def orbitEvaluation (r k l : ℕ) : invariantForms r k l →ₗ[ℂ] (ParityClass r k l → ℂ) where
  toFun F b := value F.val (sample b)
  map_add' F G := by ext b; rfl
  map_smul' a F := by ext b; rfl

local instance (r k l : ℕ) : AddCommGroup ↥(invariantForms r k l) :=
  Submodule.addCommGroup (R := ℂ) (M := Form r k l) (invariantForms r k l)

private theorem orbitEvaluation_injective (r k l : ℕ) : Function.Injective (orbitEvaluation r k l) := by
  intro A B hab
  apply sub_eq_zero.mp
  let F := A - B
  have hF : orbitEvaluation r k l F = 0 := by rw [map_sub, hab, sub_self]
  change F = 0
  apply Subtype.ext
  apply value_ext
  intro q
  change value F.val q = 0
  by_contra hn
  have hzero (b : ParityClass r k l) : value F.val (sample b) = 0 := congrFun hF b
  rcases support_parity F q hn with he | ho
  · let b : ParityClass r k l := ⟨false, ⟨q, he⟩⟩
    exact hn (same_orbit_zero F q (sample b) b.val he (sample_parity b) (hzero b))
  · let b : ParityClass r k l := ⟨true, ⟨q, ho⟩⟩
    exact hn (same_orbit_zero F q (sample b) b.val ho (sample_parity b) (hzero b))

/-- Arithmetic feasibility of the empty-parity orbit. The witness counts
the axes shared by the first two wedges. -/
def feasible (r k l : ℕ) : Prop :=
  ∃ d : Fin 15, d.val ≤ r ∧ d.val ≤ k ∧ r + k = l + 2 * d.val ∧ r + k ≤ 14 + d.val

instance (r k l : ℕ) : Decidable (feasible r k l) := inferInstanceAs (Decidable (∃ d : Fin 15,
  d.val ≤ r ∧ d.val ≤ k ∧ r + k = l + 2 * d.val ∧ r + k ≤ 14 + d.val))

def parityBound (r k l : ℕ) : ℕ :=
  (if feasible r k l then 1 else 0) + (if feasible r k (14 - l) then 1 else 0)

private theorem feasible_of_parity {r k l : ℕ} (b : ParityClass r k l) :
    feasible r k (if b.val then 14 - l else l) := by
  let q := sample b
  have h := third_of_parity q b.val (sample_parity b)
  let d := q.1.val ∩ q.2.1.val
  have hd : d.card ≤ 14 := by simpa using Finset.card_le_univ d
  have hr : d.card ≤ q.1.val.card := Finset.card_mono Finset.inter_subset_left
  have hk : d.card ≤ q.2.1.val.card := Finset.card_mono Finset.inter_subset_right
  rw [q.1.prop] at hr
  rw [q.2.1.prop] at hk
  have hu := Finset.card_union_add_card_inter q.1.val q.2.1.val
  rw [q.1.prop, q.2.1.prop] at hu
  change (q.1.val ∪ q.2.1.val).card + d.card = r + k at hu
  have hU : (q.1.val ∪ q.2.1.val).card ≤ 14 := by simpa using Finset.card_le_univ (q.1.val ∪ q.2.1.val)
  have hf := diff_card q.1.val q.2.1.val
  rw [q.1.prop, q.2.1.prop] at hf
  change (q.1.val ∆ q.2.1.val).card + 2 * d.card = r + k at hf
  have hl : q.2.2.val.card = l := q.2.2.prop
  refine ⟨⟨d.card, by omega⟩, hr, hk, ?_, by change r + k ≤ 14 + d.card; omega⟩
  change r + k = (if b.val then 14 - l else l) + 2 * d.card
  by_cases hb : b.val = true
  · rw [if_pos hb] at h ⊢
    rw [h, Finset.card_compl, Fintype.card_fin] at hl
    have hc : (q.1.val ∆ q.2.1.val).card ≤ 14 := by simpa using Finset.card_le_univ (q.1.val ∆ q.2.1.val)
    omega
  · rw [if_neg hb] at h ⊢
    rw [h] at hl
    omega

theorem empty_parity_feasible {r k l : ℕ} (q : Triple r k l) (h : parity q = ∅) :
    feasible r k l :=
  feasible_of_parity (⟨false, ⟨q, h⟩⟩ : ParityClass r k l)

/-- A nonzero coefficient has one of two parity types, and the dimensions
of the three wedges permit at most one orbit of each type. -/
theorem finrank_invariantForms_le (r k l : ℕ) :
    Module.finrank ℂ (invariantForms r k l) ≤ parityBound r k l := by
  classical
  let P := ParityClass r k l
  let Q := {b : Bool // feasible r k (if b then 14 - l else l)}
  let f (b : P) : Q := ⟨b.val, feasible_of_parity b⟩
  have hfin : Fintype.card P ≤ Fintype.card Q :=
    Fintype.card_le_of_injective f (fun a b h => Subtype.ext (congrArg (fun x : Q => x.val) h))
  have hcard : Fintype.card Q = parityBound r k l := by
    change Fintype.card {b : Bool // feasible r k (if b then 14 - l else l)} = _
    rw [Fintype.card_subtype]
    have he : (Finset.univ : Finset Bool) = {false, true} := by decide
    rw [he]
    by_cases he : feasible r k l <;> by_cases ho : feasible r k (14 - l) <;>
      simp [Finset.filter_insert, Finset.filter_singleton, parityBound, he, ho]
  have hu := LinearMap.finrank_le_finrank_of_injective (orbitEvaluation_injective r k l)
  rw [Module.finrank_pi] at hu
  exact hu.trans (hfin.trans_eq hcard)

abbrev ExteriorIntertwiners (r k l : ℕ) :=
  Representation.IntertwiningMap ((exteriorRepresentation r).tprod (exteriorRepresentation k))
    (exteriorRepresentation l)

private def asForm {r k l : ℕ} (T : ExteriorIntertwiners r k l) : Form r k l :=
  LinearMap.mk₂ ℂ (fun x y => exteriorMetric l (T (x ⊗ₜ[ℂ] y)))
    (fun x x' y => by simp only [TensorProduct.add_tmul, map_add])
    (fun c x y => by simp only [← TensorProduct.smul_tmul', map_smul])
    (fun x y y' => by simp only [TensorProduct.tmul_add, map_add])
    (fun c x y => by simp only [TensorProduct.tmul_smul, map_smul])

private theorem asForm_invariant {r k l : ℕ} (T : ExteriorIntertwiners r k l) :
    asForm T ∈ invariantForms r k l := by
  intro g x y z
  have h := Representation.IntertwiningMap.isIntertwining
    ((exteriorRepresentation r).tprod (exteriorRepresentation k)) (exteriorRepresentation l) T g (x ⊗ₜ[ℂ] y)
  simp only [Representation.tprod_apply, TensorProduct.map_tmul] at h
  change exteriorMetric l (T (exteriorRepresentation r g x ⊗ₜ[ℂ] exteriorRepresentation k g y))
    (exteriorRepresentation l g z) = exteriorMetric l (T (x ⊗ₜ[ℂ] y)) z
  rw [h, D7ComplementaryGrades.metric_invariant]

private def formOfIntertwiner (r k l : ℕ) : ExteriorIntertwiners r k l →ₗ[ℂ] invariantForms r k l where
  toFun T := ⟨asForm T, asForm_invariant T⟩
  map_add' T U := by
    apply Subtype.ext
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    change exteriorMetric l ((T + U) (x ⊗ₜ[ℂ] y)) z = _
    simp only [Representation.IntertwiningMap.coe_add, Pi.add_apply, map_add, LinearMap.add_apply]
    rfl
  map_smul' c T := by
    apply Subtype.ext
    apply LinearMap.ext
    intro x
    apply LinearMap.ext
    intro y
    apply LinearMap.ext
    intro z
    change exteriorMetric l ((c • T) (x ⊗ₜ[ℂ] y)) z = _
    simp only [Representation.IntertwiningMap.coe_smul, Pi.smul_apply, map_smul, LinearMap.smul_apply,
      RingHom.id_apply]
    rfl

private theorem formOfIntertwiner_injective (r k l : ℕ) : Function.Injective (formOfIntertwiner r k l) := by
  intro T U h
  apply Representation.IntertwiningMap.ext
  apply TensorProduct.ext'
  intro x y
  apply exteriorMetric_injective l
  exact DFunLike.congr_fun (DFunLike.congr_fun (congrArg Subtype.val h) x) y

def metricEquiv (l : ℕ) : Ext l ≃ₗ[ℂ] (Ext l →ₗ[ℂ] ℂ) := (basis l).toDualEquiv

theorem metricEquiv_toLinearMap (l : ℕ) : (metricEquiv l).toLinearMap = exteriorMetric l := by
  apply (basis l).ext
  intro s
  apply LinearMap.ext
  intro z
  change (basis l).toDual (basis l s) z = exteriorMetric l (basis l s) z
  rw [Module.Basis.toDual_apply_right, exteriorMetric_axis, Module.Basis.coord_apply]

private theorem formOfIntertwiner_surjective (r k l : ℕ) : Function.Surjective (formOfIntertwiner r k l) := by
  intro F
  let f := (metricEquiv l).symm.toLinearMap.comp (TensorProduct.lift F.val)
  have hmetric (x : Ext r) (y : Ext k) : exteriorMetric l (f (x ⊗ₜ[ℂ] y)) = F.val x y := by
    rw [← metricEquiv_toLinearMap]
    change metricEquiv l ((metricEquiv l).symm (TensorProduct.lift F.val (x ⊗ₜ[ℂ] y))) = _
    rw [LinearEquiv.apply_symm_apply, TensorProduct.lift.tmul]
  let T : ExteriorIntertwiners r k l :=
    { toLinearMap := f
      isIntertwining' g := by
        apply TensorProduct.ext'
        intro x y
        simp only [LinearMap.comp_apply, Representation.tprod_apply, TensorProduct.map_tmul]
        apply exteriorMetric_injective l
        apply LinearMap.ext
        intro z
        obtain ⟨w, rfl⟩ := D7ComplementaryGrades.exterior_surjective l g z
        rw [D7ComplementaryGrades.metric_invariant, hmetric, hmetric]
        exact F.prop g x y w }
  refine ⟨T, Subtype.ext ?_⟩
  apply LinearMap.ext
  intro x
  apply LinearMap.ext
  intro y
  exact hmetric x y

/-- Lowering the output index with the determinant metric identifies
intertwiners with invariant trilinear forms. -/
def exteriorIntertwinerEquiv (r k l : ℕ) : ExteriorIntertwiners r k l ≃ₗ[ℂ] invariantForms r k l :=
  LinearEquiv.ofBijective (formOfIntertwiner r k l)
    ⟨formOfIntertwiner_injective r k l, formOfIntertwiner_surjective r k l⟩

theorem finrank_exteriorIntertwiners_le (r k l : ℕ) :
    Module.finrank ℂ (ExteriorIntertwiners r k l) ≤ parityBound r k l :=
  (exteriorIntertwinerEquiv r k l).finrank_eq.le.trans
    (finrank_invariantForms_le r k l)

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem alternating_bounds_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, parityBound 3 k.val l.val) =
      D7Counts.expectedRows.map (fun row => row.alternating.toNat) := by decide +kernel

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem vector_bounds_by_grade :
    (List.ofFn fun k : Fin 15 => ∑ l : Fin 15, parityBound 1 k.val l.val) =
      D7Counts.expectedRows.map (fun row => row.vector.toNat) := by decide +kernel

set_option maxRecDepth 8192 in
set_option maxHeartbeats 4000000 in
theorem vector_and_alternating_upper_bounds :
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 1 k.val l.val)) ≤ 56 ∧
    (∑ k : Fin 15, ∑ l : Fin 15, Module.finrank ℂ (ExteriorIntertwiners 3 k.val l.val)) ≤ 96 := by
  constructor
  · have h := Finset.sum_le_sum fun k : Fin 15 => fun _ : k ∈ Finset.univ =>
      Finset.sum_le_sum fun l : Fin 15 => fun _ : l ∈ Finset.univ => finrank_exteriorIntertwiners_le 1 k.val l.val
    exact h.trans (by decide +kernel)
  · have h := Finset.sum_le_sum fun k : Fin 15 => fun _ : k ∈ Finset.univ =>
      Finset.sum_le_sum fun l : Fin 15 => fun _ : l ∈ Finset.univ => finrank_exteriorIntertwiners_le 3 k.val l.val
    exact h.trans (by decide +kernel)

end
end GeometricUnity.D7TripleInvariants
