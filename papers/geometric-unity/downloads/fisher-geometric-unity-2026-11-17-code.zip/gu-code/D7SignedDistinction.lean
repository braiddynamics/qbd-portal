import D7ComplementaryGrades

/-!
# Separation of the signed middle constituents

One diagonal torus element detects the distinction between the two signs.
For the exterior action the top eigenvalue has only the all-plus coordinate
wedge. For the vector tensor action each top eigenvector has that same
exterior factor. Both eigenspaces lie in the negative Hodge sector.
-/

namespace GeometricUnity.D7SignedDistinction

open D7Exterior D7Hodge D7Irreducible D7VectorGrades D7MiddleTensor
open scoped BigOperators TensorProduct

noncomputable section

private abbrev plusIndex := highestPlus (7 : Fin 15)
private abbrev nullBasis := axisBasis.exteriorPower 7
private abbrev nullTensorBasis := axisBasis.tensorProduct nullBasis

private def exponent (s : Finset Axis) : ℤ := ∑ i ∈ s, axisSign i

private theorem axisSign_le_one (i : Axis) : axisSign i ≤ 1 := by
  unfold axisSign
  split <;> norm_num

private theorem plus_axis_iff : ∀ i : Axis, i ∈ plusIndex.val ↔ axisSign i = 1 := by decide +kernel

private theorem plus_exponent : exponent plusIndex.val = 7 := by
  unfold exponent
  rw [Finset.sum_congr rfl (fun i hi => (plus_axis_iff i).mp hi), Finset.sum_const]
  rfl

private theorem plusIndex_of_max (s : Index 7) (hs : 7 ≤ exponent s.val) : s = plusIndex := by
  apply Subtype.ext
  apply Finset.eq_of_subset_of_card_le _ (Nat.le_of_eq (plusIndex.prop.trans s.prop.symm))
  intro j hj
  by_contra hn
  have hlt : axisSign j < 1 :=
    lt_of_le_of_ne (axisSign_le_one j) (fun he => hn ((plus_axis_iff j).mpr he))
  have hh : exponent s.val < ∑ i ∈ s.val, (1 : ℤ) :=
    Finset.sum_lt_sum (fun i _ => axisSign_le_one i) ⟨j, hj, hlt⟩
  rw [Finset.sum_const, show s.val.card = 7 from s.prop] at hh
  norm_num at hh
  omega

private def t : Pair → ℂˣ := fun _ => Units.mk0 (2 : ℂ) (by norm_num)
private def g : splitSpecialOrthogonal := torusElement t

private theorem scale_t (i : Axis) : (scale t i : ℂ) = (2 : ℂ) ^ axisSign i := by
  simp [scale, t]

private theorem exponent_power (s : Finset Axis) : (∏ i ∈ s, (2 : ℂ) ^ axisSign i) = (2 : ℂ) ^ exponent s := by
  induction s using Finset.induction_on with
  | empty => simp [exponent]
  | @insert i s hi ih => simp [exponent, hi, ih, zpow_add₀ (show (2 : ℂ) ≠ 0 by norm_num)]

private theorem exterior_diagonal (s : Index 7) :
    exteriorRepresentation 7 g (nullBasis s) = (2 : ℂ) ^ exponent s.val • nullBasis s := by
  change exteriorPower.map 7 (torus t) (nullBasis s) = _
  rw [torus_exterior, ← subset_character, Units.coe_prod]
  simp only [scale_t, exponent_power]

private theorem tensor_diagonal (q : Axis × Index 7) :
    action 7 g (nullTensorBasis q) = (2 : ℂ) ^ (axisSign q.1 + exponent q.2.val) • nullTensorBasis q := by
  rw [Module.Basis.tensorProduct_apply', action_tmul]
  have h₁ : g.val (axisBasis q.1) = (2 : ℂ) ^ axisSign q.1 • axisBasis q.1 := by
    change torus t (axisBasis q.1) = _
    rw [torus_axis, scale_t]
  have h₂ : exteriorPower.map 7 g.val (nullBasis q.2) =
      (2 : ℂ) ^ exponent q.2.val • nullBasis q.2 := exterior_diagonal q.2
  rw [h₁, h₂, TensorProduct.smul_tmul_smul, ← zpow_add₀ (show (2 : ℂ) ≠ 0 by norm_num)]

private theorem two_power_injective : Function.Injective (fun n : ℤ => (2 : ℂ) ^ n) := by
  intro i j hij
  change (2 : ℂ) ^ i = (2 : ℂ) ^ j at hij
  have hr : (2 : ℝ) ^ i = (2 : ℝ) ^ j := by
    apply Complex.ofReal_injective
    simpa only [Complex.ofReal_zpow, Complex.ofReal_ofNat] using hij
  exact (zpow_right_strictMono₀ (a := (2 : ℝ)) (by norm_num)).injective hr

private theorem diagonal_sign {E ι : Type*} [AddCommGroup E] [Module ℂ E] [Fintype ι]
    (b : Module.Basis ι ℂ E) (f J : E →ₗ[ℂ] E) (d : ι → ℂ) (a : ℂ)
    (hf : ∀ s, f (b s) = d s • b s)
    (hJ : ∀ s, d s = a → J (b s) = -b s)
    {x : E} (hx : f x = a • x) : J x = -x := by
  classical
  have hsupport (s : ι) (hs : b.repr x s ≠ 0) : d s = a := by
    let c := b.coord s
    have hc : c.comp f = d s • c := by
      apply b.ext
      intro u
      simp only [LinearMap.comp_apply, hf, map_smul, LinearMap.smul_apply,
        c, Module.Basis.coord_apply, Module.Basis.repr_self, Finsupp.single_apply]
      by_cases hu : s = u <;> simp [hu, eq_comm, smul_eq_mul]
    have he := DFunLike.congr_fun hc x
    change c (f x) = d s • c x at he
    rw [hx, map_smul] at he
    exact (mul_right_cancel₀ hs he).symm
  have hsum := congrArg J (b.sum_repr x)
  simp only [map_sum, map_smul] at hsum
  rw [← hsum]
  calc
    _ = ∑ i, b.repr x i • (-b i) := by
      apply Finset.sum_congr rfl
      intro i _
      by_cases hi : b.repr x i = 0
      · rw [hi, zero_smul, zero_smul]
      · rw [hJ i (hsupport i hi)]
    _ = -x := by simp only [smul_neg, Finset.sum_neg_distrib, b.sum_repr]

private theorem exterior_top_sign (x : Mid)
    (hx : exteriorRepresentation 7 g x = (2 : ℂ) ^ (7 : ℤ) • x) : involution x = -x := by
  apply diagonal_sign nullBasis (exteriorRepresentation 7 g) involution
    (fun s => (2 : ℂ) ^ exponent s.val) _ exterior_diagonal _ hx
  intro s hs
  have he : exponent s.val = 7 := two_power_injective hs
  rw [plusIndex_of_max s (ge_of_eq he)]
  exact ((mem_sector (-1) (nullBasis plusIndex)).mp highestPlus_mem_sector).trans
    (neg_one_smul ℂ (nullBasis plusIndex))

private theorem tensor_top_sign (x : Product 7)
    (hx : action 7 g x = (2 : ℂ) ^ (8 : ℤ) • x) : tensorInvolution x = -x := by
  apply diagonal_sign nullTensorBasis (action 7 g) tensorInvolution
    (fun s => (2 : ℂ) ^ (axisSign s.1 + exponent s.2.val)) _ tensor_diagonal _ hx
  intro ⟨i, s⟩ hs
  have he : axisSign i + exponent s.val = 8 := two_power_injective hs
  have hs' : s = plusIndex := plusIndex_of_max s (by have := axisSign_le_one i; omega)
  subst s
  have hJ := (mem_sector (-1) (nullBasis plusIndex)).mp highestPlus_mem_sector
  rw [neg_one_smul ℂ (nullBasis plusIndex)] at hJ
  rw [Module.Basis.tensorProduct_apply', tensorInvolution, TensorProduct.map_tmul, LinearMap.id_apply, hJ,
    TensorProduct.tmul_neg]

private theorem zero_of_eq_neg {E : Type*} [AddCommGroup E] [Module ℂ E] (x : E) (hx : x = -x) : x = 0 := by
  have hs : (2 : ℂ) • x = 0 := by rw [two_smul]; exact add_eq_zero_iff_eq_neg.mpr hx
  exact (smul_eq_zero.mp hs).resolve_left (by norm_num)

/-- The two signed middle exterior representations have distinct isomorphism classes. -/
theorem exterior_sectors_inequivalent :
    ¬ Nonempty ((sectorRepresentation (-1)).Equiv (sectorRepresentation 1)) := by
  rintro ⟨e⟩
  let x : ↥(sector (-1)) := ⟨nullBasis plusIndex, highestPlus_mem_sector⟩
  let y := e.toLinearEquiv x
  have hx : sectorRepresentation (-1) g x = (2 : ℂ) ^ (7 : ℤ) • x := by
    apply Subtype.ext
    change exteriorRepresentation 7 g (nullBasis plusIndex) = _
    rw [exterior_diagonal, plus_exponent]
    rfl
  have h := Representation.IntertwiningMap.isIntertwining (sectorRepresentation (-1))
    (sectorRepresentation 1) e.toIntertwiningMap g x
  change e.toLinearEquiv (sectorRepresentation (-1) g x) = sectorRepresentation 1 g y at h
  rw [hx, map_smul] at h
  have hy : exteriorRepresentation 7 g y.val = (2 : ℂ) ^ (7 : ℤ) • y.val :=
    congrArg Subtype.val h.symm
  have hp := (mem_sector 1 y.val).mp y.prop
  rw [one_smul, exterior_top_sign y.val hy] at hp
  have hz : y = 0 := Subtype.ext (zero_of_eq_neg y.val hp.symm)
  exact highestPlus_ne_zero (7 : Fin 15) (congrArg Subtype.val (e.toLinearEquiv.map_eq_zero_iff.mp hz))

set_option backward.isDefEq.respectTransparency false in
/-- The two signed middle residual representations have distinct isomorphism classes. -/
theorem residual_sectors_inequivalent :
    ¬ Nonempty ((residualSectorAction (-1)).Equiv (residualSectorAction 1)) := by
  rintro ⟨e⟩
  let x : ↥(residualSector (-1)) := ⟨plusLabelCandidate, plusLabelCandidate_sector⟩
  let y := e.toLinearEquiv x
  have hx : residualSectorAction (-1) g x = (2 : ℂ) ^ (8 : ℤ) • x := by
    have hB : nullTensor plusIndex = nullTensorBasis (plusAxis 0, plusIndex) :=
      (Module.Basis.tensorProduct_apply' axisBasis nullBasis (plusAxis 0, plusIndex)).symm
    have he : action 7 g (nullTensor plusIndex) = (2 : ℂ) ^ (8 : ℤ) • nullTensor plusIndex := by
      rw [hB, tensor_diagonal, plus_exponent, show axisSign (plusAxis 0) = 1 by decide,
        show (1 + 7 : ℤ) = 8 by decide]
    apply Subtype.ext
    apply Subtype.ext
    exact he
  have h := Representation.IntertwiningMap.isIntertwining (residualSectorAction (-1))
    (residualSectorAction 1) e.toIntertwiningMap g x
  change e.toLinearEquiv (residualSectorAction (-1) g x) = residualSectorAction 1 g y at h
  rw [hx, map_smul] at h
  have hy : action 7 g y.val.val = (2 : ℂ) ^ (8 : ℤ) • y.val.val :=
    congrArg (fun z : ↥(residualSector 1) => z.val.val) h.symm
  have hp := tensorInvolution_of_mem_residualSector 1 y.val y.prop
  rw [one_smul, tensor_top_sign y.val.val hy] at hp
  have hz : y = 0 := Subtype.ext (Subtype.ext (zero_of_eq_neg y.val.val hp.symm))
  have hx0 := e.toLinearEquiv.map_eq_zero_iff.mp hz
  exact nullTensor_ne_zero plusIndex (congrArg (fun z : ↥(residualSector (-1)) => z.val.val) hx0)

end
end GeometricUnity.D7SignedDistinction
