#!/usr/bin/env python3
"""
Quantum Braid Dynamics (QBD) — Standalone Reference Simulation Engine
A single-file, self-contained Python script to reproduce all analytical priors,
move grammar invariants, and simulation tables from the preprint manuscript.

Dependencies: Python >= 3.8, networkx >= 2.6
"""

from __future__ import annotations

import argparse
import collections
import csv
import json
import math
import os
import random
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import Dict, List, Optional, Sequence, Set, Tuple

import networkx as nx


# =============================================================================
# 1. CANONICAL ANALYTICAL REFERENCE PRIOR SUITE (TABLE 1)
# =============================================================================

def compute_analytical_priors() -> Dict[str, float]:
    """Computes constitutive scales from discrete combinatorial principles (Table 1)."""
    T_c = math.log(2.0)                                    # Loop-closure free energy neutrality: T_c = ln 2 (Prop 4.1)
    mu_0 = 1.0 / math.sqrt(2.0 * math.pi)                  # Z Poisson summation & modular S-duality: mu_0 = 1/sqrt(2*pi) (Prop 4.3)
    lambda_0 = math.e - 1.0                                # Arrhenius 1-nat defect relaxation: lambda_0 = e - 1 (Prop 4.2)
    eps_geo = math.log(2.0) / 3.0                          # k_deg=3 vertex channel equipartition: eps_geo = ln(2)/3 (Prop 4.4)
    Lambda_theory = 2.0 ** (-6)                            # 6-port triad binary simplex routing: Lambda = 2^-6 (Prop 4.5)
    rho_c = 1.0 / (24.0 - 6.0 * math.e)                    # Unpumped critical nucleation barrier: rho_c = 1/(24-6e) (Sec 6.2)
    mu_crit = ((9.0 - 3.0 * lambda_0) ** 2) / 108.0       # Saddle-node continuum bifurcation threshold (Sec 6.2.1)

    return {
        "T_c": T_c,
        "mu_0": mu_0,
        "lambda_0": lambda_0,
        "eps_geo": eps_geo,
        "Lambda_theory": Lambda_theory,
        "rho_c": rho_c,
        "mu_crit": mu_crit,
    }


# =============================================================================
# 1b. TRIAD OCCUPANCY CHECKS (SECTION 3.5.4)
# =============================================================================

# Paper table 3.5.4: computational-basis labels for |q12 q23 q31>.
TRIAD_OCCUPANCY_TABLE: Tuple[Tuple[int, int, int, str, str], ...] = (
    (0, 0, 0, "Vacuum", "Pre-geometric Void"),
    (1, 0, 0, "Tension A", "Single Edge 1 -> 2"),
    (0, 1, 0, "Tension B", "Single Edge 2 -> 3"),
    (0, 0, 1, "Tension C", "Single Edge 3 -> 1"),
    (1, 1, 0, "Precursor A", "Compliant 2-Path 1 -> 2 -> 3"),
    (0, 1, 1, "Precursor B", "Compliant 2-Path 2 -> 3 -> 1"),
    (1, 0, 1, "Precursor C", "Compliant 2-Path 3 -> 1 -> 2"),
    (1, 1, 1, "Geometric Quantum", "Closed 3-Cycle"),
)

# Expected (S1, S2, S3, V) with S1=Z12 Z23, S2=Z23 Z31, S3=Z31 Z12, V=Z12 Z23 Z31.
TRIAD_OCCUPANCY_EXPECTED: Dict[Tuple[int, int, int], Tuple[int, int, int, int]] = {
    (0, 0, 0): (1, 1, 1, 1),
    (1, 0, 0): (-1, 1, -1, -1),
    (0, 1, 0): (-1, -1, 1, -1),
    (0, 0, 1): (1, -1, -1, -1),
    (1, 1, 0): (1, -1, -1, 1),
    (0, 1, 1): (-1, 1, -1, 1),
    (1, 0, 1): (-1, -1, 1, 1),
    (1, 1, 1): (1, 1, 1, -1),
}


def z_occupancy_eigenvalue(bit: int) -> int:
    """Z|0> = +|0>, Z|1> = -|1> on a directed-edge occupancy qubit."""
    if bit not in (0, 1):
        raise ValueError("occupancy bit must be 0 or 1")
    return 1 if bit == 0 else -1


def triad_occupancy_checks(q12: int, q23: int, q31: int) -> Tuple[int, int, int, int]:
    """
    Evaluate triad occupancy checks on |q12 q23 q31>.

    S1 = Z12 Z23, S2 = Z23 Z31, S3 = Z31 Z12, V = Z12 Z23 Z31.
    """
    z12 = z_occupancy_eigenvalue(q12)
    z23 = z_occupancy_eigenvalue(q23)
    z31 = z_occupancy_eigenvalue(q31)
    s1 = z12 * z23
    s2 = z23 * z31
    s3 = z31 * z12
    volume = z12 * z23 * z31
    return s1, s2, s3, volume


def pi_order_eigenvalue(q12: int, q23: int, q31: int) -> int:
    """
    Eigenvalue of Pi_order = I - (1/8)(I-Z12)(I-Z23)(I-Z31).
    Equals 0 on |111> and 1 otherwise. Not an allowed-set projector.
    """
    return 0 if (q12, q23, q31) == (1, 1, 1) else 1


# =============================================================================
# 2. COMBINATORIAL GRAPH BUILDER (G0 & SEED INJECTION)
# =============================================================================

def generate_bethe_fragment(N: int = 100) -> Tuple[nx.DiGraph, List[List[int]]]:
    """
    Constructs an outward-directed regular Bethe fragment (Section 2.3).
    Root has out-degree 3; subsequent internal nodes have in-degree 1, out-degree 2.
    Leaves have in-degree 1, out-degree 0. Total leaves L = (N + 2)/2 (~50%).
    """
    if N < 3:
        raise ValueError("N must be at least 3 for a valid vacuum")
    G = nx.DiGraph()
    root = 0
    G.add_node(root)
    levels = [[root]]
    node_id = 1

    while G.number_of_nodes() < N:
        next_level = []
        if not levels[-1]:
            break
        for parent in levels[-1]:
            children = 3 if parent == root else 2
            for _ in range(children):
                if G.number_of_nodes() >= N:
                    break
                G.add_node(node_id)
                G.add_edge(parent, node_id, H=0)
                next_level.append(node_id)
                node_id += 1
        if not next_level:
            break
        levels.append(next_level)

    return G, levels


def inject_seed_defect(G: nx.DiGraph, levels: Optional[List[List[int]]] = None) -> nx.DiGraph:
    """Injects a single symmetry-breaking 3-cycle defect at the root (Section 2.4, H=1)."""
    if levels and len(levels) >= 3 and levels[2]:
        v = levels[0][0]
        u = levels[2][0]
        G.add_edge(u, v, H=1)
    else:
        children = list(G.successors(0))
        if children:
            w = children[0]
            grandchildren = list(G.successors(w))
            if grandchildren:
                G.add_edge(grandchildren[0], 0, H=1)
    return G


# =============================================================================
# 3. MOVE GRAMMAR FILTERS (PUC & AEC)
# =============================================================================

def is_permissible_puc(G: nx.DiGraph, u: int, v: int, w: int) -> bool:
    """
    Parent-Uniqueness Condition (PUC, Section 2.5.2).
    Requires (v,u) not in E, and v -> w -> u is the unique directed 2-path from v to u.
    """
    if G.has_edge(v, u):
        return False
    for x in G.successors(v):
        if x != w and G.has_edge(x, u):
            return False
    return True


def pre_check_aec(G: nx.DiGraph, u: int, v: int, H_new: int) -> bool:
    """
    Acyclicity Pre-Check (AEC, Section 2.5.3).
    Evaluates paths from v to u up to depth L_cut = floor(log2 N) + 3 via BFS.
    """
    N = G.number_of_nodes()
    L_cut = max(1, int(math.floor(math.log2(N))) + 3) if N > 1 else 1

    queue = collections.deque([(v, -1, 0)])  # (node, prev_edge_height, depth)
    visited = set([(v, -1)])
    while queue:
        curr, prev_h, depth = queue.popleft()
        if depth >= L_cut:
            continue
        for succ in G.successors(curr):
            edge_h = G[curr][succ].get("H", 0)
            if edge_h > prev_h:  # Strictly monotone increasing
                if succ == u and edge_h < H_new:
                    return False  # Closed acausal monotone loop detected
                state = (succ, edge_h)
                if state not in visited:
                    visited.add(state)
                    queue.append((succ, edge_h, depth + 1))
    return True


def find_all_3_cycles(G: nx.DiGraph) -> List[List[Tuple[int, int]]]:
    """Finds all unique directed 3-cycles in the spatial graph."""
    cycles = []
    for u in G.nodes():
        for v in G.successors(u):
            for w in G.successors(v):
                if G.has_edge(w, u) and u < v and u < w:
                    cycles.append([(u, v), (v, w), (w, u)])
    return cycles


def find_legal_addition_sites(
    G: nx.DiGraph,
) -> List[Tuple[Tuple[int, int], int, Tuple[int, int, int]]]:
    """Finds all candidate 2-paths satisfying Parent-Uniqueness (PUC) and Acyclicity (AEC)."""
    sites = []
    for v in G.nodes():
        for w in list(G.successors(v)):
            for u in list(G.successors(w)):
                if v == u or G.has_edge(u, v):
                    continue
                if not is_permissible_puc(G, u, v, w):
                    continue
                in_edges = G.in_edges(u, data=True)
                max_h_in = max((d.get("H", 0) for _, _, d in in_edges), default=0)
                H_new = max_h_in + 1
                if not pre_check_aec(G, u, v, H_new):
                    continue
                sites.append(((u, v), H_new, (v, w, u)))
    return sites


# =============================================================================
# 3b. POLYGON DIGESTION (THEOREM 2.2.8 / TABLE 1)
# =============================================================================

# Paper Table 1: (Ops_add, Ops_del, total) for an isolated directed k-cycle.
TABLE_1_DIGESTION: Dict[int, Tuple[int, int, int]] = {
    4: (4, 1, 5),
    5: (5, 3, 8),
    6: (6, 2, 8),
    7: (7, 3, 10),
    8: (8, 3, 11),
    9: (9, 3, 12),
    10: (10, 3, 13),
    11: (11, 3, 14),
    12: (12, 3, 15),
}


def create_directed_cycle(k: int) -> nx.DiGraph:
    """Simple directed k-cycle: the isolated topological defect of Theorem 2.2.8."""
    G = nx.DiGraph()
    for i in range(k):
        G.add_edge(i, (i + 1) % k)
    return G


def max_simple_cycle_length(G: nx.DiGraph) -> int:
    cycles = list(nx.simple_cycles(G))
    if not cycles:
        return 0
    return max(len(c) for c in cycles)


def find_compliant_2_paths_for_digestion(G: nx.DiGraph) -> List[Tuple[int, int, int]]:
    """PUC-compliant open 2-paths (v -> w -> u) on an isolated defect (no timestamps)."""
    paths: List[Tuple[int, int, int]] = []
    for v in G.nodes():
        for w in G.successors(v):
            for u in G.successors(w):
                if u == v or G.has_edge(v, u):
                    continue
                if any(x != w and G.has_edge(x, u) for x in G.successors(v)):
                    continue
                paths.append((v, w, u))
    return paths


def phase_1_add_chords(G: nx.DiGraph) -> int:
    """
    Exhaustive parallel chord insertion: close v -> w -> u with (u -> v).
    Combinatorial benchmark for cycle reduction (Monograph §2.4.10, Table 1).
    """
    paths = find_compliant_2_paths_for_digestion(G)
    ops = 0
    for v, w, u in paths:
        if not G.has_edge(u, v):
            G.add_edge(u, v)
            ops += 1
    return ops


def phase_2_delete_macro_cycles(G: nx.DiGraph) -> int:
    """
    Delete one perimeter edge at a time until every remaining cycle has length <= 3.
    Topological pruning phase for isolated defect benchmark (Table 1).
    """
    ops = 0
    while max_simple_cycle_length(G) > 3:
        target = next((c for c in nx.simple_cycles(G) if len(c) > 3), None)
        if target is None:
            break
        u, v = target[0], target[1]
        if G.has_edge(u, v):
            G.remove_edge(u, v)
            ops += 1
    return ops


def run_reduction_protocol(k: int) -> Tuple[int, int]:
    """
    Digest an isolated directed k-cycle to a simplicial state L_max <= 3.
    Returns (Ops_add, Ops_del) as in Table 1 (Monograph §2.4.10).
    Note: Evaluates unweighted topological cycle reduction to verify simplicial
    ground states; physical evolution is governed by the 4-step scheduler (Section 2.8).
    """
    if k <= 3:
        return 0, 0
    G = create_directed_cycle(k)
    add_ops = phase_1_add_chords(G)
    del_ops = phase_2_delete_macro_cycles(G)
    return add_ops, del_ops


def reduce_directed_k_cycle(k: int) -> Tuple[nx.DiGraph, int, int]:
    """Same protocol, also returning the reduced graph for L_max checks."""
    G = create_directed_cycle(k)
    if k <= 3:
        return G, 0, 0
    add_ops = phase_1_add_chords(G)
    del_ops = phase_2_delete_macro_cycles(G)
    return G, add_ops, del_ops


# =============================================================================
# 4. FOUR-STEP PARALLEL SCHEDULER & HOMEOSTATIC EQUILIBRIUM (SECTION 2.8)
# =============================================================================

def build_stress_map(cycles: Sequence[Sequence[Tuple[int, int]]]) -> Dict[int, int]:
    """Computes vertex cycle incidence count."""
    stress_map: Dict[int, int] = {}
    for cycle in cycles:
        for u, _v in cycle:
            stress_map[u] = stress_map.get(u, 0) + 1
    return stress_map


def execute_parallel_tick(G: nx.DiGraph, mu: float, lam: float) -> Tuple[nx.DiGraph, bool]:
    """
    Executes one discrete tick under scheduler operator U (Section 2.8).
    Step 1: Awareness | Step 2: Proposals | Step 3: Merge | Step 4: Deletion
    Returns (G_next, active_flag). Returns active=False if homeostatic equilibrium is reached.
    """
    # Step 1: Awareness
    cycles = find_all_3_cycles(G)
    legal_additions = find_legal_addition_sites(G)

    # Combinatorial absorbing boundary: zero legal addition sites AND zero active 3-cycles
    if not legal_additions and not cycles:
        return G, False

    stress_map = build_stress_map(cycles)

    # Step 2: Proposals (Independent Bernoulli trials)
    A: Set[Tuple[Tuple[int, int], int]] = set()
    for (u, v), H_new, (node_v, node_w, node_u) in legal_additions:
        s_add = stress_map.get(node_v, 0) + stress_map.get(node_w, 0) + stress_map.get(node_u, 0)
        P_acc = math.exp(-mu * s_add)
        if random.random() < P_acc:
            A.add(((u, v), H_new))

    D: Set[Tuple[int, int]] = set()
    for cycle in cycles:
        cycle_nodes = {x for edge in cycle for x in edge}
        s_del = max(0, sum(stress_map.get(x, 0) for x in cycle_nodes) - 1)
        Q_del = min(1.0, 0.5 * (1.0 + lam * s_del) * math.exp(-mu * s_del))
        if random.random() < Q_del:
            chosen_edge = random.choice(cycle)
            D.add(chosen_edge)

    # Step 3: Merge (Symmetric conflict resolution & Additions First)
    A_edges = {e for e, _ in A}
    A_filtered = {((u, v), H_new) for (u, v), H_new in A if (v, u) not in A_edges and u != v}
    for (u, v), H_new in A_filtered:
        G.add_edge(u, v, H=H_new)

    # Step 4: Deletions (Applied to intermediate graph)
    for u, v in D:
        if G.has_edge(u, v):
            G.remove_edge(u, v)

    # Homeostatic Equilibrium Check (Physical Stasis: Delta t_phys == 0)
    if not A and not D:
        return G, False

    return G, True


def evolve_graph_to_equilibrium(
    G: nx.DiGraph, mu: float, lam: float, max_steps: int = 1500
) -> Tuple[nx.DiGraph, int]:
    """Runs the simulation until homeostatic equilibrium (quiet tick) or max_steps."""
    for step in range(max_steps):
        G, active = execute_parallel_tick(G, mu, lam)
        if not active:
            return G, step + 1
    return G, max_steps


# =============================================================================
# 5. STATISTICAL DIAGNOSTICS & ENSEMBLE RUNNERS
# =============================================================================

def compute_qsd_moments(n3_values: Sequence[int], N: int) -> Dict[str, float]:
    """Computes unconditioned and conditioned QSD moments from an ensemble."""
    n = len(n3_values)
    survivors = [x for x in n3_values if x > 0]
    p_surv = len(survivors) / float(n) if n else 0.0
    mean_all = statistics.fmean(n3_values) if n else 0.0
    var_all = statistics.variance(n3_values) if n > 1 else 0.0
    mean_qsd = statistics.fmean(survivors) if survivors else 0.0
    var_qsd = statistics.variance(survivors) if len(survivors) > 1 else 0.0

    rho_all = [x / float(N) for x in n3_values]
    rho_qsd = [x / float(N) for x in survivors]

    # Skewness
    def _skew(xs):
        if len(xs) < 3: return 0.0
        m = statistics.fmean(xs)
        v = statistics.pvariance(xs)
        if v <= 0: return 0.0
        s = math.sqrt(v)
        return sum(((x - m)/s)**3 for x in xs) / len(xs)

    return {
        "n": float(n),
        "n_surv": float(len(survivors)),
        "p_surv": p_surv,
        "p_surv_se": math.sqrt(p_surv * (1.0 - p_surv) / n) if n else 0.0,
        "mean_n3_all": mean_all,
        "mean_rho_all": mean_all / float(N),
        "median_rho_all": statistics.median(rho_all) if rho_all else 0.0,
        "std_rho_all": statistics.stdev(rho_all) if n > 1 else 0.0,
        "skew_rho_all": _skew(rho_all),
        "fano_all": (var_all / mean_all) if mean_all > 0 else 0.0,
        "mean_n3_qsd": mean_qsd,
        "mean_rho_qsd": mean_qsd / float(N) if (N and survivors) else 0.0,
        "mean_rho_qsd_se": (statistics.stdev(rho_qsd) / math.sqrt(len(rho_qsd))) if len(rho_qsd) > 1 else 0.0,
        "median_rho_qsd": statistics.median(rho_qsd) if rho_qsd else 0.0,
        "std_rho_qsd": statistics.stdev(rho_qsd) if len(rho_qsd) > 1 else 0.0,
        "fano_qsd": (var_qsd / mean_qsd) if mean_qsd > 0 else 0.0,
        "n3_min_qsd": float(min(survivors)) if survivors else 0.0,
        "n3_max_qsd": float(max(survivors)) if survivors else 0.0,
    }


def compute_scar_diagnostics(G: nx.DiGraph, N: int = 100) -> Dict[str, float]:
    """Computes topological scar and graph degree observables (Table 5)."""
    cycles = find_all_3_cycles(G)
    cycle_edges = {e for c in cycles for e in c}
    total_edges = G.number_of_edges()
    scar_edges = total_edges - len(cycle_edges)
    G_undir = G.to_undirected()
    comps = list(nx.connected_components(G_undir))
    largest_cc = max(comps, key=len) if comps else set()
    diam = float(nx.diameter(G_undir.subgraph(largest_cc))) if len(largest_cc) > 1 else 0.0
    mean_deg = sum(dict(G.degree()).values()) / float(N)

    return {
        "total_edges": float(total_edges),
        "num_3_cycles": float(len(cycles)),
        "scar_edges": float(scar_edges),
        "mean_degree": float(mean_deg),
        "diameter": diam,
    }


def _worker_trajectory(args: Tuple) -> Dict:
    if len(args) >= 6:
        run_idx, N, mu, lam, seed, max_steps = args[:6]
    else:
        run_idx, N, mu, lam, seed = args
        max_steps = 60
    random.seed(seed)
    t0 = time.time()
    G, levels = generate_bethe_fragment(N)
    G = inject_seed_defect(G, levels)
    G_final, steps = evolve_graph_to_equilibrium(G, mu, lam, max_steps=max_steps)
    n3 = len(find_all_3_cycles(G_final))
    scar = compute_scar_diagnostics(G_final, N)
    return {
        "run_idx": run_idx,
        "N": N,
        "mu": mu,
        "lam": lam,
        "steps": steps,
        "n3_final": n3,
        "is_survivor": int(n3 > 0),
        "total_edges": scar["total_edges"],
        "scar_edges": scar["scar_edges"],
        "mean_deg": scar["mean_degree"],
        "diameter": scar["diameter"],
        "elapsed_sec": time.time() - t0,
    }


# =============================================================================
# 6. PROPERTY-BASED INVARIANT VERIFICATION
# =============================================================================

def test_engine_invariants(num_ticks: int = 50, N: int = 100) -> bool:
    """
    Verifies microscopic mathematical invariants:
    1. Move Disjointness (Lemma 2.1): A_edges and D are strictly disjoint.
    2. Scar Immunity (Theorem 6.2): Deletions only target 3-cycle edges.
    3. Irreflexivity & Asymmetry (Axiom 1): Additions never create self-loops or reciprocal edges.
    4. DAG Acyclicity: Terminal state is certified acyclic when cycles vanish.
    """
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]

    G, levels = generate_bethe_fragment(N)
    # Check 50% leaf boundary theorem
    leaves = sum(1 for v in G.nodes() if G.out_degree(v) == 0)
    expected_leaves = (N + 2) // 2
    assert leaves == expected_leaves, f"Leaf theorem mismatch: got {leaves}, expected {expected_leaves}"

    G = inject_seed_defect(G, levels)
    assert len(find_all_3_cycles(G)) == 1, "Seed cycle injection failed"

    for _ in range(num_ticks):
        cycles = find_all_3_cycles(G)
        active_cycle_edges = {e for c in cycles for e in c}
        stress_map = build_stress_map(cycles)

        legal_additions = find_legal_addition_sites(G)
        A: Set[Tuple[Tuple[int, int], int]] = set()
        for (u, v), H_new, (node_v, node_w, node_u) in legal_additions:
            s_add = stress_map.get(node_v, 0) + stress_map.get(node_w, 0) + stress_map.get(node_u, 0)
            if random.random() < math.exp(-mu * s_add):
                A.add(((u, v), H_new))

        D: Set[Tuple[int, int]] = set()
        for cycle in cycles:
            cycle_nodes = {x for edge in cycle for x in edge}
            s_del = max(0, sum(stress_map.get(x, 0) for x in cycle_nodes) - 1)
            Q_del = min(1.0, 0.5 * (1.0 + lam * s_del) * math.exp(-mu * s_del))
            if random.random() < Q_del:
                D.add(random.choice(cycle))

        A_edges = {e for e, _ in A}
        assert A_edges.isdisjoint(D), "Invariant Violated: A_edges and D overlap"
        assert D.issubset(active_cycle_edges), "Invariant Violated: Deletion of non-cycle edge"
        assert all(u != v for u, v in A_edges), "Invariant Violated: Self-loop in additions"
        assert all((v, u) not in A_edges for u, v in A_edges), "Invariant Violated: Reciprocal additions"

        A_filtered = {((u, v), H_new) for (u, v), H_new in A if (v, u) not in A_edges and u != v}
        for (u, v), H_new in A_filtered:
            G.add_edge(u, v, H=H_new)
        for u, v in D:
            if G.has_edge(u, v):
                G.remove_edge(u, v)

        if not A and not D and len(cycles) == 0:
            assert nx.is_directed_acyclic_graph(G), "Terminal state is not a DAG"
            break

    print("  [PASS] All Microscopic Invariants & Lean Properties Verified Cleanly.")
    return True


# =============================================================================
# 7. CLI ENTRY POINT & TABLE GENERATORS
# =============================================================================

def run_canonical_slice_cli(runs: int = 100, N: int = 100, workers: int = None):
    """Reproduces Table 4: Median Density Collapse along the mu=0.40 Canonical Slice."""
    priors = compute_analytical_priors()
    mu = 0.40
    lambdas = [0.8, 1.1, 1.4, 1.7, 2.0, 2.3, 2.6, 2.9, 3.2, 3.5, 3.8, 4.1]
    w = workers or max(1, (os.cpu_count() or 4) - 1)

    print(f"\nExecuting Canonical Slice Sweep (mu={mu:.2f}, {len(lambdas)} points, runs={runs}/pt, workers={w})...")
    
    header = f"{'lambda':>8} | {'p_surv':>8} | {'<rho>_all':>10} | {'Median rho':>12} | {'<rho>_QSD':>10} | {'<N3>_QSD':>10}"
    print("\n" + "=" * 75)
    print("TABLE 4: CANONICAL SLICE DENSITY METRICS (mu = 0.40, N = 100)")
    print("=" * 75)
    print(header)
    print("-" * 75)

    with ProcessPoolExecutor(max_workers=w) as ex:
        for lam in lambdas:
            jobs = [(i + 1, N, mu, lam, 42 * 10007 + int(lam * 100) * 199 + i * 31) for i in range(runs)]
            results = list(ex.map(_worker_trajectory, jobs))
            n3_vals = [r["n3_final"] for r in results]
            moments = compute_qsd_moments(n3_vals, N)
            print(f"{lam:8.1f} | {moments['p_surv']:8.3f} | {moments['mean_rho_all']:10.4f} | {moments['median_rho_all']:12.4f} | {moments['mean_rho_qsd']:10.4f} | {moments['mean_n3_qsd']:10.2f}")
    print("=" * 75)


def run_scar_diagnostics_cli(runs: int = 100, N: int = 100, workers: int = None):
    """Reproduces Table 5: Topological Scar Accumulation and Degree Saturation Invariants."""
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]
    w = workers or max(1, (os.cpu_count() or 4) - 1)

    print(f"\nExecuting Scar & Degree Invariant Diagnostics (N={N}, mu={mu:.4f}, lambda={lam:.4f}, runs={runs}, workers={w})...")
    jobs = [(i + 1, N, mu, lam, 42 * 10007 + i * 31) for i in range(runs)]
    with ProcessPoolExecutor(max_workers=w) as ex:
        results = list(ex.map(_worker_trajectory, jobs))

    edges_all = [r["total_edges"] for r in results]
    scars_all = [r["scar_edges"] for r in results]
    degs_all = [r["mean_deg"] for r in results]
    diams_all = [r["diameter"] for r in results if r["diameter"] > 0]
    steps_all = [r["steps"] for r in results]

    print("\n" + "=" * 75)
    print("TABLE 5: TOPOLOGICAL SCAR ACCUMULATION & DEGREE SATURATION (N = 100)")
    print("=" * 75)
    print(f"  Mean Total Final Edges <|E|>    : {statistics.fmean(edges_all):6.2f} +/- {statistics.stdev(edges_all):.2f}")
    print(f"  Mean Frozen Scar Edges <|E_scar|>: {statistics.fmean(scars_all):6.2f} +/- {statistics.stdev(scars_all):.2f}")
    print(f"  Mean Undirected Degree <k>      : {statistics.fmean(degs_all):6.3f} +/- {statistics.stdev(degs_all):.3f}")
    if diams_all:
        print(f"  Mean Network Diameter <diam>    : {statistics.fmean(diams_all):6.2f} +/- {statistics.stdev(diams_all):.2f}")
    print(f"  Mean Trajectory Duration        : {statistics.fmean(steps_all):6.1f} +/- {statistics.stdev(steps_all):.1f} ticks")
    print("=" * 75)


def run_sweep_cli(runs_per_point: int = 20, N: int = 100, workers: int = None):
    """Reproduces Table 2: 132-Point Parameter Sweep Matrix over (mu, lambda)."""
    mus = [0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65]
    lambdas = [0.8, 1.1, 1.4, 1.7, 2.0, 2.3, 2.6, 2.9, 3.2, 3.5, 3.8, 4.1]
    w = workers or max(1, (os.cpu_count() or 4) - 1)

    print(f"\nExecuting Parameter Sweep ({len(mus)}x{len(lambdas)}={len(mus)*len(lambdas)} grid, {runs_per_point} runs/cell, workers={w})...")
    
    # Header
    col_headers = "".join(f" | {l:4.1f}" for l in lambdas)
    print("\n" + "=" * 90)
    print("TABLE 2: UNCONDITIONED MEAN CYCLE DENSITY <rho> (N = 100)")
    print("=" * 90)
    print(f" mu \\ lam" + col_headers)
    print("-" * 90)

    with ProcessPoolExecutor(max_workers=w) as ex:
        for mu in mus:
            row_str = f"  {mu:4.2f}  "
            for lam in lambdas:
                jobs = [(i + 1, N, mu, lam, 42 * 10007 + int(mu * 1000) * 37 + int(lam * 100) * 199 + i * 31) for i in range(runs_per_point)]
                results = list(ex.map(_worker_trajectory, jobs))
                n3_vals = [r["n3_final"] for r in results]
                mean_rho = statistics.fmean(n3_vals) / float(N)
                row_str += f" | {mean_rho:5.3f}"
            print(row_str)
    print("=" * 90)


def run_design_point_cli(runs: int = 100, N: int = 100, workers: int = None):
    """Reproduces Table 3: Moments of 3-Cycle Activity at Canonical Design Point."""
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]
    w = workers or max(1, (os.cpu_count() or 4) - 1)

    print(f"\nExecuting Design Point Ensemble: N={N}, mu={mu:.4f}, lambda={lam:.4f}, runs={runs}, workers={w}...")
    jobs = [(i + 1, N, mu, lam, 42 * 10007 + i * 31) for i in range(runs)]
    with ProcessPoolExecutor(max_workers=w) as ex:
        results = list(ex.map(_worker_trajectory, jobs))

    n3_vals = [r["n3_final"] for r in results]
    moments = compute_qsd_moments(n3_vals, N)

    print("\n" + "=" * 75)
    print(f"TABLE 3: MOMENTS OF 3-CYCLE ACTIVITY AT CANONICAL POINT (mu0, lambda0)")
    print("=" * 75)
    print(f"  Unconditioned Mean Density <rho>  : {moments['mean_rho_all']:.4f} +/- {moments['std_rho_all']/math.sqrt(runs):.4f}")
    print(f"  Unconditioned Median Density      : {moments['median_rho_all']:.4f}")
    print(f"  Survival Fraction p_surv          : {moments['p_surv']:.3f} +/- {moments['p_surv_se']:.3f} (Surviving runs: {int(moments['n_surv'])}/{runs})")
    print(f"  Conditioned QSD Mean Density      : {moments['mean_rho_qsd']:.4f} +/- {moments['mean_rho_qsd_se']:.4f}")
    print(f"  Conditioned QSD Median Density    : {moments['median_rho_qsd']:.4f}")
    print(f"  Conditioned QSD Mean Cycles <N3>  : {moments['mean_n3_qsd']:.2f}")
    print(f"  QSD Fano Factor Var(N3)/<N3>      : {moments['fano_qsd']:.2f}")
    print(f"  Skewness gamma                    : {moments['skew_rho_all']:.3f}")
    print("=" * 75)


def main():
    parser = argparse.ArgumentParser(description="QBD Standalone Reference Simulation Engine")
    parser.add_argument("--priors", action="store_true", help="Print Table 1 (Analytical Reference Priors)")
    parser.add_argument("--test-invariants", action="store_true", help="Run property-based mathematical verification")
    parser.add_argument("--design-point", action="store_true", help="Run Table 3 Design Point Ensemble")
    parser.add_argument("--canonical-slice", action="store_true", help="Run Table 4 Canonical Slice Sweep")
    parser.add_argument("--scar-diagnostics", action="store_true", help="Run Table 5 Scar & Degree Diagnostics")
    parser.add_argument("--sweep", action="store_true", help="Run Table 2 Parameter Sweep Matrix")
    parser.add_argument("--runs", type=int, default=100, help="Number of trajectories per cell (default: 100)")
    parser.add_argument("-N", "--N", type=int, default=100, help="Graph size (default: 100)")
    parser.add_argument("--workers", type=int, default=None, help="Worker count")

    args = parser.parse_args()

    if args.priors:
        priors = compute_analytical_priors()
        print("\n" + "=" * 70)
        print("TABLE 1: CANONICAL ANALYTICAL REFERENCE PRIORS")
        print("=" * 70)
        for k, v in priors.items():
            print(f"  {k:<16}: {v:12.6f}")
        print("=" * 70)

    if args.test_invariants:
        print("\nRunning Microscopic Move Grammar & Invariant Verification...")
        test_engine_invariants(num_ticks=50, N=args.N)

    if args.design_point:
        run_design_point_cli(runs=args.runs, N=args.N, workers=args.workers)

    if args.canonical_slice:
        run_canonical_slice_cli(runs=args.runs, N=args.N, workers=args.workers)

    if args.scar_diagnostics:
        run_scar_diagnostics_cli(runs=args.runs, N=args.N, workers=args.workers)

    if args.sweep:
        run_sweep_cli(runs_per_point=args.runs, N=args.N, workers=args.workers)

    if not any([args.priors, args.test_invariants, args.design_point, args.canonical_slice, args.scar_diagnostics, args.sweep]):
        priors = compute_analytical_priors()
        print("=" * 70)
        print("QBD STANDALONE REFERENCE ENGINE: CANONICAL PRIORS")
        print("=" * 70)
        for k, v in priors.items():
            print(f"  {k:<16}: {v:12.6f}")
        print("=" * 70)
        print("\nVerifying Invariants...")
        test_engine_invariants(num_ticks=50, N=100)
        print("\nCLI Options:")
        print("  --priors            : Table 1 (Constitutive scales)")
        print("  --design-point      : Table 3 (QSD moments at mu0, lambda0)")
        print("  --canonical-slice   : Table 4 (Density transition along lambda)")
        print("  --scar-diagnostics  : Table 5 (Frozen scars & degree saturation)")
        print("  --sweep             : Table 2 (132-point parameter sweep)")
        print("  --test-invariants   : Property-based Lean-mirrored unit tests")


if __name__ == "__main__":
    main()
