-- ============================================================================
-- QUANTUM BRAID DYNAMICS: CONTINUUM DERIVATIVE & MATHLIB STABILITY SUITE
-- Formal Real-Analysis Calculus Proofs for Section 5.2.3 & Section 5.4
-- Requires: Mathlib.Analysis.Calculus.Deriv.Basic (Mathlib v4.33.1)
-- ============================================================================

import Mathlib.Data.Real.Basic
import Mathlib.Analysis.Calculus.Deriv.Basic
import Mathlib.Analysis.Calculus.Deriv.Polynomial
import Mathlib.Analysis.SpecialFunctions.Exp
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Basic
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.Ring

/-- Unpumped master equation polynomial drift rate f(lam, ρ) = (9 - 3*lam)ρ² - (1/2)ρ. -/
noncomputable def drift_rate (lam : ℝ) (ρ : ℝ) : ℝ :=
  (9 - 3 * lam) * ρ^2 - (1 / 2) * ρ

/--
THEOREM M.1: Linear Stability of the Absorbing Vacuum
Formally proves that the Fréchet derivative of the polynomial drift at ρ = 0 is strictly -1/2 < 0.
-/
theorem absorbing_vacuum_linear_stability (lam : ℝ) :
    HasDerivAt (drift_rate lam) (- (1 / 2)) 0 := by
  unfold drift_rate
  have h1 : HasDerivAt (fun ρ : ℝ => (9 - 3 * lam) * ρ^2) 0 0 :=
    ((hasDerivAt_pow 2 (0 : ℝ)).const_mul (9 - 3 * lam)).congr_deriv (by simp)
  have h2 : HasDerivAt (fun ρ : ℝ => (1 / 2 : ℝ) * ρ) (1 / 2) 0 :=
    ((hasDerivAt_id (0 : ℝ)).const_mul (1 / 2 : ℝ)).congr_deriv (by simp)
  exact (h1.sub h2).congr_deriv (by simp)

/-- Critical nucleation barrier function rho_c(lam) = 1 / (2*(9 - 3*lam)). -/
noncomputable def rho_c (lam : ℝ) : ℝ := 1 / (2 * (9 - 3 * lam))

/--
THEOREM M.2: Strict Monotonicity of the Nucleation Barrier
Proves that the critical nucleation threshold ρ_c(λ) is strictly increasing for all λ ∈ [0, 3).
-/
theorem nucleation_barrier_strictly_increasing (lam₁ lam₂ : ℝ)
    (_h1 : 0 ≤ lam₁) (h_order : lam₁ < lam₂) (h2 : lam₂ < 3) :
    rho_c lam₁ < rho_c lam₂ := by
  dsimp [rho_c]
  have denom1_pos : 0 < 2 * (9 - 3 * lam₁) := by linarith
  have denom2_pos : 0 < 2 * (9 - 3 * lam₂) := by linarith
  have denom_strict : 2 * (9 - 3 * lam₂) < 2 * (9 - 3 * lam₁) := by linarith
  exact (one_div_lt_one_div denom1_pos denom2_pos).mpr denom_strict

/--
THEOREM M.3: Sub-Critical Extinction Basin Negativity
Proves that for any sub-critical density 0 < ρ < ρ_c, the drift rate is strictly negative.
-/
theorem unpumped_nucleation_basin (lam ρ : ℝ)
    (_hlam : lam < 3)
    (hρ_pos : 0 < ρ)
    (hρ_sub : ρ < 1 / (2 * (9 - 3 * lam))) :
    (9 - 3 * lam) * ρ ^ 2 - (1 / 2) * ρ < 0 := by
  have h_denom : 0 < 2 * (9 - 3 * lam) := by linarith
  have h_factor : (9 - 3 * lam) * ρ - 1 / 2 < 0 := by
    have h1 : ρ * (2 * (9 - 3 * lam)) < 1 := (lt_div_iff₀ h_denom).mp hρ_sub
    linarith
  calc
    (9 - 3 * lam) * ρ ^ 2 - (1 / 2) * ρ = ρ * ((9 - 3 * lam) * ρ - 1 / 2) := by ring
    _ < 0 := mul_neg_of_pos_of_neg hρ_pos h_factor

noncomputable def mu_0 : ℝ := 1 / Real.sqrt (2 * Real.pi)
noncomputable def lambda_0 : ℝ := Real.exp 1 - 1
noncomputable def lambda_death (μ : ℝ) : ℝ := Real.exp (2 * μ) - (1 / 2)

/--
THEOREM M.4: Sub-Critical Isolated Death Margin
Proves that the canonical catalysis parameter λ₀ sits strictly below the isolated death line λ_death(μ₀).
-/
theorem isolated_death_line_gap
    (h_e : Real.exp 1 ≤ 2.7183)
    (h_exp_2mu : 2.2208 ≤ Real.exp (2 * mu_0)) :
    lambda_0 < lambda_death mu_0 := by
  dsimp [lambda_0, lambda_death]
  linarith
