"""
Section 3.5.4 triad occupancy checks S1, S2, S3 and volume operator V.
Also locks the even-overlap 000 -> 111 fact and the rejection of Pi_order.
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from vacuum_phase_engine import (
    TRIAD_OCCUPANCY_EXPECTED,
    TRIAD_OCCUPANCY_TABLE,
    pi_order_eigenvalue,
    triad_occupancy_checks,
)


def test_eight_row_triad_table_matches_section_354():
    assert len(TRIAD_OCCUPANCY_TABLE) == 8
    for q12, q23, q31, _name, _phys in TRIAD_OCCUPANCY_TABLE:
        got = triad_occupancy_checks(q12, q23, q31)
        assert got == TRIAD_OCCUPANCY_EXPECTED[(q12, q23, q31)]


def test_vacuum_and_geometry_share_zz_syndrome_split_by_volume():
    s_vac = triad_occupancy_checks(0, 0, 0)
    s_geo = triad_occupancy_checks(1, 1, 1)
    assert s_vac[:3] == (1, 1, 1)
    assert s_geo[:3] == (1, 1, 1)
    assert s_vac[3] == 1
    assert s_geo[3] == -1


def test_completing_three_cycle_has_even_overlap_with_each_si():
    """Delta E = {e12, e23, e31}; supp(S1)={e12,e23} has even intersection, etc."""
    supports = (
        {0, 1},  # S1 = Z12 Z23
        {1, 2},  # S2 = Z23 Z31
        {2, 0},  # S3 = Z31 Z12
    )
    delta_e = {0, 1, 2}
    for supp in supports:
        assert len(delta_e & supp) % 2 == 0
    assert len(delta_e) % 2 == 1  # V has odd support


def test_pi_order_annihilates_geometry_and_is_excluded_from_allowed_set():
    for q12, q23, q31, _name, _phys in TRIAD_OCCUPANCY_TABLE:
        eig = pi_order_eigenvalue(q12, q23, q31)
        if (q12, q23, q31) == (1, 1, 1):
            assert eig == 0
        else:
            assert eig == 1
