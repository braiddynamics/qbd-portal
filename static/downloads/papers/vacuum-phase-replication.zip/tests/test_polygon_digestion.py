"""
Theorem 2.2.8 / Table 1: isolated k-cycle polygon digestion.
"""

import sys
import os
import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from vacuum_phase_engine import (
    TABLE_1_DIGESTION,
    max_simple_cycle_length,
    reduce_directed_k_cycle,
    run_reduction_protocol,
)


@pytest.mark.parametrize("k", list(range(4, 13)))
def test_table1_add_delete_counts(k):
    adds, dels = run_reduction_protocol(k)
    exp_add, exp_del, exp_total = TABLE_1_DIGESTION[k]
    assert adds == exp_add
    assert dels == exp_del
    assert adds + dels == exp_total
    assert adds == k


@pytest.mark.parametrize("k", list(range(4, 13)))
def test_digestion_terminates_at_simplicial_ground_state(k):
    G, _adds, _dels = reduce_directed_k_cycle(k)
    assert max_simple_cycle_length(G) <= 3


def test_deletions_bounded_for_large_defects():
    for k in range(7, 13):
        _adds, dels = run_reduction_protocol(k)
        assert dels <= 3
