"""
Unit tests for Category Hist Cumulative Trajectories, Deletion Indelibility,
and Automorphism Preservation under Maximal Parallelism (Paper §3.3, §4.1, §4.2, Lean Theorems 5.3, 5.4, 6.6–6.10).
"""

import math
import random
import pytest
import networkx as nx
import sys
import os

# Add parent directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from vacuum_phase_engine import (
    compute_analytical_priors,
    generate_bethe_fragment,
    inject_seed_defect,
    find_all_3_cycles,
    find_legal_addition_sites,
    build_stress_map,
)


def test_hist_cumulative_edge_monotonicity_and_deletion_indelibility():
    """
    Validates Definition 4.1.2, Lemma 4.1.3, and Lean 4 Theorems 6.8–6.10:
    1. The cumulative edge set E(H_t) is strictly monotonically non-decreasing: E(H_t) ⊆ E(H_{t+1}).
    2. Active spatial edge count |E(G_t)| fluctuates and drops under deletions (E(G_{t+1}) ⊊ E(G_t)).
    3. Every deleted kinematic edge is permanently retained in the historical record E(H_{t+1}).
    """
    random.seed(42)
    priors = compute_analytical_priors()
    mu, lam = priors["mu_0"], priors["lambda_0"]

    G, levels = generate_bethe_fragment(60)
    G = inject_seed_defect(G, levels)

    # Initialize cumulative history record H_0 = E(G_0)
    H_edges = set(G.edges())
    timestamps = {e: G.edges[e].get("H", 0) for e in G.edges()}

    had_deletion_event = False

    for tick in range(1, 41):
        prev_G_edges = set(G.edges())
        prev_H_edges = set(H_edges)

        cycles = find_all_3_cycles(G)
        stress_map = build_stress_map(cycles)
        legal_additions = find_legal_addition_sites(G)

        # Propose additions
        A = set()
        for (u, v), H_new, (node_v, node_w, node_u) in legal_additions:
            s_add = stress_map.get(node_v, 0) + stress_map.get(node_w, 0) + stress_map.get(node_u, 0)
            if random.random() < math.exp(-mu * s_add):
                A.add(((u, v), H_new))

        # Propose deletions
        D = set()
        for cycle in cycles:
            cycle_nodes = {x for edge in cycle for x in edge}
            s_del = max(0, sum(stress_map.get(x, 0) for x in cycle_nodes) - 1)
            Q_del = min(1.0, 0.5 * (1.0 + lam * s_del) * math.exp(-mu * s_del))
            if random.random() < Q_del:
                D.add(random.choice(cycle))

        A_edges = {e for e, _ in A}
        A_filtered = {((u, v), H_new) for (u, v), H_new in A if (v, u) not in A_edges and u != v}

        # Step 3: Add additions
        for (u, v), H_new in A_filtered:
            G.add_edge(u, v, H=H_new)
            H_edges.add((u, v))
            timestamps[(u, v)] = H_new

        # Step 4: Delete edges
        for u, v in D:
            if G.has_edge(u, v):
                had_deletion_event = True
                G.remove_edge(u, v)

        current_G_edges = set(G.edges())

        # 1. Monotonicity of H_t: prev_H_edges must be a subset of current H_edges
        assert prev_H_edges.issubset(H_edges), f"Tick {tick}: Cumulative history violated monotonicity!"
        assert len(H_edges) >= len(prev_H_edges), f"Tick {tick}: Cumulative history size decreased!"

        # 2. Deletion indelibility: Every deleted edge must still be present in H_t
        for del_edge in D:
            assert del_edge not in current_G_edges, f"Tick {tick}: Deleted edge {del_edge} remained in G_t!"
            assert del_edge in H_edges, f"Tick {tick}: Deleted edge {del_edge} was erased from H_t!"

        # 3. Spatial state G_t is an active subgraph of cumulative history H_t
        assert current_G_edges.issubset(H_edges), f"Tick {tick}: Active graph G_t contains edges not in H_t!"

    assert had_deletion_event, "Test expected at least one topological deletion event during evolution."


def test_automorphism_preservation_maximal_parallelism():
    """
    Validates Theorem 3.3.2 and Lean 4 Theorems 5.3 & 5.4:
    1. An automorphism φ of G_0 is preserved in Aut(G_0 ∪ A) if the proposal set A is φ-equivariant.
    2. An automorphism φ of G_0 is strictly broken if the proposal set A splits the orbit of φ.
    """
    # Construct a symmetric directed tree fragment with root 0
    # Branch 1 (left): 0 -> 1 -> 3
    # Branch 2 (right): 0 -> 2 -> 4
    G_base = nx.DiGraph()
    edges = [(0, 1), (0, 2), (1, 3), (2, 4)]
    G_base.add_edges_from(edges)

    # Base graph has automorphism φ swapping the branches: 0 -> 0, 1 <-> 2, 3 <-> 4
    phi = {0: 0, 1: 2, 2: 1, 3: 4, 4: 3}

    # Verify φ is an automorphism of G_base
    for u, v in G_base.edges():
        assert G_base.has_edge(phi[u], phi[v]), "φ must be a valid automorphism of G_base!"

    # Case A: Orbit-Complete Parallel Addition (Theorem 3.3.2 Sufficiency & Lean Theorem 5.3)
    # Propose chord additions simultaneously on compliant 2-paths on both branches:
    # 2-path (0 -> 1 -> 3) yields chord (3, 0); 2-path (0 -> 2 -> 4) yields chord (4, 0)
    G_parallel = G_base.copy()
    G_parallel.add_edge(3, 0)
    G_parallel.add_edge(4, 0)

    # Verify φ remains an automorphism of G_parallel
    for u, v in G_parallel.edges():
        assert G_parallel.has_edge(phi[u], phi[v]), "Orbit-complete update must preserve φ in Aut(G_parallel)!"

    # Case B: Orbit-Splitting Serial Addition (Theorem 3.3.2 Necessity & Lean Theorem 5.4)
    # Propose chord addition ONLY on branch 1 ((3, 0)) while omitting branch 2 ((4, 0))
    G_serial = G_base.copy()
    G_serial.add_edge(3, 0)

    # Verify φ is strictly broken in G_serial
    has_broken_edge = any(not G_serial.has_edge(phi[u], phi[v]) for u, v in G_serial.edges())
    assert has_broken_edge, "Orbit-splitting update must break the automorphism φ in G_serial!"
    assert not G_serial.has_edge(phi[3], phi[0]), "(4, 0) is missing in G_serial despite (3, 0) being present!"


def test_historical_inclusion_and_timestamp_acyclicity():
    """
    Validates Theorem 4.2.1:
    In the cumulative trajectory category Hist, directed path timestamps are strictly increasing,
    precluding causal cycles across cumulative history H_t.
    """
    G = nx.DiGraph()
    # Path: 0 -> 1 -> 2 -> 3 with increasing timestamps
    G.add_edge(0, 1, created_at=1)
    G.add_edge(1, 2, created_at=2)
    G.add_edge(2, 3, created_at=3)

    # Any simple path has strictly increasing timestamps
    paths = list(nx.all_simple_paths(G, 0, 3))
    for p in paths:
        ts = [G.edges[p[i], p[i+1]]["created_at"] for i in range(len(p)-1)]
        assert all(ts[i] < ts[i+1] for i in range(len(ts)-1)), "Timestamps along causal path must be strictly increasing!"
