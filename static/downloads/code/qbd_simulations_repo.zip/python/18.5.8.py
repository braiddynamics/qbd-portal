# §18.5.8 — Flatness Attractor Stability

import numpy as np
import pandas as pd

def run_flatness_stabilization(initial_curvatures=[-0.5, -0.2, 0.2, 0.5], t_max=60.0, dt=10.0):
    """
    Simulates the restoration of spatial flatness from arbitrary initial perturbations.
    
    The spatial curvature obeys:
      Omega_k(t) = Omega_k0 * exp(J * t)
      where the Jacobian eigenvalue at the stable attractor is J ≈ -0.33292.
    """
    # 1. Vacuum Parameters
    Lambda = 0.015625
    mu = 1.0 / np.sqrt(2.0 * np.pi)
    lcat = np.e - 1.0
    rho_star = 0.037061
    
    # 2. Analytical Jacobian derivative calculation
    # F(rho) = (Lambda + 9*rho^2)*e^(-6*mu*rho) - 0.5*rho - 3*lcat*rho^2
    term1 = (18 * rho_star - 6 * mu * (Lambda + 9 * (rho_star ** 2))) * np.exp(-6 * mu * rho_star)
    term2 = 0.5 + 6 * lcat * rho_star
    J = term1 - term2
    
    steps = int(t_max / dt)
    results = []
    
    for step in range(steps + 1):
        t = step * dt
        damping = np.exp(J * t)
        
        # Calculate current curvature for each initial value
        curv_vals = [Omega0 * damping for Omega0 in initial_curvatures]
        
        results.append({
            "Time t": f"{t:.1f}",
            "Damping e^(Jt)": f"{damping:.4e}",
            "Curv [Omega0=-0.5]": f"{curv_vals[0]:.6f}",
            "Curv [Omega0=-0.2]": f"{curv_vals[1]:.6f}",
            "Curv [Omega0=+0.2]": f"{curv_vals[2]:.6f}",
            "Curv [Omega0=+0.5]": f"{curv_vals[3]:.6f}"
        })
        
    return results, J

def run_flatness():
    print("-" * 72)
    print("§18.5.8 Flatness Attractor Stability")
    print("Verifying Jacobian Linearization and Curvature Relaxation")
    print("-" * 72)
    
    results, J = run_flatness_stabilization()
    df = pd.DataFrame(results)
    print(df.to_markdown(index=False, tablefmt="github"))
    print("-" * 72)
    print("Analysis:")
    print(f"Calculated Jacobian Eigenvalue J: {J:.5f}")
    print("Regardless of the initial spatial curvature (positive or negative),")
    print("the negative feedback of the Master Equation dampens the perturbation.")
    print("Over 60 ticks of logical proper time, the spatial curvature is suppressed")
    print("by a factor of 2.2e-9 (e^-20), driving the universe to perfect flatness.")
    print("-" * 72)

if __name__ == "__main__":
    run_flatness()
